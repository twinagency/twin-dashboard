# SENDER_INVENTORY.md

P0 deliverable: every receiver, reply generator, scheduled sender, manual-send path, payment path,
content source and dashboard control that can read or write Telegram-visible state or money for the
selected bot, with its owner and its migration disposition.

All evidence is `BOT_ROOT = bot/` (local `main` @ `f414f32`) unless a path says otherwise. Line
numbers are from that revision and will drift; verify the file, not the number.

Disposition vocabulary from plan sections 8 and 13:

- **retain** - keeps working unchanged.
- **gateway** - keeps its obligation but must be re-driven through the single Fastt delivery authority.
- **replace** - legacy generator is disabled for migrated conversations; behaviour is mapped to Fastt.
- **unsupported** - no Telegram equivalent; must be explicitly disabled, never fabricated.

---

## 1. Inbound receivers (`bot/src/index.ts`, `registerCloneHandlers` L344)

Registration order is load-bearing: the four payment handlers sit **above** the two conversational
handlers because a grammY middleware that returns without `next()` ends the chain, so a
conversational handler registered first would swallow `successful_payment` (documented in-file at
L357-389, and proven by `src/dev/check-payment-handler-reachable.ts`).

| # | Registration | Line | Purpose | Owner | Disposition |
|---|---|---|---|---|---|
| R1 | `bot.on("business_connection", ...)` | 352 | record the business account username on connect/change | Node gateway | retain |
| R2 | `bot.on("pre_checkout_query", ...)` | 391 | currently approves positive XTR without buyer/order validation | Node settlement | strengthen in P3B: bounded exact order/buyer/payload check within 10 seconds; preserve valid legacy products |
| R3 | `bot.on("message:successful_payment", ...)` | 402 | direct-chat payment fulfilment | Node settlement | retain |
| R4 | `bot.on("business_message:successful_payment", ...)` | 422 | business-connection invoice fulfilment | Node settlement | retain |
| R5 | `bot.on("business_message", ...)` | 442 | **the** persona conversation channel (Business only) | Fastt (after migration) | replace - route to engine |
| R6 | `bot.on("message", ...)` | 461 | plain bot chat; refused unless `TWIN_ALLOW_PLAIN_CHAT=1` | Fastt (after migration) | replace - route to engine |
| - | `bot.catch(...)` | 463 | error sink to `system_logs` | Node | retain |

`allowed_updates` (L548) includes `edited_message`, `edited_business_message`,
`deleted_business_messages` and `callback_query` even though no handler consumes them today. Plan
section 7.3 requires these become *distinct events* with explicit handling, not silently dropped -
a P2/P4 obligation, flagged here.

### 1.1 Receiver-owned identity and admission

| Concern | Today | Where |
|---|---|---|
| Which clone | `store.getCloneByBotToken(msg.botToken)` fresh per message (no cache) | `handler.ts:240` |
| Duplicate suppression | `store.markUpdateSeen(msg.updateId)` - **global PK on `update_id`** (`processed_updates`) | `handler.ts:234`, `db/schema.sql:463` |
| Fan lookup/creation | `getUser` / `createUser` scoped by `(cloneId, telegramId)` | `handler.ts:255-268` |

**Finding (defect, for the record).** `processed_updates(update_id)` is a single global primary key.
Telegram `update_id`s are **per bot**, so two different bots can each send `update_id = 100` and the
second is wrongly treated as a duplicate. This has not been observed to bite (the fleet may not yet
have colliding ids in the retry window), but the P1 `telegram_events` record fixes it by keying on
**(bot id, update id)**. Recorded here so the fix is attributed, not silently made.

Also note: `markUpdateSeen` is called only inside the conversational path. The payment handlers
(R2-R4) and the business-connection handler (R1) do **not** call it; payment idempotency is instead
enforced by charge-id dedup downstream (`payments.ts`, `star-reconcile.ts`).

---

## 2. Reply generators (compose fan-visible output)

| Generator | File | Trigger | Owner after migration | Disposition |
|---|---|---|---|---|
| Main turn | `handler.ts` -> `flows/router.ts` -> `flows/{text,voice,vision,media,bundle,discount,vip,spoil,human,smart,silence-fallback,locked-caption,bonus-photo,offer-*}` | inbound message | Fastt | replace |
| Payment reaction | `star-reconcile.ts` (`reactToPayment`) and `payments.ts` tail | money received | Fastt (reaction) / Node (settlement) | gateway |
| Campaign drip | `campaign.ts` (`runCampaignOnce`) | 5-min tick, hours-quiet steps | Fastt scheduler | replace |
| Onboarding | `onboarding.ts` (`runFreePreviewOnce` + in-turn steps) | 5-min tick + in-turn count trigger | Fastt scheduler | replace |
| Follow-up nudge | `followup.ts` (`runFollowupOnce`) | 60-s tick, one-shot per hang | Fastt scheduler | replace |
| Manual operator send | `manual-send.ts` (`runManualSendOnce`) | 10-s tick over `manual_sends` | Node delivery authority | gateway |
| Welcome/return | inside flows/onboarding | `/start`, first message | Fastt | replace |

The plan (section 8) requires **one** durable action ID per emitted bubble and the retirement of the
legacy generators listed as "replace" for migrated conversations. Until a conversation is migrated,
those generators stay as-is (disabled-by-default migration).

---

## 3. Scheduled senders (timers)

All recurring work goes through `services/scheduler.ts` (`createFleetScheduler`), which the plan
quotes as the model for bounded, in-flight-guarded background work with a separate payments lane.

| Job | Interval | Line | Lane | Work |
|---|---|---|---|---|
| `campaign` | 5 min | 636 | background | `runCampaignOnce`, `runFreePreviewOnce`, `expireLapsedSubscriptions` |
| `followup` | 60 s | 669 | background | `runFollowupOnce` |
| `manual-send` | 10 s | 684 | background | `runManualSendOnce` |
| `star-reconcile` | 60 s | 725 | **payments** | `reconcileStarPayments` per clone |
| `secrets-reload` | 60 s | 821 | none (guarded) | `loadSecrets` from `app_settings` |
| `clone-reconcile` | 30 s | 831 | none | `reconcile()` launch/stop bots |
| `trace-prune` | 24 h | 838 | none | `pruneTraceLogs()` |
| `scheduler-stats` | 10 min | 843 | none | `console.log(scheduler.statsLine())` |

Plus a boot-time one-shot: `reconcileStarPayments(..., {notify:false})` in `bot.start({onStart})`
(L562) - a historical back-fill that must not DM the fan.

Plan section 7.7 requires the payment lane to keep running while conversation generation is paused.
`star-reconcile` already has its own lane and permits, which is the property to preserve.

---

## 4. Manual-send path (operator)

| Step | Where |
|---|---|
| Compose | dashboard `app/users/actions.ts` -> `manualSendText` / `manualSendVoice` / `manualSendPhoto` INSERT a `pending` row into `manual_sends` (L157/177/198) |
| Consume | bot `manual-send.ts` `runManualSendOnce` on the 10-s tick |
| Gates | `outboundVerdict(user)` (24 h window, blocked, inactive, unreachable) **before** composing/TTS; re-checks `user.paused` at send time; paid photos are refused (free-only) |
| Deliver | `send.sendText` / `send.sendVoice` / `send.sendFreeMedia`; history appended with `meta.flow = "manual"` |

Plan section 13 requires manual commands to claim the **same** delivery authority and to append only
confirmed output to history. Retained obligation; the polled-table pattern is the established
cross-box mechanism (`manual-send.ts` header explains why there is no HTTP call path).

---

## 5. Payment and fulfillment paths

| Path | File | Trigger | Settlement owner |
|---|---|---|---|
| Pre-checkout answer | `payments.ts` `handlePreCheckout` | `pre_checkout_query` | Node |
| Direct successful payment | `payments.ts` `handleSuccessfulPayment` | `message:successful_payment` | Node |
| Business successful payment | same function, called from R4 | `business_message:successful_payment` | Node |
| **Stars reconciler (primary credit path)** | `star-reconcile.ts` `reconcileStarPayments` | 60-s tick + boot back-fill | Node |
| VIP subscription grant | `subscription-grant.ts` `grantSubscriptionPayment` | both payment paths | Node |
| Subscription lapse sweep | `store.expireLapsedSubscriptions` | campaign tick | Node |
| Catalogue checkout (Stars) | `twin-dashboard/lib/catalogue-checkout.ts` | dash storefront | Node (via bot invoice) |
| Catalogue checkout (TON/external) | `twin-dashboard/lib/catalogue-ton.ts` | dash storefront | Node + external rail |
| Mini App catalogue | `twin-dashboard/lib/catalogue-commerce.ts`, `catalogue-owned-media.ts` | Mini App | Node |

Established invariants to preserve (from `bot/CLAUDE.md` rule 4 and `star-reconcile.ts`): dedup on
`charge_id`; never double-credit; business-connection invoices fire no `successful_payment` because
the reconciler is the primary path; canary one clone before the fleet. The plan (section 11) requires
these to keep their policy while exact normalized purchase events are projected to Fastt, and adds
the rule that a refund sharing the original payment id is a distinct transaction, not a suppressed
duplicate.

---

## 6. Content sources (catalogue and media)

| Source | Table / storage | Notes |
|---|---|---|
| Photos | `photos` + Supabase Storage object | per-clone; `is_free`, price, classification, caption, `visual_description`, `telegram_file_id` cache |
| Videos | `videos` | plus duration/dimensions where present |
| Photo bundles | `photo_bundles` + `photo_bundle_items` (ordered) | bundle price, ordered item ids |
| Catalogue bundles | `catalogue_bundles` (`photo_ids[]`) | distinct product source type; Mini App ids preserved |
| Catalogue checkout orders | `catalogue checkout orders` (via `lib/catalogue-checkout.ts`) | frozen product/price/composition |
| Telegram file cache | `photos.telegram_file_id`, `videos.telegram_file_id` | bot-scoped reuse only |

Plan section 10 requires one-way projection into Fastt's search index, freezing asset lists at offer
creation, and never deleting the projection on a source outage. The bot's `db/migrations` already
carries the media-link and bundle-price-cap migrations (`121_star_tx_media_link`,
`142_photo_bundle_price_cap`).

---

## 7. Dashboard controls (operator-facing, `DASHBOARD_ROOT = twin-dashboard/`)

| Control | Route / file | Effect on the bot | Disposition |
|---|---|---|---|
| Business-connection status (read-only) | `app/api/business-connection/route.ts` | none (info only); reads `users.business_connection_id` then Telegram `getBusinessConnection` | retain |
| Business account (read-only panel) | `app/info/BusinessConnectionCard.tsx` | none | retain |
| Fan block / pause / credits / counters | `app/users/actions.ts` | sets `users.blocked`, `users.paused`, credits | retain |
| Manual send (text/voice/photo) | `app/users/actions.ts` | inserts `manual_sends` | gateway |
| Clone toggles (photos/videos/voice/tips/subs/…) | `app/clones/toggle-fields.ts`, `app/clones/actions.ts` | typed `clones` columns read per message | retain, plus engine mapping |
| Model / API keys | Settings page -> `app_settings` | `loadSecrets` precedence (DB wins) | retain, plus per-purpose mapping (P2) |
| Catalogue editing | `app/catalogue/**`, `lib/catalogue-*.ts` | storefront + Mini App | retain |
| Media upload + caption | `app/media/actions.ts`, `lib/caption.ts` | writes `photos`/`videos`; upload-time vision | retain UI/files/human edits; replace automatic generator per asset in P3A; gate imports/backfills through same owner |
| Flows / intent experiment | `app/flows/**`, `lib/intent-*` | experiment arm assignment | retain, review at P4 |
| Admin read API | `app/api/admin/v1/**` | read-only over the same data | retain |
| Public read API | `app/api/v1/**` | read-only revenue/fan | retain |
| Agency / creator portals | `app/agency/**`, `app/creator/**` | clone scoping | retain; engine status still to be added (P4) |

Plan section 13 lists the engine-status UI (name, version, channel mode, requested vs effective
activation, projection freshness, worker health) as a **P4** deliverable. No dashboard code is
changed in P1.

---

## 8. Unsupported / out-of-scope Telegram paths (never fabricate)

From plan section 8's final row and section 12. These have **no** verified Telegram implementation
and must not be substituted:

- OnlyFans subscriber events, scraping, online-presence, feed posts, co-tags, Giphy-id handling.
- Telegram voice/media **generation** interpretation beyond what is already deployed (preserve the
  deployed entitlement/input path only).
- Any paid broadcast feature (disabled by this migration).
- Deliberate-typo / misspelling / word-distortion injection (owner preference: keep **off**).

---

## 9. Owner summary (P0 acceptance: every enabled writer has a named owner)

| Writer class | Owner | Notes |
|---|---|---|
| Inbound receive + routing | Node gateway | R1-R6 above |
| Conversation generation | Fastt Python worker | after migration; legacy engine until then |
| Delivery (all Telegram sends) | Node delivery authority | single authority; Fastt requests actions |
| Financial settlement + entitlements | Node (Supabase) | unchanged |
| Catalogue / content / Storage | Dashboard + Supabase | one-way projection to Fastt |
| Manual operator control | Node delivery authority | same authority as automatic sends |
| Scheduling | Fastt scheduler | replacing the legacy Node drips |

---

## 10. Routing ownership (P2-I1 helper implemented; review outstanding, 18 October 2026)

`bot/src/engines/engine-router.ts` is the intended single effective resolver for
the engine question. No production writer currently consumes its new resolver.
Its intended outcomes are `legacy` (positively unmigrated), `fastt` (positively
assigned and ready), or `held` (authority unknown or Fastt generation ineligible).
P2_INCREMENT4_REVIEW.md reproduces pilot-selection and persisted-control defects;
correct them before wiring. Identity registration must not create pilot permission.

| Writer class | Consults the resolver at | Held behaviour |
|---|---|---|
| Inbound receiver (`bot/src/index.ts`, `registerCloneHandlers`) | before the batcher is offered the message | not yet wired (deliverable 2); a held scope must not reach the batcher |
| Background jobs / follow-ups / campaigns | before each job body runs | must skip generation, leaving settlement untouched |
| Manual send / operator control | scoped operation through the existing delivery authority | AI hold is not a blanket manual refusal; effective conversation takeover can authorize manual sending under the action-class rules |
| Delivery authority | per action-class claim | a held AI action cannot cross the send boundary |

Required resolver rules (the submitted helper suite passes, but real-store probes
in P2_INCREMENT4_REVIEW.md expose gaps; these are not yet accepted integration):

- Migration disabled (the default) is positively legacy and performs no lookup.
- A failed authority lookup, a dangling conversation override, an allowlisted
  conversation with no assignment, and an unrecognised stored engine value all
  HOLD. None of them falls through to legacy.
- A creator default of `fastt` covers only the explicit per-conversation subset;
  that is positively legacy, not held.
- A `fastt` scope is held unless readiness is positively attested: not paused,
  no effective takeover, worker available and projection current.

The earlier helpers (`resolveEngine`, `canRouteToFastt`, `assignmentFor`) remain
exported with different semantics and currently have only test callers. Consolidate
operational decisions through the effective resolver before adoption; a raw stored
engine accessor must not be presented as readiness or permission. Receiver, jobs,
sender and control adoption/testing remain P2 implementation work.
