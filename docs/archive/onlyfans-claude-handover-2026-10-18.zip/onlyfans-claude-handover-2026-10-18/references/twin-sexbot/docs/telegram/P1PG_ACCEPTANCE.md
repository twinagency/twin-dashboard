# P1-PG independent acceptance

17 October 2026. **P1-PG is accepted within its local PostgreSQL implementation and verification scope.** PG1-A, PG1-B, PG3-A and PG3-B are closed. The earlier PG2, PG4 and PG5 closures remain in force. P1-R remains accepted. P2 implementation may begin under the updated START_HERE.md; live activation remains gated separately.

This review inspected the actual adapter and permanent regressions, reran the saved independent reproductions from an unchanged copy, and reran required Node checks. It did not accept the builder's report on assertion counts alone.

## Findings closed

| Item | Code and independent evidence |
|---|---|
| PG1-A authority/claim arbitration | Claims take a shared binding advisory lock, the exclusive conversation lock, then the action row. Applicable binding and conversation authority writers take conflicting locks through commit. All seven inside-statement variants now wait on real locks; none commits underneath the admitted claim. Requested takeover remains pending while that claim is unresolved. Earlier control-first and claim-first cases pass. |
| PG1-B deadline after waits | The eligibility clock is read after binding, conversation and action-row acquisition. The real action-row wait probe advances past expiry and now refuses the claim. Existing not-before and lease cases remain green. |
| PG3-A contiguous publication | New explicit positions must equal the transactionally allocated next position; a jump to 4 after 1 raises ProjectionConflictError. Actual PG records reach the real SQLite target and cursor: 2 published, 2 applied, cursor 2. Permanent checks additionally cover rollback/retry and file-backed close/reopen. Concurrent source publishers allocate 1 and 2. |
| PG3-B atomic receipt publication | Standalone and transaction-facade completion share finishActionOn. The permanent real-PG test rolls back completion evidence, obligation settlement, publication and stream head together, then retries the same receipt successfully without a second settlement or publication. The independent probe confirms the facade exposes completion. |

No further blocking defect was demonstrated in this bounded re-review. This statement is not a guarantee that the whole product is free of defects.

## Verification rerun by the reviewer

Evidence directory, relative to the workspace root: `output/telegram-p1pg-final-review-20261017/`.

| Command / boundary | Observed result |
|---|---|
| `bot: npm run typecheck` | exit 0 |
| `bot: tsx src/dev/check-fastt-pg.ts` using disposable loopback PG | exit 0; 183 passing assertions, 0 failures |
| Saved independent `probe.mts`, copied without changing its expectations | exit 0; failedExpectations empty; own database removed |
| `bot: npm test` | exit 0; 99/99 default checks; DB suites excluded by design |
| Required PG suite with forced unavailable runtime | exit 1; BLOCKED; no success marker |
| Required PG suite without its URL | exit 1; BLOCKED; no success marker |
| `git diff --check`, bot and inflowwkiller | exit 0 / 0 |

The live-data `npm run test:db` aggregate was not run. The real PG suite was selected directly instead. Python source was unchanged by these corrections; its earlier results remain historical evidence, not a claimed rerun in this review. Runtime evidence: Node v24.18.0; PostgreSQL 18.4 on Windows.

## Frozen reviewed source

| File | SHA-256 |
|---|---|
| bot/src/services/telegram-control-store-pg.ts | 5A2CFF69D5920F7FF31EE1E8FD4C5ACF6A6794A5FCC0B9AB35D001D013C11BE9 |
| bot/src/dev/check-fastt-pg.ts | 50C79592710D61D26C63737E73DF8FFC2E6B210B397570D0E2026A4BD5CF7597 |

The evidence directory records all six before/after hashes, including unchanged migration 144, its rollback script, the reference store and default runner. Both reviewed source hashes remained unchanged throughout this review. Bot HEAD remains f414f32da07f32f1108c4ed7bd34139e547d59ef on codex/telegram-fastt; the new implementation is uncommitted.

## Boundaries carried into P2 and deployment

- The PG store is still unwired. This acceptance does not claim a Telegram reply, a native Fastt invocation, production provider integration or live migration.
- Disposable PG used a minimal clones stub. Actual Supabase version, schema, role grants, connection/pooling behavior and deployment runtime still require target attestation before any live schema application.
- The lock protocol coordinates repository operations. All future authority writers must use the same owners/protocol; an arbitrary direct SQL writer would bypass advisory locks. Transactions must not span model or network calls. Compose source mutation before publication consistently.
- Receipt completion returning false is not success. P2 must publish confirmed receipt events only for accepted evidence, using the composed operation; uncertain/conflicting outcomes remain visible and held.
- Final platform eligibility after pacing, supported Telegram response evidence, durable receiver offsets, writer exclusion and native recovery remain P2 responsibilities, as already specified in the plan.
- Rollback 144 destroys control state; reapplying it resets epochs. Fence old workers before destructive rollback. It is not the application rollback method for a live migrated bot.
- No production application source was edited by the reviewer. Only review evidence and governing documentation were written. No receiver, model call, live data access, message, migration, deployment, commit or push occurred.

The next milestone is P2's real Fastt text path through the existing Node gateway, first verified with synthetic data and fake external services. P3A/P3B and live pilots are not authorized by this acceptance.
