# Fastt Telegram migration progress

Current state, 2026-10-18: **P2 is partially implemented; its neutral transport
increment is independently accepted after the corrections in P2_INCREMENT1_REVIEW.md.**
The supported Python 3.13 environment is installed. The complete native connection,
production routing, recovery and real offline round trip remain unfinished.
The 18 October plan re-review is recorded in P2_PLAN_REVIEW.md; section 8.1 of
IMPLEMENTATION_PLAN.md now specifies concrete composition requirements. These are
part of the same P2 package, not a new phase. START_HERE.md is the current assignment.

Current independent review: `P2_INCREMENT4_REVIEW.md`. The original I7-A/I7-B
public-call and secrets-import reproductions now pass; those bounded repairs are
closed. Async facades and a routing helper are present. The helper is unwired and
has two reproduced gaps: identity rows grant pilot scope and persisted holds can be
ignored. Stable policy snapshots, malformed-policy handling and explicit isolated
DB startup remain acceptance work. Complete these within the full existing P2
assignment alongside gateway/receiver/worker/recovery/control wiring and the composed
offline round trip. The native refactor's size is unfinished work, not an external
blocker. No live Telegram migration or test is ready from this increment alone.

**P1-R remains independently accepted within its offline
foundation scope.** P1R_ACCEPTANCE.md closes all four findings from the 18:54 builder
report. Independent re-runs passed: 99/99 default Node checks, typecheck, both permanent
Python suites, all eight saved runtime probes and additional operator-evidence checks.
The async-assignment project produces only the expected compiler rejection. No further
blocking defect was demonstrated in the bounded re-review. The corrected purchase,
evidence, projection, reservation and scoped-takeover behavior is preserved.
**P1-PG is now independently accepted within its local PostgreSQL scope.**
P1PG_ACCEPTANCE.md closes PG1-A, PG1-B, PG3-A and PG3-B and preserves the earlier
PG2/PG4/PG5 closures. Independent verification: 183 permanent PG assertions,
the saved original reproduction with zero failed expectations, typecheck and
99/99 default Node checks. Forced-unavailable and absent-URL checks both fail
correctly with exit 1. These are earlier foundation results, not P2 acceptance.
P0 local inventory is delivered; live runtime/schema attestation remains pending.
No Telegram migration was activated.
Earlier entries retain historical builder/reviewer evidence.

History: on 17 October 2026 a planning pack was created here from read-only local
source inspection (no code, data, workers, model calls or sends changed). That pack
is `START_HERE.md` and `IMPLEMENTATION_PLAN.md`; this file is now the progress
record for the work actually done.

| Package | State |
|---|---|
| P0 Runtime and product attestation | Local inventory delivered; live target attestation pending |
| P1-R Contracts and durable control repairs | **Accepted offline, 2026-10-17** - P1R_ACCEPTANCE.md; all four final findings closed |
| P1-PG Production PostgreSQL control store | **Accepted locally, 2026-10-17** - P1PG_ACCEPTANCE.md; all residual findings closed |
| P2 Native Fastt text connection and OpenRouter | In progress; neutral transport increment accepted, complete integration and offline round trip outstanding; START_HERE.md |
| P3A Media enrichment and accepted catalogue projection | Not started |
| P3B Catalogue offers and Stars sales | Not started |
| P4 Operator and automation compatibility | Not started |
| P5 Deployment and recovery verification | Not started |
| P6 Canary and migration | Not started |

Architecture decision (unchanged): preserve the established Node Telegram gateway,
Supabase catalogue/configuration/financial data and dashboard. Add Fastt as a native
Python engine with isolated durable SQLite state and one delivery authority. V2 is
a separate test runtime and is **not** assumed to be the deployed Telegram fleet.

Media decision added 2026-10-17: preserve Twin's dashboard, catalogue, Storage and
approved human metadata, but replace Twin's one-frame automatic media generator for
newly analysed assets in P3A with Fastt-style duration-based factual extraction,
structural/cross-field validation and a fact-grounded stored-copy pass. Do not run both
generators for one asset revision and do not mass re-caption history. The comparison
reused Fastt prompts/formatting and similar sampling through an alternative OpenRouter
harness because native tenant keys were absent. It bypassed native retries, collection,
budgets and persistence; the small sample does not certify native pipeline parity or
general factual/reliability superiority. Preserve legacy metadata without inventing
approval provenance; review flagged results, preserve explicit human overrides and
prices, and map optional contextual captions to one native owner. Within media scope, P2 must only
add disabled media-purpose configuration, not run media jobs.

---

## 1. Source revisions this work was built against

| Root | Repo | Branch | HEAD | Worktree |
|---|---|---|---|---|
| `BOT_ROOT` | `bot/` (`ronan-com/twin-bot`) | `codex/telegram-fastt` (created from `main`) | `f414f32` | clean before; only new untracked files after |
| `DASHBOARD_ROOT` | `twin-dashboard/` (`ronan-com/twin-dashboard`) | `main` | `fb6b345` | unchanged, clean |
| `FASTT_ROOT` | `inflowwkiller/` (`BlackPhoenixSlo/inflowwkiller`) | `codex/onlyfans-integration` (**not switched**) | `e72316f` | existing dirty OF/bridge work preserved; new files added |
| docs | `twin-sexbot/docs/telegram/` (untracked) | - | - | new and updated docs |

`allieai2-bot/`, `allieai2-dashboard/`, every sibling dashboard worktree, V2's
`src/channels/` and the workspace root were **not** modified.

---

## 2. P0 deliverables (all in `twin-sexbot/docs/telegram/`)

| File | Contents |
|---|---|
| `RUNTIME_MANIFEST.md` | per-field attestation (observed / inferred / pending) for roots, bot, dashboard, Supabase, Fastt, ops |
| `runtime-manifest.json` | the same, machine-readable and secret-free |
| `SOURCE_MAP.md` | which source root is which, why `bot/` beats `allieai2-bot/`, all candidates and their disposition, revision ledger |
| `SENDER_INVENTORY.md` | every receiver, reply generator, scheduled sender, manual-send path, payment path, content source and dashboard control, with owner and disposition |
| `CONFIG_MAPPING.csv` | every existing setting mapped to retained / mapped / replaced / unsupported |
| `CAPABILITIES.csv` | every product capability with its owner and target package |

Resolved by evidence, not assumption:

- `BOT_ROOT = bot/` (`ronan-com/twin-bot`) because its own workflow deploys it to the
  bot box as ECR repo `twin-bot`, instance `i-0584d283506f3f6be`, container
  `next-app`, remote `/home/ubuntu/allieai2-bot`.
- `DASHBOARD_ROOT = twin-dashboard/` (`ronan-com/twin-dashboard`) because its own
  workflow deploys it as ECR repo `twin-dashboard`, instance `i-09a9dd3bd749643a5`,
  remote `/home/ubuntu/allieai2-dashboard`.
- The box directory named `allieai2-bot` is a **directory name**, not the source
  repository. `allieai2-bot/` (remote `QuestGltAdmin/allieai2-bot`) has no deploy
  workflow, a different history and a narrower feature set, so it was left alone.
- `FASTT_ROOT = inflowwkiller/` (the Fastt MIT engine plus the existing OF bridge).
- The channel is **Telegram Business** (`business_message`), reached by long polling
  with an explicit `allowed_updates` list and a webhook delete at boot.

Still open: whether Fastt is deployed anywhere today.

---

## 3. P1 deliverable: the versioned contract

Canonical location: `twin-sexbot/docs/telegram/contracts/`.

| File | Contents |
|---|---|
| `CONTRACT.md` | event v1 + action v1 semantics, identity rules, rejection codes |
| `telegram-event.v1.schema.json` | JSON Schema (documentation-grade; the validators are normative) |
| `delivery-action.v1.schema.json` | JSON Schema (documentation-grade) |
| `fixtures/telegram-contract.cases.json` | 42 shared cases: 9 valid (7 events, 2 actions), 33 invalid |
| `fixtures/FIXTURES.sha256` | `043e7ab57e8c96a1c84ca79cc36413e7b57b0eb493c80b89985117963a54f733` |

Both language suites verify that hash, so a copy that drifts fails on the side that
changed. All three copies (canonical, `bot/`, `inflowwkiller/`) currently match.

Contract properties that carry a requirement from the plan:

- the **action id is derived** from `(bindingId, sourceKind, sourceId, ordinal)`,
  never from a process run id, so a restart re-emits the same identity;
- the **payload digest** is computed over an explicit ordered field list (not raw
  JSON), so Node and Python cannot disagree on number or unicode serialization;
- **money is XTR only**; currency and amount must appear together and the amount is a
  positive integer number of Stars. There is no dollar-to-Stars conversion.

---

## 4. P1 deliverable: code added

### 4.1 `bot/` - new files only (branch `codex/telegram-fastt`; nothing existing modified)

| File | Role |
|---|---|
| `src/engines/fastt-contract.ts` | event v1 + action v1 types, validators, identity keys, action id, payload digest |
| `src/engines/engine-router.ts` | legacy-vs-Fastt assignment; **legacy by default**, Fastt only on an explicit binding |
| `src/engines/fixtures/telegram-contract.cases.json` + `FIXTURES.sha256` | the shared fixture mirror |
| `src/services/telegram-control-store.ts` | durable SQLite control store (10 tables), BEGIN IMMEDIATE transactions |
| `src/services/identity-map.ts` | scoped bot/chat/message/fan identity maps and native-id allocation |
| `src/services/delivery-authority.ts` | the single delivery authority: admit / claim / confirm / fail / unknown |
| `src/services/projection-cursor.ts` | ordered projection events with an atomic cursor |
| `src/dev/check-fastt-contract.ts` | cross-language fixture conformance (Node side) |
| `src/dev/check-fastt-durable.ts` | the nine durable scenarios (Node side) |
| `src/dev/check-fastt-import-safe.ts` | importing the new modules starts nothing |
| `src/dev/check-fastt-schema-parity.ts` | DDL drift guard: the Node SQLite DDL, the Postgres migration and the rollback script must agree on every table and column |
| `src/dev/fastt-sqlite-harness.ts` | the one shared node:sqlite availability + skip-path seam the two SQLite checks use (not a check itself) |
| `db/migrations/144_telegram_fastt_contracts.sql` | **additive** Postgres mirror of the control records, RLS enabled with no policies |

### 4.2 `inflowwkiller/` - new files only (branch unchanged; existing OF work untouched)

| File | Role |
|---|---|
| `service/telegram_contract/__init__.py` | package surface |
| `service/telegram_contract/contract.py` | the Python mirror of the validators |
| `service/telegram_contract/identity.py` | the Python identity keys |
| `service/telegram_contract/store.py` | durable SQLite store for one creator's native database |
| `service/telegram_contract/schema.sql` | the additive SQLite schema (10 tables) |
| `service/telegram_contract/fixtures/` | the shared fixture mirror |
| `service/tests/test_telegram_contract.py` | cross-language conformance (Python side) |
| `service/tests/test_telegram_store.py` | the nine durable scenarios (Python side) |

### 4.3 Docs

`RUNTIME_MANIFEST.md`, `runtime-manifest.json`, `SOURCE_MAP.md`,
`SENDER_INVENTORY.md`, `CONFIG_MAPPING.csv`, `CAPABILITIES.csv`, `contracts/`, and
this file.

---

## 5. Tests actually run, with real exit codes

| Command | Result |
|---|---|
| `bot: npm run typecheck` | **exit 0** (`tsc --noEmit`) |
| `bot: npm test` | **exit 0** - `ALL 99 CHECKS PASSED` (95 pre-existing + 4 new; the runner skipped its 4 Supabase-backed checks by design) |
| `bot: npx tsx src/dev/check-fastt-contract.ts` | **exit 0** - 42 shared cases, key derivations, generated boundary cases |
| `bot: npx tsx src/dev/check-fastt-durable.ts` | **exit 0** - all durable scenarios |
| `bot: npx tsx src/dev/check-fastt-import-safe.ts` | **exit 0** - no signal handler and no timer on import |
| `bot: npx tsx src/dev/check-fastt-schema-parity.ts` | **exit 0** - SQLite DDL, Postgres migration and rollback agree on all 10 tables and every column |
| `inflowwkiller: service\run_tests.cmd telegram_contract telegram_store` | **exit 0** - `2 passed, 0 failed`, both printing the house `all cases passed` marker |

Baseline before this work: `bot: npm test` = `ALL 95 CHECKS PASSED`, exit 0;
`bot: npm run typecheck` = exit 0.

The Node durable check needs `node:sqlite` (unflagged on Node >= 23.4, or
`--experimental-sqlite` on Node 22.5-23.3). It ran on **Node v24.18.0** here. On a
runtime without it the check prints an unmistakable SKIP banner and passes, so a
Node-22 CI runner does not go red for a runtime it does not have; that runner's
result is a skip, not evidence.

Deliberately **not** run: `bot: npm run test:db` (needs live Supabase); the
`twin-dashboard` suites (no dashboard code changed in P1); and the wider Fastt
Python suite (my additions are new files in a new package, and the wider suite
starts ephemeral servers unrelated to these changes).

---

## 6. The nine required scenarios, and where each is proven

| Scenario | Node check | Python test |
|---|---|---|
| duplicate Telegram updates | `check-fastt-durable` - identical re-delivery is a duplicate, a different payload is a conflict | `test_telegram_store` scenario 1 |
| the same user across different creators | `check-fastt-durable` - two scoped fan keys, two native ids, two separate databases | scenario 2 |
| identical message ids in different chats | `check-fastt-durable` - two message keys, two native ids, and a third on another bot | scenario 3 |
| malformed IDs and timestamps | `check-fastt-durable` - 8 malformed cases refused with the exact code, nothing stored | scenario 4 |
| stale ownership revisions | `check-fastt-durable` - an action frozen at the old epoch cannot claim; the epoch bump itself refuses a stale expectation | scenario 5 |
| conflicting action payloads | `check-fastt-durable` - same id + same payload is idempotent; same id + new payload conflicts and does not overwrite | scenario 6 |
| transaction rollback | `check-fastt-durable` - a rolled-back allocation consumes nothing; an interrupted import leaves no event and no cursor move | scenario 7 |
| competing workers | `check-fastt-durable` - two connections, exactly one wins, attempt count 1 | scenario 8 |
| projection cursor recovery | `check-fastt-durable` - interrupt, retry, no duplicate, no rewind | scenario 9 |

Plus, in both suites: a single-writer lease, and an interrupted native invocation
that is still `interrupted` after the database is reopened.

Cross-language equality is asserted against **Node-computed constants** in the
Python suite (identity keys, action ids, both payload digests, the canonical
timestamps), so the two implementations cannot drift apart silently.

---

## 7. Decisions and deviations, with reasons

1. **`bot/` branch created; `inflowwkiller/` branch not switched.** The plan asks for
   isolated `codex/telegram-fastt` checkouts. `bot/` was clean, so the branch was
   free. `inflowwkiller/` carries substantial uncommitted OnlyFans work on
   `codex/onlyfans-integration`; switching its branch would relabel that work under a
   Telegram name. Its new files are additive on the existing branch instead, and the
   deviation is recorded rather than hidden.
2. **One canonical action digest.** The store first hashed the whole action object
   while the contract already defined a field-list digest; both stores now use the
   contract digest, so the gateway and the worker agree on the frozen identity of an
   action instead of each having its own.
3. **Byte-bound cases are generated, not stored.** A literal over-16 KiB fixture
   would be duplicated into two repos, so each suite generates it and asserts the same
   code. No case sits near the boundary, because a JS and a Python JSON serializer
   differ by a few bytes.
4. **`node:sqlite` for the Node durable tests.** It is the only SQLite available
   without adding a dependency to the bot's `package.json`. The trade-off is the Node
   version note in section 5.
5. **`engine_commands` is schema only.** It is created but not exercised beyond the
   invocation journal; command execution is P2/P4 work.

---

## 7b. Governing-rules re-audit repairs (17 Oct 2026)

When the mandatory **Governing development rules** were added to the contract, the whole P0/P1
change set was re-inspected against the *current* code rather than the earlier notes. Three real
defects were found and repaired; the rest of the change set passed.

1. **The typecheck was actually red.** `bot: npm run typecheck` had been recorded as exit 0, but
   the shared SQLite harness added late in the work re-declared `SqliteDatabase` as a *narrower
   structural interface* than `node:sqlite`'s own `DatabaseSync`. A handle from the harness was
   therefore not assignable to `new TelegramControlStore(db)`, and `check-fastt-schema-parity`
   called the class without `new` (a type error *and* a runtime `TypeError`). Fixed by aliasing the
   harness's `SqliteDatabase` to the real `DatabaseSync` and calling `new`, so the harness is the
   single definition it claims to be instead of a hand-maintained copy that drifts from the
   runtime API. `tsc --noEmit` is now genuinely exit 0.
2. **A real DDL drift, caught by the guard once it ran.** `check-fastt-schema-parity` then reported
   that Postgres `engine_bindings` carried a `created_at` column the **two** SQLite copies (the
   Node store and the Python worker schema) did not. All three are meant to describe the same
   record, so the migration was aligned to the SQLite reference by removing that one column; the
   two SQLite DDLs already agreed, so this is the smallest change in one component. (Not yet
   applied to any live project.)
3. **The canonical fixture hash was missing.** `contracts/fixtures/FIXTURES.sha256` was listed in
   `CONTRACT.md` and claimed as matching, but the canonical copy did not exist. Created as a
   byte-exact copy of the two repo mirrors; all three are now 64 bytes and byte-identical.

None of these repairs touched a fan-facing prompt, a live handler, a sender, a scheduler or a
Supabase path. Nothing in the change set starts a service, registers a signal handler or leaves a
timer (`check-fastt-import-safe`), and no live module imports the new code - only the new files
reference each other (confirmed by inspection during this re-audit).

## 8. Unresolved deployment facts (unchanged, still blocking a live pilot)

Recorded in full in `RUNTIME_MANIFEST.md` section 7. In short:

1. first creator clone UUID, public bot id/username, permitted test user/chat;
2. Business account versus conventional bot chat for that creator;
3. running bot revision (container `GIT_SHA`) versus local `f414f32`;
4. running dashboard revision versus local `fb6b345`;
5. applied Supabase schema state on `aouaenqayfltoqrmpitg`;
6. enabled products for the selected creator;
7. effective model ids, purposes and fallback policy;
8. whether Fastt is deployed today and on which Python runtime;
9. last verified restore and disk headroom.

No value above was invented, and no live system was queried.

---

## 9. Remaining P1 work (not done, and why)

Historical builder assertion, superseded by the independent review above: P1's **offline** acceptance was reported met. The builder listed the following as remaining work needing the
target established, which P0 could not resolve:

1. wire `engine-router` into `src/index.ts` behind the (still legacy) assignment,
   without changing today's behaviour;
2. create the Postgres control tables on a real project through the repo's migration
   process, then re-run the same scenario tests against Postgres rather than SQLite;
3. bind a concrete `bindingId` to the selected creator's clone/bot/mode and record the
   activation cutoff;
4. an operator-facing read of engine assignment and worker health (a P4 UI item).

---

## 10. Owner development rules

The Telegram implementation contract and builder handoff now state the owner's mandatory change discipline explicitly: inspect current code, effective prompts/configuration, tests, recent changes, worktree diff and pending work before recommendations or edits; trace interactions; make the smallest owner-local change; add no contradictory or duplicate logic, unnecessary prompt layers, parallel truth or model calls; keep prompts consistent with implemented behaviour; preserve approved behaviour; test real boundaries, failures, compatibility and rollback; report uncertainty honestly; and work one reviewed stage at a time. These rules remain outside every fan-facing prompt.

## 11. Safety attestations for this change set

No Telegram receiver or second poller was started. No creator or bot was activated.
No Telegram message was sent. No paid model was called. No secret was read or
printed. No live Supabase data was written. Nothing was deployed, committed or
pushed. Existing uncommitted Telegram, OnlyFans, dashboard and bridge work is
untouched. Deliberate typos and misspellings remain disabled. No dollars were
converted to Stars. No second conversation engine or fallback sender was created.

Historical next action superseded: the independent review did not accept P1. Complete
P1-R, review it, then complete P1-PG before P2. See the current START_HERE.md.

## Independent final-plan review, 17 October 2026

Three focused reviews inspected the P1 implementation, Telegram/financial architecture,
and media plan. The governing rules remain in the full plan and immediate handoff.
No application implementation was changed in this review.

R1-R6: recoverable event/action/projection bodies; projection source identity and
cursor idempotency; conversation arbitration and attempt-bound late completion;
source-content versus receipt-metadata dedupe; cross-language integer/time ranges;
trusted binding identity and final-gate predicates. See REVIEW_FINDINGS.md for exact
source anchors, reproduced outcomes and acceptance requirements.

Independent verification: bot typecheck and its four named Fastt suites all exited 0;
Python telegram_contract and telegram_store suites both exited 0. Additional in-memory
probes reproduced defects despite those results. The prior full-suite result above is
builder evidence, not a newly repeated full-suite result. No PostgreSQL behavior or
live runtime has been verified by these SQLite checks.

Plan corrections: make production PostgreSQL transactions an explicit P1-PG gate;
enforce every legacy writer before the P2 pilot; reuse Business window policy; require
exact effective config mapping; strengthen pre-checkout in P3B; distinguish stored
versus optional contextual captions; preserve legacy metadata/human fields/manual
prices; separate pending analysis from sale readiness; bound retry/accounting and
factual-validation claims; gate upload/import/backfill enrichment consistently.

Current files: IMPLEMENTATION_PLAN.md is the full project contract; START_HERE.md is
P1-R only; REVIEW_FINDINGS.md records the review; CONFIG_MAPPING.csv and CAPABILITIES.csv
are corrected inventories, not proof the mappings are implemented. No live migration,
bot activation, model run, message, commit, push or deployment occurred.

## P1-R repair implementation, 17 October 2026 (implemented, awaiting independent review)

All six P1-R findings are repaired in the additive, disabled foundation, with a
correct-outcome regression for each in BOTH languages. Nothing was activated: the
engine is still legacy by default, no receiver/poller runs, no message is sent, no
model is called, no live database is touched, and nothing is committed or deployed.

### R1-R6 mapping (finding -> fix -> regression)

| Finding | Repair | Regression (Node / Python) |
|---|---|---|
| R1 recoverable bodies | Every normalized event, action and projection body is persisted as canonical JSON with its schema version and digest, with typed readback (`eventRecord`/`actionRecord`/`projectionRecord`). The frozen action keeps text, assets, destination and deadlines. | check-fastt-durable "R1 ..." block (file-backed close/reopen) / test_telegram_store scenario 1b |
| R2 projection identity + cursor | Source supplies a stable `sourceEventId` and per-stream `sourceSequence`; destination autoincrement is gone. Re-import same id+body is a no-op; changed body conflicts. The stream cursor advances only over the contiguous prefix, so a gap holds later events. Event and cursor commit in one transaction. | check-fastt-durable "R2 ..." + "R2 redelivery after reopen" / test_telegram_store scenarios 9, 9b |
| R3 arbitration + attempt-bound completion | A claim is refused while ANY other action in the same conversation is dispatching/unknown. A claim records an immutable attempt token; completion requires it. Unknown may later settle to confirmed/known_failed from evidence using the ORIGINAL token, surviving an epoch change; terminal rows are never overwritten. | check-fastt-durable "R3 ..." blocks / test_telegram_store scenarios 10, 11 |
| R4 content vs receipt | `payload_digest` is now the SEMANTIC source-content digest over an explicit field list that excludes `eventId`/`receivedAt`; a restart re-delivering the same update is a duplicate, changed provider content still conflicts. | check-fastt-durable "R4 ..." + check-fastt-contract digest pins / test_telegram_contract + scenario 1 |
| R5 typed wire rules | `ordinal` 0..2147483647; `expectedEpoch`/`expectedInputRevision` 0..9007199254740991; XTR amount 1..25000 and only on `send_media`; paid media <=10 photo/video entries; year-zero input refused; huge integers are typed `money-invalid`, never a raw `OverflowError` or silent rounding. | check-fastt-contract section 7 + 16 shared fixtures / test_telegram_contract |
| R6 trusted binding + class | clone/bot/mode/Business connection immutable under a binding id; a trusted `bindings_conversations` record gates registration/claim against forged scope; claim checks not-before/expiry; class predicates (ai needs active Fastt + unpaused + current input/config; manual needs takeover; fulfillment needs an obligation and survives pause/input/engine change). | check-fastt-durable "R6 ..." blocks / test_telegram_store scenarios 12, 13, 14 |

### Changed files

`bot/` (branch `codex/telegram-fastt`, base `f414f32`):
`src/engines/fastt-contract.ts`, `src/services/telegram-control-store.ts`,
`src/services/delivery-authority.ts`, `src/services/projection-cursor.ts`,
`src/dev/check-fastt-contract.ts`, `src/dev/check-fastt-durable.ts`,
`src/dev/check-fastt-schema-parity.ts`, `src/dev/fastt-sqlite-harness.ts`,
`db/migrations/144_telegram_fastt_contracts.sql`,
`db/manual/ROLLBACK_144_telegram_fastt_contracts.sql`,
`src/engines/fixtures/telegram-contract.cases.json` + `FIXTURES.sha256`.

`inflowwkiller/` (base `e72316f`, existing `codex/onlyfans-integration` work preserved):
`service/telegram_contract/contract.py`, `.../store.py`, `.../schema.sql`,
`.../fixtures/telegram-contract.cases.json` + `FIXTURES.sha256`,
`service/tests/test_telegram_contract.py`, `service/tests/test_telegram_store.py`.

`DOCS_ROOT/`: `contracts/CONTRACT.md`, `contracts/fixtures/*` (58 shared cases),
and this file. The three fixture copies are byte-identical, pinned at SHA-256
`63c5f24fe1fe27686a9adc09375bfdbc6f8f63e49fb688252f9301c6559ed21e`.

### Failing-before -> passing-after evidence

Two throwaway probes (deleted after use, never committed) ran the review's scenarios
against the PRE-repair code and reproduced every defect:

```text
R2 import #1 again  => 1 (old code) / 2 (new code); rows 2/1... rows=2 cursor=2  [BAD]
R4 retry same content, new receivedAt+eventId => THREW EventConflictError  [BAD]
R6 rebind same id to a different Business connection => ACCEPTED  [BAD]
R6 register+claim a DIFFERENT clone action => true  [BAD]
R3 claim a DIFFERENT action while the conversation has an unknown attempt => true  [BAD]
R3 complete a dispatching action knowing ONLY its id => true  [BAD]
R5 Node ordinal 1e21 => ACCEPTED (hashed exponent form)  [BAD]
R5 Node expectedEpoch 9007199254740993 => ACCEPTED (rounded to ...992)  [BAD]
R5 Node year-zero timestamp => ACCEPTED (normalised into year one)  [BAD]
R5 Python amount 10**400 => THREW OverflowError  [BAD]
```

After the repairs the equivalent regressions in the normal suites PASS in both
languages, and the previously divergent R5 cases now produce the SAME typed code in
Node and Python (asserted by the shared fixtures and the generated boundary cases).

### Verification actually run (this session)

Runtimes: Node v24.18.0; `inflowwkiller/.venv` Python.

| Command | Result |
|---|---|
| `bot: npm run typecheck` | exit 0 |
| `bot: npx tsx src/dev/check-fastt-contract.ts` | exit 0 - 58 shared cases, R4 digest pins, R5 boundary set |
| `bot: npx tsx src/dev/check-fastt-durable.ts` | exit 0 - all original scenarios + R1-R4/R6 regressions |
| `bot: npx tsx src/dev/check-fastt-import-safe.ts` | exit 0 |
| `bot: npx tsx src/dev/check-fastt-schema-parity.ts` | exit 0 - 12 tables, every column, plus rollback agreement |
| `bot: npm test` | exit 0 - `ALL 99 CHECKS PASSED` |
| `inflowwkiller: .venv\\Scripts\\python.exe service/tests/test_telegram_contract.py` | exit 0 - all cases passed |
| `inflowwkiller: .venv\\Scripts\\python.exe service/tests/test_telegram_store.py` | exit 0 - all cases passed |
| `py_compile` on the changed Python modules | exit 0 |
| `git diff --check` (bot, inflowwkiller) and a trailing-whitespace scan of the new files | exit 0 / clean |

Note on the full suite: `check-send-lock` (untouched by P1-R) failed once when the
runner saturated the box with the heavier new checks and then passed standalone and
on the immediate full re-run. That is the known timing flake the runner documents,
not a P1-R regression.

### Deliberate behaviour change and remaining boundaries

1. **node:sqlite now FAILS loudly when unavailable.** The durable and parity checks
   previously printed a SKIP banner and exited 0, which counted a blocked run as a
   pass. They now exit non-zero with a BLOCKED banner unless the explicit
   `TWIN_FASTT_FORCE_NO_SQLITE=1` seam is set (used only to exercise the skip path),
   which still exits 0. Verified: the forced seam exits 0 with the banner.
2. **P1-PG is still required.** Migration 144 is DDL and a name/column parity check;
   there is no Node PostgreSQL store and no real PostgreSQL transaction, type,
   constraint or RPC verification yet. That remains the next gate.
3. **Not verified here:** live Telegram receiver/Business permissions, the real
   financial handlers, the native Fastt engine, real model calls, and any
   PostgreSQL behaviour. The real permission observation and receiver wiring are
   later packages.
4. **Engine still legacy.** No binding is activated; `resolveEngine` returns legacy
   unless a binding literally says fastt.

---

## Independent P1-R re-review, 17 October 2026

Verdict: **not accepted yet**. Current remaining requirements and exact code
references are in `P1R_REVIEW.md`; the next assignment in `START_HERE.md` now points
there. This continues P1-R and does not start P1-PG, P2 or a new product stage.

Preserve verified improvements: recoverable bodies/reopen, semantic receipt retries,
original numeric/year-zero repairs, immutable binding identity, basic conversation
arbitration and genuine late receipt handling. Remaining C1-C4 cover actual
projection application and immutable replay metadata, outcome evidence/uncertain
send holds, conversation-scoped takeover/input and exact fulfillment obligations,
plus action-shape/whitespace/schema alignment.

Reviewer independently ran `npm run typecheck` and `npm test` in bot: both exit 0,
all 99 offline checks pass (four Supabase-backed checks intentionally excluded).
Both named Python Telegram suites exit 0. Runtimes: Node v24.18.0, Python 3.11.9.
The independent correct-outcome review probes reproduce remaining failures; their
nonzero exits are expected failed assertions, not test-runner errors. Commands,
outputs and interpretation are preserved in
`output/telegram-p1r-review-20261017/{projection,authority,contract}/`.

`P1R_REVIEW_BASELINE.json` records the reviewed implementation hashes. This review
edited only planning/status/contract commentary and new review evidence; it did
not change application implementation or normal test suites. No live attestation,
PostgreSQL execution, native Telegram/model call, private data access, migration,
activation, send, commit, push or deployment was performed.

---

## P1-R C1-C4 continuation, 17 October 2026 (implemented, awaiting independent review)

Continuation of the same P1-R package after the 17 Oct re-review. Preserves every
accepted repair (recoverable bodies, semantic receipt retries, original
numeric/year-zero repairs, immutable binding identity, basic arbitration, genuine
late receipts). Nothing was activated: engine is still legacy by default, no
receiver/poller runs, no message is sent, no model is called, no live database is
touched, and nothing is committed or deployed. Dashboard and OnlyFans production
work are untouched.

### C1-C4 mapping (finding -> fix -> regression)

| Finding | Repair | Regression (Node / Python) |
|---|---|---|
| C1 finish R2: application is mandatory for consumption | `importProjectionEvent`/`import_projection_event` REQUIRE a synchronous transactional application seam (`ProjectionApplier`). An omitted or malformed applier and an unsupported kind are refused BEFORE any write or cursor move, so a position is never consumed unapplied; the previous envelope-only compatibility path is removed. Each newly CONTIGUOUS event is applied to destination state and marked `applied_at` inside the same transaction that moves the cursor, so a target-mutation failure rolls back target state + marker + cursor together. Only the contiguous prefix is applied (a gapped event is stored but held). | check-fastt-durable "C1 an omitted applier refuses to consume" etc. / test_telegram_store "C1 an omitted applier refuses to consume a position" etc. |
| C1-P2 immutable replay metadata | A replay is compared on `payload_digest` AND `event_kind` AND `source_sequence` AND body schema version; a genuine replay returns the STORED sequence and re-applies nothing, while a changed sequence/kind under the same id is `ProjectionConflictError`. Sequence must be a strictly positive representable integer. | check-fastt-durable "C1 an exact replay ..." / scenario 15 |
| C2 evidence must survive the public authority boundary | `finishAction`/`finish_action` require validated, provenance-carrying outcome EVIDENCE; evidence kind and ref are persisted. `confirmed` needs a real message receipt OR the control acknowledgement (`telegram_ack`, carried through `DeliveryAuthority.confirm`/`resolveUnknown`, never a fabricated message id). `held`/`cancelled`/`known_failed` from a dispatching attempt need a CLASSIFICATION from the closed `PROVEN_UNSENT_CLASSES` set (`never_dispatched`, `connect_refused`, `dns_failure`, `tls_failure`, `provider_rejected_before_send`) or a recorded operator decision (actor + reason). A bare error label (`"network"`) and arbitrary prose (`"network timeout"`) are refused; `DeliveryAuthority.fail` no longer manufactures proof from an error category. An already-`unknown` attempt is released only by a genuine late receipt (to `confirmed`) or a recorded operator decision (to `known_failed`) - a proof string cannot clear it. Terminal rows are never overwritten; identical evidence is idempotent and contradictory late evidence is appended to a durable reconciliation record. | check-fastt-durable "C2 a bare network error cannot release the hold through the authority", "C2 free-text proof cannot release an unknown attempt", "C2 a typing acknowledgement completes through the authority", "C2 a normal reply dispatches after a completed control action" / test_telegram_store scenario 16 (same, store-side) + `verify_postfix` |
| C3 conversation-scoped authority (removes the binding-wide bypass) | Input revision and takeover live on the authoritative conversation record (seeded from the creator-wide value at bind time). New input in one conversation no longer stales another's prepared answer; a takeover request is scoped to its own conversation and reported effective only once no unresolved send holds it. AI requires no effective takeover in its conversation (creator-wide `ai_paused`/`human_takeover` still block AI). Manual requires the action's OWN conversation to report effective takeover; the binding-wide `human_takeover` flag is NO LONGER a manual-authorization shortcut, and it does not make a conversation's takeover effective. | check-fastt-durable "C3 a binding-wide takeover flag alone does not authorize manual work in a conversation" (and the class-predicate block) / test_telegram_store scenario 14 + scenario 17 |
| C3 reservation, specific obligation and delivery settlement | Trusted fulfilment registration BINDS a specific canonical obligation/portion (an explicit id is validated, otherwise the oldest exact outstanding obligation is bound, or the action stays unassociated and unclaimable; a later purchase can never wake an unassociated action). `recordObligation` freezes the composition. A claim RESERVES that obligation (`outstanding -> reserved`, tied to the action) in the same transaction as the winning claim; `dispatching`/`unknown` keep the reservation and the conversation hold; only verified delivery SETTLES it (`-> fulfilled`); a proven-unsent result RELEASES it (`-> outstanding`, action cleared) so a separately authorized replacement can still deliver the paid work, with the attempt evidence retained. A fulfilled/mismatched/cross-binding/settled obligation cannot authorize work and a whole order is never marked done on first claim. | check-fastt-durable "C3 the claim reserves rather than fulfils", "C3 proven-unsent returns the obligation to outstanding", "C3 a confirmed delivery settles the obligation", "C3 a duplicate receipt does not settle twice", "C3 an unassociated fulfilment cannot claim" / test_telegram_store scenario 17 (same) + `verify_postfix` |
| C4 action compatibility | One action/body compatibility matrix enforced in both validators: `send_text` and the control actions carry no assets; `send_voice` carries only voice assets; `send_media` carries only photo/video. An unrelated asset is `malformed-field`. Valid caption text and the valid paid-media composition are unchanged. | 5 shared fixtures (`invalid_action_photo_on_*`) + `valid_action_send_voice_with_voice_asset`, run by both contract suites |
| C4 shared blank/padding (preserve rejection, align languages) | Blank/padding classification uses ONE explicitly enumerated Unicode set shared by both validators - the UNION of what each side previously rejected: U+0009..U+000D, U+001C..U+0020, U+0085, U+00A0, U+1680, U+2000..U+200A, U+2028, U+2029, U+202F, U+205F, U+3000, U+FEFF. A blank-only value (including NBSP, EM SPACE, NEL, BOM) and a padded id are refused in both languages; ordinary Unicode content is unchanged and nonblank text/ids are never rewritten. The earlier weakening (ASCII-only, U+0085/U+FEFF treated as content) is removed. | 7 new shared fixtures (`invalid_event_*_only_ascii_space|nbsp|em_space`, `*_text_only_*`, `invalid_event_binding_id_padded_nbsp`) plus the 4 flipped `*_only_nel|bom` cases; run by both contract suites |
| C4 schema/prose alignment | `telegram-event.v1.schema.json` `$comment`/description now document the enumerated blank/padding set; `delivery-action.v1.schema.json` keeps the ordinal/epoch/revision maxima, the XTR `1..25000` maximum, the paid-media 10-item limit and the per-action asset-kind constraints. CONTRACT.md was corrected so it no longer (a) calls the applier optional, (b) says U+0085/U+FEFF are content, or (c) lists the binding-wide flag as manual authority. | `check-fastt-contract` verifies the fixture hash; both suites parse the fixture; `node -e JSON.parse` on both schemas |

### Changed files

`bot/` (branch `codex/telegram-fastt`, base `f414f32`):
`src/engines/fastt-contract.ts`, `src/services/telegram-control-store.ts`,
`src/services/delivery-authority.ts`, `src/services/projection-cursor.ts`,
`src/dev/check-fastt-contract.ts`, `src/dev/check-fastt-durable.ts`,
`src/engines/fixtures/telegram-contract.cases.json` + `FIXTURES.sha256`,
`db/migrations/144_telegram_fastt_contracts.sql`.

`inflowwkiller/` (base `e72316f`, existing `codex/onlyfans-integration` work preserved):
`service/telegram_contract/contract.py`, `.../store.py`, `.../schema.sql`,
`.../fixtures/telegram-contract.cases.json` + `FIXTURES.sha256`,
`service/tests/test_telegram_contract.py`, `service/tests/test_telegram_store.py`.

`DOCS_ROOT/`: `contracts/CONTRACT.md`, `contracts/*.schema.json`,
`contracts/fixtures/*` (77 shared cases; all three copies byte-identical, pinned at
SHA-256 `cf88cca455cb4a15ebaccabd6625663a16f6d2316090b759056c459007f7487b`),
and this file. No dashboard or OnlyFans production file was edited.

New evidence: `output/telegram-p1r-continuation-20261017/` (`verify_postfix.mts`,
`verify_postfix.py`, `README.md`) and the reviewer's original probe directories, kept
unchanged. New/corrected helpers: `NO_OP_APPLIER` in both durable suites and the
`refuses`/`projectionRefuses` helpers used by the negative regressions.

### Failing-before -> passing-after evidence (the C1-C4 continuation probes)

The 17 Oct re-review probes failed correct-outcome assertions on the reviewed
baseline: C1/C4 nine each (Node/Python), C2 four/two, C3 five each. Re-running the
SAME saved probes on this revision:

```text
telegram-p1r-c2-rereview-20261017/probe.mts  -> exit 0 (failures: 0)
telegram-p1r-c2-rereview-20261017/probe.py   -> exit 0 (failures: 0)
telegram-p1r-c3-rereview-20261017/review_c3.mts/.py -> exit 1 (10 passed, 3 failed)
telegram-p1r-c1c4-rereview-20261017/check_node.mts / check_python.py -> refuse (C1)
telegram-p1r-continuation-20261017/verify_postfix.mts -> exit 0 (42 passed, 0 failed)
telegram-p1r-continuation-20261017/verify_postfix.py  -> exit 0 (41 passed, 0 failed)
```

The C1/C4 probe calls the projection API with no applier, which now raises
`a synchronous transactional applier is required to consume a projection position`
- the C1 correction - so it aborts instead of observing the old silent consumption;
`verify_postfix` runs the same scenario with the corrected expectation. The three
residual C3 assertions are all driven by the probe supplying
`unsentProof: "synthetic-pre-send-connect-refused"`, an arbitrary prose string that
the repaired C2 evidence contract deliberately refuses; the same lifecycle with a
valid classification (`connect_refused`) passes in `verify_postfix` and the permanent
suites. The original probe directories and their `*-results.json` are preserved
unchanged as prior evidence; the new runs are recorded separately in
`output/telegram-p1r-continuation-20261017/`.

### Verification actually run (this session)

Runtimes: Node v24.18.0; `inflowwkiller/.venv` Python 3.11.9.

| Command (cwd) | Result |
|---|---|
| `bot: npm run typecheck` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-contract.ts` | exit 0 - 77 shared cases (15 valid, 62 invalid), R4 digest pins, R5 boundary set |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-durable.ts` | exit 0 - all prior scenarios + the new C1/C2/C3 negative regressions |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-import-safe.ts` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-schema-parity.ts` | exit 0 - 12 tables, every column, plus rollback agreement |
| `bot: npm test` | exit 0 - `ALL 99 CHECKS PASSED` (4 Supabase-backed checks excluded by the offline runner) |
| `inflowwkiller: .venv\Scripts\python.exe service/tests/test_telegram_contract.py` | exit 0 - all cases passed (77 shared cases) |
| `inflowwkiller: .venv\Scripts\python.exe service/tests/test_telegram_store.py` | exit 0 - all cases passed (scenarios 1-17, incl. the new C1/C2/C3 regressions) |
| `output/telegram-p1r-c2-rereview-20261017/probe.mts` / `probe.py` | exit 0 - failures: 0 |
| `output/telegram-p1r-continuation-20261017/verify_postfix.mts` | exit 0 - 42 passed, 0 failed |
| `output/telegram-p1r-continuation-20261017/verify_postfix.py` | exit 0 - 41 passed, 0 failed |
| `py_compile` on `store.py`, `contract.py`, both Telegram test modules | exit 0 |
| `git diff --check` (bot, inflowwkiller) | exit 0 / clean |
| fixture copies: SHA-256 of each copy equals its recorded hash; three copies byte-identical | match (`cf88cca4...`) |

### Remaining boundaries

1. **P1-PG is still required.** Migration 144 is DDL (now aligned) and a
   name/column parity check; there is no Node PostgreSQL store and no real
   PostgreSQL transaction, type, constraint or RPC verification yet. SQLite proves
   the transaction boundaries here; PostgreSQL execution remains the next gate.
2. **The projection applier is a neutral seam, not the native reducers.** The
   regression uses a concrete configuration projection to prove the seam; real
   catalogue/history/configuration adapters and the production outbox remain P1-PG.
3. **Not verified here:** live Telegram receiver/Business permissions, the real
   financial handlers, the native Fastt engine, real model calls, actual orders and
   one-time pre-checkout (P3B), and any PostgreSQL behaviour.
4. **Engine still legacy.** No binding is activated; `resolveEngine` returns legacy
   unless a binding literally says `fastt`.
5. **Evidence contract is a closed set, by design.** `PROVEN_UNSENT_CLASSES` is a
   five-value vocabulary; the real transport must map its own failure classes onto
   it (or submit an operator decision) when the live transport is wired in P2/P3B.
   No live transport classification is observed here.
6. **Receipt scope is not enforced here.** The public `DeliveryReceipt` carries a
   message id (or the control acknowledgement); extra bot/chat/Business scope fields
   are the reviewer's non-blocking observation, and scoped receipt validation
   belongs with the trusted transport wiring, not this synthetic boundary. The
   acceptance of message-id value `"0"` is likewise unestablished as a provider
   contract defect and left unchanged.
7. **The three residual reviewer C3 assertions** are the probe's prose-proof
   precondition, explained above - not an outstanding lifecycle defect.
8. **`npm test` was green here (99/99).** The earlier failing `esbuild`/`spawn
   UNKNOWN` launch was environmental and did not reproduce; no prompt/honesty code
   was changed.
9. **Unresolved deployment facts** in section 8 above are unchanged.

### Safety attestations for this continuation

No Telegram receiver or second poller was started. No creator or bot was activated.
No Telegram message was sent. No paid model was called. No secret was read or
printed. No live Supabase data was written. Nothing was deployed, committed or
pushed. Existing uncommitted Telegram, OnlyFans, dashboard and bridge work is
untouched. Deliberate typos and misspellings remain disabled. No dollars were
converted to Stars. No second conversation engine or fallback sender was created.
P1-PG and P2 were not started.

---

## P1-R final four corrections, 17 October 2026 (implemented, awaiting independent review)

The bounded repairs for the four defects in P1R_CURRENT_REVIEW.md, in their existing
owners. Every accepted fix from earlier packages is preserved; nothing was activated.

### Finding -> fix -> regression

| Finding | Repair | Regression |
|---|---|---|
| 1. C3 purchase identity is inferred when omitted (P1) | Removed asset matching as a source of purchase identity in both stores: a `fulfillment` action is bound only by the EXPLICIT trusted obligation/portion id, carried through public `DeliveryAuthority.admit(action, "fulfillment", obligationId)` and the store's `obligationId`. No id => the action stays unassociated and unclaimable; a later purchase can never wake it, and two identical-media purchases are never ambiguous. `findOutstandingObligation`/`_find_outstanding_obligation` were deleted. Scope, frozen composition/revision, immutable association and the reservation lifecycle are unchanged. | check-fastt-durable "C3 an omitted purchase id is not guessed from identical assets", "C3 an explicit purchase id claims that purchase", "C3 a conflicting association cannot silently retarget an action" etc.; test_telegram_store same; reviewer c3/current-boundaries 10/10 both languages |
| 2. C2 Python accepts invalid operator evidence (P1) | A shared validation rule in both stores: operator evidence must be an object with ACTUAL nonblank STRING `actor` and `reason`. Null/boolean/number/container/blank/missing/non-object values are refused, never coerced with `str()`. The unknown hold, the reservation and the successor block are preserved; the exact supplied strings are stored as provenance. Node's previous `.trim()`-on-unknown-value path (which could throw a raw type error) is replaced by the same guard. | check-fastt-durable and test_telegram_store: "C2 invalid operator (null/boolean/number/container/blank/missing/not-an-object) cannot resolve an unknown attempt / leaves the attempt unknown / keeps the successor blocked"; reviewer c2 probes 4/4 and 13/13 |
| 3. C2 distinct operator decisions collide (P2) | Operator-decision evidence now carries `actor` and `reason` as SEPARATE structured fields, and its reference is an unambiguous canonical JSON array (was `"actor:reason"`). Terminal comparison compares kind, ref, actor and reason independently. An exact replay is idempotent; a different actor/reason is different evidence and follows the existing reconciliation path. | check-fastt-durable "C2 a colliding-but-different operator decision is not an identical replay" + reconciliation/retained-outcome assertions; test_telegram_store same; reviewer c2 probes |
| 4. C1 Node rejects async application after it has started (P2) | `ProjectionApplier.apply` return type is now `undefined` (not `void`), so a direct async implementation is a COMPILER error; the store additionally refuses an actual async function in `assertProjectionApplier` BEFORE invoking it. The returned-thenable check is retained as defense. Valid synchronous reducers, rollback and ordered replay are unchanged. Python's existing awaitable rejection is unchanged and now has an explicit regression. | check-fastt-durable "C1 an async applier is refused before invocation" (+ after-a-turn no-write / no-consume / no-envelope); test_telegram_store "C1 an awaitable application result is refused"; `async-typecheck.mts` is an EXPECTED compiler rejection (tsc exit 2); reviewer c1c4 11/11 |

### Changed files

`bot/` (branch `codex/telegram-fastt`, base `f414f32`):
`src/services/telegram-control-store.ts` (ProjectionApplier type, async pre-check,
validated operator + structured evidence, removed obligation-inference fallback),
`src/services/delivery-authority.ts` (`admit` carries the trusted obligation id),
`src/dev/check-fastt-durable.ts` (regressions + explicit-id fixtures).

`inflowwkiller/` (base `e72316f`; OF/native-pilot/bridge work preserved):
`service/telegram_contract/store.py` (validated operator + structured evidence,
removed obligation-inference fallback),
`service/tests/test_telegram_store.py` (regressions + explicit-id fixtures).

`DOCS_ROOT/`: `contracts/CONTRACT.md` (explicit purchase identity, strict operator
evidence, unambiguous comparison, stronger synchronous applier, representation
compatibility note), `PROGRESS.md`.

`output/`: `telegram-p1r-finalfix-20261017/README.md` (new); the reviewer's `c3/adapted-old`
copies adapted to supply the explicit trusted id; `telegram-p1r-continuation-20261017`
`verify_postfix` fulfilments given explicit ids. No dashboard or OnlyFans production
file was edited.

### Failing-before -> passing-after evidence

The reviewer's probes reproduced all four defects; re-running the SAME probes on this
revision (runtimes Node v24.18.0 / Python 3.11.9):

```text
c1c4/check.mts          before 10 passed / 1 failed  -> after exit 0, 11 passed / 0 failed
c1c4/check.py           before exit 0, 6 passed      -> after exit 0, 6 passed
c1c4 async-typecheck    before exit 0 (compiled)     -> after exit 2 (expected rejection)
c2/probe.mts            before 2 passed / 2 failed   -> after exit 0, 4 passed / 0 failed
c2/probe.py             before 2 passed / 11 failed  -> after exit 0, 13 passed / 0 failed
c3/current-boundaries   before 9 passed / 1 failed   -> after exit 0, 10 passed / 0 failed (both languages)
c3/adapted-old          before 13 passed / 0 failed  -> after exit 0, 13 passed / 0 failed (both languages)
```

### Verification actually run (this session)

| Command (cwd) | Result |
|---|---|
| `bot: npm run typecheck` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-contract.ts` | exit 0 - 77 shared cases |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-durable.ts` | exit 0 - 216 assertions, incl. the new C1/C2/C3 regressions |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-import-safe.ts` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-schema-parity.ts` | exit 0 |
| `bot: npm test` | exit 0 - `ALL 99 CHECKS PASSED` (4 Supabase-backed checks excluded) |
| `bot: tsc --project output/.../c1c4/tsconfig.json` (async assignment) | exit 2 - expected compile rejection |
| `inflowwkiller: .venv\Scripts\python.exe service/tests/test_telegram_contract.py` | exit 0 - all cases passed |
| `inflowwkiller: .venv\Scripts\python.exe service/tests/test_telegram_store.py` | exit 0 - 223 assertions passed |
| reviewer probes c1c4 / c2 / c3 (current-boundaries + adapted-old), Node and Python | exit 0 |
| `verify_postfix.mts` / `verify_postfix.py` | exit 0 (42 / 41 assertions) |
| `py_compile` on the four changed Python files | exit 0 |
| `git diff --check` (bot, inflowwkiller) | exit 0 / clean |

### Remaining boundaries

1. **P1-PG and P2 not started.** Migration 144 remains DDL parity only; no PostgreSQL
   runtime transaction/constraint verification. Native Fastt reducers remain P2;
   financial handlers remain P3B.
2. **Operators are still synthetic.** The validation proves the trusted boundary's
   TYPE rules; real operator authentication/attribution is later wiring.
3. **Evidence representation change is documented, not migrated.** The operator-decision
   `evidence_ref` is now a canonical JSON array; no shared database is reset and no live
   evidence rows exist to migrate (the store is a new, locally unapplied, disabled
   foundation).
4. **Unresolved deployment facts** in section 8 above are unchanged.

### Safety attestations for these final corrections

No Telegram receiver or second poller was started. No creator or bot was activated. No
Telegram or OnlyFans message was sent. No paid model was called. No secret or private
transcript was read or printed. No live Supabase data was written. Nothing was deployed,
committed or pushed. Existing uncommitted Telegram, OnlyFans, dashboard and bridge work
is untouched. Deliberate typos and misspellings remain disabled. No dollars were
converted to Stars. No second conversation engine or fallback sender was created. P1-PG
and P2 were not started.

## P1-PG production PostgreSQL control store, 17 October 2026 (builder submission; superseded by independent review below)

P1-R was independently accepted (see `P1R_ACCEPTANCE.md`). This package implements the
production Node PostgreSQL control store the plan requires before P2, and verifies it
against a REAL disposable PostgreSQL cluster. No live receiver, worker, model, message,
secret, migration or deployment is involved.

### What P1-PG delivers

- `bot/src/services/telegram-control-store-pg.ts` (new) - the production async `pg`
  adapter for the same control-record contract the offline SQLite reference store
  mirrors: bindings/ownership epoch, conversation scope and controls, paid obligations
  and their reservation lifecycle, event admission, native identity allocation,
  delivery-action registration/claim/completion, projection import + per-stream cursor,
  worker leases and the invocation journal. It is DISABLED BY DEFAULT: constructing it
  opens no receiver/worker/timer and connects to nothing on import.
- `bot/src/dev/check-fastt-pg.ts` (new) - the permanent, DB-gated PostgreSQL verification
  (78 assertions when first delivered; 131 after the PG1-PG5 corrections below) that
  creates and drops its own scratch database.
- `bot/src/services/telegram-control-store.ts` (edited) - the pure, security-relevant
  decision logic (`outcomeEvidence`, `sameEvidence`, `assertProjectionApplier`) and the
  small helpers (`digestOf`, `isAsyncFunction`, `validatedOperator`, `operatorRef`,
  `PROJECTION_BODY_SCHEMA_VERSION`) are now exported / static, so the Postgres adapter
  REUSES them instead of re-implementing them.
- `bot/src/dev/run-checks.ts` (edited) - a DB-gated set now covers both the live-Supabase
  checks and `check-fastt-pg`; the offline `npm test` run is unchanged and still skips
  every DB-backed check.
- `bot/src/dev/check-fastt-import-safe.ts` (edited) - also imports the Postgres module,
  asserting that importing it starts nothing.

### How divergence is prevented (no parallel source of truth)

The governing rules forbid two hand-maintained descriptions of one contract. This package
keeps ONE definition at each layer:

1. **DDL shape** - already guarded by `check-fastt-schema-parity` (SQLite DDL <-> migration
   144 <-> rollback script). Unchanged by P1-PG.
2. **Decision logic** - the evidence rules, the action-class authority predicate inputs and
   the appliance validation are the reference store's exported static methods; the
   Postgres adapter calls `TelegramControlStore.outcomeEvidence`,
   `TelegramControlStore.sameEvidence` and `TelegramControlStore.assertProjectionApplier`
   directly, so they cannot drift. The one Postgres-local predicate (`authorizeClassOn`)
   reads obligations inside the transaction's client but otherwise mirrors the accepted
   class rules.
3. **Concurrency** - the only genuinely dialect-specific part. SQLite used
   `BEGIN IMMEDIATE` (a global writer lock); Postgres is READ COMMITTED, so the adapter
   takes a transaction-scoped advisory lock per serialised stream (a conversation, a
   projection recipient, a native-id space, the event receipt sequence, a worker lease)
   plus `FOR UPDATE` / conditional `UPDATE ... RETURNING`, so two independent clients
   cannot both win one claim or one admission.

### Direct-connection decision (no new RPC, no new migration)

The plan prefers narrow RPCs "unless a direct connection is justified and tested". The
control operations here are multi-statement transactions with row locks and advisory
locks, which PostgREST cannot express; PostgREST chains are explicitly not transactions.
A direct `pg` connection is therefore justified and is exercised by this package's tests.
No new RPC and no new migration were added: migration 144 is FROZEN and is applied as-is
in the test (never rewritten), and the plan requires target schema attestation before any
live application. The browser/tenant path is closed by RLS enabled with no policies
(deny-all), which the test proves for a non-service role; service-role requests are scoped
by the store's explicit ownership checks rather than RLS. Wrapping the operations in
scoped RPCs and the dashboard controls are P2/P4 work.

### Changed files

| File | Change |
|---|---|
| `bot/src/services/telegram-control-store-pg.ts` | new - production Postgres adapter |
| `bot/src/dev/check-fastt-pg.ts` | new - disposable-PostgreSQL verification |
| `bot/src/services/telegram-control-store.ts` | exports + static methods only (behaviour-preserving) |
| `bot/src/dev/run-checks.ts` | DB-gated set now includes the Postgres check |
| `bot/src/dev/check-fastt-import-safe.ts` | import the Postgres module |
| `output/telegram-p1pg-20261017/` | new - evidence logs and README |

No migration, DDL, dashboard, `inflowwkiller`, engine-router or `src/index.ts` file was
edited. The only pre-existing TRACKED file changed is `bot/src/dev/run-checks.ts`; every
other file above was already untracked P1/P1-R work.

### Verification actually run (this session)

Runtimes: Node v24.18.0; PostgreSQL 18.4 (loopback 127.0.0.1:55432, disposable); Python
3.11.9.

| Command (cwd) | Result |
|---|---|
| `bot: npm run typecheck` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-pg.ts` (with `TWIN_FASTT_PG_URL`) | **exit 0 - 78 assertions, 0 failures** (superseded by 131 after PG1-PG5) |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-pg.ts` (no URL) | **exit 1 - BLOCKED, not a pass** |
| `bot: ...check-fastt-pg.ts` (with `TWIN_FASTT_FORCE_NO_PG=1`) | exit 0 - the deliberate skip seam |
| `bot: ...check-fastt-durable.ts` | exit 0 - 216 assertions; the shared-logic refactor is behaviour-preserving |
| `bot: ...check-fastt-schema-parity.ts` | exit 0 |
| `bot: ...check-fastt-import-safe.ts` | exit 0 - importing the Postgres store starts nothing |
| `bot: npm test` | exit 0 - `ALL 99 CHECKS PASSED` (5 DB-backed checks skipped, incl. check-fastt-pg) |
| `bot: npm run test:db` (with `TWIN_FASTT_PG_URL`) | 104 checks: **check-fastt-pg PASS (2.7s)**; 2 of 104 FAILED (see below) |
| `inflowwkiller: .venv/Scripts/python.exe -B service/tests/test_telegram_contract.py` | exit 0 |
| `inflowwkiller: .venv/Scripts/python.exe -B service/tests/test_telegram_store.py` | exit 0 |
| `git -C bot diff --check` / `git -C inflowwkiller diff --check` | exit 0 / exit 0 |

The 2 failures in `npm run test:db` are the pre-existing live-Supabase checks
`check-check-slug-default` (spawns `npx`, which is not on this PATH) and
`check-clone-column-drift` (no Supabase credentials). Neither is related to P1-PG and no
live-Supabase verification is claimed.

### What the PostgreSQL check exercises (the acceptance list)

| Required scenario | Where it is proven against real PostgreSQL |
|---|---|
| duplicate Telegram updates | identical redelivery is a no-op and returns the first event id; two concurrent admissions insert exactly once |
| same user across different creators | `telegramFanKey` for CLONE_A and CLONE_B allocates two native identities |
| identical message ids in different chats | `telegramMessageKey` for two chats allocates two native ids; conversation keys differ |
| malformed ids / timestamps | non-decimal, zero-padded id and year-zero timestamp raise `FasttContractError`; no row written |
| stale ownership revisions | stale conversation input revision, stale config and stale ownership epoch are all refused by name |
| conflicting action payloads | a changed body under an existing action id raises `ActionConflictError` (see note) |
| transaction rollback | a simulated projection interruption and an async applier leave rows, applied markers and cursor unchanged; a rejected completion leaves the obligation reserved |
| competing workers | two independent clients race one claim -> exactly one wins, `attempt_count = 1`; conversation-wide hold blocks a second action |
| projection cursor recovery | gap holds the cursor; filling the gap advances only over the contiguous prefix; replay is a no-op |
| late receipts | an `unknown` attempt settles to `confirmed` with the same token; conflicting late evidence is recorded for reconciliation, not overwritten |
| explicit purchase association | unassociated fulfilment is unclaimable; a mismatched obligation is refused; identical-media purchase B settles while A stays outstanding |
| reservation/settlement rollback | confirmed settles; proven-unsent releases back to outstanding and clears the action link |
| access denial | a non-service role reads zero rows and cannot insert past deny-all RLS; the store refuses a wrong-clone caller and an out-of-scope action |
| recovery documentation | the rollback script is applied and drops exactly the twelve control tables, leaving the pre-existing `clones` table intact |

Note: `ActionConflictError` is asserted by code path in the adapter and in
`check-fastt-durable` against the reference store; the P1-PG run exercises the identical
shared predicate and the `EventConflictError`/`ProjectionConflictError` siblings directly.

### Remaining boundaries and deployment facts

1. **No live schema attestation.** Migration 144 was validated on a disposable cluster
   with a minimal `clones` stub; it has NOT been applied to live Supabase and the real
   `clones`/default-privilege state is still unverified. Target schema attestation remains a
   prerequisite before any live application.
2. **Still not wired.** The Postgres store is not imported by `src/index.ts`; no receiver,
   router, worker or sender uses it. `delivery-authority.ts`, `projection-cursor.ts` and
   `identity-map.ts` remain synchronous and typed to the reference store; building the
   async authority/gateway layer is P2, as is the native Fastt worker and OpenRouter.
3. **Permissions are synthetic.** RLS denial was proven with a purpose-created restricted
   role; the production `anon`/`authenticated` roles and Supabase default privileges were
   not exercised here. No new RPC was added, and no scoped RPC authorization exists yet.
4. **Concurrency is at the storage boundary.** Two independent clients were proven at the
   store/DB layer, not through the real grammY receiver integration, which is P2.
5. **Rollback limitation (unchanged and documented in the script header).** Applying the
   rollback destroys control state that is not recoverable from elsewhere, and a later
   re-apply restarts ownership epochs at 0, so any worker holding an old epoch must be
   fenced first.
6. **Python native state and projections are untouched.** Fastt's native SQLite state, its
   own reference store and the derived projections are unchanged; real financial handler
   integration remains P3B.
7. **Unresolved deployment facts** in section 8 are unchanged.

### Safety attestations for P1-PG

No Telegram receiver or second poller was started. No creator or bot was activated. No
Telegram or OnlyFans message was sent. No paid model was called. No secret or private
transcript was read or printed. No live Supabase data was read or written and migration
144 was not applied to any live project. The only database touched was the disposable
loopback cluster created and dropped by the check itself. Nothing was deployed, committed
or pushed. Existing uncommitted Telegram, OnlyFans, dashboard and bridge work is
untouched. Deliberate typos and misspellings remain disabled. No dollars were converted to
Stars. No second conversation engine, delivery authority or fallback sender was created.
P2 has not started.

## P1-PG independent review, 17 October 2026 — corrections required

Disposition: **P1-PG is not accepted; complete PG1-PG5 in P1PG_REVIEW.md.**
P1-R remains accepted. START_HERE.md now identifies this exact next assignment.
The earlier builder submission is historical evidence, not the review verdict.

The reviewer inspected actual source and ran real disposable PostgreSQL probes:

- PG1: takeover reported effective before an old AI claim subsequently succeeded;
  a separate epoch-race probe claimed with epoch 0 after epoch 1 committed; an
  action that expired during a real lock wait still claimed.
- PG2: simultaneous identical action registration returned one success and one
  raw unique-constraint error (23505).
- PG3: a real target write survived while projection event/cursor rolled back;
  the PG applier has no transaction-client seam. The required canonical source
  publisher/recipient sequence allocator is also missing. Keep native destination
  application in the existing SQLite transaction owner.
- PG4: an inbound event with a known binding but a different clone/bot was
  stored. The standalone authorization helper is not an operation-level boundary.
- PG5: forcing the PG check to skip prints its success marker and exits 0.

Independent verification: permanent PG 78/78; typecheck exit 0; reference durable,
schema parity and import-safe checks exit 0; both Python suites exit 0. Initial
default Node run had three process failures (one explicit memory crash, two
silent native exits); each failed check passed individually, and a subsequent
complete default run passed 99/99. The final independent defect diagnostic exits
1 with six failed expectations. Missing-PG exits 1 correctly; forced skip exits
0 incorrectly. No live-Supabase-inclusive `test:db` run was performed.

Evidence: `output/telegram-p1pg-review-20261017/README.md`, `probe.mts`,
`probe-results.json`, exact command logs, `baseline.json` and `final-hashes.json`.
All six reviewed app/migration hashes are unchanged by review. Disposable review
databases were dropped; the previously running loopback cluster was reused.
Only review evidence and planning/status documents changed. No application fix,
receiver, worker, activation, send, model call, secret/private-data inspection,
live Supabase operation, deployment, commit or push occurred. P2 remains closed.

## P1-PG corrections PG1-PG5, 17 October 2026 (builder submission; superseded by re-review below)

Astra's independent PostgreSQL review reproduced five bounded findings in
`P1PG_REVIEW.md` (frozen evidence in `output/telegram-p1pg-review-20261017/`).
This section completes PG1-PG5 and their permanent regressions only; P1-R stays
accepted and P2 has not started.

### Finding -> change -> regression

| Finding | Change (owner) | Permanent regression |
|---|---|---|
| **PG1** authority changes and claims were not one concurrency protocol; the claim clock predated the lock | `claimAction` now performs the class decision AS the transition: one conditional `update delivery_actions set state = 'dispatching' ...` whose WHERE clause re-checks ownership epoch, effective assignment, AI pause, binding takeover, conversation takeover, input revision, config and the outstanding obligation against the latest committed rows at write time, leaving zero rows on any change. The conversation advisory lock still serialises claimants; the pre-read only supplies the class and the diagnostic reason. The clock is read AFTER the lock, and `acquireLease` reads its clock after its lock too | `PG1 claim races each authority change, both serialization orders` (takeover race, epoch race, expiry-during-lock-wait, unrelated-conversation progress) and `a lease granted after a lock wait is not already expired` |
| **PG2** two clients could both read a missing action and one then failed with a raw 23505 | `registerAction` keeps its fast-path read then uses an UNTARGETED `on conflict do nothing` + frozen-digest readback (the table has two unique indexes, so a targeted clause was insufficient); `upsertBinding` and `bindConversation` use the same guarded insert + readback | `PG2 concurrent identical registration` (both clients forced through the missing-record window; one reports creation, one an idempotent replay; one row; typed conflict; binding and conversation establishment races) |
| **PG3** the PG adapter only had a destination importer whose no-op callback did not prove target-state atomicity, and there was no production publisher | Retired the PG destination-import API (`importProjectionEvent`, `applyPrefixOn`, `projectionAppliedAt`). Added `publishProjectionEvent` (transactional per-recipient `source_sequence` allocation, immutable identity/body/digest, idempotent replay, typed conflict on changed content or reused position), `readProjectionEvents` (bounded ordered reads) and `withTransaction` (a composition seam whose facade holds one client, so a source mutation and its outbox commit or roll back together). Destination target-state + cursor atomicity stays with the SQLite consumer, proven by `check-fastt-durable` | `source publication: identity, isolation, ordering, rollback and composition (PG3)` |
| **PG4** `admitEvent` accepted a mismatched clone/bot and `assertAuthorizedScope` was only used by its own test | `admitEvent` resolves the TRUSTED binding identity inside its transaction and refuses a mismatched clone/bot/mode/Business connection, or an unknown binding, before any event/outbox write. Added `ScopedTelegramControlRepository`, a trusted-context scope facade covering privileged operations (create/update binding, bind conversation, admit, register, claim, finish, obligation, controls, epoch, reads) | `PG4 trusted inbound binding scope` and `PG4 scoped repository boundary at real operations` |
| **PG5** `TWIN_FASTT_FORCE_NO_PG=1` printed SKIPPED, then a success marker, and exited 0 | Forced unavailability now returns the SAME nonzero BLOCKED result as a missing URL - no green bypass. The default offline runner still EXCLUDES `check-fastt-pg` from `npm test`; that exclusion is separate from falsely passing an explicitly selected database check | `check-fastt-pg-forced-unavailable.log` (exit 1) and `check-fastt-pg-missing-url.log` (exit 1) |
| Doc accuracy | The PG module header claimed the action-class authority was shared pure logic. It is not: evidence validation and appliance validation are shared, but each adapter states the class predicate. The header now says so and notes the PG claim is authoritative for a Postgres deployment, with observable parity covered by the durable suites | header comment (no separate regression; the inaccuracy was documentation-only) |

`check-fastt-import-safe` already imports the PG module and still proves that
importing it starts no timer, signal handler or receiver.

### Commands actually run (this session)

Runtimes: Node v24.18.0; PostgreSQL 18.4 on loopback `127.0.0.1:55432`
(disposable); Python 3.11.9. The reviewer's frozen probe was NOT edited; an
adapted copy with the same six expectations is in
`output/telegram-p1pg-fix-20261017/probe.mts`.

| Command (cwd) | Result |
|---|---|
| `bot: npm run typecheck` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-pg.ts` (local PG URL) | **exit 0 - 131 assertions, 0 failures** |
| `bot: ...check-fastt-pg.ts` with `TWIN_FASTT_FORCE_NO_PG=1` | **exit 1 - BLOCKED (no success marker)** |
| `bot: ...check-fastt-pg.ts` with no URL | exit 1 - BLOCKED |
| `bot: node_modules/.bin/tsx.cmd '..\output\telegram-p1pg-fix-20261017\probe.mts'` (adapted diagnostic) | **exit 0 - `failedExpectations: []`** |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-durable.ts` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-schema-parity.ts` | exit 0 |
| `bot: node_modules/.bin/tsx.cmd src/dev/check-fastt-import-safe.ts` | exit 0 |
| `bot: npm test` | exit 0 - `ALL 99 CHECKS PASSED` (DB-backed checks skipped) |
| `inflowwkiller: .venv\Scripts\python.exe -B service/tests/test_telegram_contract.py` | exit 0 |
| `inflowwkiller: .venv\Scripts\python.exe -B service/tests/test_telegram_store.py` | exit 0 |
| `git -C bot diff --check` / `git -C inflowwkiller diff --check` | exit 0 / exit 0 |

Note: the first `npm test` of this session failed 32 of 99 with a machine-level V8
`ERR_WORKER_INIT_FAILED` / "Zone Allocation failed" (0.6 GB free of 15.5 GB). A
subsequent full run passed 99/99; the same instability was recorded by the
reviewer. No application failure is inferred: each affected suite passes
individually and the re-run is green.

### Source hashes (SHA-256)

| File | Hash |
|---|---|
| `bot/src/services/telegram-control-store-pg.ts` | `4733CA5AD510CD63D695A27142A6588EDF88CF20D5E1F536E79736F49AAFC7B1` |
| `bot/src/dev/check-fastt-pg.ts` | `F0D58F5203D31FC6F30E0375C0C6585C41E0DE3A244FC3A7B1735233DFCA79C3` |
| `bot/src/dev/check-fastt-import-safe.ts` | `A74E1C74350E4B7B602B09D308F00D7730DB51E343DF323B5545687F13A4E61F` |
| `bot/src/dev/run-checks.ts` | `3EA19A74A34F261DF0FB6ED519A8779C11E7DC9F1F05A4070707B411124F85F6` (unchanged this package) |
| `bot/src/services/telegram-control-store.ts` | `9E71EC26B36456D94C6470D85012E0A40585EF0FF0854F2AF98B41350375D58F` (unchanged this package) |
| `bot/db/migrations/144_telegram_fastt_contracts.sql` | `4D477B20A0B131527F13B99F39884452B29D23ACD9877D70CED721DF72B5CBDC` (unchanged, not rewritten) |
| `bot/db/manual/ROLLBACK_144_telegram_fastt_contracts.sql` | `0CDE911A39A7AE961AA26F4492E9F2BC8AB6B93421D8DB134A1DC76A82B0DC48` (unchanged) |

### Changed files

| File | Change |
|---|---|
| `bot/src/services/telegram-control-store-pg.ts` | PG1 claim protocol + clock-after-lock; PG1 lease clock; PG2 conflict-safe insert/readback; PG3 publisher + `readProjectionEvents` + `withTransaction` (retiring the destination importer); PG4 trusted binding scope in `admitEvent` + `ScopedTelegramControlRepository`; corrected header claim |
| `bot/src/dev/check-fastt-pg.ts` | PG1-PG5 permanent regressions; PG5 no green bypass; gated-pool scheduling helpers; header updates |
| `bot/src/dev/check-fastt-import-safe.ts` | already imported the PG module (unchanged this session's edits) |
| `output/telegram-p1pg-fix-20261017/` | new - adapted diagnostic, logs, README |
| `output/telegram-p1pg-review-20261017/` | untouched (frozen review evidence) |

No migration, dashboard, `inflowwkiller`, engine-router or `src/index.ts` file was
edited. `bot/src/dev/run-checks.ts` remains the only changed pre-existing TRACKED
file (the DB gate from the previous package).

### Cleanup evidence

After all runs: `scratch dbs=0 restricted roles=0` (no `twin_fastt%` database and no
`twin_control_restricted` role left on the loopback cluster), and each check reports
`databaseRemoved: true`.

### Remaining deployment facts and rollback limitations

1. **No live schema attestation.** Migration 144 was validated on a disposable
   cluster with a minimal `clones` stub; it has NOT been applied to live Supabase.
   The cluster version is 18.4; production version/privileges remain unverified.
2. **Still unwired.** The PG store and the scoped repository are not imported by
   `src/index.ts`; no receiver, router, worker, sender or HTTP route uses them.
   `delivery-authority.ts`/`projection-cursor.ts`/`identity-map.ts` stay synchronous
   and typed to the reference store; the async authority/gateway, the native Fastt
   worker and OpenRouter are P2.
3. **Concurrency is proven at the storage boundary** (two independent clients at the
   store/DB layer), not through the real grammY receiver, which is P2.
4. **No new RPC or migration.** The direct `pg` connection remains justified
   (PostgREST cannot express these transactions) and tested; the browser/tenant path
   stays closed by deny-all RLS. Production `anon`/`authenticated` roles were not
   exercised; RLS denial used a purpose-created role.
5. **Rollback limitation (unchanged, documented in the script header).** Applying the
   rollback destroys control state that is not recoverable elsewhere, and a later
   re-apply restarts ownership epochs at 0, so any worker holding an old epoch must
   be fenced first.
6. **Obligation/epoch semantics are unchanged** from the accepted reference store:
   a claim (of any class) still requires the expected ownership epoch, so an epoch
   bump after registration blocks a stale prepared action rather than granting it a
   new dispatch. Late completion of an already-claimed attempt is unaffected.
7. Section 8 deployment facts are unchanged.

### Safety attestations for PG1-PG5

No Telegram receiver or second poller was started. No creator or bot was activated.
No Telegram or OnlyFans message was sent. No paid model was called. No secret or
private transcript was read or printed. No live Supabase data was read or written
and migration 144 was not applied to any live project. The only database touched was
the disposable loopback cluster created and dropped by the checks. Nothing was
deployed, committed or pushed. Existing uncommitted Telegram, OnlyFans, dashboard
and bridge work is untouched. Deliberate typos and misspellings remain disabled. No
dollars were converted to Stars. No second conversation engine, delivery authority
or fallback sender was created. P2 has not started.

## P1-PG corrections re-review, 17 October 2026 — PG2/PG4/PG5 closed

Reviewed actual adapter hash `4733CA5A...`, permanent PG suite hash `F0D58F52...`.
**PG2, PG4 and PG5 are closed within this package. PG1 and PG3 remain open.**
P1PG_REREVIEW.md and the updated START_HERE.md define four residual items only:

- PG1-A: the conditional UPDATE still races control changes committed while it
  is running. A timing-only trigger in a disposable PostgreSQL database exposed
  seven actual mutation variants; effective takeover became false after an old
  AI claim, and epoch 0 claimed after epoch 1 committed. Control writers must
  participate in a conflicting lock protocol through the claim commit.
- PG1-B: a clock sampled after the conversation lock but before the action-row
  lock still admitted an action expiring during the latter real wait.
- PG3-A: allowed publication positions `[1,4,5]` left the actual SQLite consumer
  at cursor 1 with only one target row applied. Keep source allocation contiguous.
- PG3-B: the transaction facade omits receipt completion, so that source mutation
  cannot yet share a transaction with publication. Reuse the existing completion
  owner; do not implement another evidence/financial authority.

Independent checks: typecheck exit 0; PG suite 131/131, exit 0; builder adapted
probe exit 0; default Node suite 99/99, exit 0; forced and missing PostgreSQL
both BLOCKED/exit 1/no success marker. Independent residual probe exits 1 with
ten expectations across the four items above. Concurrent automatic publication
passes with positions 1 and 2. Bot/Fastt diff checks exit 0. Python source was
unchanged; this re-review did not repeat the prior Python runs.

Evidence: `output/telegram-p1pg-rereview-20261017/README.md`, `probe.mts`, JSON
results, exact logs and baseline/final hashes. All seven reviewed app/migration
files are byte-unchanged by review. Probe databases are removed in finally; no
service was started/stopped and the existing loopback cluster was reused. Only
review evidence and governing status/handoff documents changed. No live data,
secrets, private transcripts, model calls, messages, activation, deployment,
commit or push. P1-R remains accepted; P2 remains not started.

## P1-PG residual corrections (PG1-A, PG1-B, PG3-A, PG3-B), 17 October 2026

Adapter hash moved `4733CA5A...` -> `5A2CFF69...`; permanent suite hash
`F0D58F52...` -> `50C79592...` (full hashes below). Scope is exactly the four
residual items in P1PG_REREVIEW.md. PG2/PG4/PG5 stay closed; migration 144 is
untouched; P1-R stays accepted. The reviewer's frozen evidence in
`output/telegram-p1pg-rereview-20261017/` was not modified - the probe was re-run
from a copy.

### Finding -> change -> regression

- **PG1-A (authority writers fatally fenced through the claim).** In
  `bot/src/services/telegram-control-store-pg.ts` a claim now takes a SHARED
  transaction-scoped advisory lock on `binding:<id>`, then the exclusive
  `conversation:<key>` lock, then the action-row `FOR UPDATE`. Every applicable
  authority writer now takes the conflicting exclusive lock: `bumpEpoch`,
  `setBindingControls`, `createOrUpdateBinding`/`updateBindingMutable` on the
  binding; `setConversationControls` and `bumpConversationInputRevision` on the
  conversation. One documented order (binding -> conversation -> action row ->
  obligation row) prevents cycles and no lock is held across an AI/transport call.
  The READ COMMITTED other-table predicates remain as a second line of defence.
  Regression: `authorityWriterFenceSection` installs a scheduling-only BEFORE UPDATE
  trigger in the disposable database and proves all seven writers (conversation
  takeover, epoch, AI pause, binding takeover, input revision, config, effective
  engine) block on a real lock and cannot commit underneath a paused claim. The
  retained `authorityRaceSection` Order A/B were adapted to the protocol so the claim
  admitted first wins and the writer follows instead of deadlocking.
- **PG1-B (deadline sampled after every relevant lock wait).** `claimAction` samples
  the eligibility clock after the binding lock, the conversation lock AND the
  action-row `FOR UPDATE`, immediately before the conditional transition; not-before
  and expiry are both re-evaluated. Regression: `rowLockExpirySection` holds the
  action row in a real concurrent transaction, advances the injected clock past the
  expiry during the wait, and proves the claim is refused with an expiry reason. The
  existing conversation-lock expiry case is retained.
- **PG3-A (no unexplained publication gaps).** `publishProjectionEventOn` is the
  single allocator: a caller-supplied `sourceSequence` is accepted only when it equals
  the transactionally derived next contiguous position, otherwise a typed
  `ProjectionConflictError` is raised before any write; allocation stays bounded by
  `INDEX_MAX`. Regression: the permanent projection section replaced the `[1,4,5]`
  success expectation with a typed gap rejection plus contiguous allocation, and a
  real SQLite consumer (`TelegramControlStore` importer) with an actual target-table
  applier applies every published position and reaches the publisher head, surviving
  close/reopen.
- **PG3-B (receipt completion composable with publication).** The existing
  `finishAction` body was extracted as the transaction-aware `finishActionOn`, used by
  both the standalone method and the `withTransaction` facade, which now also exposes
  `finishAction`. No second evidence validator, ledger or completion authority was
  added. Regression: `completionCompositionSection` completes a real synthetic
  dispatch and publishes its receipt in one transaction; an injected failure rolls
  back action state/evidence, the obligation reservation, the outbox row and the
  stream head; an identical retry settles and publishes exactly once.

### Actual verification (commands and exits)

| Command | Result |
|---|---|
| `npm run typecheck` (in `bot/`) | exit 0 |
| `TWIN_FASTT_PG_URL=postgres://postgres@127.0.0.1:55432/postgres npx tsx src/dev/check-fastt-pg.ts` | exit 0 - 183 assertions, `check-fastt-pg: all cases passed` |
| `npx tsx output/telegram-p1pg-verify-20261017/probe.mts` (reviewer's probe, re-run from a copy) | exit 0 - `failedExpectations: 0`, `cleanup.databaseRemoved: true` |
| `npm test` | exit 0 - `ALL 99 CHECKS PASSED`; `check-fastt-pg` correctly skipped in the offline suite |
| `TWIN_FASTT_FORCE_NO_PG=1 npx tsx src/dev/check-fastt-pg.ts` | exit 1 - BLOCKED banner, no success marker (PG5 preserved) |

Reviewer probe re-run detail: all seven authority variants now report
`controlCommittedBeforeClaim=false`, `controlWaitedOnLock=true`, `claimed=true` with
the winning claim keeping its admitted epoch; `expiryAfterRowWait.claim.claimed=false`
with reason `action has expired`; `publisherGap` rejects the position-4 jump with
`ProjectionConflictError` and applies `2/2` rows to the real SQLite consumer at cursor
2 = head; `receiptCompletionComposable=true` with `finishAction` listed among the
transaction operations; concurrent publishers allocate `[1,2]`.

Cleanup: `leftover twin_fastt dbs=0 any twin_ dbs=0 restricted roles=0` on the
loopback cluster after all runs.

### Changed files and hashes (SHA-256, lower-case)

| File | SHA-256 |
|---|---|
| `bot/src/services/telegram-control-store-pg.ts` | `5a2cff69d5920f7ff31ee1e8fd4c5acf6a6794a5fcc0b9ab35d001d013c11be9` |
| `bot/src/dev/check-fastt-pg.ts` | `50c79592710d61d26c63737e73df8ffc2e6b210b397570d0e2026a4bd5cf7597` |
| `bot/db/migrations/144_telegram_fastt_contracts.sql` | `4d477b20a0b131527f13b99f39884452b29d23acd9877d70ced721df72b5cbdc` (unchanged) |
| `bot/db/manual/ROLLBACK_144_telegram_fastt_contracts.sql` | `0cde911a39a7ae961aa26f4492e9f2bc8ab6b93421d8db134a1dc76a82b0dc48` (unchanged) |
| `bot/src/services/telegram-control-store.ts` | `9e71ec26b36456d94c6470d85012e0a40585ef0ff0854f2af98b41350375d58f` (unchanged) |
| `bot/src/dev/run-checks.ts` | unchanged from the reviewed baseline |
| `output/telegram-p1pg-verify-20261017/` | new - probe copy, probe log/results, PG suite logs (`pg-run.log`, `pg-run2.log`), offline suite log, forced-unavailable log |

### Remaining deployment facts and limitations

1. No live schema attestation: migration 144 was exercised only on the disposable
   loopback cluster (PostgreSQL 18.4) with a minimal `clones` stub; it has not been
   applied to live Supabase. No new RPC or migration was added for these fixes.
2. Still unwired: the PG store and the scoped repository are not imported by
   `src/index.ts`; no receiver, router, worker, sender or route uses them. The async
   authority/gateway, native Fastt worker and OpenRouter remain P2.
3. Concurrency is proven at the storage boundary with two independent clients, not
   through the real grammY receiver (P2).
4. PG1-A/B fence control writers and claim eligibility. They do not fence an authority
   change that commits before the claim begins - that order correctly refuses the
   claim and is covered by `authoritySection` - nor wall-clock advance after a valid
   claim before a later external send, which the future transport gate owns.
5. Rollback limitation unchanged: applying the rollback destroys control state and a
   later re-apply restarts ownership epochs at 0, so an old-epoch worker must be
   fenced first.

### Safety attestations (this correction)

No Telegram receiver or second poller was started. No creator or bot was activated.
No Telegram or OnlyFans message was sent. No paid model was called. No secret or
private transcript was read or printed. No live Supabase data was read or written and
no migration was applied to any live project. Only the disposable loopback cluster
created and dropped by the checks was touched. Nothing was deployed, committed or
pushed. Existing uncommitted Telegram, OnlyFans, dashboard and bridge work is
untouched. Deliberate typos remain disabled. No dollars were converted to Stars. No
second conversation engine, delivery authority, publisher or fallback sender was
created. P2 has not started. Stopped for Astra's P1-PG review.

---

## 2026-10-17 Independent acceptance of the final P1-PG corrections

Disposition: **accepted within local PostgreSQL implementation scope**. All four
residual PG1-A/PG1-B/PG3-A/PG3-B findings are closed; PG2/PG4/PG5 and P1-R stay
accepted. See P1PG_ACCEPTANCE.md. No additional repair assignment was opened.

The reviewer inspected the actual responsible code and permanent tests, then ran:

- Node typecheck: exit 0.
- Permanent disposable PostgreSQL suite: exit 0, 183 assertions, 0 failures.
- Unchanged copy of the independent reproduction: exit 0, no failed expectations.
  All seven authority writers waited on real locks; row-wait expiry was refused;
  publication positions remained contiguous and the real SQLite cursor reached
  the source head; receipt completion is exposed on the shared transaction facade.
- Default Node tests: exit 0, 99/99 checks. Required PG suite selected separately;
  no live-data aggregate was run.
- Forced unavailable and missing PG URL: exit 1 / 1, both BLOCKED, no green skip.
- bot and inflowwkiller diff checks: exit 0 / 0.

Permanent regression evidence includes completion/evidence/obligation/publication
rollback and idempotent retry, plus file-backed SQLite consumption and reopen.
Python files were unchanged and their previous results were not claimed as reruns.
Evidence and before/after source hashes are in
output/telegram-p1pg-final-review-20261017/. Original review evidence is preserved.

Only review evidence and documentation changed during this review. No application
code was edited, no live system accessed or activated, and nothing was sent,
committed, pushed or deployed. Migration 144 and its rollback remain unchanged.
Live schema/runtime attestation and safe application rollback remain deployment
requirements; this acceptance does not certify the unwired receiver or engine.

START_HERE.md now assigns **P2 implementation and offline verification** of the
real Fastt text connection, preserving all mandatory rules and the original plan's
scope. P2 has not yet been implemented or accepted. The next review must assess
the real receiver/native-engine/transport boundaries. Live calls and activation
require the distinct pilot gates; P3A media and P3B selling remain later work.

## P2 implementation (increment 1), 18 October 2026 - PARTIAL, awaiting review

**This is not a completed P2 package.** It is the first verified increment. The
assignment's core acceptance - a deterministic offline round trip through the
*actual* Fastt Python engine (`ai_chatter`), the native OpenRouter provider, the
native SQLite projection and the Node transport - is **BLOCKED in this
environment** and is not implemented. Evidence of the blocker is recorded under
"Environment blocker" below. Nothing was activated, and no legacy behaviour
changed.

### What was implemented and verified (deliverable 5, transport half)

New module `bot/src/services/fastt-telegram-transport.ts`: the neutral Telegram
transport for Fastt-owned conversations. It performs exactly one platform call
for an already-authorized bubble and reports what the platform answered. It is
the owner of "platform call + technical validation" and it deliberately does NOT
reuse `TelegramMessenger`'s legacy dialogue editing.

- **No legacy rewriting.** Unlike `TelegramMessenger.sendText`, it never calls
  `clean()`, the media-honesty / time-of-day / price-guard / ai-disclosure
  passes, injects deliberate typos, collapses or reorders bubbles, or truncates
  text. The engine's bytes reach the platform unchanged or the bubble is refused.
- **Technical validation only.** Blank bubbles and bubbles over Telegram's 4096
  UTF-16-unit limit, or containing an unpaired surrogate, are refused with a
  typed `not_sent` (`provider_rejected_before_send`) - never silently edited.
- **Delivery semantics.** `sent` is reachable only from a usable platform message
  id. An accepted call with no, zero, negative, fractional, zero-padded,
  non-numeric or boolean id is `uncertain`. Control actions (typing) return
  `acknowledged` and can never be recorded as a delivered message.
- **Classified failures, no blind retry.** A refused connection / DNS / TLS
  failure and any received 4xx answer map to the accepted `PROVEN_UNSENT_CLASSES`
  vocabulary; a timeout, reset, 429-class ambiguity that we did not receive as a
  4xx, 5xx or unknown error is held as `uncertain`. Exactly one platform call is
  made per bubble.
- **Not a second sender/authority.** The module holds no state, does not decide
  eligibility and is not wired into any live path; the single delivery authority
  and the existing outbound gate/send-lock keep their roles.

New check `bot/src/dev/check-fastt-p2-transport.ts` (offline, scripted fake
platform API, no sockets/tokens/timers) proves: byte-for-byte delivery with no
rewriting; Business-connection propagation and omission; blank / over-limit /
surrogate refusal with no platform call; the proven-unsent vocabulary for
ECONNREFUSED / EHOSTUNREACH / ENOTFOUND / EAI_AGAIN / TLS and HTTP
400/403/404/429; uncertain outcome (and exactly one attempt) for timeouts,
resets, 500/502 and unknown errors; every rejected id shape as uncertain;
multi-bubble order and per-bubble identity; and that the transport's
classification vocabulary does not drift from the control store's.

`check-fastt-import-safe.ts` also imports the new module, confirming it starts
nothing (no signal handlers, no timers).

### Environment blocker (real, evidenced)

The P2 acceptance requires a supported Fastt Python runtime. In this workspace
there is no such runtime:

- `service/run_tests.cmd` expects a repo-root `.venv`; **no `.venv` exists**
  anywhere in the workspace.
- The only interpreters available are `py` (Python 3.14.6) and `python3.13`
  (3.13.16), and **neither has the Fastt dependencies**: `python3.13 -m pip list`
  reports only `pip`, and importing `sqlalchemy`, `aiohttp`, `pydantic` and even
  `dotenv` fails with `ModuleNotFoundError`.
- `inflowwkiller/requirements.txt` (50 lines: fastapi, httpx, pydantic,
  sqlalchemy[asyncio], SQLModel, ...) is therefore not installed, so
  `service/llm_providers.py` / `llm_models.py` / `automations/ai_chatter.py`
  cannot be imported and the native OpenRouter provider cannot be registered and
  exercised here.

Creating and populating that runtime, and then integrating the native engine
capability seam, the `telegram_runtime` package and the OpenRouter provider, are
the substantive remainder of P2 and are outside what could be done and honestly
verified in this increment.

### P2 deliverables: status

| # | Deliverable | Status |
|---|---|---|
| 1 | Production repository / gateway composition (async authority, mapping, projection over the accepted PG store) | **Not done.** `delivery-authority.ts`, `identity-map.ts`, `projection-cursor.ts` still drive the synchronous reference store; adapting them is a real change with a ~139-call-site update to the accepted `check-fastt-durable.ts`. |
| 2 | Actual receiver / router integration and polling-offset boundary | **Not done.** `src/index.ts` is unmodified. |
| 3 | Dedicated native worker, platform/capability injection, projections | **Blocked** (no Python runtime). `FASTT_ROOT/service/telegram_runtime/` does not exist. |
| 4 | OpenRouter + creator configuration in the native owners | **Blocked** (no Python runtime); `llm_providers.py` still has no OpenRouter entry. |
| 5 | Text actions, transport and interruption recovery | **Partial.** Neutral transport implemented and verified. Durable action journal, pacing, unknown-send hold and receipt repair are **not done**. |
| 6 | Writer exclusion and basic operator controls | **Not done** (all writers still run as before; legacy remains the only live path). |
| 7 | Real offline round trip | **Blocked** (deliverable 3/4). |

### Actual verification (commands and exits)

| Command | Result |
|---|---|
| `npm run typecheck` (in `bot/`) | exit 0 |
| `npx tsx src/dev/check-fastt-p2-transport.ts` | exit 0 - `check-fastt-p2-transport: all cases passed` |
| `npx tsx src/dev/check-fastt-import-safe.ts` | exit 0 - `all cases passed` (new module starts nothing) |
| `npm test` | exit 0 - `ALL 100 CHECKS PASSED` (was 99; the new offline check is included) |
| `TWIN_FASTT_PG_URL=postgres://postgres@127.0.0.1:55432/postgres npx tsx src/dev/check-fastt-pg.ts` | exit 0 - `all cases passed` (unchanged; re-run for fresh evidence) |

### Changed files (this increment)

| File | Change |
|---|---|
| `bot/src/services/fastt-telegram-transport.ts` | new - neutral transport (no legacy rewriting) |
| `bot/src/dev/check-fastt-p2-transport.ts` | new - offline regression suite |
| `bot/src/dev/check-fastt-import-safe.ts` | imports the new module (import-safety) |

No migration, dashboard, `twin-sexbot` app code, or `inflowwkiller` source was
edited. `twin_bridge/` (the pre-existing OnlyFans bridge) and `native_pilot/`
(the experimental monkeypatch wrapper, explicitly not production) were inspected
and left untouched. The mapping/capability/sender inventories were **not**
updated, because no new live consumer was wired - adding an inventory row for an
unwired module would misstate the runtime.

### Remaining pilot prerequisites (unchanged, plus new)

1. A pinned, supported Fastt Python runtime with `requirements.txt` installed,
   plus the native capability seam, `telegram_runtime` package and OpenRouter
   provider registration (P2 deliverables 3-4).
2. The async authority/mapping/projection adaptation and the receiver/router
   wiring with sender exclusion (deliverables 1-2, 6).
3. Verified Telegram creator/chat/channel identity, positive reply/spend limits,
   live runtime/schema attestation, durable storage and backup restore.
4. An offline round-trip command that exercises the real native engine with a
   fake model and fake Telegram transport.

### Safety attestations (this increment)

No receiver, poller or worker was started. No creator or bot was activated. No
message was sent. No paid model was called. No secret or private transcript was
read. No live Supabase was accessed and no migration was applied. Nothing was
deployed, committed or pushed. Legacy routing remains the default and no live
path imports the new module. Deliberate typos remain disabled. No dollars were
converted to Stars. No second sender, delivery authority or fallback engine was
created. P2 is not self-accepted; P3A/P3B have not started.

### Astra review addendum — 18 October 2026

The P2 neutral Telegram transport increment is accepted after two narrow review corrections. The submitted transport incorrectly classified HTTP 408/429 as proven unsent and used JavaScript `trim()` instead of the accepted shared Unicode blank policy. Both are corrected in the existing owners, with permanent regressions for 408/429 uncertainty and U+0085/BOM/NBSP/EM SPACE blank input.

Independent post-fix verification passed: `npm run typecheck`; `check-fastt-p2-transport.ts`; `check-fastt-contract.ts`; `check-fastt-import-safe.ts`; and `npm test` with 100/100 checks. Evidence is preserved under `output/telegram-p2-increment1-review-20261018/`. No PostgreSQL owner or schema changed in these corrections.

The reported Python blocker is cleared. A clean Python 3.13.16 environment with `inflowwkiller/requirements.txt` installed is available at `output/telegram-p2-python313/venv/`, and the declared core dependencies import successfully. `aiohttp` is neither declared nor imported and was not a P2 requirement. Native service imports remain intentionally deferred until P2 adds a test-safe configuration seam because the current provider module reads `service/.env` on import.

P2 remains partial. Deliverables 1–4 and 6–7, plus the durable recovery portion of deliverable 5, are still unfinished. Continue the current P2 assignment from `START_HERE.md` and `P2_INCREMENT1_REVIEW.md`; do not rebuild the accepted transport or restart P1. Nothing is activated, live, deployed, committed or pushed.

## P2 increment 2: native OpenRouter + injected strict configuration (P2-I7), 18 October 2026

**Still partial P2 — deliverables 1, 2, 3, 5 (recovery half), 6 and 7 remain.** This
increment implements requirement **P2-I7** ("Strict configuration in the existing
owners") inside the real native owners and proves it offline. No live behaviour is
activated; the OnlyFans path is unchanged when the injected Telegram policy is absent.

### What changed (existing owners only — no new module)

| File | Change |
|---|---|
| `inflowwkiller/service/llm_providers.py` | Registered the `openrouter` provider; added the `TelegramLLMPolicy` contextvar seam (`set_telegram_policy` / `reset_telegram_policy` / `active_telegram_policy` / `telegram_credential`) and the `TWIN_FASTT_CONFIG_ISOLATED` import-time dotenv/secrets-store gate |
| `inflowwkiller/service/llm_models.py` | Registered `openrouter/deepseek-v4-flash` (wire `deepseek/deepseek-v4-flash`) and `openrouter/qwen3-vl-30b` (wire `qwen/qwen3-vl-30b-a3b-instruct`, vision, DISABLED in P2) |
| `inflowwkiller/service/llm_client.py` | `_resolve` refuses a provider outside the policy allowlist; `_tenant_api_key` resolves the Telegram credential ONLY from the policy's named env reference (no tenant/owner lookup, no house key, no `_FALLBACK_KEY_ENVS` hole, no `.env`/secrets-store read) and refuses when it is missing |
| `inflowwkiller/service/automations/_common.py` | `resolve_model` returns the policy's mapping for a purpose and RAISES when a purpose is unmapped/invalid, instead of falling back to the house model (docstring updated) |
| `inflowwkiller/service/db/engine.py` | Same `TWIN_FASTT_CONFIG_ISOLATED` gate on the import-time dotenv read, so an offline check cannot pick up a real `DATABASE_URL` |
| `inflowwkiller/service/tests/test_telegram_provider_policy.py` | New offline regression suite (22 assertions) |

### Actual verification (commands and exits)

The Fastt Python suites must run OUTSIDE the workspace sandbox: the sandbox blocks
asyncio event-loop creation (an unmodified `asyncio.run` probe hangs inside the
sandbox on Python 3.10/3.11/3.13 and returns immediately when run escalated). This is
a harness restriction, not a runtime defect; the supplied venv is otherwise sound.

| Command | Result |
|---|---|
| `output/telegram-p2-python313/venv/Scripts/python.exe -u tests/test_telegram_provider_policy.py` (cwd `inflowwkiller/service`) | exit 0 — `test_telegram_provider_policy: all cases passed` |
| `output/telegram-p2-python313/venv/Scripts/python.exe -u tests/test_telegram_contract.py` | exit 0 — `all cases passed (telegram contract)` |

The new suite proves: OpenRouter is registered with the expected wire base URL; both
OpenRouter models resolve to their vendor wire ids; a model on a non-allowlisted
provider is refused inside the policy; the credential comes only from the policy
reference (the house `OPENROUTER_API_KEY` stays set and unused); a missing credential
stops before any model call; an unmapped or invalid purpose raises; and outside the
policy the house default, the `help_assistant` pin and the legacy fallback are
byte-identical to before. It also proves the isolation flag suppresses the real
`service/.env` (a provider key present in that file resolves to `""`).

### Inventory updates

`CONFIG_MAPPING.csv` gained the `provider/openrouter`, `model/*` and
`model_policy/telegram_*` rows; `CAPABILITIES.csv` gained the OpenRouter routing,
disabled media_vision/media_copy and Telegram credential-isolation rows. Both mark
the media purposes as `added_disabled`.

### Remaining live/preflight requirements (unchanged plus new)

1. Replace the OpenRouter price seeds with measured OpenRouter rates before
   activation (they are deliberately seeded at the direct-provider rate, the
   conservative direction for the cap).
2. The remaining P2 deliverables: async PG authority/identity facades and receiver
   routing (1–2), the dedicated native worker plus projections (3), durable
   text/recovery (5), writer exclusion/operator controls (6) and the real offline
   round trip (7).
3. Pilot-only gates as before: verified Telegram identity, positive reply/spend
   limits, live runtime/schema attestation, durable storage and the pilot recovery
   checks.

### Safety attestations (this increment)

No receiver, worker, poller or model call was started. No message was sent. No real
secret was read: the offline suite sets `TWIN_FASTT_CONFIG_ISOLATED=1`, points
`DATABASE_URL` at a temp file and proves the real `.env` is not consulted. No live
Supabase access or migration. Nothing deployed, committed or pushed. OnlyFans
defaults are preserved outside the injected policy. Deliberate typos remain disabled;
no dollars were converted to Stars; no second sender, engine or fallback was added.
P2 is not self-accepted.

## P2 increment 3: I7-A + I7-B closed, and deliverable 1 (async facades), 18 October 2026

**P2 is still incomplete** - deliverables 2, 3, the recovery half of 5, 6 and 7
remain. This increment closes both reproduced findings from
`P2_INCREMENT2_REVIEW.md` and completes the Node half of deliverable 1.

### I7-A - the public model-call boundary enforces the whole policy

`llm_client.telegram_call_refusal(purpose, model, account_id)` is the SINGLE policy
decision, evaluated in `chat` immediately after `_resolve` and therefore BEFORE the
credential lookup, the cap reservation, the audit row and the HTTP request. It checks
the policy is well formed, the account is the policy's `trusted_account_id`, the
purpose is enabled, the model IS the configured model and its provider is allowed.
`telegram_model_for(purpose)` is the same decision for the resolver consumer, which
`automations/_common.resolve_model` now calls, so selection and admission cannot
disagree. `TelegramLLMPolicy.trusted_account_id` + `config_problem()` are the new
policy-owner API; malformed policy values are rejected at that owner.

### I7-B - the indirect secrets import is closed

`secrets_store._adopt_legacy_file()` runs at import and copies the pre-mount
`secrets.json`. It is now gated by `TWIN_FASTT_CONFIG_ISOLATED`: an isolated process
skips the migration entirely and records `_LEGACY_ADOPTION_SKIPPED = True`, while an
ordinary OnlyFans startup still adopts the legacy store. The permanent suite installs
`pathlib.Path.read_text/exists/is_file` guards for protected paths BEFORE every native
import and asserts no access was even attempted.

### Pricing claim corrected

The `llm_models` OpenRouter comment no longer calls the copied direct-provider seeds
"conservative". It now states the truth: OpenRouter bills upstream PLUS its own fee, so
the seed can under-count, and live OpenRouter pricing plus upstream acceptance of the
wire id/reasoning body must be verified before any paid activation.

### Deliverable 1 (Node half) - async authority and identity facades

`bot/src/services/delivery-authority.ts` now exposes `DeliveryStorePort`, whose
operations may return a value (SQLite reference store) or a promise (PostgreSQL), and
every method awaits. `bot/src/services/identity-map.ts` does the same with
`IdentityStorePort`. ONE authority and ONE identity map therefore serve both mouths;
no second production authority was added. `projection-cursor.ts` is deliberately
unchanged: it stays the synchronous reference destination consumer, per START_HERE.
`check-fastt-durable.ts` (the accepted reference suite) was mechanically adapted to
`await` the facades; its assertions are unchanged.

### Actual verification (commands and exits)

| Command | Result |
|---|---|
| `npm run typecheck` (bot/) | exit 0 |
| `npx tsx src/dev/check-fastt-durable.ts` | exit 0 - `all cases passed` |
| `TWIN_FASTT_PG_URL=postgres://postgres@127.0.0.1:55432/postgres npx tsx src/dev/check-fastt-pg.ts` | exit 0 - **195 assertions** (was 183), incl. the new `P2: async authority and identity facades against PostgreSQL` section |
| `npm test` | exit 0 - `ALL 100 CHECKS PASSED` |
| `output/telegram-p2-python313/venv/Scripts/python.exe -u tests/test_telegram_provider_policy.py` (cwd inflowwkiller/service) | exit 0 - 45 assertions, `all cases passed` |
| `output/telegram-p2-python313/venv/Scripts/python.exe -u tests/test_telegram_contract.py` | exit 0 - `all cases passed` |
| reviewer probe, adapted only for the new `trusted_account_id` field, from `output/telegram-p2-increment2-verify-20261018/` (`python -I -B -u probe.py`) | exit 0 - `builder-suite: exit 0`, `public-call: exit 0`, `secret-import: exit 0` |

The public-`chat` regressions prove the five refusal cases (unmapped purpose, disabled
media purpose, wrong model for the purpose, empty account, another creator's account)
each make **zero** HTTP attempts and write **no** audit row, while the valid control
makes exactly one attempt and one audit row; three malformed policies are likewise
refused with zero HTTP.

### Changed files this increment

| File | Change |
|---|---|
| `bot/src/services/delivery-authority.ts` | async port + awaited methods |
| `bot/src/services/identity-map.ts` | async port + awaited helpers |
| `bot/src/dev/check-fastt-durable.ts` | mechanical `await` adaptation (assertions unchanged) |
| `bot/src/dev/check-fastt-pg.ts` | new PG facade section + wiring |
| `inflowwkiller/service/llm_client.py` | `telegram_call_refusal` + `telegram_model_for`; `chat` gate |
| `inflowwkiller/service/llm_providers.py` | `trusted_account_id` + `config_problem()` |
| `inflowwkiller/service/automations/_common.py` | resolver uses the one shared decision |
| `inflowwkiller/service/secrets_store.py` | isolation gate on the import-time legacy adoption |
| `inflowwkiller/service/llm_models.py` | corrected the OpenRouter pricing comment |
| `inflowwkiller/service/tests/test_telegram_provider_policy.py` | public-`chat`, isolation-guard and legacy-adoption regressions |

### Remaining live/pilot prerequisites (unchanged, plus one)

1. Verify live OpenRouter pricing and that each OpenRouter wire id + reasoning body is
   accepted upstream before enabling paid calls.
2. Protected-file guards prove no secret file is touched; real credential provisioning
   is still a pilot step.
3. The remaining P2 deliverables (receiver routing, native worker/projections, durable
   recovery, writer exclusion/controls, the composed round trip) and the pilot gates
   recorded in the increment-2 section.

### Safety attestations (this increment)

No receiver, worker, poller or model call was started. No message was sent. No real
secret was read - the Python suite proves the isolation flag suppresses dotenv, the
secrets store and the legacy adoption. No live Supabase access or migration. Nothing
deployed, committed or pushed. OnlyFans behaviour is unchanged outside the injected
policy. Deliberate typos remain disabled; no dollars were converted to Stars; no second
sender, engine, authority or fallback was added. P2 is not self-accepted.

## P2 increment 4: P2-I1 one effective assignment, 18 October 2026

**P2 is still incomplete** - deliverables 2, 3, the recovery half of 5, 6 and 7
remain. This increment implements the P2-I1 integration requirement in its
existing owner (`bot/src/engines/engine-router.ts`) and adds permanent
regressions. It changes no live behaviour: migration is disabled by default, so
every scope is still positively legacy and no lookup is performed.

### What changed

The P1 router could only answer `legacy` or `fastt`, and collapsed every
non-`fastt` value to legacy. Section 8.1 P2-I1 requires ONE resolver, used by
ingress, jobs, senders and controls, that also distinguishes a **held** scope,
because "a missing binding is not proof of legacy when authority lookup
failed".

`resolveAssignment(port, request)` is that resolver. It is read-only, takes a
structural read port (so the sync SQLite reference store and the async
PostgreSQL store both satisfy it), and returns `legacy | fastt | held` with a
CLOSED reason vocabulary in `ROUTING_REASON`. Rules:

1. Migration disabled (the default) -> legacy, with NO lookup at all.
2. Conversation override row, else creator default row; a read failure HOLDs.
3. No row -> legacy for a positively named scope, but a dangling conversation
   override or an allowlisted conversation with no assignment HOLDs.
4. A `fastt` row is held unless it is in the explicit per-conversation pilot
   subset AND readiness is positively attested (not paused, no effective
   takeover, worker available, projection current). Omitted readiness is
   "unknown" and therefore HOLDs.
5. A `legacy` row is legacy; any other non-null value HOLDs.

The former callers (`resolveEngine`, `canRouteToFastt`, `assignmentFor`) are
preserved; `assignmentFor` is now async to match the async PG mouth and returns
`held` on a read failure. Adoption of `resolveAssignment` at the live receiver,
job, sender and control boundaries is the remaining deliverable-2 work, not a
second resolver.

### Actual verification (commands and exits)

| Command | Result |
|---|---|
| `npm run typecheck` (bot/) | exit 0 |
| `npx tsx src/dev/check-fastt-routing.ts` | exit 0 - 44 assertions, `all cases passed` |
| `npm test` | exit 0 - `ALL 101 CHECKS PASSED` (was 100; `check-fastt-*` are auto-discovered) |
| `TWIN_FASTT_PG_URL=postgres://postgres@127.0.0.1:55432/postgres npx tsx src/dev/check-fastt-pg.ts` | exit 0 - `all cases passed`, 195 `ok` assertions |
| `python -u tests/test_telegram_provider_policy.py` (P2 3.13 venv, cwd inflowwkiller/service) | exit 0 - `all cases passed` |
| `python -u tests/test_telegram_contract.py` | exit 0 - `all cases passed (telegram contract)` |
| `python -u tests/test_telegram_store.py` | exit 0 - `all cases passed (telegram store)` |

Logs: `output/p2-inc4-npm-test.log`, `output/p2-inc4-pg.log`.

The routing regressions cover: migration-disabled default with no lookup;
legacy default and legacy row; ready Fastt allowlisted; unknown readiness ->
held; paused/takeover/projection-stale -> held; creator-default Fastt outside
the subset -> legacy (not held); explicit conversation override counts as the
subset; conversation-read and binding-read failures -> held; dangling override
-> held; allowlisted-without-binding -> held; unrecognised stored value ->
held; the same request through three caller shapes agreeing on engine, reason
and epoch and all seeing an operator flip; and the core rule that a held scope
is never returned as legacy.

### Demonstrated blocker for the remaining Python worker (deliverable 3)

Deliverable 3 requires invoking the real native `automations/ai_chatter.py`
with injected platform/model/configuration capabilities, and the plan forbids
the `service/native_pilot/engine.py` `unittest.mock.patch` approach as
production wiring. Replacing those patches with real seams is a large refactor
of a 660 KB module: `_make_client` has 6 call sites, `ax.` is referenced 52
times, and `resolve_model(` / `llm_client.chat` / `_load_config(` / `enqueue_job(`
/ `load_day(` are each reached from multiple native lanes. Section 8's required
capability interface (scoped history reads, config snapshot, catalogue/offer
access, gateway text/media actions, typing, read acknowledgement, job
scheduling, purchase events, permission/status checks, cancellation reporting)
must be threaded through those call sites without a second engine. This is
independent work that did NOT fit this increment and is reported rather than
stubbed. It is not an external blocker: the Python 3.13 runtime is present and
the native modules import under the isolation flag.

### Changed files this increment

| File | Change |
|---|---|
| `bot/src/engines/engine-router.ts` | extended into the single legacy/fastt/held resolver with a closed reason vocabulary |
| `bot/src/dev/check-fastt-routing.ts` | new permanent regressions (auto-run by `npm test`) |
| `twin-sexbot/docs/telegram/SENDER_INVENTORY.md` | section 10: routing ownership and held behaviour per writer class |
| `twin-sexbot/docs/telegram/CAPABILITIES.csv` | one row: one effective engine assignment |
| `twin-sexbot/docs/telegram/CONFIG_MAPPING.csv` | `engine/effective_engine` and `engine/migration_enabled` rows |

### Remaining live/pilot prerequisites (unchanged)

1. Verify live OpenRouter pricing and that each OpenRouter wire id + reasoning
   body is accepted upstream before enabling paid calls.
2. Real credential provisioning and protected-file verification in the pilot
   environment.
3. Deliverables 2 (receiver adoption), 3 (native worker + projections), the
   recovery half of 5, 6 (writer exclusion) and 7 (composed offline round trip),
   plus the pilot gates already recorded.

### Safety attestations (this increment)

No receiver, worker, poller or model call was started. No message was sent. No
real secret was read. No live Supabase access or migration. Nothing deployed,
committed or pushed. OnlyFans behaviour is unchanged. Deliberate typos remain
disabled; no dollars were converted to Stars; no second sender, engine,
resolver or fallback was added. P2 is not self-accepted.
