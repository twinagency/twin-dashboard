# P1-R independent acceptance

Reviewed 17 October 2026 against the builder's 18:54 report and current local source.

**P1-R is accepted within its offline foundation scope. All four remaining findings in P1R_CURRENT_REVIEW.md are closed. No further blocking defect was demonstrated in this bounded re-review.** P1-PG has not started and remains required before P2; this is not approval for production deployment, live activation or fleet capacity.

## What is accepted

| Finding | Independently verified result |
|---|---|
| C3 explicit purchase identity | DeliveryAuthority.admit forwards the trusted obligation ID; both asset-inference helpers are removed. Omitted ID stays unassociated/unclaimable. Explicit B reserves/settles B while identical-media purchase A stays outstanding. Repeated admission cannot retarget the stored association. |
| C2 strict operator evidence | Both stores reject invalid operator objects and missing/null/bool/numeric/container/blank actor or reason without clearing uncertainty. Valid provenance is preserved. |
| C2 evidence comparison | Structured actor/reason plus JSON references distinguish the previous colon collision. Exact replay is idempotent; conflicting evidence is recorded without replacing the first terminal outcome. |
| C1 synchronous projection application | Direct async implementations fail the actual TypeScript contract. Runtime rejects an actual async function before invocation; the await-then-write reproduction leaves target, envelope and cursor unchanged. |

Previously accepted reservation/release/settlement, uncertain holds, late receipts, settlement rollback, scoped takeover and C4 Unicode behavior remain covered by passing regressions.

The C3 probe adaptations are legitimate: positive and recovery cases now pass their existing trusted purchase IDs. The deliberately unassociated case and expected behavior were not weakened. Old-format operator evidence was simulated separately: replay safely records reconciliation and retains the original terminal record, matching the documented representation policy.

## Commands and observed results

Runtimes: Node v24.18.0 and Python 3.11.9. All runs were offline with synthetic data and fake external boundaries.

| Check | Result in this review |
|---|---|
| bot: npm run typecheck | exit 0 |
| bot: npm test | exit 0, **all 99 default checks passed**, including the four Fastt suites |
| inflowwkiller: .venv/Scripts/python.exe -B service/tests/test_telegram_contract.py | exit 0 |
| inflowwkiller: .venv/Scripts/python.exe -B service/tests/test_telegram_store.py | exit 0 |
| Saved C1/C4 runtime probes | Node 11 and Python 6 passing assertions, exit 0 |
| Saved async-assignment TypeScript project | exit 2 with exactly the expected TS2322 Promise<void> versus undefined error; this is an expected rejection |
| Saved C2 probes | Node 4 and Python 13 passing assertions, exit 0 |
| Additional C2 individual-field/compatibility checks | Node 52 and Python 57 passing assertions, exit 0 |
| Saved current C3 probes | Node/Python 10 passing assertions each, exit 0 |
| Adapted older C3 probes | Node/Python 13 passing assertions each, exit 0 |
| git diff --check, bot and inflowwkiller | exit 0 |

The default bot runner deliberately excludes four live Supabase checks. No live database verification is claimed. The reported verify_postfix and py_compile results are builder evidence; they were not separately rerun in this review because the stronger relevant probes and permanent suites passed.

Evidence and exact commands are preserved under `output/telegram-p1r-acceptance-20261017/`, including c1c3/README.md and c2/README.md. baseline.json identifies the 24 implementation/test/schema files reviewed. No application source or permanent test was edited by the reviewer.

## Current project position

- P0 local inventory is delivered; deployed runtime/schema/first-pilot facts remain pending.
- P1-R offline contracts and durable control foundations are accepted.
- **Next: P1-PG**, the actual Node PostgreSQL control-store implementation, isolated transaction/concurrency/permission verification and publication behavior.
- **Then: P2**, the native Fastt worker and OpenRouter connection, history/configuration projection, Telegram text routing and all competing-sender exclusion.
- A first live text pilot follows P2 acceptance plus the attestation, selected identities/limits and pilot recovery prerequisites in the implementation plan.
- Media analysis, catalogue sales, remaining dashboard/automation compatibility, operating verification and fleet rollout remain P3A through P6.

The previous OnlyFans pilots do not prove this Telegram migration is live. Existing Telegram assignments remain legacy/off for the new path.

## Nonblocking note and limits

Python store.py's register_action docstring near line 693 still mentions the removed oldest-matching fallback. Actual implementation has no fallback. Correct that stale comment during routine documentation maintenance; it does not require another P1-R repair cycle.

This acceptance covers the reviewed disabled foundations and the four requested corrections. Real transport classification, live operator authorization, PostgreSQL transactions and native Fastt invocation are subsequent work. No zero-defect, exactly-once external delivery or large-scale capacity guarantee is made.

START_HERE.md now points to the already-planned P1-PG package. The completed repair instructions are preserved in P1R_START_HERE_ARCHIVE.md. No live service, receiver, model, message, secret inspection, migration, deployment, commit or push was performed by this review.
