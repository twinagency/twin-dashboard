# Claude handoff for the Fastt to Twin Telegram migration

Prepared 18 October 2026, Australia/Brisbane. Read this as an orientation and continuity document, followed by the governing references below. It covers the complete project through rollout; the immediate implementation assignment is the complete remaining P2 package.

## 1. What Jesse wants

Jesse owns Twin, an existing Telegram creator-chat product with a dashboard, creator configuration, media catalogue, payments and customer history. Replace its conversation and mapped sales decision engine with Fastt's real native engine while keeping the existing Twin product, data, Telegram identities and financial behavior.

The result must autonomously receive a fan's Telegram messages, generate the selected creator's replies through Fastt, deliver them through the existing Node gateway, remember confirmed history, and eventually select and sell existing photos/videos/bundles with correct Telegram Stars settlement. An assistant manually relaying replies is not the result. A standalone Fastt demo or copied prompt is not the migration.

Keep Twin's dashboard and Supabase catalogue/Storage, purchases, credits, subscriptions, VIP, tips, Mini App access and human edits. The user is not agreeing to replace the Twin dashboard with Fastt's OnlyFans UI. Every enabled capability must be preserved, mapped, or explicitly excluded from an agreed rollout; do not silently drop it.

Jesse wants less back-and-forth and fewer helper-sized reports. Finish the whole agreed package before review. Do not claim that a package is complete because its validators, adapter or helper tests pass. He expects inspection of actual code before advice, and is particularly concerned about contradictory prompts, duplicate handlers, competing senders and accidental double charging.

The long-term discussed sizing target is 1,000 creators and 100,000 fans chatting daily, with text and existing media. This is an ambition to measure against, not demonstrated capacity or a promise of bug-free operation. No reliable calendar or model-credit estimate has been established. Do not repeat earlier optimistic estimates or claim a simulator proves conversion or fleet reliability.

## 2. Where to work and what the names mean

Workspace:

`C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION`

Use a coding session with filesystem and terminal access to this existing workspace. A new GitHub clone alone will miss most migration work because it is uncommitted/untracked. If you only have an ordinary web chat, you can read this pack but cannot honestly implement or verify the local source. Establish source access before claiming implementation. Do not ask for secrets or a zip of live databases/session folders.

| Root relative to workspace | Meaning | Observed branch and HEAD on this handoff |
|---|---|---|
| `bot/` | Established Telegram product, repository `ronan-com/twin-bot`; Node/TypeScript/grammY | `codex/telegram-fastt`, `f414f32da07f32f1108c4ed7bd34139e547d59ef`; dirty, many migration files untracked |
| `inflowwkiller/` | Fastt, repository `BlackPhoenixSlo/inflowwkiller`; native Python conversation/sales engine and prior OnlyFans work | `codex/onlyfans-integration`, `e72316fd9c34092f767bc6e425ca9faea340da27`; dirty, mixed prior OF and new Telegram work |
| `twin-dashboard/` | Existing Twin dashboard, repository `ronan-com/twin-dashboard`; Next.js | `main`, `fb6b345692a735d131b875e7b69ce8f955ba9a03`; clean when checked |
| `twin-sexbot/` | Twin V2, repository `jesse98/twin-sexbot`; separate single-creator runtime and home of migration docs | `codex/onlyfans-integration`, `7b0036bf4d1a58413c57d19434fa4bcad3a1c4f4`; dirty |
| `twin-sexbot/docs/telegram/` | Governing plan, current assignment, reviews, contracts, inventories and progress | Mostly untracked local documentation |
| `twin-ops/`, `twin-tgaiclone/pipeline/` | Existing operations/deployment evidence | Inspect when their work becomes relevant |
| `output/` | Local evidence, review probes, logs and supported Python environment | Preserve relevant evidence; do not bulk clean |

These are current local observations, not the verified running cloud revision. Recheck before editing. The workspace contains several sibling `allieai2-*`, dashboard and OnlyFans worktrees. Do not substitute them because their names look similar. A server directory named `/home/ubuntu/allieai2-bot` does not mean the local `allieai2-bot/` repository is the deployment source. `SOURCE_MAP.md` explains the evidence.

Terminology:

- **Fastt** is the engine/repository `inflowwkiller`, not an AI model.
- **Flash / DeepSeek** was the previous coding assistant. Claude is taking over that builder role.
- **OpenRouter** is the selected application model gateway/billing integration. Its configured conversation/vision/copy models are separate from the model doing the coding.
- **Astra** is the independent reviewer in Jesse's workflow.
- **V2 (`twin-sexbot`)** is not the full deployed Telegram fleet backend. Do not migrate V2 while leaving `bot/` untouched and call the product finished.

## 3. Read in this order and resolve authority correctly

All names below, unless otherwise specified, are under `twin-sexbot/docs/telegram/`.

1. `START_HERE.md`: the full current P2 assignment, mandatory development rules and stop boundary.
2. `P2_INCREMENT4_REVIEW.md`: current unresolved findings and exact continuation. This supersedes the completion claims in earlier builder reports.
3. `IMPLEMENTATION_PLAN.md`: read in full. Sections 4–9, especially 8.1 P2-I1 through P2-I10, define composition. Sections 10–13 cover media, money and controls. Section 14 contains the full stage sequence; sections 16–21 contain acceptance, migration, recovery and completion.
4. `P1R_ACCEPTANCE.md`, `P1PG_ACCEPTANCE.md`, `P2_INCREMENT1_REVIEW.md`: accepted scopes and tests to preserve. Their historical "next stage" paragraphs describe their dates, not the current assignment.
5. `PROGRESS.md`: read the current header/table and latest relevant entries first. Older repair reports are history, not instructions to restart completed work.
6. `RUNTIME_MANIFEST.md`, `runtime-manifest.json`, `SOURCE_MAP.md`: source selection and live facts still pending.
7. `SENDER_INVENTORY.md`, `CONFIG_MAPPING.csv`, `CAPABILITIES.csv`: every writer, setting and capability; verify actual consumers before declaring a feature wired.
8. `contracts/CONTRACT.md`, both schemas and `contracts/fixtures/`: shared wire rules and fixture hashes.
9. `P2_PLAN_REVIEW.md` for the reasoning behind the composition requirements. `P2_INCREMENT2_REVIEW.md` is historical context for the original I7 defects already closed.
10. Applicable `AGENTS.md` and `CLAUDE.md` in the actual directories, especially `bot/CLAUDE.md`, `twin-dashboard/CLAUDE.md`, `inflowwkiller/CLAUDE.md`, then current sources, tests and all affected tracked/untracked changes.

The full implementation plan owns architecture; START_HERE owns the current package/boundary; the latest independent review owns finding disposition within its scope. This handoff indexes and explains them, without introducing a second specification. Earlier chat summaries and builder reports do not override verified source or current requirements. If sources reveal a contradiction, name the exact requirements and resolve it in the existing owner within the agreed design. Do not silently stack both behaviors or reopen accepted packages because an old report said they were incomplete.

Repository instructions contain broad standing live-write/deploy permissions and live startup examples. The current P2 assignment deliberately excludes live access, activation, messages, paid model calls and deployment. Those examples are not authorization to run them during P2. The repository's old style-rewrite convention must not be reintroduced into Fastt's migrated reply path; the agreed migration deliberately replaces that part while retaining independent safety/authorization checks.

## 4. Current position, accepted work and interruption

| Package | State at handoff | Meaning |
|---|---|---|
| P0 inventory | Local inventory delivered; live attestation pending | Local source roots identified; running revisions/schema/first pilot remain unverified |
| P1-R contracts and reference control | Independently accepted offline | Keep the cross-language contracts, evidence, scoped authority, obligation and projection behavior |
| P1-PG production control adapter | Independently accepted on disposable PostgreSQL | Real PG transaction/concurrency/publication behavior accepted locally; no live migration implied |
| P2 text connection | Incomplete | Transport accepted; async facades and provider work present; router has unresolved findings; core composition missing |
| P3A media enrichment | Not started | Factual media analysis, stored copy and catalogue projection |
| P3B content sales | Not started | Offers, Stars, media fulfillment and payment compatibility |
| P4 full controls and automations | Not started | Dashboard and mapped lifecycle behavior |
| P5 operating verification | Not started as full package | Deployment, restore, recovery, capacity; a subset is required before any text pilot |
| P6 canary and rollout | Not started | Selected pilot, then measured expansion |

Fresh handoff inspection confirmed the same four local HEADs above and no `inflowwkiller/service/telegram_runtime/` directory. The new router/authority/transport have no references in the inspected `bot/src/index.ts` and `bot/src/manual-send.ts`. This is consistent with the latest review's unwired state. No application test suites were rerun merely to create this handoff; historical results below remain attributed evidence.

Accepted foundations include versioned Node/Python validators and byte-identical fixtures; creator/chat/message identity scoping; explicit paid-obligation identity and reservation/release/settlement; strict operator evidence; attempt-bound receipts and unresolved-send holds; synchronous native projection application; PG source publication; and the authority lock protocol. Do not replace them with simpler duplicate stores or helpers.

The last builder report claimed 101 default Node checks, 195 PG assertions, 44 routing assertions and passing Python provider/contract/store suites. These are reported results, not proof of P2 completion. The independent increment-4 review reproduced router and configuration gaps despite that green suite. Accepted PG review had 183 assertions at its earlier source revision. Counts differ by revision; never present an old count as a current rerun.

The last attempt to continue stopped with `401 Unauthorized` from OpenCode Go: the coding provider's API key had expired. It had already displayed file/command activity before the error, so do not assume zero work occurred; inspect the tree. It did not deliver a completed P2 package. This credential is for the former DeepSeek coding session, separate from the application's OpenRouter credentials. Do not rotate application credentials to fix that error. Claude using its own authorized coding session need not depend on the expired provider.

## 5. Architecture and rules against overlap

The intended flow is:

```text
Telegram
  -> existing Node receiver and one effective assignment resolver
  -> canonical PostgreSQL admission, identities, controls and outbox
  -> scoped native SQLite projection
  -> real Fastt ai_chatter with native configuration/state
  -> explicitly configured OpenRouter purpose calls
  -> frozen durable action
  -> Node delivery authority and neutral Telegram transport
  -> accepted receipt in PostgreSQL
  -> idempotent native bookkeeping/history and dashboard projection
```

| Responsibility | One owner |
|---|---|
| Creator/business data, catalogue, approved edits/prices, purchases/entitlements | Existing Supabase product and authorization/settlement owners |
| Canonical Telegram events, identities, assignment/epochs, actions, claims and receipts | Node with the PostgreSQL control adapter |
| Conversation and mapped sales decisions for migrated scope | Fastt native Python engine |
| Native questions, offer/scheduler state and source projections | Isolated durable native SQLite database per creator |
| Telegram token and actual Telegram calls | Existing Node gateway only |
| Selected model credentials/usage | Existing native provider/client owners under explicit scoped Telegram policy |
| Dashboard controls | Existing authorized server actions, shared effective configuration and durable commands |

PostgreSQL and native SQLite have different responsibilities; they are not competing canonical databases. The SQLite control implementation remains an offline reference, not a production dispatch authority. All creator workers share one versioned code/image; isolation is not per-creator code forks or bespoke deployments.

Mandatory owner rules:

1. Before every recommendation/edit, inspect current responsible code, prompts, configuration, pending changes and affected tests. Trace effects through storage, delivery, payments, scheduling and UI as applicable.
2. Make the smallest coherent change in the existing responsible component. A large necessary native refactor can still be one coherent change; a new wrapper is not automatically safer.
3. Do not add duplicate handlers, competing state machines, a second resolver, a fallback reply engine, parallel canonical ledgers, unnecessary prompt layers or unnecessary AI calls. New components are allowed where the governing plan requires a missing responsibility, with one named owner and integration tests.
4. Once assigned to Fastt, an unavailable/paused/stale scope becomes `held`, never automatically legacy. A positively established unmigrated scope remains legacy. Selection revocation must fence/drain existing work; it cannot erase uncertain attempts.
5. Exactly one application delivery authority handles AI, authorized manual work and paid fulfillment with their distinct rules. A worker cannot grant itself manual or financial privileges.
6. Preserve selected behavior and legacy scopes. Keep old conversational prompt/postprocessing out of Fastt replies. Keep independent safety, age, factual-content, money and permission gates. Disable deliberate typos/misspellings without altering intended casual voice via a second rewrite layer.
7. Use one owner each for burst collection, native leases, pacing, credit reservation and model retries. Do not double-delay, double-charge or wrap retries around native retries.
8. Keep displayed configuration/prompt previews consistent with the actual runtime. An old dashboard control that Fastt ignores must be mapped or visibly inactive.
9. Test real owners and failure boundaries; examine compatibility and rollback. Do not certify "no clashes" merely because typechecking passes. Preserve meaningful reproductions without weakening expected outcomes.
10. Keep these development rules outside fan-facing prompts. Do not bind every creator to Riley or carry over another creator's persona as a default.
11. Preserve all dirty work. No reset/clean, bulk overwrite, branch switch that loses work, destructive cleanup or unrelated deletion. If another writer is active, coordinate ownership before editing shared files. Do not run parallel writers on the same native owners.
12. Work one agreed package at a time. For now that means finish ALL of P2, not one helper. Checkpoint internally when necessary and resume unfinished work. If a platform/session limit interrupts you, record the exact state and next step rather than claiming completion or beginning again.

## 6. Current findings to resolve in their existing owners

Read `P2_INCREMENT4_REVIEW.md` in full and reproduce against the current tree before changing anything. Preserve fixes already present if newer work has landed.

### R4-A: identity registration wrongly authorizes the pilot

`bot/src/engines/engine-router.ts` treats a `conversationBinding()` identity row as an engine override and bypasses pilot selection. Registering an ordinary conversation must not select it for Fastt. Keep trusted identity separate from explicit pilot authorization in the planned authority/config owner. Test real selected/unselected registrations, empty selection, removal, explicit overrides if implemented and outstanding-action fencing. Do not add a second assignment store.

### R4-B: persisted pause/takeover can be ignored

Caller-supplied readiness cannot override current stored binding/conversation pause or takeover. Missing required information must hold unless the authoritative source independently establishes it. Keep the final action-class check even after readiness passes. Test stale/missing readiness, binding controls and conversation takeover requested/effective.

### Configuration and bootstrap requirements still unfinished

- The installed Telegram model policy retains caller-owned mutable purpose mappings. Freeze/copy a validated snapshot and use explicit versioned replacement so later mutation cannot enable media or change billing/scope.
- Malformed policy data such as `provider_allowlist=None` must produce the existing typed configuration refusal before model HTTP, rather than an accidental raw exception.
- Isolated startup without an explicit database URL must refuse. It must never default to the native live `chatterly.db`. Preserve normal OnlyFans defaults outside the isolated Telegram context.

Original I7 public model-call enforcement and secrets-import isolation failures were independently closed. Retain their regressions; do not repeat that repair from scratch. `resolveEngine`, `canRouteToFastt` and `assignmentFor` must not become alternative operational eligibility rules alongside `resolveAssignment`.

## 7. Complete P2 as one implementation package

Use START_HERE's seven deliverables and the full plan's P2-I1–I10 as the exact acceptance contract.

### 7.1 Compose the authenticated PG gateway

Use the existing asynchronous authority/identity facades and accepted PostgreSQL transactions. Persist source mutation plus publication on one client/transaction. Publish a confirmed receipt only after evidence acceptance succeeds in the same transaction. Bound/version requests and responses, authenticate the creator scope, use finite deadlines and sanitize errors. Worker-supplied IDs are claims to validate, not authorization.

Do not revive the retired PG destination importer. Node publishes; Python applies native target rows plus cursor atomically using the existing synchronous applier and its supplied SQLite connection. A new `get_session()`/async callback is a different transaction and must not be used inside that applier.

### 7.2 Wire the actual receiver and assignment

Extend the existing grammY receiver/handlers, retaining deployed Telegram Business mode and business connection identity. Financial events remain first. Preserve access/credit/safety policy. Route migrated input before detached legacy batching and commit durable admission/outbox before acknowledgement or polling offset advancement.

The installed grammY tracks `lastTriedUpdateId` before completion, including error/shutdown paths. Merely awaiting a store call or throwing is insufficient. Test configured fake polling, mixed batches, admission outage, stop during admission and restart against the real offset behavior. Do not launch a second real poller or silently change to a conventional bot.

Use one durable burst rule and one entitlement effect per logical turn. Handle edits, supported deletes, attributable external outbound activity and permission changes explicitly; do not invent events the platform cannot observe.

### 7.3 Build the scoped native worker and projections

Implement the dedicated `service/telegram_runtime/` responsibility using explicit dependency injection in existing `ai_chatter`, `_common`, executor/config/model owners. Do not copy the engine or promote `native_pilot`'s monkeypatch approach into production.

Start only the Telegram entry point, not the OF server, lifespan, pumps, vault sweeps or generic supervisor. No OF client/session access and no Python-held Telegram token. Use isolated durable native state per creator, a canonical identity mapping and one worker lease. Backfill/restart must not generate welcomes.

`ai_chatter.run` is an account sweep: empty `only_fan_ids` means all fans. Each Telegram invocation needs a trusted nonempty singleton fan/conversation scope and frozen turn identity. Refuse expanded/missing scope. Do not use `force_ids`, invented purchases or success stubs. Deliberately map native payer/eligibility gates to the approved Telegram entitlement policy; prove an eligible ordinary nonpayer works and an ineligible recipient does not. That mapping is not permission to remove all sales eligibility rules.

Disable unmapped pack/teaser/sticker/media/sales/follow-up capabilities in P2. An empty catalogue is insufficient if other native branches can still call models or enqueue jobs. Require relevant history/configuration watermarks. Do not reacquire the same native fan lease twice.

### 7.4 Finish native model/configuration integration

Preserve the existing OpenRouter integration and selected creator's effective configuration. Explicitly map every enabled native purpose, model, provider allowlist, credential reference, trusted account/billing identity, retries and budgets. No silent house-key, cross-tenant or cross-provider fallback. An explicitly approved routing policy may be retained, bounded and recorded.

Preserve the original I7 repairs, fix the current snapshot/type/database issues, and produce neutral effective-config/prompt snapshots through the real loader. CONFIG_MAPPING is currently an inventory: add actual transformation type/default/precedence/unit, runtime consumer and test for each enabled setting. Creator facts are distinct from the old compiled Node/V2 prompt.

Native `llm_client` owns bounded model retries. Account for actual attempts and unknown spend if a response is lost. Do not rerun an entire invocation or add a second answer generator. Media vision/copy purposes remain configured but disabled in P2.

Observed model registrations are implementation facts, not upstream availability proof: `openrouter/deepseek-v4-flash` maps to `deepseek/deepseek-v4-flash`, and `openrouter/qwen3-vl-30b` maps to `qwen/qwen3-vl-30b-a3b-instruct`. The selected conversation model may differ. Direct-provider seed prices are not verified OpenRouter rates; validate configured wire IDs, reasoning/request shape and current prices before paid activation. Do not change the coding model to change the bot model.

### 7.5 Compose actions, timing, transport and recovery

Persist exact frozen bubbles with stable turn/ordinal identities before dispatch. Due times survive restart. Recheck current authority, applicable input/config/ownership revisions and platform permission after waits. No database transaction spans a model/network call.

Keep `fastt-telegram-transport.ts` as the neutral platform owner. The current grammY transformer retries `retry_after`; `api.raw` does not necessarily bypass it. Prove one lowest-level HTTP attempt through the configured migrated API chain. Preserve the accepted conservative classification: ambiguous timeouts/408/429/5xx/malformed responses become unknown/held; do not add hidden retries. Legacy behavior remains outside migrated scopes.

Extend existing scoped outbound eligibility and reuse `send-lock.ts` once in a documented order. Chat-only caches must not leak between bots, Business windows must not apply to incompatible modes, a delayed/resumed action cannot rely on a live-reply exemption, and a degraded "run anyway" lock cannot authorize a migrated send. Local TTL expiry never erases a canonical unresolved dispatch.

Persist an invocation/action journal. Pending queue acceptance is not native send success. A lost gateway response queries the same action. Propagate held/interrupted outcomes through broad native exception/retry wrappers. Repair attribution/history/offer state from original accepted receipts without replaying the whole invocation. Preserve confirmed bubble prefixes and hold unresolved suffixes.

### 7.6 Fence every writer and provide basic controls

Use SENDER_INVENTORY at actual dispatch boundaries. Suppress legacy replies, welcomes/free previews, campaigns, follow-ups and payment-generated conversation reactions for Fastt scopes. Keep settlement, subscription maintenance, access, credits and existing paid obligations alive. A compound tick must not be disabled wholesale if it also settles payments.

Provide status, pause requested/effective and conversation-scoped manual takeover through the existing authority. An AI `held` outcome is not a blanket ban on authorized manual or owed fulfillment. Manual sending requires effective takeover and must respect unresolved attempts. Unsupported writers are visibly held; unmet required paid fulfillment blocks the pilot rather than disappearing.

Official Telegram sessions can send outside this gateway. Observe attributable outbound activity and hold/cancel undispatched AI work; do not claim atomic control over all devices. A controlled pilot needs exclusive operator use of its chat.

### 7.7 Prove the composed flow

Provide a runnable local synthetic command using real internal owners and fake external services:

```text
real receiver/router -> real PG admission/publication
-> actual native target projection -> real ai_chatter
-> native model request owner with fake OpenRouter HTTP
-> durable action -> real Node transport owner with fake Telegram HTTP
-> accepted canonical receipt -> native bookkeeping/history repair
-> a second fan turn that sees the confirmed first reply
```

Fake only external model/Telegram HTTP and synthetic business source data. Do not stub the receiver, authority, DB, engine or projection into success. Include a second projected fan to prove scoped invocation. This verifies integration and failure behavior, not live platform access, conversational quality or conversion.

Required cases include duplicate/burst/reordered input; two creators sharing a user; chat-scoped message IDs; forged scope; payment-first routing; admission failure and actual offset restart; missing config/house-key refusal; model 429/timeout/malformed output and budgets; cross-context policy isolation; multi-bubble replies; new input/config/pause/takeover during generation/pacing; permission revocation; competing workers/senders; stale legacy work resuming after switch; crash before/after persistence/send/receipt; lost response; confirmed prefix; older native state against newer canonical epochs/receipts; and legacy retention outside scope.

After full P2 implementation and applicable tests, report for Astra's review. No P3 work or real activation is authorized by this immediate package. Do not invent another review boundary for each helper. Genuine environmental/access failures should be recorded with the exact command, exit and blocked criterion after completing independent work.

## 8. Runtimes, checks and evidence

Supported P2 native interpreter:

`C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/telegram-p2-python313/venv/Scripts/python.exe`

Recorded runtime is Python 3.13.16 with Fastt requirements installed. Its file exists at handoff. The ignored `inflowwkiller/.venv` is historically Python 3.11.9 and is not the native P2 runtime. Do not replace it. Local Node test evidence is v24.18.0 and disposable PG is 18.4; source deployment uses Node 22, so verify deployment compatibility rather than silently upgrading production.

Use synthetic configuration and an explicit disposable native database before imports, including `TWIN_FASTT_CONFIG_ISOLATED=1`. Inspect existing safe harness setup; the flag alone does not cure the still-unfixed missing-database default. Do not use real `.env`, sessions, private transcripts or account data. Importing `src/index.ts` or the full native server is not a harmless test startup.

Existing check entry points, to inspect and run from the appropriate directory with required disposable dependencies:

```text
bot/: npm run typecheck
bot/: npm test
bot/: node_modules/.bin/tsx.cmd src/dev/check-fastt-contract.ts
bot/: node_modules/.bin/tsx.cmd src/dev/check-fastt-durable.ts
bot/: node_modules/.bin/tsx.cmd src/dev/check-fastt-import-safe.ts
bot/: node_modules/.bin/tsx.cmd src/dev/check-fastt-schema-parity.ts
bot/: node_modules/.bin/tsx.cmd src/dev/check-fastt-p2-transport.ts
bot/: node_modules/.bin/tsx.cmd src/dev/check-fastt-routing.ts
bot/: node_modules/.bin/tsx.cmd src/dev/check-fastt-pg.ts
inflowwkiller/service/: <supported Python> -B -u tests/test_telegram_contract.py
inflowwkiller/service/: <supported Python> -B -u tests/test_telegram_store.py
inflowwkiller/service/: <supported Python> -B -u tests/test_telegram_provider_policy.py
```

The PG check requires `TWIN_FASTT_PG_URL` pointing only to a verified disposable local cluster. Earlier runs used `127.0.0.1:55432`; recheck whether it is available and use the existing setup/evidence, not live credentials. Required missing dependencies must fail as BLOCKED, not green SKIP. Default `npm test` excludes live DB tests and PG checks; run the required PG suite explicitly. Do not use `npm run test:db` for this offline assignment.

Record return codes and real success markers, not just counts. Historical sandbox runs could not create asyncio loopback sockets; a minimal probe worked outside that sandbox. The current host may differ: prove a present environment failure rather than repeating the old claim. Prior Node runs also hit memory exhaustion; run bounded checks sequentially when appropriate and distinguish resource failure from a passing test.

Do not run the unrelated broad Fastt vault suite without inspecting it: `test_vault_upload.py` historically has baseline assertions and a Windows `os.kill(1,0)` console-signal hazard. Use named affected suites. Never weaken an acceptance check to manufacture green.

Current independent evidence locations under workspace `output/`:

- `telegram-p1r-acceptance-20261017/`
- `telegram-p1pg-final-review-20261017/`
- `telegram-p2-increment1-review-20261018/`
- `telegram-p2-increment4-review-20261018/router-probe.mts`
- `telegram-p2-inc4-i7-review-20261018/probe.py` and `residual.py`
- `p2-inc4-npm-test.log`, `p2-inc4-pg.log` are builder logs.

Preserve old evidence and add current runs under a clearly dated directory. Do not describe historical tests as rerun. A full P2 round-trip command does not exist in the handoff snapshot; implementing and exercising it is a deliverable.

## 9. After P2: first live text pilot

A passing offline P2 package is ready for independent review, not automatically production. After acceptance, the live test requires actual Telegram creator/clone, bot identity, channel mode, Business binding and designated chat; positive reply/spend limits and deadline; validated provider/model settings and secure credential provisioning; attested live schema/runtime; durable state; exclusive receiver/worker ownership; effective pause/stop; backup/restore and a rehearsed return to legacy preserving unknown outcomes and history.

The old OnlyFans creator/fan selection and 3/10/15-reply allowances were for separate OF tests. They authorize no Telegram recipient. Do not reuse them, infer Telegram numeric IDs, or contact live fans from those earlier discussions.

Prepare concrete preflight/runbook steps during the authorized work. Ask only for missing identity/product choices and the final required live approval, when the reviewable result is ready. Do not demand permission for already-authorized offline implementation. Do not promise the preflight is necessarily short: live schema or deployment facts may uncover work.

The milestone is autonomous text through the actual Fastt path with correct creator facts, delivered memory and one writer. It does not claim photos, videos or sales are implemented.

## 10. P3A: media facts, descriptions and catalogue projection

Keep existing Supabase assets/UUIDs/private storage, prices, bundles, approved metadata and dashboard edits. Do not bulk reupload or re-caption history. Legacy usable metadata stays usable under its existing publication policy, labelled as legacy without fabricated approvals.

For new or explicitly re-analysed revisions, implement one Fastt-style pipeline:

1. Bounded factual vision extraction. Photos use the image. Videos use ordered duration-based sampling: six frames below 30 seconds, nine from 30 seconds to below three minutes, twelve at three minutes or longer. Test exact boundaries and real native/helper parity. Record timestamps/coverage and resource limits; sparse samples do not prove every event in a video.
2. Deterministic schema and cross-field contradiction checks. These can reject malformed/impossible combinations but cannot prove every language claim matches pixels. Flag uncertain/contradictory results for review.
3. One fact-grounded stored-copy pass using accepted facts, no pixels or fan history. Do not invent familiarity, previous requests/preferences, prices, urgency, recording time or unseen content.
4. Publish accepted versioned metadata into the existing catalogue; Fastt receives only that accepted projection. Failed/pending/corrupt analyses remain visible and preserve existing accepted fields. Stale results cannot overwrite later human edits.

One durable job identity covers creator, typed asset ID, immutable object revision, pipeline/model/config revision. Journal all attempts/cost and bound retries; one accepted result is not a promise of one billed HTTP call. Price-only edits do not rerun vision. Manual prices and accepted metadata survive failures. A new asset without valid price/publication state remains not-for-sale, never accidentally free.

Route dashboard uploads, imports and backfills through the same job owner. Retire old automatic Twin analysis only when the new path owns that revision. Do not run both generators. Use pure Fastt helpers with injected file access/persistence, not OF vault/server startup.

Distinguish stored sales copy from an optional contextual delivery caption. When explicitly mapped/enabled, Fastt's existing `_ppv_caption` owner can combine accepted asset facts with authorized conversation evidence; reuse an already valid caption and persist it with the action. Disable competing Node live-caption generation for that action. No unconditional third pass and no extra model call at the Telegram gateway.

Catalogue projection must paginate, handle equal timestamps/deletes/tombstones, and distinguish a source outage from an empty inventory. Preserve all photo/video/bundle source formats and private-storage access. Test wrong owner, removed media, expired URLs, corrupt input, missing ffmpeg/frame tooling, provider outage, restart, duplicate job, stale candidate, review/acceptance and all duration bands.

The earlier four-file media comparison used adapted Fastt prompts/sampling over OpenRouter, not the full native pipeline; it supports only the observed sample. It is not evidence of universal factual accuracy or better conversion.

## 11. P3B: content selection, Stars offers and fulfillment

Fastt should own mapped conversation/sales decisions and match requests against accepted catalogue metadata. Keep price/authorization/entitlement truth in deterministic product owners. Never run the old sales decider plus Fastt on the same turn.

Keep original IDs/source types for photos, videos, `photo_bundles` with independently stored items, `catalogue_bundles`, Mini App orders and old purchases. Freeze buyer, composition/order, accepted asset versions, price/currency and caption when an offer/order is created. Validate before promises and before delivery. Do not split an oversized bundle into separately charged messages without an explicitly supported product policy.

Telegram money is integer XTR/Stars, not USD/cents. Start with existing approved Stars prices. Disable unmapped dollar ladders, floors, spending thresholds and inferred-dollar purchases. Any dynamic Stars ladder/discount needs explicit configured ranges and tests in the existing pricing owner. Do not copy the V2 prompt's dollar-to-Stars explanation or let a model calculate money.

Preserve the existing paginated `star-reconcile.ts` and payment/entitlement infrastructure. Validate new and legacy payloads, buyer, amount, currency, expiry, order and actual provider receipt. Strengthen the current permissive pre-checkout path without an AI call. Approval is not payment; paid-media notification is not an invented monetary transaction; Business payments still need reconciliation. Duplicate callback/poller evidence must grant once. Refund identity must not be swallowed as a duplicate purchase.

Settle confirmed money, exact obligation, fulfillment outbox and engine purchase event atomically where possible, otherwise with one durable idempotent repair. Paid obligations explicitly reference trusted order IDs; never infer which purchase to fulfill from matching assets. A tip is not an automatic media unlock. Payment at zero chat credits still settles. AI pause, new input or engine switch cannot discard owed fulfillment. An unavailable asset remains a support/refund obligation; paid upload failure never falls back to free delivery.

Test precise requests and no-match; wrong creator; removed asset/stale price; supported bundles; old invoices paid after cutover; duplicate receipts; partial delivery; refunds; more than one transaction page; Mini App/chat ownership consistency; and rollback with outstanding orders. Use supported test-payment facilities first where applicable, then a separately approved small real purchase.

Second usable milestone: a supported real purchase delivers the right item, updates ownership once, appears correctly in the dashboard and informs the next Fastt turn.

## 12. P4: dashboard and lifecycle behavior

Preserve Twin UI and authorization. Add effective engine/config version, channel identity, worker health, projection lag, requested/effective activation/pause/takeover, error/held reasons and manual command outcomes. Retain media editing, fan/history/revenue views, purchases and Mini App access. Show only confirmed messages as delivered and account usage once.

Map welcome/first-message, returning fan, follow-up, aftercare/post-purchase and relevant scheduled behavior into one engine/scheduler owner. A process restart or history import is not a new fan. Fence old jobs during switch. P2 already excludes conflicting writers; P4 completes mapped feature behavior and full controls.

Walk configuration end to end: schema, both repos' types, row mapping, actions/optional columns, UI state/control, actual runtime consumer and tests. Read both CLAUDE.md files: a saved-but-unused control is a known failure mode. Do not silently leave old prompt knobs effective in previews but ignored at runtime. Preserve typed creator facts and compatible onboarding fields; this is not permission to invent a new questionnaire.

Preserve enabled voice/incoming-media/credit/subscription behaviors or explicitly block rollout until supported. Existing AI assistant/admin/public APIs retain authorization, field allowlists, secret exclusions and revenue/cost visibility boundaries. Full operator/agency/creator isolation must be verified, not inferred from a service-role key.

## 13. P5: deployment, recovery and measured capacity

Verify actual hosts/releases, source plus dirty dependencies, applied migrations/roles, supported Node/Python/SDK versions, provider availability/prices, secret references, enabled products and all writers before choosing deployment actions. Current infrastructure details in RUNTIME_MANIFEST come from source; do not assume today's cloud access or running image.

Repository instructions identify Supabase project `aouaenqayfltoqrmpitg` as the intended live Twin project and forbid writes to `cnnsllgzskqkvdovyiiv`. Treat the intended project as live too; current P2 uses neither. Never use production as a disposable test DB. Node owns migrations under `bot/db/migrations/`; do not blindly apply the old schema dump or rewrite an applied migration.

Deliver reproducible pinned images/dependencies, dedicated worker bootstrap, durable volumes, backup/restore, migration dry runs/counts/checkpoints, redacted health/metrics, deployment and rollback runbooks. Preserve MIT license notices from Fastt. Do not start its general OF app to obtain the Telegram worker.

Rehearse process kill at every send boundary, uncertain outcomes, receipt repair, old-snapshot restore against newer canonical actions, full disk/backpressure, database/model outage, competing workers and repeated rollout/rollback. Native SQLite includes non-reconstructible questions/scheduler/offer state; it is not a disposable cache. If missing native state cannot be reconstructed, hold it explicitly.

Canonical epochs remain monotonic across worker restore. Fence old owners before replacement. Migration 144's destructive rollback drops control state/resets epochs; it is not the live application rollback procedure. Keep current confirmed/unknown actions, identities, purchases and obligations.

Measure worker memory/disk, concurrency, pool pressure, queue growth, rate limiting and model spend with synthetic load in the intended topology and fake platform transport. Define supported capacity from results, not a million-message claim. Pilot subset of these recovery prerequisites happens before the first live text test, not only at the end.

## 14. P6: controlled migration and completion

After applicable acceptance and explicit target authorization:

1. Deploy additive code/schema disabled, preserving the active service and settlement.
2. Snapshot the selected creator's data/history/config/catalogue/entitlements and native state consistently; import with generation disabled and verify counts/references.
3. Catch up projections, freeze/drain old conversational work, and inventory scheduled/manual/paid obligations.
4. Resolve or hold in-flight/unknown sends; never erase them to make cutover convenient.
5. Change assignment/ownership epoch atomically, retaining one actual receiver and delivery authority.
6. Enable only the named canary conversation with visible limits, deadline, stop/pause and observed costs/outcomes.
7. Verify text, then supported sales/payment/refund cases as those packages become accepted. Expand by creator only after evidence and enabled-capability coverage allow it.

Rollback is forward reconciliation: stop Fastt generation, retain/reconcile its actions and obligations, project confirmed history/ownership into legacy-compatible sources, then change epoch/assignment. Never overwrite new purchases/messages with an old whole-database snapshot. Keep affected conversations paused if old/new data compatibility is unresolved.

Completion for a bot means actual autonomous Fastt conversation through its real Telegram identity, correct creator/memory, enabled content sales and paid fulfillment, working dashboard controls, retained existing entitlements, tested interruption/restore/rollback and no competing legacy generator. Whole-project completion requires that evidence for the agreed fleet scope, not one test chat.

Live sample messages and conversation style do not establish revenue lift. Record delivered/failed/unknown outcomes, sample size, cost and operator interventions; compare conversion with matched cohorts over an agreed observation period. Never guarantee zero bugs or exactly-once external delivery.

## 15. What to do first and what to return

First inspect all applicable instructions, the live worktree status and the current references. Preserve any new changes that appeared after this snapshot. Read untracked files directly; `git diff` alone omits most migration modules. Keep other chats' OnlyFans/dashboard work separate and do not initiate extra writers.

Then resolve the current P2 findings and finish the seven deliverables. Use internal checkpoints; update the existing progress/mapping/sender documents with actual consumers/tests. Do not create a competing plan or spend another run merely restating the roadmap. Do not reimplement accepted P1/transport work unless a new integration reproduction requires a narrow change.

At the full P2 review boundary return:

- A clear complete/incomplete status tied to each deliverable and P2-I1–I10.
- All changed/new files, source revisions and relevant pending-work preservation.
- The actual autonomous internal flow and its production consumers, not helper-only claims.
- One executed synthetic round-trip command and observed first/second-turn behavior.
- Actual tests, exit codes, failure/restart evidence, model/Telegram HTTP attempt counts and remaining gaps.
- Confirmation that migration remains legacy/off by default and the exact outstanding live-preflight facts.
- Updated PROGRESS, capability/configuration/sender inventories, and a concrete review request for Astra.

Current implementation authorization: offline P2 code, synthetic tests, disposable local databases and loopback fake services. No real Telegram/OF messages, receiver/worker activation, paid model/media calls, live Supabase access/migration, secret inspection, deployment, commit or push. Subsequent packages follow the plan's review sequence. This handoff records the complete end goal; it does not quietly remove these boundaries.

## 16. Pack contents and evidence limits

The companion reference archive contains this handoff, the full governing plan/current assignment and review, accepted foundation reviews, full progress/inventories, contract fixtures/schemas, repository instruction files and a handoff snapshot manifest with hashes. Historical references are labelled by their dates and scopes. This is documentation/evidence, not a replacement for the current source checkout.

The pack intentionally does not bundle application secrets, sessions, databases, private conversations, media, dependencies or an implicit deployment artifact. Current source and uncommitted changes must be available in the workspace. If moving execution to another machine, make a separately reviewed source-only transfer that includes required untracked code and preserves its provenance; do not zip the entire workspace.

At preparation, documentation and Git/source presence were inspected, but no application test, model call, migration, activation or deployment was performed. Source hashes identify this snapshot; they do not prove code correctness. Re-read current workspace documents if they have advanced after this pack was created.
