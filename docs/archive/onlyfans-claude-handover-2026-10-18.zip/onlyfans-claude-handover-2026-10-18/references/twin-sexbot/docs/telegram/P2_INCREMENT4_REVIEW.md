# P2 increment 4 review and current continuation

18 October 2026. **P2 remains incomplete and inactive. The original I7-A/I7-B reproductions are now closed at the component boundary. The new assignment resolver has two demonstrated semantic defects and is not accepted as complete.**

This is the current review of the increment 4 report and the earlier I7 repairs it references. Continue the existing full P2 package. Do not return to P1 or create another approval boundary for each helper. The native worker refactor is unfinished implementation, not an external blocker; the builder explicitly confirms the supported runtime exists.

## Verified progress and limits

- The original public-call tests now pass: one valid synthetic call produces one fake HTTP request and audit row; unmapped purpose, disabled media purpose, wrong configured model and blank account produce configuration errors with zero HTTP and no extra audit rows.
- Synthetic legacy-present imports no longer attempt protected secret-file access when isolation is active. The original reviewer probe was adapted only for the added `trusted_account_id` argument. Its prior evidence is preserved.
- Async authority/identity facades are present. Typechecking passes. This review does not promote their reported 195 PG assertions into an independently rerun result, or equate those facades with the full authenticated gateway composition.
- The new router's submitted suite passes. The new code has no production receiver/job/sender/control consumers yet; search finds its calls in dev checks. Calling the same helper three times is not a test through those three application paths.
- No `service/telegram_runtime` package exists yet. The native worker, projections and complete offline message round trip are still outstanding.

## R4-A: identity registration is not pilot authorization

`bot/src/engines/engine-router.ts` calls the result of `conversationBinding()` an override. It then skips the explicit allowlist whenever that row exists. In both real stores, `bindConversation` records the immutable trusted conversation-to-binding/creator identity, input revision and takeover controls. It does not record a pilot opt-in or engine override.

The real SQLite-store probe demonstrates this without fake store decisions:

1. Establish a Fastt creator binding and an allowlist containing only a different, designated test conversation.
2. Resolve an ordinary conversation: `legacy`, as expected.
3. Register only that ordinary conversation's trusted identity with the same binding. No pilot selection changes.
4. Resolve again: incorrectly becomes `fastt`.
5. Even an empty allowlist still resolves it to `fastt`.

Thus an identity record can expand pilot scope, and removing a selection does not remove this permission. This would affect scope selection when wired, although no real receiver currently uses this router.

Correct the existing resolver and its test fixtures. Keep the identity relation intact for delivery/ownership. Establish explicit pilot authorization separately using the planned authoritative assignment/configuration facts; ordinary registration must never create it. If an explicit override feature needs a durable representation, implement that in the existing authority/config owner rather than overloading `bindings_conversations`. Do not invent another selector, compatibility fallback or parallel assignment database. Preserve fenced ownership transitions and unresolved sends on removal; revocation must not silently hand an in-flight Fastt conversation to the legacy engine.

Use real store operations to test registered/unregistered selected and unselected conversations, selection removal, an actual explicit override if implemented, and outstanding-action handling. The current submitted case 10 encodes the wrong meaning of `conversationBinding`; correct its premise rather than retaining the defect to keep that assertion green.

## R4-B: current persisted controls must govern readiness

The router retrieves a binding containing `ai_paused` and `human_takeover`, but checks only the separate caller-supplied readiness flags. A current stored pause or takeover is therefore ignored if the caller supplies false or omits those flags. The interface says omitted readiness is unknown, yet only worker availability and projection freshness require an explicit true.

The real store probe sets each persisted control through `setBindingControls` and supplies healthy worker/projection plus false pause/takeover. Both cases incorrectly return `fastt`. Omitting pause/takeover attestations also returns `fastt`.

This proves incorrect generation eligibility/status. It does not prove a send bypasses the existing final authority: both stores retain claim-time pause/takeover checks.

Use current authoritative binding and conversation controls in the one resolver. Caller readiness cannot negate a persisted hold. Missing required readiness/control information must hold, unless the resolver has independently established that exact fact from its authoritative source. Keep the final action-class-specific authority check; a readiness snapshot does not replace it. Test binding pause, binding takeover, conversation takeover requested/effective, unknown information, stale supplied readiness, and healthy selected conversations.

## Remaining configuration acceptance, without reopening the original repairs

The original I7-A/I7-B failures are closed. Supplementary guarded probes show three already-requested configuration/bootstrap requirements remain before completing P2:

- **Stable configuration snapshot:** `TelegramLLMPolicy` retains the caller's mutable purposes dictionary. Adding `media_vision` to that dictionary after installing a conversation-only policy changes the active policy and allows a fake Qwen request and audit. Freeze/copy accepted configuration in its existing owner and apply changes through explicit versioned replacement; do not add a second policy layer. Retain the same isolation between asynchronous contexts.
- **Malformed policy error path:** `provider_allowlist=None` raises raw `TypeError` in `_resolve` before `config_problem` runs. There are zero HTTP/audit effects, so this is not a credential leak. Validate before using malformed policy fields and produce the existing configuration-error outcome.
- **Explicit isolated database:** an isolated import without `DATABASE_URL` still constructs an engine pointing to native `chatterly.db`. The probe inspected only its URL and never opened it. Finish the explicit database requirement in the existing bootstrap/database owners before worker imports; isolated operation must fail clearly rather than default to the live native file. Preserve normal OnlyFans defaults outside the isolated path.

Evidence: `output/telegram-p2-inc4-i7-review-20261018/README.md`, original adapted `probe.py`, and supplementary `residual.py`. These are remaining P2 requirements, not new stages. Preserve passing original public-call and secret-import regressions.

## Prevent overlapping decisions when wiring

`resolveEngine`, `canRouteToFastt` and `assignmentFor` still answer different questions from `resolveAssignment`. They currently have only test consumers; this review does not claim a live second sender exists. Before wiring, make every operational engine decision use the same effective resolver. Retain a raw configuration accessor only if its name/result clearly cannot be mistaken for readiness or permission. Remove or adapt obsolete helper consumers rather than keeping contradictory operational rules.

The resolver owns generation assignment. A `held` AI scope does not automatically forbid settlement, outstanding paid fulfillment or authorized manual sending. For example, effective human takeover holds AI while enabling the manual action under the existing authority. Apply the established action-class rules at those boundaries. Do not make the sender inventory's former blanket manual-refusal wording into production logic.

Update `CAPABILITIES.csv`, `CONFIG_MAPPING.csv` and the sender inventory to distinguish helper implementation, outstanding findings and actual adoption. Do not claim P2-I1 is integrated across application consumers until those consumers and their tests exist.

## Exact continuation within P2

Read START_HERE.md and IMPLEMENTATION_PLAN.md; their seven deliverables and section 8.1 remain the assignment. Address the current findings in their existing owners and continue the full implementation, including:

1. Complete PG-backed gateway composition and authenticated scoped protocol, reusing the existing async facades and accepted transaction interface.
2. Wire real receivers and existing writers through one assignment decision, preserving payment-first handling and durable admission before acknowledgement.
3. Implement real capability injection into native `ai_chatter` and the dedicated scoped worker/projections. Do not copy the engine, use pilot monkeypatches in production, or start the OnlyFans application.
4. Complete stable creator/config snapshots and explicit model purposes/billing/limits in the existing native owners.
5. Compose durable text actions, pacing, final authority, one transport attempt, journals and interruption/receipt recovery.
6. Complete writer exclusion and basic action-class-aware controls without stopping settlement or duplicating legacy generation.
7. Exercise the actual composed offline flow through real internal owners with fake external HTTP, including a second turn observing the confirmed first reply and required failure/restart cases.

Use internal checkpoints to manage a large refactor. Its size alone is not an external blocker and does not require another user approval. Finish independent work and return at the full P2 review boundary. If genuinely blocked, state the failing command, unmet acceptance criterion and remaining independent work. Do not call the current boundary P1.

## Evidence

| Check | Independently observed result |
|---|---|
| `node node_modules/typescript/bin/tsc --noEmit` in `bot` | exit 0 |
| `node_modules/.bin/tsx.cmd src/dev/check-fastt-routing.ts` in `bot` | exit 0; submitted assertions pass |
| `node_modules/.bin/tsx.cmd ../output/telegram-p2-increment4-review-20261018/router-probe.mts` in `bot` | exit 1; 5 failed assertions across the two router findings; 4 controls pass |
| Supported Python `-I -B -u output/telegram-p2-inc4-i7-review-20261018/probe.py` | exit 0; builder/public-call/secret-import modes all pass |
| Supported Python `-I -B -u output/telegram-p2-inc4-i7-review-20261018/residual.py` | exit 1; three remaining acceptance checks documented above |

The router probe uses an in-memory real SQLite control store. Python probes use temporary native stores, synthetic credentials, protected-file/network guards and fake HTTP. No real secret, private transcript, model request, platform request or live database was used.

Reviewed Node router SHA-256: `57DCC4F8FD1DC1847EC965AB960F1B59078881A81A9A61904EE18CD6C2160BD8`; submitted routing-suite SHA-256: `37CB88E5D84AB5AFCCDF219C1E6754187B316A92034110BB80846CEA2554B0E2`. Bot HEAD remains `f414f32`; Fastt HEAD remains `e72316f`.

This review changes evidence and documentation only. It does not activate, deploy, commit, push or modify production code. No claim of P2 acceptance or live readiness is made.
