# Fastt engine migration for Twin Telegram bots

Prepared 17 October 2026; P2 integration instructions re-reviewed against current source on 18 October 2026. Status: implementation contract. P0 local inventory is delivered; P1-R is accepted in `P1R_ACCEPTANCE.md` and the PostgreSQL foundation is independently accepted in `P1PG_ACCEPTANCE.md`. All four residual PG1/PG3 findings are closed within that local scope. P2 is partially implemented: its neutral transport increment is accepted in `P2_INCREMENT1_REVIEW.md`; the complete native text connection and offline round trip remain the current assignment in `START_HERE.md`. Live runtime/schema attestation and pilot approval remain separate gates. No production activation or live data changes were made by this planning/review task.

The goal is to run Fastt's native conversation and content sales logic behind the existing Twin Telegram product while preserving the dashboard, Supabase data and Storage, creator identities, existing media, OpenRouter account, purchase history and paid entitlements. This covers the connection, verification, deployment and migration of selected bots. It does not assume that every live bot currently runs V2.

The selected architecture keeps the established Node Telegram service as the only Telegram receiver and delivery gateway. A dedicated Python Fastt worker supplies conversation and sales decisions. Supabase remains the authoritative business data store. Fastt retains its native SQLite state in an isolated, durable worker volume. This is two runtime components with separate responsibilities, not two competing reply engines.

The first usable milestone is a controlled Telegram conversation through Fastt. The second is a controlled content sale with correct settlement and dashboard reporting. Fleet migration follows compatibility, recovery and operating checks. A live pilot requires the exact creator, channel mode, test recipient and send/spend limits to be resolved; earlier OnlyFans pilot approvals do not identify a Telegram recipient.

## Governing development rules

These owner-mandated rules apply to every recommendation, plan, review and edit affecting Twin V2, the established Telegram runtime, the dashboard or the Fastt migration. They are development instructions and must never be inserted into a creator's fan-facing prompt.

1. Before recommending or changing anything, inspect the current responsible code, effective prompts and configuration, relevant tests, worktree state, recent changes and pending work at the exact target revision. If the deployed revision cannot be established, mark the target-specific decision pending rather than assuming a local folder is authoritative.
2. Trace the proposed change through existing behaviour before implementing it. Identify the current owner of the behaviour and check for interactions with ingress, prompt construction, post-processing, storage, scheduling, delivery, payments, operator controls and rollback where relevant.
3. Make the smallest necessary change in the existing responsible component wherever practical. Do not add contradictory instructions, duplicate handlers, competing engines or state machines, unnecessary prompt layers, parallel sources of truth or extra AI calls. A new component or model call requires a documented need, one clear owner and tests proving that it does not compete with an existing path.
4. Keep the bot's effective prompt, any prompt displayed in the dashboard and the behaviour implemented by code consistent. Preserve previously approved behaviour unless the agreed stage explicitly changes it. Record the deliberate disposition of any replaced or disabled behaviour.
5. Test the affected end-to-end flow at its real boundaries and the relevant failure cases. Check data compatibility, restart/recovery and rollback when applicable. Report what changed, the exact verification evidence and any remaining uncertainty. Never claim there are no clashes, regressions or duplicate paths without checking the current code and pending diff.
6. Work one agreed stage at a time and stop at its stated review boundary. Do not begin a later stage because an earlier helper or isolated test passed.
7. Apply these requirements to suggestions and repairs as well as implementation. Do not propose a change until it has been checked against existing prompts, code, configuration and pending work for contradictions, duplicate logic, unnecessary calls and failure risks.

## 1 Decisions and scope

1. Preserve the existing Supabase project, Storage objects, clone UUIDs and dashboard identities. Do not recreate accounts or bulk reupload assets.
2. Preserve the deployed Telegram mode. A Telegram Business account and a conventional bot chat are different routes; one cannot silently replace the other.
3. Keep one Node receiver per bot token. Extend the attested existing runtime with an engine router; do not launch a second poller using the same token.
4. Use Fastt's real native engine, content resolver and mapped sales state. Do not implement a second approximation by copying its system prompt into V2.
5. Keep the existing OpenRouter billing account and selected model configuration. Add production OpenRouter support to Fastt rather than using its experimental monkeypatch wrapper.
6. Keep catalogue editing, Storage, approved descriptions, approved selling copy and human review in the current dashboard. For newly analysed or explicitly re-analysed assets, replace Twin's single-frame automatic generator in P3A with one Fastt-style pipeline: bounded multi-frame factual extraction, deterministic validation, then one fact-grounded selling-copy pass. Fastt receives only the accepted versioned projection. Do not mass re-describe historical inventory.
7. Reuse the established Telegram settlement and entitlement paths after verifying the deployed revision and repairing demonstrated gaps. In particular, the current pre-checkout handler approves positive XTR without checking buyer/order/payload; its existence is not evidence of complete validation. Do not replace the paginated reconciler with V2's limited test payment poller.
8. Route every outgoing operation for migrated conversations through one durable delivery authority. Legacy dialogue, campaign, welcome and purchase-reaction generators must not compete with Fastt.
9. Keep deliberate typo and misspelling injection disabled, as requested. Keep creator facts separate from engine instructions.
10. Preserve old source and data for rollback. Retire old runtime paths per migrated bot only after acceptance; do not delete unrelated OnlyFans work.

This plan specifies the bounded Telegram rollout. It does not certify 1,000 creators or any message volume before measurements. The worker-per-creator design deliberately prioritizes isolation and reuse; its process, memory and storage costs must be measured before fleet expansion.

## 2 What the local source establishes

All local paths are under C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION unless linked explicitly. Runtime versions below are local source observations, not an attestation of today's deployment.

| Component | Observed source | Role and implication |
|---|---|---|
| Established Telegram bot | bot, branch codex/telegram-fastt at f414f32 with untracked P1 work; a different allieai2-bot copy also exists | Multi-creator grammY service, Supabase history, Business messages, credits, subscriptions, paid media, refunds and dashboard manual commands. Local implementation does not establish the running revision. |
| Twin V2 | twin-sexbot, base 7b0036b with uncommitted OnlyFans work | Separate single-creator test runtime with local history. It is not the complete dashboard-backed product. |
| Dashboard | twin-dashboard, local main fb6b345, plus divergent sibling worktrees | Creator/agency access, content administration, model settings, chat/revenue views, manual control and Mini App catalogue. Select the actual deployed worktree/release. |
| Fastt | inflowwkiller, base e72316f plus integration and pilot work | Python native engine and sales modules; currently assumes OnlyFans/Fansly in platform operations. |
| Operations | twin-ops and twin-tgaiclone/pipeline | Deployment, backup and fleet tooling exists. Source names an allieai2-bot server directory; this does not establish the running image. |

Specific findings that change the implementation:

- The established bot routes production conversations through Telegram Business handlers; direct bot chatting is separately gated. Preserve business connection IDs and permissions.
- The established bot already has paginated Stars reconciliation. The earlier observation that V2 reads only 100 transactions does not describe that mature runtime.
- TelegramMessenger contains marketing/style rewrites as well as transport calls. Reusing the entire class would alter Fastt's output. Extract the platform operations and explicit validation gates.
- Fastt's native provider registry lacks OpenRouter. The successful OnlyFans experiment used a separate OpenRouter shim.
- Fastt accepts a PostgreSQL connection string in its engine constructor, but hot paths contain SQLite-specific SQL and inserts. A URL change is not a verified database migration.
- Fastt assumes account-wide unique message IDs in several purchase/history helpers. Raw Telegram message IDs must be mapped, not copied into those fields.
- The dashboard has multiple bundle formats and Mini App order/ownership paths. Migrating only photos and videos would omit part of the product.

## 3 Runtime attestation before choosing deployment targets

Create RUNTIME_MANIFEST.md and a machine-readable, secret-free equivalent in this docs directory. Record each field as observed, inferred or pending:

| Required field | How to establish it |
|---|---|
| First creator clone UUID, public bot ID/username and permitted test user/chat | Existing dashboard identity plus explicit test selection; no username-only authorization |
| Dashboard URL and release | Running release/image metadata and source revision |
| Bot release and source root | Running process/container metadata, image digest, source SHA and dirty patch manifest |
| Telegram channel mode | Existing handler/configuration and actual Business binding or conventional bot registration |
| Receiver ownership | Polling or webhook configuration and owning process; read-only inspection, no second getUpdates consumer |
| Supabase project and applied schema | Redacted project identity, migration history and metadata-only schema inspection |
| Enabled products | Text, media, bundles, Mini App, credits, VIP, tips, voice, subscriptions, campaigns and external checkout paths |
| Model configuration | Effective model IDs, purpose routing, generation parameters, fallback policy and secret references only |
| Data sources | Counts and coverage of history, purchases, offers and media; last synchronization times |
| Current writers | Every process/job that can generate, send, settle, change ownership or consume manual commands |
| Recovery assets | Backup locations, last restore verification, disk capacity, existing deployment rollback mechanism |

Do not dump environment files, tokens, database passwords, session files or private transcripts into the manifest. Use existing authorized access when available. If deployment access or the first bot is unresolved, finish the independent offline contracts and tests, but leave target-specific deployment blocked explicitly.

Logical names used below are resolved by this manifest: BOT_ROOT, DASHBOARD_ROOT and FASTT_ROOT. The local bot directory is the current source candidate, not an instruction to overwrite allieai2-bot or a remote checkout. Preserve unrelated uncommitted work. Use isolated codex/telegram-fastt branches/checkouts based on the correct revisions; include required uncommitted dependencies deliberately with a patch manifest, not a bulk copy or reset.

## 4 Architecture and ownership

~~~mermaid
flowchart TD
  TG[Telegram user or Business chat] --> EDGE[Existing Node receiver and engine router]
  UI[Existing Twin dashboard] --> SB[Supabase business data and event ledger]
  EDGE --> SB
  SB --> PROJ[Versioned projection into creator worker]
  PROJ --> ENGINE[Fastt native Python engine]
  ENGINE --> OR[Existing OpenRouter account]
  ENGINE --> INTENT[Persisted action with stable identity]
  INTENT --> SEND[Node delivery authority]
  SEND --> TG
  SEND --> SB
  SB --> UI
  STORE[Existing Supabase Storage] --> SEND
~~~

| Fact or responsibility | Authoritative owner | Other components may do |
|---|---|---|
| Creator identity, agency access and approved configuration | Existing Supabase/control-plane authorization | Project validated, versioned configuration into Fastt |
| Files, descriptions, flags, approved prices and bundle definitions | Existing Supabase catalogue and Storage | Maintain searchable Fastt projections with source references |
| Received Telegram events and actual delivered messages | Node gateway plus canonical Supabase event/receipt records | Project into Fastt and dashboard views idempotently |
| Purchases, refunds, credits, subscriptions and ownership | Existing settlement service and canonical financial ledger | Publish exact normalized events to Fastt; do not infer purchases independently |
| Conversation decisions, questions, offers and mapped follow-up logic | Fastt worker for the selected engine revision | Expose read-only status and audit events to dashboard |
| Telegram sending, rate limits and result classification | One Node delivery authority | Fastt requests actions and reads durable results |
| Operator pause, block, takeover and engine assignment | Supabase control records, enforced at final delivery boundary | Workers obey requested/effective revisions |
| Native Fastt engine-only state | Creator's durable SQLite worker database | Back up, migrate with its worker, and project selected diagnostics |

Fastt's database is not disposable. It contains both reconstructible source projections and non-reconstructible native state such as question history, offer progression and job checkpoints. Keep one active worker lease per creator database, with a durable volume and tested backup/restore. Do not share the existing OnlyFans database or place SQLite on an arbitrary shared network filesystem.

All creators use the same versioned worker image and code; creator configuration and assignments remain data rows. Isolation does not mean per-creator source forks or manually divergent deployments. The P1 SQLite control store is an offline reference implementation, not a second production authority. Production event admission, identity allocation, assignments, delivery claims and receipts live in PostgreSQL/Supabase; Python's SQLite contains native state and explicitly derived projections only.

Restore a consistent native backup through a recorded checkpoint, together with projection and delivery watermarks. Source-event replay alone cannot reconstruct lost native decisions, question history or scheduler mutations. Recover those through retained native WAL/change records or hold affected conversations for explicit recovery when unavailable. Before restoring or replacing a worker, stop/fence the old process and issue a strictly newer Supabase ownership epoch; never restore ownership authority from SQLite. Canonical identity allocations, stable action IDs, confirmed receipts and unknown outcomes survive restore unchanged. A restored native allocator must reconcile against the canonical identity map before allocating another ID.

Run a dedicated Telegram Fastt entry point. It must not start the full OnlyFans server lifespan, event pumps, vault sweeps or generic automation supervisor. Node alone holds Telegram tokens. Python receives scoped gateway access and required model credentials through a secret reference; it has no OnlyFans session credentials or direct Telegram sending path.

The initial deployment can colocate Node and Python over authenticated loopback/private networking. This avoids public engine endpoints and a new cloud service. Keep the protocol versioned so placement can later change without changing business semantics.

## 5 Nonnegotiable behavior

1. Exactly one engine assignment and delivery authority revision is valid per conversation. Dashboard/manual application actions and automatic application actions use that authority. Official-app activity is an external writer as described in section 7.
2. Duplicate inbound updates, worker submissions and purchase receipts are idempotent. Conflicting payloads under an existing identity are errors, not overwrites.
3. A generated answer, queued action, typing notification or accepted HTTP request is never evidence of delivery.
4. A network failure after possible transmission produces an unresolved outcome. It must not create a fresh action or invoke the old engine as fallback.
5. No automatic replay of an interrupted native invocation unless its state and externally visible actions have been reconciled.
6. Creator, bot, fan, chat, Business connection and source message identities remain distinct and scoped.
7. Existing purchases and credits survive migration. An offered item is not an owned item.
8. Currency is explicit. Telegram Stars are not dollars or dollar cents.
9. Imported history and catalogue updates do not trigger welcome messages, campaigns or sales.
10. Revoked assets, lost platform permission and blocked recipients prevent affected dispatches. AI pause and stale conversational input/configuration block AI actions; manual takeover and paid fulfillment use the action-class rules in section 12.
11. Financial settlement continues while conversation generation is paused. A pause cannot discard a paid order.
12. Old conversation prompts and post-processing do not modify Fastt replies. Independent safety, truthful-content, price and authorization checks remain explicit and tested.

These rules reduce known failure modes; they do not create a guarantee of zero bugs or exactly-once external delivery.

## 6 Additive data contracts

Use existing equivalent durable tables and transaction helpers where they satisfy these constraints. Do not create a parallel payment ledger or duplicate existing primary keys merely to match the proposed names. New names below are proposed until schema attestation resolves them.

| Record | Required content and constraints |
|---|---|
| engine_bindings and conversation assignments | clone UUID, bot identity, channel mode, allowed Business connection, creator default engine, explicit per-conversation pilot overrides/allowlist, requested/effective mode, monotonic ownership epoch, config version, activation cutoff, worker lease; one effective assignment resolver used by ingress and every job/sender |
| telegram_events | Unique bot ID + update ID; canonical event ID; scoped conversation key; original message/user/chat/connection IDs; kind, origin, timestamps, receipt sequence, immutable versioned body (or durable retrievable body reference) and semantic payload digest |
| engine_turns | Stable input-set/turn ID, input event range and digest, engine/config/catalogue versions, ownership epoch, state, retry classification, result/action manifest |
| native_identity_map | Durable unique mappings for account, fan, message and asset identities; source type and complete scoped source key; no hash truncation into numeric IDs |
| delivery_actions | Unique action ID, turn/job source, ordinal, recoverable exact frozen body plus digest, intended recipient, price/asset manifest, epoch, state, immutable attempt token/evidence, Telegram receipt and error category |
| projection_events and cursors | Stable source event ID plus source revision and recipient, immutable recoverable body plus digest, ordered sequence and per-stream consumed cursor; duplicate import is a no-op; a cursor cannot advance before its import transaction commits |
| engine_offers or existing order extension | Immutable offer UUID, intended buyer, source assets and revisions, ordered composition, price/currency, expiry and delivery/settlement references |
| engine_commands | Authenticated pause/resume/takeover/config/manual commands, actor, expected revision, requested/effective outcome and reason |
| worker_invocations | Native invocation started/completed/interrupted status, turn identity and recorded action list; survives process restart |

Canonical identity rules:

- Wire IDs are strings with explicit validation and size limits; do not coerce booleans, padded strings or floating values into identifiers.
- Conversation identity includes channel, clone UUID, bot ID, channel mode, Business connection when applicable, and chat ID. Fan/user identity is separate from chat identity.
- Source message identity includes bot, chat and Business connection context. Telegram message 42 in two chats must map to two different native message IDs.
- Native numeric IDs are allocated persistently and bijectively. Preserve original provider timestamps and canonical sequence for ordering; never assume a late imported older message is newest because its surrogate is larger.
- Same Telegram user talking to two creators is two scoped relationships. No automatic cross-platform merging with an OnlyFans fan of the same numeric ID or username.
- Media mappings distinguish photo, video, photo_bundle_item and catalogue bundle membership. A UUID from one table cannot alias another source type.
- Cache Telegram file IDs by bot identity and immutable asset revision; a token rotation for the same bot and a different bot identity are distinct situations to validate.

Incoming event schema v1 contains: schemaVersion, eventId, channel, bindingId, cloneId, botId, mode, businessConnectionId, chatId, userId, updateId, messageId, occurredAt, receivedAt, origin, eventKind, text/caption, supported attachment references and sourceRevision. Binding and authorization derive from trusted receiver configuration, not these claims alone.

An action schema v1 contains: actionId, turnId or jobId, ordinal, bindingId, conversationKey, expectedEpoch, expectedInputRevision, configVersion, actionKind, exact text/formatting, asset/offer references, currency/amount where relevant, notBefore and expiresAt. An action ID is based on the durable logical turn/job and ordinal, never a new process run ID. Freeze the payload before the external boundary and reject different content with the same ID.

Use canonical UTC timestamps, distinguish server receipt time from provider event time, and reuse the Unicode/length validation lessons from the existing bridge without copying its OnlyFans-only contract unchanged. Include malformed surrogate, oversized body, invalid timestamp, duplicate-field/parser and large-ID fixtures in both languages.

Hash semantic provider content separately from receiver bookkeeping. Redelivery of the same bot/update with a new local receipt time must return the existing event and its first accepted metadata; changed provider content under that identity must conflict. Every persisted event, action and projection must be readable after close/reopen without the original in-memory input. A digest alone is not replayable data. Preserve versioned bodies with bounded size, scoped access and no secret fields.

For v1, ordinal is an integer in 0..2147483647 (matching PostgreSQL integer); epoch and input revision are integers in 0..9007199254740991 (the common JavaScript safe-integer range). Their encoded decimal representation must match Python exactly. Numeric Telegram IDs remain validated decimal strings; Business connection IDs, UUIDs and other opaque IDs remain strings under their field-specific rules. Native numeric allocation must detect exhaustion/precision loss instead of rounding. Both parsers reject a year-zero input even when an offset would normalize it into year one, reject normalization outside their common supported date range, and turn conversion failures into typed contract errors. Apply action-specific limits: a priced action is a supported paid-media action with 1..25000 XTR and at most ten supported photo/video items; text, typing, read acknowledgements and voice must not silently accept money or unrelated assets. Preserve stricter platform formatting/length/file checks at the Node boundary.

Projection publication assigns a monotonic sequence within each recipient stream, separately from the stable source-event identity. The importer consumes that source sequence, never a locally generated row number. An identical event retry returns its existing record; a changed body under the same identity conflicts. Apply projected state and its source cursor in the same destination SQLite transaction. Missing earlier stream positions hold later positions unless an explicit recorded tombstone covers the gap. Publication and claim allocation must be transactional; rolled-back sequence allocation must not create an unexplained permanent gap. If an alternative global outbox cursor is chosen, define filtered-page checkpoint semantics and prove them before replacing this recipient-stream contract.

Production control-store operations are atomic database transactions exposed through scoped Node repository methods/RPCs. A chain of independent PostgREST inserts is not a transaction. Prefer narrow existing-compatible RPCs over a second database client unless a direct connection is justified and tested. Restrict function execution and ownership checks explicitly; RLS alone does not scope a service-role request. Node holds database service credentials; the worker cannot directly mutate canonical ownership or delivery rows. Validate the PostgreSQL implementation on disposable PostgreSQL, including constraints, row locking, two independent clients, crash/rollback and role isolation. SQLite/DDL column-name parity is insufficient.

## 7 Receiving and processing messages

1. The current receiver identifies the trusted bot and creator binding. Financial events are classified before ordinary chat text; they cannot fall through to reply generation.
2. Persist the inbound event and its scheduling/outbox effect atomically. A polling offset advances only after the corresponding updates are durably stored; a webhook acknowledges only after durable admission. Keep the currently deployed receiver method initially.
3. Keep inbound edits, deletes, own-account outbound, blocked/unblocked and Business connection changes as distinct events. Unsupported message types must have explicit handling, never invented text/image interpretation.
4. Admission applies the existing platform/business rules: access, credits/VIP where applicable, age/safety, blocked/paused state and current messaging permissions. Entitlement charging/reservation is idempotent per logical turn and follows the established product policy, not per model attempt or bubble.
5. Freeze bursts using one persisted batching policy. Retain the chosen existing behavior initially and record its configuration; do not stack Node batching plus a second independent Fastt merge delay.
6. Project history, configuration, catalogue and purchases into the creator worker. Commit the data and projection cursor in one SQLite transaction. A turn starts only when all required versions/watermarks are available.
7. Acquire creator worker ownership and conversation processing rights. The worker invokes the real native engine with the mapped account/fan and explicit turn context.
8. New inbound text during generation or pacing increments the input revision. Before sending, recheck whether the frozen answer is stale. Preserve paid fulfillment obligations even when conversational work is cancelled.
9. Native actions pass to the single delivery service. Results update canonical receipts first, then native bookkeeping and dashboard projections with idempotent repair.

The actual receiver and financial paths must continue during a pause of AI generation. Separate effective generation pause from disconnecting the bot entirely.

For Telegram Business, current `can_reply` permission applies to private chats with incoming activity in the preceding 24 hours. Check the current connection rights and recorded last qualifying inbound instant at dispatch, including delayed follow-ups and resumed actions. Expired/unknown eligibility holds the application send with a visible reason; never switch silently to ordinary bot chat. Test before/at/after the expiry boundary, permission revocation and late inbound delivery. Platform rejection remains authoritative. Durable admission must precede grammY polling-offset advancement; test the actual receiver integration, not just a standalone store insert.

Human messages from the official Telegram application or another authenticated session bypass the gateway. On observing attributable external outbound activity, advance the conversation revision, apply the configured human-takeover hold and cancel undispatched conversational actions. Observation cannot atomically prevent that human send racing a bot message already dispatched. Require exclusive operator use of the designated chat during the pilot and display this boundary accurately; the gateway controls application writers, not every Telegram session.

## 8 Fastt platform adaptation

Introduce real dependency injection or a registered platform capability interface into the native engine and shared automation helpers. Do not extend unittest.mock.patch in native_pilot into production.

Required capabilities are: scoped history reads from projection, current account/config snapshot, catalogue/offer access, gateway text/media actions, typing, supported read acknowledgement, job scheduling, exact purchase events, permission/status checks and cancellation/hold reporting. Unknown platform selection must fail; it must not fall through to the OnlyFans client constructor.

The gateway protocol should provide versioned action submission, action-status lookup, engine command/status and projection acknowledgements. Submission is idempotent and may report pending; only a confirmed receipt returns native send success. An RPC timeout means query the existing action, not allocate a new one. Apply request/response bounds, authenticated scope, finite deadlines and redacted logs.

Native ai_chatter sends before recording some attribution and offer state. Implement a durable invocation/action journal and a typed interruption path that survives its broad per-fan exception handlers and the scheduler's retry wrapper. A held or uncertain action must remain held after the outer run returns. It cannot be converted to generic failure and scheduled again.

For a confirmed gateway send, map the raw Telegram message ID to the native ID and supply the exact confirmed content/media to native bookkeeping. Replaying that receipt repairs missing attribution/offer state without sending. A native invocation interrupted before its own internal state is reconciled remains visible as interrupted; receipt availability alone is not proof that every native state mutation is complete.

Sender inventory for both old and new runtimes must include:

| Path | Migration handling |
|---|---|
| Main replies and multiple bubbles | Fastt owns generation; every bubble has a durable action ID |
| Fastt content/teaser, post_buy, aftercare, nudge, discount and delivery jobs | Enable only after each branch reaches the gateway and has recovery tests; inspect payload branches, not only job names |
| Existing Node campaigns, follow-ups and onboarding freebies | Disable legacy generators for migrated conversations; map desired behavior to one Fastt scheduler |
| Existing payment reactions | Keep settlement, replace conversational reaction with one Fastt event/job |
| Manual dashboard text/media/voice | One operator command path through delivery authority; truthful effective takeover status |
| Existing invoice/checkout fulfillment | Preserve obligated fulfillment through settlement; never depend on a sales-model response |
| OF subscriber events, scraping, online presence, feed posts, co-tags and Giphy IDs | Unsupported for Telegram unless a separately verified implementation exists; no fabricated substitutes |

Telegram start/return behavior uses actual Telegram events and saved history. A restart is not a new subscription or a new fan. Voice and incoming-media interpretation are separate capabilities: preserve any deployed entitlement and input path, enable generation only when explicitly mapped, and display unavailable capabilities honestly.

P2 must fence ALL existing application writers for a migrated scope before its text pilot, even if their replacement feature is scheduled for P4: campaign/free-preview/follow-up generation, purchase reactions, manual sends and outstanding fulfillment. Route supported non-AI operations through the same authority; hold an unmapped writer visibly. In compound ticks disable only the competing generation branch, not unrelated subscription expiry/settlement. P4 implements replacement feature behavior and full controls; it does not defer the first sender exclusion. Keep all legacy behavior unchanged outside the selected scope.

### 8.1 P2 composition requirements from the 18 October source review

These specify how the existing P2 requirements compose with current code. They do not introduce a new package or authorize a rewrite of accepted foundations. Implement them in the existing owners; update `SENDER_INVENTORY.md`, `CONFIG_MAPPING.csv` and `CAPABILITIES.csv` with responsible functions and test names rather than creating another competing specification.

**P2-I1 — One effective assignment.** Extend `bot/src/engines/engine-router.ts` into one resolver used by ingress, jobs, senders and controls. Distinguish a positively established legacy/unmigrated scope, a Fastt scope, and a held/unavailable scope. The disabled migration path preserves legacy behavior. Once a scope is Fastt-assigned, pause, missing configuration, projection lag, lookup failure or an unavailable worker must hold it, never fall through to the legacy engine. A missing binding is not proof of legacy when authority lookup failed. Resolve creator defaults and conversation pilot overrides consistently. Test the same assignment change through receiver, background and manual paths.

**P2-I2 — Durable admission before actual acknowledgement.** Route migrated updates before the old detached `batcher.enqueueText` / `runNow` paths. Commit required input and its outbox before allowing the polling acknowledgement to pass it; keep slow generation outside this short boundary. Inspect the installed grammY polling/error/shutdown behavior: it sets `lastTriedUpdateId` before handler completion and uses that value when polling again and stopping. Merely adding `await` or throwing is not acceptance. Exercise the actual configured receiver with fake `getUpdates` responses, including admission failure, the registered error handler, shutdown during admission, mixed batches and restart. Verify no acknowledgement offset passes an uncommitted required update. If persistence remains unavailable, retain/backpressure the input; never acknowledge it as successfully handled. Keep payment-first dispatch and settlement responsive. Support the event types available for the actual Telegram mode; do not fabricate unobservable deletion/activity events.

**P2-I3 — One external send attempt.** The transformer installed in `bot/src/index.ts` retries `retry_after` responses. Wire durable Fastt mutations through a single-attempt API path owned by the existing Node gateway, adapting that transformer/composition seam without introducing another sender or poller. Do not assume `api.raw` bypasses installed transformers. Preserve legacy behavior outside migrated scope. Count actual lowest-level HTTP requests through the configured grammY chain, not calls to a fake `sendMessage` helper. Under the accepted conservative policy, Telegram 408/429 and other ambiguous outcomes remain held; no inner transformer may sleep and resend them. Rate-limit waiting occurs before dispatch and rechecks authority afterward. Keep the accepted neutral transport as the platform-call owner; only make targeted changes if the real integration demonstrates a defect.

**P2-I4 — Compose eligibility and locks, do not duplicate them.** Extend the existing `outbound-gate.ts` owner for trusted bot/creator/connection/channel scope and fresh eligibility. Its current unreachable cache is keyed only by chat id, and its Business window is unconditional: neither may leak between bots or be applied to a different mode. The live-reply exemption cannot authorize a delayed or resumed Fastt action. Reuse `send-lock.ts` once at the outer dispatch boundary; a busy check is not acquisition, and nested acquisition or its degraded run-anyway mode cannot authorize a migrated send. Local TTL expiry never clears a canonical dispatching/unknown attempt. Document one acquisition order across local locks, native fan leases and short PG transactions; do not hold DB transactions across external calls. Preserve section 12's action-class distinctions: AI input/config/pause gates must not become new cancellation rules for manual or paid obligations. Fence/drain pre-existing legacy work on assignment change and test an old task resuming after cutover.

**P2-I5 — Different stores have different jobs.** Adapt the existing Node authority and identity facades to the asynchronous PG repository. PG source mutations and publication use the accepted transaction facade; a confirmed receipt is published only if evidence acceptance succeeds, in the same transaction. Do not revive the retired PG destination importer. `projection-cursor.ts` is a synchronous reference consumer, not a production PG importer to convert mechanically. On Python, reuse the accepted synchronous applier to mutate actual native target tables and the consumed cursor through the same supplied SQLite connection/transaction. A fresh `get_session()` or deferred async callback is a different transaction and is prohibited inside that applier. SQLite action/ownership reference tables cannot authorize production dispatch. Native post-send attribution and receipt repair use one canonical-to-native message mapping and idempotent bookkeeping owner; they must not append duplicate history rows. Prove rollback against the real target rows, not envelope counts alone.

**P2-I6 — Bound the native invocation and capabilities.** `ai_chatter.run` is an account sweep: empty `only_fan_ids` means all candidates. Each Telegram turn must supply a nonempty trusted singleton fan/conversation scope plus the frozen turn identity; refuse missing, mismatched or expanded scope before native work. Do not use `force_ids`, invented purchases or a success stub to make tests pass. Map native `payers_only` and other selection gates deliberately to the retained Telegram entitlement policy; test an eligible ordinary nonpayer and an ineligible recipient. Enable only the mapped P2 text/control capabilities. Explicitly disable native pack/teaser/sticker/sales/follow-up branches whose mapping belongs to later packages; an empty catalogue alone is insufficient. Unsupported branches must not enqueue jobs, call a model for that disabled capability or manufacture successful sends. Node's pre-existing paid obligations remain preserved under section 12. Do not reacquire the same fan lease that native `ai_chatter` already acquires; the native lease is scheduling protection, not a second external delivery authority.

**P2-I7 — Strict configuration in the existing owners.** Add injected Telegram policy to the existing native provider/model/credential resolvers. `_common.resolve_model` currently skips invalid configuration and falls back to house defaults; `llm_providers` and `llm_client` can read local secret sources and choose house credentials. An OpenRouter registry entry alone does not close those paths. Missing or malformed Telegram purpose/configuration/billing identity must stop before model HTTP. Preserve an explicitly approved provider-routing/fallback policy with bounded recorded behavior; never invent a fallback or change another tenant's payer. Preserve existing OnlyFans defaults outside the injected Telegram context. Isolate startup and later credential resolution, including dotenv, secrets-store and database defaults, in both test processes. Tests use synthetic config/credentials and deny access to real secret files; they must not succeed by reading the host environment. Do not globally disable legacy configuration loading as a shortcut.

**P2-I8 — One model retry owner and honest usage.** The native `llm_client` already retries, and currently reserves/audits around the loop. Keep the bounded transport retry policy in that owner. Do not wrap it in worker/gateway retries or rerun an interrupted native invocation. Record each attempted request and its confirmed or unknown cost exposure; a lost response is not proof of zero spend. Preserve bounded legitimate native purpose calls, including explicitly enabled verification/repair, within one invocation budget; no extra wrapper-generated answer. Model retries and Telegram delivery retries are different policies. Prove typed held/interrupted outcomes survive `ai_chatter`'s per-fan catch and the executor retry wrapper without generic rescheduling. A diagnostic/error projection must not expose raw provider bodies, secret-bearing URLs or credentials.

**P2-I9 — One timing, entitlement and prompt policy.** Map each retained behavior to its existing responsible owner before wiring it: burst collection, eligibility/cooldown, fan lease, pacing, credit reservation, safety validation and prompt assembly. Durable burst timing must not be followed by another independent native merge delay; persisted native pacing must not be followed by another Node conversational delay. Inherited technical rate limiting remains separately identified. One logical turn has one idempotent entitlement reservation and the established commit/release policy across crash, refusal and partial delivery. Keep independent deterministic safety/fact/permission validation while removing old conversation rewriting from the migrated path. Rejection is a recorded outcome, not an unbounded regeneration loop. Document what replaces every legacy prompt/control setting; effective configuration and displayed snapshots must agree, and development rules never enter the fan prompt.

**P2-I10 — Prove the composed runtime.** Factor current registration/bootstrap functions only as needed for import-safe tests and dependency injection; do not create a second test-only copy of the receiver or engine. The round trip exercises real PG operations, the real native SQLite schema/applier, `ai_chatter`, model request handling and configured grammY transport. Fake only external services/source data. Include a second projected fan to prove singleton scope, mixed legacy/Fastt routing, configuration/permission/ownership change during waits, uncertain receipts and all P2-I1–I9 conflict cases. Synthetic loopback servers and temporary child processes are permitted; real Telegram polling, production workers and external model/platform calls are not. Preserve the local Node 24/Python 3.13 test evidence and record the deployment Node 22 compatibility check or explicit remaining runtime limitation; do not silently change the production runtime. Extend existing accepted suites for affected behavior and demonstrate new regressions fail on the conflicting path without overwriting another chat's work. Inventory claimed-but-unwired controls as inactive.

## 9 Model and creator configuration

Add OpenRouter to Fastt's provider registry and native model resolution. Retain native request accounting and limits, while publishing usage into the current dashboard cost views idempotently. Do not bill one call in both systems or let a Node wrapper generate a second answer.

Create a per-purpose mapping: conversation, intent/request reading, catalogue matching, verification, fan-profile extraction, creator/config assistance and any enabled summary work. Native per-purpose pins can override an account default, so validate all enabled purposes at startup. A missing purpose/provider mapping disables that feature with a clear error; it does not silently switch to a different provider or bill another tenant.

For the comparison baseline, record the actual selected model, upstream provider routing, fallback policy, temperature, output limits, reasoning settings and prompt/config hashes. V2's current source uses DeepSeek V4.1 Flash via OpenRouter; this is a reference, not proof that every production clone has the same configuration. Resolve the selected clone's actual model settings before activation.

Keep API keys in the existing authorized server-side secret mechanism. Dashboard app_settings and environment-based vision credentials are currently different sources; inventory and define precedence explicitly. Never copy a privileged key into a browser, plan file, model prompt or per-fan data. Secret rotation updates a reference/version without rewriting conversations.

Import only the chosen creator's approved facts, language, timezone, tone and boundaries. Do not bind another creator to Riley's persona as a default. Keep factual profile data separate from the old compiled system prompt. Maintain a mapping table for every existing setting: retained platform policy, mapped Fastt setting, replaced legacy dialogue setting, or unsupported feature. The dashboard must not present an old knob as effective when Fastt ignores it.

Disable deliberate typo, nonnative misspelling and word-distortion injections. Preserve intended casual style and multi-bubble behavior independently. Hard limits on content, facts, price and permissions remain enforceable validation; legacy text rewriting is removed from the migrated path. Validation rejection produces a recorded reason and bounded handling, not an endless regenerate loop or silent personality change.

Preserve the existing catalogue, Storage objects, human-approved descriptions and marketing text. P3A replaces the automatic Twin upload-time analysis path for newly analysed assets with one Fastt-style media enrichment pipeline: structured factual extraction first, structural/cross-field validation second, then a fact-grounded stored-copy pass. Do not run both generators for the same asset revision. Do not mass re-caption historical assets. Existing explicit human overrides retain precedence. Legacy usable metadata without approval provenance remains available under its existing publication policy, marked as legacy; do not manufacture approvals or require bulk re-analysis to keep the catalogue working.

P2 adds disabled-by-default `media_vision` and `media_copy` purpose configuration through the native OpenRouter provider, but it does not analyse media. The initial tested model roles are `qwen/qwen3-vl-30b-a3b-instruct` for factual vision and `deepseek/deepseek-v4-flash` for copy. Any provider/model fallback must be explicit, bounded, recorded and visible; do not inherit an automatic larger-model fallback silently.

The current CONFIG_MAPPING.csv is an inventory, not yet an executable transformation. Before enabling a setting in P2/P3/P4, add its exact source field, native key, type, default, precedence, unit/range transform, effective runtime consumer and test. Produce effective-config/prompt snapshots using neutral fixtures and the actual Fastt loader. A retained legacy limit must map into one policy; do not preserve both an old Node sales decision and an independent Fastt decision. Unmapped controls are visibly inactive, never silently stacked onto the old compiled prompt. Dashboard preview must use the same effective configuration/compiler, with secrets removed.

## 10 Catalogue and media mapping

The Supabase catalogue remains editable in the existing UI. Synchronization is one-way into the Fastt search projection; Fastt does not overwrite owner descriptions or prices.

| Existing source | Preserve | Fastt adaptation |
|---|---|---|
| photos | UUID, clone, storage object, revision, caption, teaser, visual_description, tags, free/price/classification flags | Account-scoped native asset mapping and factual search fields |
| videos | Same plus duration/dimensions/file metadata where present | Supported video asset reference; verify delivery suitability before offering |
| photo_bundles and photo_bundle_items | Bundle price, ordered independent item IDs and file paths | Immutable ordered offer manifest; do not assume all members are photos table rows |
| catalogue_bundles | Existing photo-ID composition and separate catalogue price | Distinct product source type; preserve Mini App identifiers |
| catalogue checkout orders | Buyer, frozen product/price/composition, old payload, charge and access state | Exact compatibility path and event projection |
| Existing Telegram file cache | Proven bot identity, asset and revision | Reuse only when scope and content match |

Paginate the entire inventory. Use updated revisions plus deletion tombstones or a bounded reconciliation scan; an updated_at cursor alone misses deletes and equal-timestamp ties. A full source outage must not appear as an empty catalogue that deletes every projected asset. Update the projection and its cursor atomically.

Preserve factual descriptions, marketing captions and human overrides separately. Missing descriptions remain missing and are flagged for review; no fabricated descriptions. Fastt's resolver reads metadata, not every file on each request. Changes in source descriptions invalidate search entries; removed/disabled assets invalidate unsent selections.

For one asset revision, one durable analysis job owns automatic enrichment. A photo supplies one image. Video sampling is duration-based and ordered: six frames below 30 seconds, nine frames from 30 seconds to below three minutes, and twelve frames at three minutes or longer. Use the native sampling implementation or a parity-tested extracted helper, with explicit limits for bytes, duration, frame count, resolution and decoding resources. Record actual frame timestamps and coverage; sparse frames do not establish everything that happens between them. The factual pass returns Fastt's versioned structured schema. Deterministic checks reject malformed structure, impossible field combinations, stale revisions and claims unsupported by the declared evidence fields. They CANNOT prove arbitrary natural-language claims match pixels or detect every omitted act. Contradictory, insufficient or uncertain results require review; no extra universal AI-review pass is implied.

Use creator ID, asset type/ID, immutable object revision, pipeline and model/config version for analysis identity; separately fence publication against metadata edits. A price-only edit must not trigger paid vision again; a factual edit invalidates copy derived from superseded facts. Route every existing enrichment caller through the same ownership/enqueue decision, including dashboard uploads and `backfill-visual-description.ts`, `import-media.ts`, `import-video-media.ts` and `import-videos.ts`. Extract/reuse pure Fastt prompt/schema/sampling helpers behind injected file access and persistence; do not import `vault_frames.collect` or the OF server/vault writer into the Telegram worker.

Only accepted factual fields may reach the upload-time copy pass. That model receives no pixels or fan history and must not invent relationship history, prior requests, familiarity, scarcity, recording time, prices, payment, unlocks or unseen details. Keep one accepted factual result and one accepted stored-copy result per asset/pipeline revision. Transport retries/fallbacks can cause additional billable attempts: journal each attempt and bound count/time/spend, rather than promising exactly one provider call. A delivery retry reuses persisted output instead of generating copy again.

Distinguish stored catalogue copy from a contextual offer caption. Preserve the selected creator's explicit contextual-caption capability; absent/unmapped configuration does not enable it. When enabled and the native flow requires it, Fastt's existing `_ppv_caption` owner may produce the final caption using accepted asset facts and separately authorized conversation facts. Reuse a valid final caption already supplied by that invocation. Disable legacy Node `generateLiveCaption` and any competing wrapper/send-time hook for that action. Persist the final caption with the action before dispatch; the gateway never calls another caption model. Stored copy is the default/fallback only where the native configured policy permits it. Map `live_captions_enabled`, `requestSpecificCaption`, native caption enablement and `media_caption_mode` explicitly. Count conditional contextual generation in purpose/attempt budgets; do not add an unconditional third analysis call. A claim such as prior fan preference is unsupported at upload time and requires actual authorized evidence in contextual copy, not a blanket phrase ban.

Supabase remains the media source of truth. Store the stable analysis identity defined above; attempt/error status; factual and copy model/config/provider metadata; usage/cost; candidate output; and acceptance/reject/supersede provenance. Preserve the existing publication policy for clean new results; require human review for flagged contradictions/uncertainty and explicit approval before overwriting human-owned fields. Do not introduce mandatory review of every existing asset. Fastt receives current accepted source metadata, including preserved legacy rows, never pending/failed candidates. A relevant source/metadata edit fences an older result. A failed job never overwrites accepted metadata with blanks.

The existing upload actions derive default prices from generated tags synchronously. When analysis becomes asynchronous, a new asset with no valid explicit price/publication state remains not-for-sale; missing tags or failed analysis must not default it to free or publish it at a guessed price. Preserve explicit manual prices and frozen offer prices. Record whether any classification-based price is provisional and validate it through the existing deterministic pricing policy only after metadata is accepted. Re-analysis cannot silently change a published price. File upload success, analysis success and sale readiness are separate states.

Evidence limit: the 17 October four-file comparison reused Fastt prompts/formatting and similar frame sampling over a separate OpenRouter harness. It bypassed native collection, transport retries, budgets and persistence, and both videos were in the same duration band. It supports improved temporal coverage on those clips; it does not establish exact native pipeline parity, universal factual accuracy, conversion superiority or production cost. Interrupted/failed calls may be billable even when no usage result was returned.

Missing frame tooling, corrupt or unsupported media, timeout, HTTP 429, malformed output, provider failure, restart and duplicate delivery must produce visible bounded states and reasons. Retry only failures classified as retryable, reuse the same job identity and record every attempt. Provider failover is configured policy, not an accidental switch. Preserve the last approved metadata on every failure.

At offer creation freeze the asset list, order, buyer, price and catalogue revision. At dispatch verify permission, availability and the offer policy. A source edit must not silently change an already accepted order's contents or amount. If an asset is removed after a paid order, keep the obligation visible and route to fulfillment support/refund policy.

Node obtains the allowed file from existing private Storage access, streams within bounded size/time limits, and uses bot-scoped Telegram cache where valid. Do not expose service credentials or long-lived paid-media URLs. Signed URLs are generated for an authorized operation, not stored as permanent source identifiers.

Do not silently split a large bundle into several separately charged messages. Freeze one supported package or explicitly offer a supported alternative. Validate dimensions, encoding, thumbnail/preview behavior, paid/free status and file size before the model can promise delivery. A failed paid upload must never fall back to sending the asset free.

## 11 Stars sales and existing payments

Fastt's dollar pricing code needs a deliberate currency adaptation. Its price_cents fields, dollar ladders, spending thresholds and amount/time purchase inference are not interchangeable with Stars.

Implement a PricePolicy returning an explicit currency and integer amount with a pricing revision. The first sales release uses existing approved Stars prices and supported bundle definitions. Fastt selects relevant products and manages offers; Node validates the final amount and executes the platform operation. For dynamic pricing, implement and test an XTR ladder, permitted discounts, floors/caps, bundle composition and spending tiers as explicit creator policy. Until that policy is configured, dollar-specific native heuristics stay disabled for Telegram. Do not silently convert USD figures or let the model invent a price.

There are two distinct receipt paths:

1. Paid media: a purchase notification can identify the buyer and immutable offer payload; reconcile monetary details against the actual transaction ledger. The notification is not a fabricated charge record.
2. Existing invoice products: retain confirmed successful-payment handling, idempotent entitlement/fulfillment and charge references, but strengthen pre-checkout validation. The current `handlePreCheckout` only receives id/currency/amount and approves any positive XTR. Pass trusted bot/buyer and invoice payload into a bounded validator; validate immutable order/product, amount, currency, intended buyer, expiry and permitted availability, including explicit legacy decoders. Answer within Telegram's ten-second limit; unsupported, mismatched or timed-out validation refuses with a neutral reason. Do not call a model. Pre-checkout approval alone is not payment. Business invoice settlement must retain the paginated reconciler because a successful-payment update is not guaranteed on that route.

Preserve the current paginated Stars reconciler after testing its deployed version. Add exact mapping for new offer payloads while retaining old photo/video/bundle/credit/VIP/tip/catalogue payload decoders until their obligations are resolved. Unknown payloads and amount/currency/buyer mismatches go to a visible reconciliation queue, not a guessed purchase.

Use stable transaction direction/type plus charge identity so a refund sharing the original payment ID cannot be suppressed as a duplicate purchase. Keep confirmed receipt, entitlement grant, fulfillment outbox and engine purchase event in one transaction where possible; otherwise use a durable idempotent repair step with a provable unique key. Repeated update plus reconciliation must yield one grant and one reaction.

Existing credits, VIP access, recurring subscriptions, tips and outstanding invoices remain enforceable even if Fastt has no identical native concept. Keep their business policy in the gateway/settlement layer and project exact events to Fastt. A tip is not automatically a content unlock. A purchase at zero chat credits must still settle. Usage charging must not multiply because Fastt makes multiple model calls or sends multiple bubbles.

Preserve Mini App catalogue ownership and access for old purchases, including frozen bundle contents. Catalogue-generated payments must inform the same ownership projection as chat-generated payments. Inventory deployed TON/external checkout code and retain historical records/access; this migration does not enable or expand those paths. Telegram chat digital purchases use the documented Stars path. Any incompatible deployed feature is a named migration blocker, not silently removed functionality.

A refund updates financial records and future entitlement/access policy. Do not claim it can erase a file already downloaded or reverse every platform-visible unlock. Handle provider refunds/chargebacks according to actual evidence; display unreconciled cases rather than making up transaction status.

## 12 Durable delivery and recovery

Delivery state progression is prepared -> dispatching -> confirmed, known_failed or unknown. Cancelled/refused actions never cross the send boundary. The final check and transition to dispatching must conditionally claim the action's applicable authority and revisions under the class-specific rules below. A worker lease expiry alone cannot authorize a second send while an older attempt may still be in flight.

The transaction must validate trusted binding/clone/conversation scope, action-class authority, applicable not-before/expiry, and absence of any conflicting dispatching/unknown action in that conversation. AI conversation actions additionally require effective Fastt assignment, current input/config revision and AI-unpaused state. An authenticated manual action requires effective human takeover. An obligated fulfillment action requires a valid canonical paid obligation, exact recipient/assets and current platform eligibility; new chat input, AI pause or engine switch cannot cancel the obligation or make its delivery depend on another sales-model response. Paid fulfillment may still be held by an unknown send, blocked recipient or unavailable asset, with visible repair/refund handling. Node derives and persists the authority class from trusted turn, operator-command or obligation context. A worker-supplied class never grants manual/financial privileges.

Enforce arbitration across different action IDs and independent clients, not just two claims on one row. Bind completion to the immutable dispatch attempt and expected prior state. Legitimate late Telegram evidence may settle its ORIGINAL attempt after ownership changes, but cannot authorize a new dispatch or overwrite conflicting terminal evidence. An old owner without that attempt identity cannot manufacture a result. Unknown resolution is a separate audited evidence/decision path; epoch bumps never erase it.

| Interruption | Required recovery |
|---|---|
| Before durable admission | Re-delivered inbound event admits once |
| After admission before engine projection | Replay the projection event and cursor transaction |
| During model generation before any action | Mark invocation interrupted; reprocess only after proving no pending action and reconciling native state |
| After action persisted before Telegram dispatch | Resume the same action if authority, relevance and expiry still permit |
| Telegram accepted but response lost | Mark unknown, hold conflicting sends; no new action or blind retry |
| Receipt stored but Python crashed before bookkeeping | Replay receipt to reconstruct native message/attribution/offer state without sending |
| Two bubbles confirmed, third unresolved | Preserve confirmed prefix and hold unresolved suffix; never rerun the whole answer |
| Pause or human takeover during pacing | Conditional final gate blocks undispatched AI actions; acknowledge effective takeover only after in-flight state is safe |
| Stale worker returns after lease loss | Reject stale epoch and show its late result diagnostically; it cannot regain authority |
| Gateway or Supabase unavailable | Stop new dispatch; keep durable work pending/held with bounded deadlines |

Do not assume the Bot API provides universal outbound idempotency or arbitrary chat-history recovery. Resolve an unknown send only from supported independent evidence or an explicit operator decision with an audit entry. Default is to hold the affected conversation, not the entire fleet. Manual sends must respect that unresolved state too.

Pacing delays use durable due times and the same input/owner revision. A process restart does not sleep and then fire a stale message. Technical rate limiting applies per bot and per chat; use Telegram error retry information and bounded retry policy only for outcomes proven unsent. No paid broadcast feature is enabled by this migration.

## 13 Dashboard and control compatibility

Retain the selected dashboard's creator/agency authorization and clone scoping. Server-side service clients do not remove the requirement to validate clone ownership on every request. New tables remain private or have explicit row-level access policy; no browser service-role credentials. Follow the existing migration ownership and Supabase CLI process after checking current help/version, rather than applying the old schema snapshot wholesale.

Required UI behavior:

- Show engine name, effective version, channel mode, requested/effective activation, projection freshness and worker health.
- Keep existing creator edits, assets, prices, bundles, purchases, fan list and history working.
- Display paused requested versus paused effective, with a reason if an unresolved send prevents safe handoff.
- Preserve per-fan block, pause, safety state and manual commands. Manual commands claim the same delivery authority and append only confirmed output to history.
- Continue payment processing while AI is paused; show pending fulfillment separately from paused conversation.
- Mark old-engine-only prompt knobs as inactive for Fastt; show mapped Fastt settings and validation errors.
- Record model usage, costs and provider purpose without raw secrets or duplicate spend rows.
- Project engine origin, action ID and delivered timestamps into existing history/analytics contracts. Do not count generated drafts as sent messages or purchases as multiple sales because two projectors observed them.
- Preserve Mini App login validation, catalogue order IDs and purchased-media access.

Separate deterministic technical validation from legacy stylistic rewrites. The extracted Telegram transport should not insert artificial typos, change the creator's words, collapse intentional bubbles or claim missing media was sent. Preserve independent content/age/price/permission enforcement as explicit gates whose outcomes are visible to the engine and operator.

## 14 Build packages and review boundaries

The main sequence is P0 inventory, P1 foundations, P2 text, P3A metadata, P3B sales, P4 full controls, P5 operations and P6 rollout. P1-R and P1-PG are independently accepted within their documented local scopes; P2 is in progress with its neutral transport increment accepted. Live target attestation remains a deployment prerequisite. The sequence produces two usable pilot milestones. Finish the stated acceptance evidence within each package before review; optional improvements stay separate from demonstrated defects.

### P0 Establish the exact target

Deliver RUNTIME_MANIFEST.md, SOURCE_MAP.md, CONFIG_MAPPING.csv, CAPABILITIES.csv and a sender/job inventory. Resolve source roots, baseline SHAs, dirty dependencies, deployed schema and channel mode. Record live-only facts still pending without inventing them. Preserve the Fastt license notice in reused source.

Acceptance: every enabled product, writer, model purpose and state store has a named owner; every first-pilot prerequisite is either verified or explicitly blocked. No application behavior changes.

### P1 Add contracts and durable control records

Deliver shared JSON fixtures/schema, Node/Python validators, additive transaction/mapping/outbox migrations, engine assignment and action-state interfaces. Engine remains legacy/off by default. Implement event and action idempotency, scoped mappings, ownership epochs, command status and projection cursors against synthetic local databases.

Current review disposition: P1-R and P1-PG are accepted within their documented local scopes; see `P1R_ACCEPTANCE.md` and `P1PG_ACCEPTANCE.md`. The production Node PostgreSQL adapter, atomic operations, disposable migration and independent-client tests are delivered. Preserve those owners and regressions in P2; do not make the worker's SQLite reference control tables a production authority. No live migration or receiver activation was performed. Target schema attestation remains required before application to Supabase.

Acceptance: cross-language malformed/large-ID cases and typed overflow failure; redelivery with new receiver metadata; two creators/same fan; two chats/same message ID; binding forgery; recoverable full bodies after reopen; idempotent projection across commit/restart; rollback atomicity; two different actions competing in one conversation; attempt-bound late receipts and unresolved holds; stale input/config/ownership; tested PostgreSQL transactions and permissions. Named required suites must fail rather than report green when their runtime/database dependency is missing. New application imports must not start services. No live secrets or model calls required.

### P2 Connect the real engine and OpenRouter

After P1-R and P1-PG acceptance, deliver the dedicated creator worker, durable native journal, platform capability injection, real OpenRouter provider, exact effective-config mapping, history/config projection and a neutral Telegram transport using the accepted PostgreSQL control store. Wire the attested receiver and production router only now, still legacy/off by default. Preserve old behavior for legacy-assigned bots. Implement text/multi-bubble/pacing and recovery, basic operator pause/takeover and ALL legacy sender exclusion before any live text test. Missing live attestation blocks activation, not independent offline implementation.

The current continuation finishes this entire offline package, including section 8.1's integration requirements. Acceptance of the neutral transport is not acceptance of its eventual configured API chain, receiver integration or native engine composition. These require the stated P2 evidence.

Acceptance: deterministic full flow through the actual Fastt engine using stubbed model and lowest transport; model route/usage limits; all text send paths use gateway; no OF client/pumps; duplicate/restart/unknown/partial-send tests; actual supported Python runtime. An opt-in bounded real-model comparison may follow with recorded usage.

Before the first live text pilot, complete the pilot subset of P5: attested supported runtime, pinned code/dependencies, durable storage, exclusive receiver/worker ownership, verified backup restore, effective pause/stop, preservation of unknown actions and rehearsed return to the legacy engine. Only then activate the authorized test identities and limits. P5 expands operational verification to the fleet; it does not defer basic pilot recovery.

First usable milestone: Fastt autonomously converses through the chosen Telegram route, with correct creator facts, memory and single-writer delivery. No sales capability is claimed yet.

### P3A Add media enrichment and the accepted catalogue projection

Deliver complete paginated/tombstoned catalogue projection plus one versioned media-analysis path. Keep Twin's dashboard, Supabase catalogue, Storage, prices, bundles, legacy usable metadata and human-approved edits. For new or explicitly re-analysed assets, run Fastt-style duration-based factual extraction, structural/cross-field validation, a fact-grounded stored-copy stage and revision-fenced publication under the policy in section 10. Flagged results require review; clean results follow the established publication policy. Retire Twin's automatic `captionPhoto`/`captionVideo` generation for an asset only when the new path owns that asset revision; upload/import/backfill paths must never run both.

Acceptance: one photo and videos across all three duration bands, including exact duration boundaries; production-style OpenRouter routing through the real provider integration; at most one accepted fact/copy result per revision with every attempted call accounted; no pixels in the upload-time copy pass; missing frame tooling, corrupt media, timeout, 429, malformed output, explicit provider fallback, restart and redelivery; structural/cross-field contradiction fixtures plus a separately labelled human accuracy review; accepted metadata and manual prices survive failure; new unready assets cannot be sold/free-sent; stale candidates cannot overwrite edited assets; flagged review and clean acceptance reach the projection; legacy rows remain available without fabricated approval; removed media cannot be matched; no historical bulk re-captioning.

### P3B Connect approved catalogue results and Stars sales

Deliver asset and bundle mappings, request matching against accepted current source metadata (including preserved legacy descriptions), delivery preflight, frozen offers and captions, currency-aware approved pricing, validated pre-checkout, new/legacy receipt compatibility, fulfillment/ownership/refund projection and exact purchase events to Fastt. Keep existing credits, VIP and Mini App obligations correct. Implement supported Stars dynamic policies only behind explicit validated configuration; incomplete policies remain visibly disabled. Do not require re-analysis of the existing catalogue to use its valid assets.

Acceptance: precise request matching using neutral described fixtures, no-match behavior, removed asset, stale price, wrong owner, three bundle source formats, duplicate receipt, old invoice paid after migration, partial failure, refund, purchase while paused, reconciliation beyond one page, Mini App-to-chat ownership and no paid-to-free fallback. Extend the pilot recovery drill to prove settlement and outstanding-order compatibility during rollback before any real purchase. Use Telegram's test environment where applicable before an authorized small real purchase.

Second usable milestone: a real supported content purchase reaches the fan, updates ownership once, appears correctly in the dashboard and influences the next Fastt turn.

### P4 Complete operator and automation compatibility

Deliver full dashboard engine controls, effective acknowledgements, manual takeover, mapped welcome/return/follow-up/post-purchase scheduling, operational usage/cost projections and every enabled product capability from P0. A product absent from the first canary cannot be silently dropped during expansion.

Acceptance: creator/agency isolation, unauthorized clone changes, pause during generation and dispatch, manual send competition, revoked Business permissions, old scheduled job after switch, returning fan after restart, voice/input capability behavior and no second legacy generator. Financial obligations remain independent of chat availability.

### P5 Verify deployment and recovery

Deliver pinned Node/Python images and lockfiles, durable worker volume/backup configuration, migration scripts with dry-run/count/checkpoints, redacted health checks, deployment and rollback runbooks and baseline performance/cost report. The supervisor starts only the dedicated Telegram worker and owns one writer lease per native database.

Acceptance: restore on a separate environment, replay events after snapshot, retain native state and unknown actions, kill at every delivery boundary, database outage, model outage, worker restart, full disk/backpressure, repeated deployment and rollback rehearsal. Deliberately restore an older native snapshot while newer confirmed and unknown canonical actions exist: prove no duplicate sends or reused internal IDs, and hold any native state that cannot be recovered. Verify actual receiver offset handling and correct supported runtime; do not rely on the old 3.11 harness for production imports.

### P6 Migrate selected bots and evaluate

Deploy disabled code, use a named canary creator/chat and explicit limits, then expand by creator only after compatibility and recovery evidence passes. Capture engine version, provider settings, catalogue revision, delivery outcomes and actual settled sales. Compare conversion with matched cohorts and an agreed observation window; conversation style alone is not measured revenue lift.

Acceptance: no wrong-recipient delivery, duplicate charge/entitlement, competing sender, incorrect paid media or lost obligations in the acceptance runs. Report observed rates and sample sizes, including held/unknown actions and operator interventions. Define the next supported cohort from measured host/model/Telegram capacity, not an arbitrary creator count.

## 15 Proposed module map

Names are implementation targets, not claims that files already exist. Resolve BOT_ROOT and DASHBOARD_ROOT in P0.

| Location | Responsibility |
|---|---|
| BOT_ROOT/src/engines/engine-router.ts | Legacy versus Fastt assignment; inbound and job routing |
| BOT_ROOT/src/engines/fastt-contract.ts and fastt-client.ts | Versioned validation, scoped private calls, timeouts/status recovery |
| BOT_ROOT/src/services/telegram-control-store.ts and production PostgreSQL adapter/RPCs | Reference-store conformance plus canonical transactional admission, scoped identities, projections, claims and receipts; SQLite reference is never production control authority |
| BOT_ROOT/src/services/delivery-authority.ts | Conditional ownership, durable action admission/dispatch/attempt-bound result |
| BOT_ROOT/src/services/fastt-telegram-transport.ts | Extracted Telegram calls, technical validation, no legacy style rewriting |
| BOT_ROOT/src/services/fastt-projection.ts | Canonical event publication, catalogue/config/history snapshots and repair |
| BOT_ROOT/src/star-reconcile.ts and existing payment handlers | Keep settlement; add exact Fastt offer compatibility/events |
| BOT_ROOT/src/index.ts, manual-send.ts and scheduler seams | One receiver, preserved handler order, no bypass senders |
| FASTT_ROOT/service/telegram_runtime/ | Dedicated bootstrap, capabilities, identity map, projector, runner, journal and receipt repair |
| FASTT_ROOT/service/llm_providers.py, llm_models.py and llm_client.py | Native OpenRouter integration and tenant/purpose accounting |
| FASTT_ROOT/service/automations/ai_chatter.py, _common.py and automation_executor.py | Minimal explicit platform/context seams and persistent interruption propagation |
| FASTT_ROOT/service/automations/content_resolver.py and pack_sender.py | Catalogue access and currency/delivery capabilities without copying conversation logic |
| FASTT_ROOT/service/telegram_runtime/media_analysis.py | Duration-based factual vision, deterministic result handoff and bounded job recovery |
| FASTT_ROOT/service/telegram_runtime/price_policy.py | Approved XTR prices and optional configured Stars policies |
| DASHBOARD_ROOT existing clone/user/media/config/catalogue actions | Preserve authorization and controls; add engine status/mapping plus candidate media-analysis review and approval |
| Selected migration owner and twin-ops | Additive records, backup, pinned deployment and recovery |

Use repository-local contract fixtures with a content hash shared by both language suites. If duplicating fixture files is necessary, CI verifies equality. Do not create competing hand-maintained wire definitions without conformance checks.

## 16 Acceptance matrix

Each test uses real orchestration/DB boundaries with fake external services where appropriate. Passing helper-only tests is insufficient. Stub model outputs for deterministic failure tests; use a small opt-in real-model set for behavior and cost. Never import production startup or use live tokens in ordinary tests.

| Area | Minimum evidence |
|---|---|
| Identity | Cross-creator same fan, cross-chat same message ID, edited event, large ID, raw ID/internal ID round trip |
| Authorization | Agency and creator scope, forged binding/offer, revoked assignment, changed Business connection |
| Ingress | Duplicate update, out-of-order update, batch crash, payment-first routing, no offset acknowledgement before commit |
| Projection | Full pagination, same timestamp, deletion, failed source read, interrupted import, config change during generation |
| Native execution | Real ai_chatter invoked, all enabled model purposes routed, deliberate typos off, correct creator persona |
| Dispatch | Queue is not delivery, duplicate same action, conflicting action digest, stale epoch, stop during pacing, uncertain network outcome |
| Recovery | Crash before send, after send, after receipt, before native bookkeeping; no duplicate confirmed prefix; older native snapshot plus newer canonical actions and monotonic epoch |
| Scheduling | Old job after engine switch, expiry, delayed reply after new inbound, paused fan, restart not new welcome |
| Media | Existing storage paths, wrong clone, expired signed URL, duration-based ordered frames, missing frame tool, malformed/contradictory model output, stale candidate, approval/rejection, cache from wrong bot, removed asset and no-match |
| Offers | Frozen composition, catalogue edits, unsupported large bundle, invalid XTR price, no invented dollar conversion |
| Settlement | Duplicate callback/poller, refunded ID collision, legacy payload, unknown payload, wrong buyer/amount, more than 100 transactions |
| Entitlements | Credits/VIP preserved, purchase with zero credits, ownership across catalogue/chat, refund and outstanding obligation |
| Dashboard | Existing thread/revenue views, confirmed-only history, usage once, pause acknowledgement, manual command result, external Business outbound takeover observation |
| Operations | Two workers compete, receiver exclusivity, bounded queues, dependency outages, backup restore and rollback |
| Isolation | No OF connection, no unconfigured provider call, no secret in logs/browser/model payload, no real network in default tests |

Use positive expected-outcome regressions. Defect demonstrations that fail their original bad-outcome assertion are supporting evidence, not the acceptance suite. Record process exit status as well as any printed success marker. Run existing affected tests and required repository checks; avoid broad unsafe unrelated test runners already known to signal/kill their console. A skipped relevant check remains a limitation.

Proposed commands must be added by the implementing package before they are advertised as runnable. Existing commands to verify first are BOT_ROOT npm run typecheck / npm test, the selected dashboard package's relevant tests, and Fastt's explicit named suites. Do not run live-data tests just because their name contains test.

## 17 Cutover and rollback procedure

1. Verify P0 manifest, source revisions, enabled capability coverage, backup/restore evidence and approved canary identities/limits.
2. Deploy additive schemas and code with engine routing still legacy. Keep financial readers and existing service healthy.
3. Snapshot selected creator configuration/catalogue/history/entitlements and native worker state using a consistent checkpoint. Import with notifications and generation disabled; compare counts and references.
4. Project concurrent changes until the worker reaches the cutover cursor. Freeze new generation for the selected conversation/creator, drain or hold existing generated work, and inventory every old scheduled/manual obligation.
5. Resolve or hold outstanding sends. An unknown old send blocks competing dispatch; it does not disappear when the engine name changes.
6. Atomically change engine assignment and ownership epoch. The current Node receiver remains the sole receiver; routing changes inside it. If replacing a receiver process is necessary, stop/drain the old owner before transferring offsets/webhook ownership without dropping pending updates.
7. Enable only the approved canary scope, with visible counter, deadline and pause control. Verify dashboard, native projection, model usage, actual delivery and payment facts together.
8. Run text acceptance before new selling, then the approved content purchase/refund scenarios. Record each limitation before expanding.
9. Expand per creator after operational review. Remove old dialogue jobs for migrated scopes; retain settlement compatibility and historical data.

Rollback is a forward data operation: stop Fastt generation, reconcile/hold its in-flight actions, drain required settlement, project confirmed transcript/purchases into the legacy-compatible source, then change the engine epoch back. Never restore an old whole-database snapshot over new purchases or messages. If the old engine cannot read the new history/entitlements accurately, keep the conversation paused while repairing compatibility. Preserve unknown outcomes and paid fulfillment across rollback.

## 18 Operating measurements and limits

Collect per creator and aggregate: admitted turns, duplicate intake prevented, generated drafts, confirmed/failed/unknown actions, stale drops, queue age, engine/transport latency, projection lag, model calls/tokens/cost by purpose, media failures, purchase reconciliation lag and operator interventions. Distinguish generation time from intentional pacing and Telegram throttling.

Set bounded queues, per-creator concurrency and model spend ceilings. Stop accepting new generation when a dependency backlog exceeds configured capacity while retaining already accepted durable events. Define backpressure behavior for both ingress and payment processing so sales settlement is not starved by long chats.

Before a paid cohort, run load tests in the deployed topology using synthetic users/files and a fake Telegram transport. Measure per-worker memory and disk, model-provider concurrency allowances, connection pools and queue growth. Do not load-test Telegram by flooding real accounts. Worker-per-creator isolation is the initial architecture; a shared/multi-worker database redesign is a separate measured decision and cannot silently share Fastt's global fan tables.

No calendar or model-credit estimate is asserted here. P1 and P2 should record elapsed implementation time, usage, test duration and unresolved dependencies so remaining effort can be estimated from actual work rather than invented certainty.

## 19 External constraints checked for this plan

Telegram's Bot API documents mutually exclusive polling/webhooks, chat-scoped message identifiers, Business reply permissions, paid media payloads and transaction/refund fields. Current documented paid-media limits include 10 items, integer Stars 1..25000, payload up to 128 bytes and caption up to 1024 characters after entity parsing. Business `can_reply` applies to private chats with incoming messages in the last 24 hours. Recheck the implementation's API/SDK compatibility before rollout. [Business rights](https://core.telegram.org/bots/api#businessbotrights), [Paid media](https://core.telegram.org/bots/api#sendpaidmedia), [Pre-checkout](https://core.telegram.org/bots/api#answerprecheckoutquery)

Telegram digital-goods payments use Stars. Invoice approval is distinct from successful payment, and test-payment facilities are available. Keep this distinction in fulfillment. [Telegram Stars payments](https://core.telegram.org/bots/payments-stars)

Telegram recommends avoiding more than one message per second in a chat and documents approximately 30 messages per second for ordinary bulk notifications. Treat these as platform guidance, honor actual throttling and do not enable paid broadcasting automatically. [Telegram FAQ](https://core.telegram.org/bots/faq#my-bot-is-hitting-limits-how-do-i-avoid-this)

OpenRouter provider order/fallback configuration is part of a request, separate from the model name. Preserve effective routing intentionally and record actual provider/usage evidence. [Provider routing](https://openrouter.ai/docs/guides/routing/provider-selection), [Chat completion API](https://openrouter.ai/docs/api/api-reference/chat/create-a-chat-completion)

Use Supabase row-level access policies and scoped server authorization for exposed data; private media delivery needs authorized access. Choose and test the actual transaction/connection mode. For RPCs, prefer invoker semantics; any required definer function must pin search_path, enforce scope and restrict execute grants explicitly. Service-role/definer access bypassing RLS is not tenant authorization. [Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security), [Database functions](https://supabase.com/docs/guides/database/functions), [Database connections](https://supabase.com/docs/guides/database/connecting-to-postgres)

## 20 Source anchors

These are inspected local implementation anchors. New work must verify the corresponding files in the attested release rather than assume line numbers survive edits.

- [Telegram production and direct handlers](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/bot/src/index.ts:129>) and [scheduled writers](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/bot/src/index.ts:603>).
- [Transport mixed with legacy rewrites](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/bot/src/services/telegram-messenger.ts:799>), [manual sends](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/bot/src/manual-send.ts:10>), [outbound gates](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/bot/src/services/outbound-gate.ts:98>).
- [Established payment reconciliation](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/bot/src/star-reconcile.ts:308>) and [Supabase store](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/bot/src/data/supabase-store.ts:426>).
- [Business connection dashboard](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-dashboard/app/api/business-connection/route.ts:25>), [creator authorization](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-dashboard/lib/creator-dashboard-identity.ts:32>), [agency authorization](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-dashboard/lib/agency-identity.ts:3>).
- [Media upload and metadata](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-dashboard/app/media/actions.ts:203>), [vision pipeline](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-dashboard/lib/caption.ts:47>), [catalogue checkout](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-dashboard/lib/catalogue-checkout.ts:85>).
- [V2 reply path](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-sexbot/src/bot.ts:123>) and [V2 test payment poller](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-sexbot/src/payments.ts:63>).
- [Fastt native engine](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/automations/ai_chatter.py:7198>), [platform client construction](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/automation_executor.py:938>), [typing dependency](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/automations/_common.py:2006>).
- [Fastt model providers](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/llm_providers.py:37>), [model client](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/llm_client.py:267>), [experimental OpenRouter shim](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/native_pilot/model.py:21>).
- [Native database setup](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/db/engine.py:35>), [global blacklist](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/db/models.py:1409>), [pack send pricing](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/service/automations/pack_sender.py:915>).
- [Deployment source map](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-tgaiclone/pipeline/lib/hosts.ts:55>), [operations tooling](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/twin-ops/README.md>), [Fastt license](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/LICENSE>).

## 21 Completion definition

The migration is complete for a selected bot only when it uses the real Fastt engine through the existing authorized Telegram identity; preserves its approved persona, files, purchases and entitlement obligations; provides verified content purchase/fulfillment for enabled products; responds to dashboard pause/manual control; recovers without blind replay; and has passed the applicable canary, restore and rollback checks. Every enabled product in the P0 manifest must be supported or explicitly excluded from that selected rollout before activation.

This is the governing execution plan after the current independent review, not a certification that implementation has no defects. P1-R and P1-PG are accepted within their documented scopes; P2 is in progress and remains the current assignment. Live runtime/schema attestation, engine integration, measured testing and live migration remain. Record progress by package and exact acceptance evidence in PROGRESS.md; do not mark a package accepted because its original tests pass or a planning document exists. Re-review only new changes and unresolved findings at the next boundary; avoid repeatedly restarting accepted work.
