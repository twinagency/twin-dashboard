# Independent Telegram integration review, 17 October 2026

Current status: the builder's subsequent P1-R repair was re-reviewed. **P1R_REVIEW.md is the current remaining-findings record**; this file preserves the original pre-repair R1-R6 evidence. Do not read the failures below as claims they all still reproduce unchanged.

## Verdict and scope

Keep the architecture. Do not start P2 yet. The local P0 inventory is useful, but its live deployment facts remain pending. P1 is implemented and disabled; its original checks pass, but independent synthetic probes reproduce defects in the promised recovery and identity boundaries. P1 is therefore **not accepted**. This review changes planning documents only, not production code or live data.

The immediate work is one consolidated **P1-R** repair package in START_HERE.md. After acceptance, finish the missing production PostgreSQL implementation as **P1-PG**, then proceed with P2. These are completion of the planned foundations, not a rebuild of the product. Findings about later media/payment behavior are assigned to their existing packages, not bundled into P1-R.

Review baseline:

| Root | Revision / working state |
|---|---|
| bot | codex/telegram-fastt, f414f32da07f32f1108c4ed7bd34139e547d59ef; P1 files untracked |
| twin-dashboard | main, fb6b345692a735d131b875e7b69ce8f955ba9a03; clean |
| inflowwkiller | codex/onlyfans-integration, e72316fd9c34092f767bc6e425ca9faea340da27; pre-existing OF changes and untracked Telegram foundations |
| twin-sexbot | codex/onlyfans-integration, 7b0036bf4d1a58413c57d19434fa4bcad3a1c4f4; existing OF changes and untracked planning files |

Line references below describe the pre-repair files. Recheck them against the current diff before editing. No live service, receiver, model, Telegram/OnlyFans send, database migration or cloud deployment was used for this review.

REVIEW_BASELINE.json records SHA-256 fingerprints for the 17 examined P1 implementation/test/schema files so subsequent repairs can be compared with this specific state. It is evidence of file identity, not acceptance.

## Required P1-R findings

### R1. Durable records omit the recoverable body

Node `bot/src/services/telegram-control-store.ts:337,424` persists identity and digest but discards event text/attachments/source revision and action text/assets/timing/clone identity. Python `inflowwkiller/service/telegram_contract/store.py:208,299` and migration 144 mirror the omission. Projection records also lack their body.

Observed: querying the admitted action returns no frozen text/assets/payload/timing. Closing the process loses the only recoverable input. A digest can verify content but cannot recreate it.

Repair: store a bounded immutable versioned validated body with its semantic digest, or a transactionally linked durable body record. Add typed readback. Reopen a file-backed database and recover the exact event, action and projection from storage without the original input object. Include source revision, destination and deadlines. Keep secrets out of these records.

### R2. Projection redelivery duplicates work and advances the wrong cursor

Node `telegram-control-store.ts:504-536`; Python `store.py:386-426` insert a new destination row for every call. There is no stable source-event identity/sequence or unique duplicate boundary.

Probe, both languages: import the same source revision/kind/body twice. Returned sequences were `1, 2`; row count was `2`; consumed cursor was `2`. The existing Node regression at `check-fastt-durable.ts:325` only checks a cursor lower bound and misses this error.

Repair: use stable source identity and recipient-stream source sequence; retry after successful commit/lost acknowledgement returns the existing record and does not mutate projected state or cursor. Different content under the same identity conflicts. Actual native projection mutation and consumed source cursor commit in one destination transaction. Test sparse/out-of-order delivery, explicit gaps, same source delivered to different recipients, rollback, reopen and redelivery after a completed commit. Never use destination autoincrement as source progress.

### R3. Conversation arbitration and completion do not enforce the attempt boundary

Node `telegram-control-store.ts:453-486` and `delivery-authority.ts`; Python `store.py:327-375` guard only the individual action's state and binding epoch.

Probe, both languages:

```text
claim A at epoch 0                      true
mark A unknown                         true
claim different B, same conversation    true
advance ownership epoch
confirm B with only its action ID       true
```

An unresolved A must prevent competing B. Completion has no claimant/attempt token, so any internal caller knowing a dispatching action ID can claim its outcome. Terminal rows cannot currently be overwritten; the defect concerns unauthorized completion of a dispatching row.

Repair: atomically arbitrate across the conversation and assign an immutable dispatch-attempt identity. Validate owner/scope/state at claim and require the original attempt identity/evidence at completion. Test independent clients and different action IDs, not only two callers claiming one ID. Preserve a real late receipt for the original attempt even after ownership changes; it may settle that attempt but must not authorize new dispatch. Unknown resolution needs independent evidence or an audited operator decision, never resend. Test forged completion separately from valid late completion.

### R4. Retry bookkeeping is incorrectly part of the source-content digest

Node `telegram-control-store.ts:312-330`; Python `store.py:181-198` hash the whole normalized envelope.

Probe: same bot/update, same actual message, later locally assigned `receivedAt` produces `EventConflictError`. A receiver restart reconstructing the envelope can therefore reject an ordinary platform retry.

Repair: specify the semantic source digest field list. Preserve first canonical event ID/receipt time; new receipt metadata does not change source identity/content. Changed provider content still conflicts. Test new receipt time and receiver event ID after restart, plus a real content change. Do not solve this by ignoring every changed field or overwriting the first event.

### R5. Node/Python numeric and timestamp rules disagree

Node `fastt-contract.ts:263-298,330,506,523,608`; Python `contract.py:249-281,316,487-525`.

Verified cases:

| Input | Node | Python |
|---|---|---|
| ordinal 1e21 | accepts; hashes exponent form, action ID act_f27ba9ec11077bdb737b0d7986b48bcd in the synthetic case | rejects same wire action ID because it hashes decimal form |
| expectedEpoch 9007199254740993 | rounded to 9007199254740992 | retains integer |
| amount 10**400 | non-finite numeric handling differs | uncaught OverflowError |
| 0000-12-31T23:59:59-00:01 | accepts and normalizes into year one | rejects year-zero input |

Repair common ranges before hashing/conversion: ordinal 0..2147483647; epochs/input revisions 0..9007199254740991; XTR paid media 1..25000. Enforce action-specific combinations and item limits, retain provider IDs as strings, reject source year zero and normalization outside the common date range. Conversion failures are typed contract errors, not raw exceptions. Add shared boundary fixtures at/above limits, booleans, huge integers and offsets. Keep both validators, schemas, contract document and all fixture copies/hashes consistent.

### R6. Binding identity can change without invalidating authority

Node `telegram-control-store.ts:258-265` and Python `store.py:114-121` allow clone/bot/mode/Business connection replacement under the same binding ID without an epoch advance. Claims do not validate the action's clone/conversation against trusted binding records. A synthetic action changed to another clone still claimed successfully.

Repair: binding identity is immutable; changed identity creates a fenced replacement or is rejected. Persist/validate the trusted conversation-to-binding relationship. Cross-clone/connection actions must fail before claim. Apply the action-class authority rules in plan section 12: current config/input, Fastt assignment and AI-unpaused state gate AI actions; authorized human takeover permits manual actions; canonical paid obligations survive conversational pause/input/engine changes. All obey scoped authority, platform eligibility and unresolved-send arbitration. The gateway derives the class; the worker cannot self-assign manual/financial privileges. Implement/test store predicates with synthetic controls in P1-R; real permission observation and receiver/financial handler wiring remain later packages.

## Missing production boundary: P1-PG

There is currently no production PostgreSQL store implementation. Migration 144 is DDL, not transactional repository behavior. The schema parity check at `bot/src/dev/check-fastt-schema-parity.ts:42-55` compares table/column names only, not types, constraints, grants, Python schema semantics or actual PostgreSQL transactions.

After P1-R review, implement the canonical Node store with atomic PostgreSQL transactions/RPCs and service-side scope. Reuse the existing application connection pattern where practical. Test on disposable PostgreSQL: full bodies, redelivery, uniqueness, two independent clients, conditional claims, binding isolation, rollback, late receipts, projection publication and restricted RPC execution. No live Supabase migration is authorized by that offline package. The worker's SQLite control-store fixture must not become another production assignment/payment/delivery database.

## Corrections already incorporated into the full plan

1. **P2 excludes every existing writer.** Campaign/free-preview/follow-up/manual/payment-reaction branches currently run independently (`bot/src/index.ts:642,674,689`, `star-reconcile.ts:822`). P4 adds replacement features/full UI; it cannot defer their initial authority gates. Keep subscription expiry/settlement running inside compound jobs.
2. **One verified configuration map.** Current CONFIG_MAPPING labels are inventory, not a tested source-to-native transform. Exact keys, types, defaults, precedence, ranges, consumers and effective prompt snapshots are required before a setting is enabled. Unmapped controls remain visibly inactive. Never layer the old compiled prompt over Fastt.
3. **Business messages have a time window.** Reuse `messaging-window.ts` and `outbound-gate.ts`; check connection rights and 24-hour inbound eligibility at final dispatch. Expired follow-ups are held/expired, not rerouted to another identity. Imported old history does not reopen eligibility. [Official rights](https://core.telegram.org/bots/api#businessbotrights)
4. **Pre-checkout needs an actual order check in P3B.** `bot/src/payments.ts:20-34` approves positive XTR without buyer/payload/order checks. Extend and bound validation, preserve valid legacy decoders, answer within ten seconds and keep the existing reconciler for Business receipts. [Official deadline](https://core.telegram.org/bots/api#answerprecheckoutquery)
5. **Media validation has limits.** Detectable schema/cross-field conflicts are testable; arbitrary factual accuracy is not guaranteed by code. Sparse sampling has gaps. Review flagged results and preserve existing valid metadata, human edits and prices.
6. **No duplicate caption owner.** Upload-time copy and optional contextual offer copy are distinct. Preserve explicit configuration, use Fastt's existing caption owner only when needed, disable the old Node caption rewrite for the same action, and freeze the final caption before dispatch. Delivery retries never call the model again.
7. **Asynchronous uploads need sale readiness.** Current dashboard prices depend on generated tags. Pending/failed new analysis cannot publish guessed/free items; re-analysis does not silently change manual or frozen prices. All upload/import/backfill entry points share the ownership gate.
8. **One accepted result does not mean one billed attempt.** Bound and record retries/fallbacks and uncertain call costs; preserve completed stages across restart.

## Verification performed

The independent code review ran the following against the unchanged implementation; every listed command exited 0:

```powershell
# From bot/
npm run typecheck
node_modules\.bin\tsx.cmd src/dev/check-fastt-contract.ts
node_modules\.bin\tsx.cmd src/dev/check-fastt-durable.ts
node_modules\.bin\tsx.cmd src/dev/check-fastt-import-safe.ts
node_modules\.bin\tsx.cmd src/dev/check-fastt-schema-parity.ts

# From inflowwkiller/
.venv\Scripts\python.exe service\tests\test_telegram_contract.py
.venv\Scripts\python.exe service\tests\test_telegram_store.py
```

Additional probes ran Node (`node --import tsx --input-type=module`) and Python stdin against synthetic fixtures and in-memory SQLite. They produced the bad outcomes recorded above. Those are review evidence, not acceptance of the implementation. P1-R must put correct-outcome regressions into the normal suites, with a file-backed reopen test where recovery is claimed. The full historical bot suite was not rerun by this reviewer; its earlier reported run is preserved in PROGRESS.md as builder evidence.

No production PostgreSQL execution, live attestation, real engine Telegram turn, paid model run, media analysis or live purchase is certified by this review. Missing dependencies must be recorded as missing, never as a passed required check. The original SQLite harness can skip when node:sqlite is unavailable; a required integration test job must fail visibly in that case.

## What this means for the project

The plan preserves the useful work: existing Telegram identity/gateway, dashboard, Supabase catalogue/files, approved facts, purchase/credit/subscription records, and Fastt's native engine. The immediate defects are in disabled new foundations and incomplete specifications. Their discovery is not evidence that the current live fleet failed, nor evidence that the architecture must be discarded.

The sequence is: P1-R repair and review; P1-PG transactional implementation and review; P2 native text and isolated proof; an explicitly selected text pilot after basic P5 recovery checks; P3A media; P3B sales; P4 remaining product controls; P5 full operations; P6 measured rollout. No blanket zero-defect or conversion guarantee is made. Each gate has observable acceptance evidence.
