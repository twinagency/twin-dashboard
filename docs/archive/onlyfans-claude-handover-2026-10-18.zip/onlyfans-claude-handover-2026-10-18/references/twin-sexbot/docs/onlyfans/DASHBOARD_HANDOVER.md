# Twin OnlyFans dashboard: new-chat handover

Prepared 17 October 2026 from the current local code, project documents and the owner's instructions. This is the starting brief for a separate dashboard architecture/build chat. Creating this handover did not change application code, start a service, inspect live sessions, send a message or deploy anything.

## 1. What the owner wants now

Start building the architecture and interface for **Twin's own OnlyFans dashboard**, in parallel with the Telegram migration running in another chat. Keep Twin branding and the useful existing dashboard. Use Fastt's native OnlyFans conversation/context/content-sales backend as the recommended foundation, with the delivery, isolation and recovery corrections described in the consolidation plan.

The immediate assignment is **OF-D0**, defined in section 12: source map, architecture/API contracts and an isolated fixture-based frontend foundation. It is not a live OnlyFans activation, backend rewrite or fleet deployment. Do useful independent work now; record backend dependencies rather than blocking the entire dashboard effort on the Telegram build.

The finished product should let an authorized operator connect/manage creator accounts, view conversations, understand automation status, take over or pause a conversation, manage content and approved prices, inspect sales, and resolve delivery/session problems. Replies should be autonomous when enabled by the verified backend. The dashboard must not require an AI coding assistant to manually relay every fan message.

The commercial target discussed is autonomous inbound text plus selling existing photos/videos. The longer-term planning scale is 1,000 creators / 100,000 daily active fans, not demonstrated capacity. Optional mass campaigns and other automations are later capability gates.

## 2. Read these documents in the correct order

Workspace: `C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION`.

| Read | Purpose / authority |
|---|---|
| This DASHBOARD_HANDOVER.md | Current parallel dashboard assignment and boundaries. |
| twin-dashboard/CLAUDE.md and applicable AGENTS.md | Dashboard implementation conventions; verify current code where old commentary is stale. |
| twin-sexbot/docs/onlyfans/CONSOLIDATION_PLAN.md | Newer proposed OnlyFans target architecture and full backend/migration roadmap. This is the OnlyFans architecture reference. |
| output/independent-audit-20261016/COMPARATIVE-AUDIT.md | Actual comparative findings and evidence limits; neither frozen implementation was ready for broad production unchanged. |
| twin-sexbot/docs/telegram/IMPLEMENTATION_PLAN.md | Concurrent Telegram track, common configuration/media decisions and shared-file dependencies. Its Node-only Telegram sender rule is channel-specific. |
| twin-sexbot/docs/telegram/START_HERE.md, PROGRESS.md, REVIEW_FINDINGS.md | Current Telegram package and protected work. At this handover: P1-R required, P2 not started. Recheck before editing. |
| twin-sexbot/docs/onlyfans/PROGRESS.md | Historical Twin-bridge build/pilot record. It is not a consolidation completion report or current process-status check. |
| inflowwkiller/service/native_pilot/README.md | Native Fastt text experiment and its limits; not the production deployment architecture. |

**Avoid the filename trap:** `docs/onlyfans/IMPLEMENTATION_PLAN.md` is the OLD Twin V2 reply-service bridge plan. Its next-stage instructions are historical. Do not rebuild that as the new product or treat its stale assignment as the current dashboard task. `CONSOLIDATION_PLAN.md` is the newer OnlyFans direction. `docs/telegram/IMPLEMENTATION_PLAN.md` is a separate, current Telegram plan.

Current owner instructions control scope. Where reference documents disagree, identify the specific conflict and preserve the current live behavior while resolving the affected boundary. Do not silently change the backend architecture to make a UI mock easier.

## 3. Repositories and what they actually are

These were verified locally for this handover. HEADs do not include uncommitted work and do not prove a running deployment.

| Folder | Observed state | Role |
|---|---|---|
| twin-dashboard/ | ronan-com/twin-dashboard; main at fb6b345692a735d131b875e7b69ce8f955ba9a03; clean | Existing Twin Next.js dashboard, identity/access, Telegram views, catalogue and UI components. Intended deployed release still needs attestation before integration. |
| inflowwkiller/ | BlackPhoenixSlo/inflowwkiller; codex/onlyfans-integration at e72316fd9c34092f767bc6e425ca9faea340da27; dirty | Fastt Python relay/native engine plus earlier bridge/native-pilot work and new Telegram contracts. Shared active source, preserve all work. |
| twin-sexbot/ | jesse98/twin-sexbot; codex/onlyfans-integration, base 7b0036bf4d1a58413c57d19434fa4bcad3a1c4f4; dirty | Twin V2 test engine, OnlyFans reply service/journal, evidence and planning documents. Not the deployed Telegram fleet backend. |
| bot/ | ronan-com/twin-bot; codex/telegram-fastt, base f414f32da07f32f1108c4ed7bd34139e547d59ef; untracked P1 work | Existing Telegram fleet runtime and active migration. Outside this dashboard assignment's edit scope. |
| twin-ops/, twin-tgaiclone/pipeline/ | Source references exist | Deployment/operations evidence. No current AWS connection or deployed release is certified by this handover. |

Do not choose a sibling dashboard worktree, allieai2-bot copy or server directory by its name alone. The deployed server folder name and the actual source repository can differ.

## 4. What has already happened

### Implemented and historically tested

- A Twin V2 OnlyFans bridge was built: input validation, scoped identities, draft/status service, durable turn/result records, authenticated local HTTP, Fastt intake, burst grouping, ownership, send attempts, receipts, takeover and a capped autonomous worker.
- Its three-reply live pilot succeeded, with distinct provider IDs and confirmed transcript updates. A subsequent bounded reliability check passed the recorded synthetic regression and disconnect scenarios. That established a narrow text baseline, not unrestricted production readiness.
- A separate native Fastt text experiment was built. It invoked Fastt's real engine using Twin's existing model/provider through an experimental OpenRouter adapter, with text-only/exact-chat controls and an allowance of up to ten outgoing messages, including bubbles. It did not use Twin's prompt/draft service.
- The owner subsequently requested comparison runs, including a fifteen-message Twin run, and supplied conversation screenshots. This handover does not re-attest those final send counts or today's worker state. Historical allowances are not fresh authorization to restart anything.
- The owner requested deliberate typo/misspelling injection be disabled. Preserve this preference. Verify the effective setting in any future live integration; do not assume it is off merely because a UI says so.

### Audited/proposed, not implemented as the finished product

- The comparative audit found stronger connected context/commerce capabilities in native Fastt and useful safer delivery semantics in the Twin bridge. It did not prove better sales conversion or certify either implementation at scale.
- The recommendation became one consolidated OnlyFans backend, using native Fastt concepts and one mandatory durable delivery authority, with corrected transactional storage and tenant/account isolation. It is not a stock Fastt copy and is not two concurrent reply engines.
- The consolidation plan proposes a real PostgreSQL port for production OnlyFans control/messages/jobs/commerce. A connection-string change is insufficient because current Fastt contains SQLite-specific code.
- No inspected evidence establishes that this full consolidation, its production dashboard API, account-scoped Twin-to-Fastt identity binding or broad rollout has been implemented.
- Telegram migration P0 inventory and disabled P1 foundations exist, but the latest independent review found six repair groups. Those code repairs and the production transaction adapter remain work for that track.

The creator-preparation extraction pack mentioned in older chat messages is not an approved onboarding/canonical content source for this task. The owner questioned that pasted assignment. Do not infer approved creator facts or usable inventory from it.

## 5. Fixed architecture direction

```mermaid
flowchart LR
  UI[Twin dashboard] --> API[Scoped Twin server API adapter]
  API --> OF[Fastt based OnlyFans backend]
  OF --> DB[(Canonical OnlyFans records)]
  OF --> ENGINE[One native conversation and sales planner]
  ENGINE --> INTENT[Durable actions]
  API --> INTENT
  INTENT --> DELIVERY[One OnlyFans delivery authority]
  DELIVERY --> PROVIDER[Private OnlyFans transport]
  PROVIDER --> DB
  DB --> API
```

- **Twin remains the product/UI.** We do not need to replace its dashboard with Fastt's UI. Reuse good existing Twin components and its authorization model.
- **Fastt is the runtime engine/backend foundation.** DeepSeek is a coding assistant; OpenRouter is a model-provider entry point. Changing the coding assistant does not change the deployed conversation model.
- **One owner per fact.** OnlyFans history, attempts and commerce come from their canonical backend. The dashboard renders projections and submits commands; it does not invent another writable ledger or conversation coordinator.
- **OnlyFans and Telegram are distinct transports.** Node remains the sole TELEGRAM gateway in that migration. This does not mean OF messages should go through the Telegram sender. OF writes go through its designated private provider transport and common OF delivery authority.
- **Different database steps are intentional.** Telegram currently plans isolated native SQLite worker state plus canonical Supabase control/financial records. The OF consolidation proposes porting its production domain/control to PostgreSQL. Do not force one track's storage topology onto the other or create duplicate canonical records to satisfy UI convenience.
- **Preserve existing data.** Keep Twin identity, assets, Storage, approved facts/edits and existing Telegram financial obligations. Inventory where OF media is actually owned/stored before specifying copies; do not assume Telegram media rows are already an OF vault.
- **Retirement happens after cutover.** The separate Twin OF reply service/file journal can leave the active OF deployment only after the replacement preserves evidence and passes migration/rollback checks. Do not delete old code/data now.

## 6. The dashboard already has useful presentation, but no proven OF integration

Existing `twin-dashboard/components/crm/CrmPreview.tsx` renders hardcoded Inbox, Fans, Campaigns, Team and Platforms previews. Its platform cards include OnlyFans, Fanvue and Fansly. These are presentation fixtures, not live integrations. Reuse the responsible presentational component/design where practical; do not start a second unrelated dashboard.

Important route behavior:
- `app/crm/inbox/page.tsx` redirects certain management sessions to Telegram `/users`.
- `app/crm/platforms/page.tsx` similarly redirects to `/business`.
- `app/messages/page.tsx` redirects to `/users`.
- `app/business/*` is Telegram Business account management.

Useful extension seams:
- Presentation: `components/crm/CrmPreview.tsx`, `components/ui/*`, `components/clone/fields.tsx`, `components/TwinPanel.tsx`.
- Later navigation integration: `components/Sidebar.tsx`, `components/TopBar.tsx`, `lib/page-meta.ts`, `app/layout.tsx`.
- Identity: `lib/dashboard-access.ts`, `lib/agency-identity.ts`, `lib/creator-dashboard-identity.ts`, `lib/creator-session.ts`.
- Scope/policy: `lib/clone-scope.ts`, `app/actions/clone-scope.ts`, `lib/agency-policy.ts`, `lib/agency-management-policy.ts`, `lib/creator-dashboard-policy.ts`, `lib/agency-write.ts`.

Do not reuse Telegram fields as OF fields. `lib/types.ts` Clone and the users/history/financial views contain Telegram bot IDs, `telegram_id`, Business connection IDs and Stars assumptions. A persona `platforms` field is not an authorized channel-account binding. OF fan IDs must not be stored in `telegram_id`; OF money must not be put into Stars columns. Do not merge fans across accounts/channels by name or matching numbers.

**Offline prototype trap:** `app/layout.tsx` loads real identity, fleet, scope and financial helpers. A fixture page inside the normal app tree is not automatically offline. Build a separate preview/test harness that imports presentational components and synthetic data only. Do not copy live environment files or disable production auth and assume that prevents database access.

## 7. Dashboard feature map and data ownership

| Surface | Needed behavior | First mock package / eventual dependency |
|---|---|---|
| Accounts / connections | Account identity, connection health, expired session/reconnect needed, permissions and sync freshness | Fixture states now; real session lifecycle later, server-side only |
| Inbox / conversation | Scoped paginated conversations, history provenance, owner/pause state, drafts versus confirmed output, partial/unknown sends | Fixture accounts + inbox now; canonical backend read adapter later |
| Fan context | Corrected facts with provenance, purchase/owned-media state, contact exclusions | DTO/design now; native context/purchase projections later |
| Engine / creator settings | Selected engine/version, model purposes, approved creator facts, requested/effective controls | Contract now; exact native mapping and backend enforcement later |
| Content library | Asset identity/source, type, existing description/copy, manual edits, availability and price; pending/failed analysis | Design now; one shared media pipeline owner and channel-aware asset mapping later |
| Sales / transactions | Offers distinct from purchases; gross/net/fees/refunds with source currency and evidence | Synthetic records now; canonical commerce integration later |
| Manual control / incidents | Pause, takeover, resume, no-contact, manual-send command status, unresolved delivery recovery | Simulated only now; shared authoritative command/delivery service later |
| Team / permissions | Existing agency/creator roles plus account-scoped operations; view-as remains read-only | Contract/fixtures now; server permission integration before live access |
| Automations | Show which capabilities are implemented, configured, paused or unavailable | Unconverted campaigns/mass/scheduled features remain inactive |

Keep connection health, automation mode and delivery outcome separate. Connected does not mean automation is enabled. Generated or queued does not mean sent. Provider acceptance does not mean read or purchased. Payment settlement must remain independent of conversational pause. Human takeover is requested until the backend confirms it is effective.

Unknown delivery must show a hold and evidence-resolution path, not a generic retry-send button. No stale cached status may silently become current. Empty, unavailable and zero are different states. Revenue totals must identify currency/period/freshness and never silently aggregate Stars with OF amounts.

## 8. API and authorization contract to design

Use a narrow server-side Twin adapter rather than exposing all of Fastt's existing relay/admin routes. Existing Fastt routes and hooks are source evidence, not an approved multi-tenant API:
- `inflowwkiller/service/server.py`: account, chats/messages, manual message and health routes.
- `service/account_config_api.py`: native account configuration.
- `app/hooks/useAccounts.ts`, `app/hooks/useAccountConfig.ts`, `app/lib/relay.ts`: existing client shapes.

Do not import/start `service/server.py` to generate types; startup/import paths can touch state or launch work. Do not send browser cookies, provider session material, service-role keys or unrestricted relay credentials into frontend code.

Proposed contract families, not claims that endpoints exist:
1. Accounts/bindings/health/capabilities.
2. Cursor-paged conversations and messages.
3. Current control state and versioned command status.
4. Creator/native configuration and effective version.
5. Catalogue/analysis/availability and immutable offer references.
6. Purchases/refunds/ownership and currency-aware summary projections.
7. Delivery incidents and audited resolution evidence.

Read models carry schema version, channel, authorized account scope, stable identity, source revision, timestamps/freshness and capability status. IDs are strings under their field-specific rules; money has explicit currency and validated integer minor units. Exact financial semantics must come from the provider/backend, not the UI.

Commands carry a stable idempotency key and expected revision. The server derives actor, permissions and allowed account binding from authenticated context. Browser IDs merely request scope. Retry/status lookup reuses the command identity; the UI must not generate a new send after a lost acknowledgement.

Preserve existing agency/creator/view-as restrictions. `getDashboardAccess()` uses null in some independently authenticated internal contexts; null alone is not admin authorization. Every future OF endpoint must validate authentication and account-level authorization explicitly. Middleware development shortcuts are not an authorization boundary. If Supabase holds binding/configuration data, use existing identity rules, server-side scope and appropriate grants/RLS, not a duplicate login system.

Use one frontend data-source interface with a deterministic fixture implementation now. Its future live implementation must use the scoped API; absent live configuration fails visibly, never switches to a permissive mock success in production. Test out-of-order responses, stale revisions, duplicate commands, account switch/cache isolation and permission-denied states.

## 9. Content and model decisions to preserve

The latest shared media recommendation is bounded multi-frame factual extraction, structural/cross-field checks, then a separate stored-copy stage. Preserve approved human edits and usable legacy metadata. Flagged/uncertain results need review; failure must not overwrite metadata with blanks or publish new content at a guessed/free price. This is planned work, not an implemented shared service.

Stored catalogue captions and optional context-specific offer captions are distinct. Preserve configured capability, use one native Fastt caption owner when needed, freeze the final text with its delivery action, and do not run a second Node rewrite. Deliberate typo injection stays disabled. No legacy Twin compiled prompt is layered over Fastt's native prompt.

The prior four-file media test reused Fastt prompts through a separate OpenRouter harness. It did not exercise the complete native collector/provider/budget/persistence path. Multi-frame input covered later activity missed by a single video frame in that sample; it is not proof of universal factual accuracy or conversion advantage. Do not hardcode test outputs into production catalogue data.

The OF dashboard track may design these states and interfaces now, but must not independently implement a second media analyzer, OpenRouter registry, persona compiler or caption policy while Telegram's shared work is pending.

## 10. Parallel ownership: avoid conflicting edits

Use a separate dashboard branch/worktree such as `codex/onlyfans-dashboard-foundation` for actual mock implementation. Reuse an appropriate existing isolated checkout if available; do not switch/reset another chat's working tree. Record the exact base and inherited/untracked dependencies. A separate branch alone does not eliminate semantic conflicts.

| Area | Owner / permitted parallel work |
|---|---|
| New dashboard-only architecture documents, view models, fixture data, isolated preview | OF dashboard chat, within its reviewed package |
| Existing CRM presentation | OF chat may minimally adapt/extract it in its isolated checkout; preserve current routes until integration review |
| bot/src/engines, P1 control stores, migration 144, Telegram tests | Telegram chat; read-only for OF dashboard work |
| Fastt telegram_contract, native engine/provider/database/sender modules | Shared or Telegram/backend owner; OF dashboard reads/contracts only in OF-D0 |
| Root layout/navigation/auth/clone types/common queries | Shared dashboard integration seam; record a proposed patch/contract first, coordinate before live route integration |
| Catalogue schema, media/caption workers, pricing/revenue helpers, model configuration | Shared decisions; one implementation owner per component, no parallel replacement |
| Live database migrations, cloud services, account sessions, workers | Outside initial dashboard scope |

Telegram's current P1-R expressly excludes dashboard edits, so independent fixture work can proceed now. Before the Telegram track reaches shared dashboard/config/media work, compare current diffs and reserve exact file ownership. Do not copy another checkout wholesale, cherry-pick unrelated work, change migration numbering independently or present an unmerged prototype as deployed.

## 11. Mandatory development rules

1. Inspect current responsible code, effective prompts/configuration, recent changes, tests and pending work before every recommendation or edit. Trace interactions rather than assuming a familiar filename is the owner.
2. Make the smallest necessary change in the responsible component. No contradictory instructions, duplicate handlers, competing generation/sending logic, unnecessary prompt layers, model calls or parallel canonical stores.
3. Preserve approved behavior unless the requested stage changes it explicitly. Keep displayed settings/prompts/status consistent with actual runtime behavior; no configured-but-inert controls presented as working.
4. Test the affected flow and relevant failures, compatibility and rollback. Report exactly what was checked and what remains unverified. Never claim zero clashes without examining the current code and pending work.
5. Work one agreed package at a time. These are development instructions, never fan-facing prompt text. Do not expand into live wiring because the mock looks complete.
6. Follow existing component/style/access conventions. Keep Twin branding; no unrequested full redesign, new login system or copied Fastt frontend. Do not expose implementation jargon where users simply need an actionable status.
7. Use synthetic neutral fixtures. Do not access private chats, cookies/session files, tokens, .env secrets, live customer media or balances for OF-D0. Do not run a standard app dev command without auditing its startup/data imports.
8. No activation, sends, paid model calls, account reconnect, allowance reset, live schema/data mutation, deployment, commit, push or deletion is authorized by the initial package. Existing historical pilot approvals do not authorize a new pilot.

## 12. Exact first assignment for the new chat: OF-D0

Complete this single package and stop for review:

1. Read the references and inspect fresh status/diffs. Confirm which source is implemented, historical, mock or only proposed. Do not re-audit the entire Telegram project or redo its repairs.
2. Establish an isolated dashboard checkout for implementation. Record target base and unresolved deployed-release facts; do not block source-only mock work merely because deployment is pending.
3. Produce a dashboard architecture document with screen map, ownership diagram, authoritative sources, authentication/account binding, proposed API contracts, feature availability and dependency gates.
4. Define TypeScript view models/data-source interfaces and deterministic fixtures for account connection status and a scoped inbox/conversation view. Document later content, sales, settings and incident contracts without implementing their backend now.
5. Reuse/minimally extract the current CRM presentation into an isolated preview foundation. Show a clear Preview / Sample data indicator. Implement mock account selection, inbox selection and status/permission states. Simulated controls are labelled as simulations; no button pretends a real account connected, message sent or setting persisted.
6. Include connected/disconnected/expired-session, empty/loading/error/stale, AI-paused, takeover-pending/effective, partial/unknown delivery and read-only states. Keep state dimensions independent and show actual available actions per capability.
7. Verify the preview can run/render without importing the live root layout, production data providers or OF server. No external account/model access. Use the existing installed toolchain where possible and isolate any preview-only configuration; do not start another application on an occupied port or install/start background services silently.
8. Verify the narrow component/contract behavior: two accounts do not share selected conversations/cache; stale results cannot overwrite a new selection; read-only simulated users cannot invoke mutation handlers; unknown delivery offers no blind resend; preview cannot fall through to live transport. These tests prove the fixture frontend contract, not backend security or production reliability.
9. Provide local preview instructions and desktop/mobile screenshots when the fixture harness is available. Record actual typecheck/tests and exit results, changed files, the protected shared files left untouched, and outstanding backend decisions in a dashboard-specific progress file.
10. Stop at OF-D0 review. Do not proceed to live reads, real commands, schema migration or account activation.

Suggested output location in the isolated dashboard checkout: `docs/onlyfans/` for architecture/contracts/progress and a clearly owned fixture-preview area using existing presentational components. Choose exact file locations after inspecting the repository; avoid a second full app and a competing design system.

## 13. Later dashboard stages and acceptance

| Stage | Outcome / dependency |
|---|---|
| OF-D0 | Architecture/contracts plus isolated accounts/inbox fixture foundation; current assignment |
| OF-D1 | Complete the remaining fixture-driven content/sales/config/control screens against reviewed contracts; visual/accessibility/error-state review |
| OF-D2 | Authenticated account binding and read-only backend adapter in isolated integration environment; requires backend contracts, authorization and storage foundations; test real route scope/pagination/cache/stream isolation |
| OF-D3 | Real pause/takeover/manual/configuration commands and incident workflow through the single backend authority; requires corrected delivery/control service; test retries/revisions/unknown/late receipts and view-as denial |
| OF-D4 | Content/commerce/revenue integration; requires exact canonical offers, purchase/refund/ownership and capability contracts; test currency, partial results and no fabricated sales |
| OF-D5 | Deployment attestation, migration/rollback rehearsal and a separately selected bounded live cohort; backend consolidation gates must pass before activation |

These dashboard stages depend on the backend milestones in CONSOLIDATION_PLAN.md; they are not a claim those milestones are done. Share pure contracts/components where verified, keep channel-specific transport and money semantics explicit, and expand only after the affected boundary works end to end.

End result: operators use the Twin dashboard to manage the consolidated Fastt-based OnlyFans product, with authoritative account-scoped state and one sending path. The existing Telegram product continues working while its own migration progresses. A good prototype, green isolated tests and a short historical pilot do not certify fleet capacity or zero future faults.
