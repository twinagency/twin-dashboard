# Original Fastt reliability and shared transport evidence

Audit date: 2026-10-16 (Australia/Brisbane). This subreport supports the independent comparison. Original source examined is **e72316fd9c34092f767bc6e425ca9faea340da27**, accessed using `git show` and the audit's `fastt-base-src` snapshot. Line references below refer to that base, not the modified working tree. Shared-versus-custom attribution was checked with `git diff e72316f --` for the inspected transport files.

## Decision contribution

Copying original Fastt one-for-one **does not establish a safer autonomous messaging system**. It removes the bridge's extra integration and state machinery, but removes useful delivery uncertainty and send-boundary controls that original Fastt lacks. Original Fastt has real protections—account/fan composite keys, an atomic live fan lease, cooldowns, bounded concurrency, history fetching, stale-generation checks, and durable scheduled jobs. Those protections are materially incomplete at precisely the accepted-send/lost-response, concurrent-process, and late-human-intervention boundaries.

Neither original Fastt nor the shared Fastt infrastructure is demonstrated suitable for a million simultaneous conversations. Its declared deployment is a single Python 3.13 process and a local SQLite database. Multiple workers cannot safely be enabled as a capacity shortcut: an actual SQLite diagnostic allowed two production job-claim calls to return the same job.

This subreport does **not** independently score Twin's conversation quality or the current bridge's complete state machine; those are separate investigations. It establishes which native risks would survive a wholesale reversion and which are shared.

## Scope, runtime, and test safety

- Read the full user request, selected original source through `git show`, and selected diffs. No production source, live configuration, private messages, credentials, workers, or provider endpoints were used or modified.
- Dockerfile line 16 declares `python:3.13-slim`; final command starts one Uvicorn worker. Installed local runtimes include 3.10, 3.11, 3.13, 3.14. The repository `.venv` is Python 3.11.9, so it was **not** used to execute these diagnostics.
- Diagnostics used `C:\Users\conta\AppData\Local\Temp\of-preflight\venv\Scripts\python.exe`, reporting Python **3.13.16**. The supplied runtime contains the required pinned database libraries.
- Startup inspection found that importing `db` normally imports the engine, loads `.env`, and constructs the configured engine. Full app startup initializes/mutates the database before its test-mode network guard (`server.py:1093–1127`). It was deliberately not imported. `test_vault_upload.py` was not executed.
- The harness loads `db/models.py` directly by file after inspection, bypassing `db/__init__.py`, and AST-extracts exact production functions without their registration decorators. It provides fake network dependencies and a newly created temporary SQLite database. This avoids application startup side effects while exercising real SQLAlchemy queries, ORM updates, commit boundaries, and production branch logic.
- The frozen source snapshot is under `output/independent-audit-20261016/fastt-base-src/service/`; the audit harness and JSON results are alongside this report.

## Actual reachable native flow

1. `server.py:_ws_pump_for_account` constructs a client for an account, attaches `__account_id` to each incoming event, and calls `_broadcast_event` (`870–920`). `OFWebSocket.events` reconnects with backoff, refreshes `/users/me`, uses the per-account proxy, parses JSON, and yields frames (`of_ws.py:90–176`). This is one in-process pump per account, not a durable subscription with a stored provider resume cursor.
2. `_broadcast_event` fans to UI and calls the event module. `events.handle_event` places each event in a bounded **RAM** persistence queue, then broadcasts it (`129–187`). The serial worker separately writes `event_inbox` and runs the transcoder (`318–345`). These are not one atomic durable intake-and-processing transaction.
3. `_transcode_chat_message` identifies inbound fan by `fromUser.id`; if it equals creator `account_id`, the outbound event is skipped because recipient is unavailable (`event_transcoder.py:339–384`). Inbound canonical rows use `(account_id, fan_id, message_id)` and fan/chat use `(account_id, fan_id)`. Message/fan/chat writes are in one SQL session (`408–535`). A malformed fan/message id can fail the event, which is logged and not retried by this worker.
4. The transcoder starts `on_inbound_message` after commit (`558–579`). The webhook dispatcher has global and per-account off gates (`webhook_dispatch.py:216–240`), then routes make-right, funnel, `ai_chatter`, or legacy gathering based on current state (`369–420`). A per-account `ai_chatter` spend gate can hand high-spend customers to humans; backup mode adds a human SLA (`607–615`). If immediate dispatch is disabled, recurring rules must supply the sweep; merely running the pump is not enough.
5. It derives response delay/cooldown, scans pending jobs to avoid a near-term duplicate, and inserts a durable job (`439–488`, `627–667`). The scan-plus-insert is not an atomic fan-inbound idempotency key. It does not record which inbound message was durably consumed; the worker later gathers current conversation state.
6. The automation supervisor materializes rules, sweeps expired leases, and spawns a task per due `(account, kind)`, bounded by global sender/bulk semaphores, default **4+2** (`automation_executor.py:92–108`, `1724–1787`). One process-local run lock prevents same-account/same-kind overlap within that process (`1624–1640`). Job claim is a SELECT followed by ORM UPDATE, not compare-and-swap (`576–604`).
7. Native chat gathers message history and fan state, applies eligibility and conversation policy, acquires an atomic database fan lease, calls the model, validates/humanizes, and sometimes parks an unpriced draft in a scheduled job (`ai_chatter.py:7812`, `9757–9815`). There is no durable outbound attempt ledger binding a pending reply to a provider acceptance decision.
8. Native `ai_chatter` checks `_thread_moved_on` once before final pacing (`9865–9872`), then awaits typing/pacing and directly calls `client.send_message` in a thread (`9988–9995`). Main chat, legacy gathering, and autoreply bypass `of_write_paced`; their typing delays are not an account-wide write budget.
9. `OFClient.send_message` forms the provider request, applies optional co-tags, and POSTs (`of_client.py:1500–1581`). Its raw proxy wrapper retries any `ProxyError` up to three attempts (`512–532`); auto-co-tag fallback can additionally re-POST on explicit 400/422 rejection. A timeout propagates. There is no provider idempotency key in this request body.
10. A truthy response id drives outbound attribution. `write_outbound_attribution` inserts/upserts the outbound row and advances the UI; its database errors are caught and logged (`attribution.py:438–528`). Native chat then sets reply state and short cooldown and releases its lease (`ai_chatter.py:10132`, `10372–10386`). These steps are separate transactions after provider delivery.
11. `run_once` marks the run and job done only after the plugin returns. An exception or cancellation requeues up to three attempts; boot also changes **every** running job to pending (`automation_executor.py:617–629`, `1653–1717`). That recovery rule does not distinguish “never POSTed” from “POST accepted but response/persistence lost.”

## Prioritized findings

### N1 — Accepted but unacknowledged native sends are not safely recoverable

**Classification:** confirmed defect in recovery semantics under a specified failure; test-demonstrated for scheduled sends, code-established for native conversational sends. **Severity:** high. **Affected:** B; A's retained native scheduled/mass/manual paths remain exposed unless a custom boundary prevents that particular send. The bridge's own free-text attempt ledger must be assessed separately.

**Trigger:** provider accepts a POST, then response is lost, malformed, or process dies before local state is committed. Native chat sees no confirmed local outgoing, releases or eventually expires its lease, and can regenerate/reply again. The scheduled worker catches a send exception through `run_once`, puts the same payload back into pending, and sends it again. On crash, `_reconcile_orphans` blindly requeues all running jobs.

**Sources:** `automations/scheduled_send.py:83–108,133–134`; `automation_executor.py:617–629,1653–1717`; `automations/ai_chatter.py:9993–10028,10372–10386`. `write_outbound_attribution` is best-effort and swallows database failures (`attribution.py:438–528`), so an attribution database failure does **not** itself force a scheduler retry; instead it loses the local outgoing record and affects future context/reconciliation. A failure in later job finalization can still requeue after a successful send.

**Diagnostic:** actual `scheduled_send.run`, `run_once`, claim/mark functions and temporary SQLite; fake provider records acceptance then raises `TimeoutError` on the first call. First run returned error and left job pending; second run posted the same payload and completed. **Observed POST calls: 2.** This proves the application's resend policy under ambiguous acceptance, not that the real provider returns that exact failure at a particular frequency.

**Missing-id variant:** fake response `{}` returned `sent_no_id`, but `run_once` marked the job **done**. It cannot establish whether a message was delivered and offers no unknown-state reconciliation. Native ai_chatter handles missing id only specially on the first bubble (`10026–10057`); a later missing id can let a partly delivered turn advance state.

**Remediation direction:** introduce persistent send intents/attempts, explicit unknown delivery state, bounded reconciliation, and idempotent acknowledgement across every sender; never use blind job replay as send recovery. Broad cross-cutting change, not a retry-count tweak. A bridge can supply this protection for its own text route without automatically fixing all native senders.

### N2 — Multiple processes can claim the same scheduled job, and boot interferes with live work

**Classification:** confirmed defect if deployed with multiple supervisors; intentional single-process deployment currently avoids that trigger. **Severity:** high for horizontal scaling. **Affected:** B and A's shared native scheduler.

`_claim_due_job` SELECTs pending, changes object status/attempts, and commits on context exit (`automation_executor.py:576–604`). The update is not conditional on still-pending status and has no owner/version. Process-local locks do not serialize separate processes (`209`, `1624–1640`). Boot's `_reconcile_orphans` considers all running jobs orphaned without owner or liveness criteria (`1695–1717`).

**Diagnostic:** the actual claim function ran twice against real SQLite, with a barrier scheduling both SELECTs before either commit, a valid multi-worker interleaving. **Both returned job id 1**, and attempts remained **1**, not 2. Running the actual reconcile function moved the running job to pending. This is deterministic interleaving evidence, not a throughput measurement.

Native chat's fan lease can reject a simultaneous conversational sender, so duplicate claim does **not** mean every chat job double-sends. Scheduled human sends deliberately acquire no fan lease (`scheduled_send.py:27–29`), and mass jobs are not per-recipient leased, making those routes directly exposed. Starting another process can requeue work while the first process still sends it.

**Remediation direction:** atomic conditional claim with worker/attempt ownership, lease heartbeat/fencing, and owner-aware recovery. Partition account ownership across workers and move pumps/scheduling out of web-server startup before scaling. Significant infrastructure work.

### N3 — Fan lease prevents initial overlap, but has no fencing of expired workers

**Classification:** useful protection plus credible risk requiring work to exceed TTL or a delayed stale release. **Severity:** high in that condition. **Affected:** B and any shared native sender using this primitive; do not assume the custom bridge relies on this lease.

The initial acquire is a sound atomic upsert keyed by creator/fan, conditional on expiry (`automation_executor.py:271–333`). Defaults are **900 seconds**, with no renewal token. Release deletes by account/fan, optionally kind, not unique acquisition id (`336–355`). Native ai_chatter normally releases without even the kind filter (`10380,10386`). No provider boundary fences a stale owner after expiry.

**Diagnostic:** live lease rejected a second acquire (positive control). After setting the synthetic first lease expired, a successor acquired it. Calling the actual old release with the same `holder="ai_chatter"` deleted the successor's lease. This confirms the missing ownership generation; it does not prove normal runs exceed 900 seconds. Global inline run-budget helps keep typical runs shorter, but it is not a fencing proof, especially for stalled external calls or suspended processes.

**Remediation direction:** unique acquisition tokens, conditional release/renew, and send-boundary ownership validation. Moderate primitive change plus all callers.

### N4 — New inbound or human intervention after stale-check still permits stale native replies

**Classification:** confirmed timing defect; code-established. **Severity:** high for incorrect/duplicate replies. **Affected:** B native engine; A only if that native engine is also active outside custom coordination protections.

`_thread_moved_on` checks for newer inbound and relevant outgoing (`ai_chatter.py:3642–3699`). Main run calls it at `9865–9872`, then awaits `hold_with_typing` at `9988–9992` and POSTs at `9995`, with no recheck between bubbles. Price-related pacing can include a 45–115 second hold (`9967–9986`). Draft replay similarly checks once (`5194`) then sends multiple `_send_free_bubble` calls (`5201–5207`), whose typing hold precedes POST (`3558–3585`). Autoreply shares the pattern (`autoreply.py:857–866`). Legacy gathering sends its generated bubbles with holds and no equivalent final recheck (`welcome_chatter_for_info.py:2175–2184`).

Manual send is permitted directly by `server.send_message` (`5232–5283`) and only sets optional human cooldown after successful attribution (`attribution.py:498–523`, default 1 minute). Scheduled sends intentionally bypass fan leases. A cooldown written during an existing send's typing hold does not cancel it. Outgoing events from the official app are deliberately not persisted (`event_transcoder.py:348–384`), and native stale detection ignores unattributed outgoing as possibly broadcasts (`ai_chatter.py:3665–3669`); full human takeover from the official app is not established.

**Remediation direction:** shared per-conversation generation/cancellation version and actual-wire validation coordinated with manual/scheduled/mass sends; distinguish official-app messages using fetched conversation and bounded timing. Moderate-to-large sender coordination change. The bridge's transport guard is therefore a genuine potential improvement, not merely complexity.

### S1 — Shared incoming events can disappear before canonical persistence

**Classification:** intentional lossy overload/shutdown tradeoff, unsuitable for an unattended loss-sensitive messaging service; code-established and queue branch test-demonstrated. **Severity:** high under burst/disk outage/restart. **Affected:** both through shared Fastt WS ingestion.

`events.py:158–175` drops the oldest RAM queue item when its **2000** item queue fills. `366–379` cancels the worker without draining. `335–345` logs persist/transcode exceptions then moves to the next item. Raw-event insertion and canonical transcoding are separate; `mark_event_processed` exists in `db/repo.py:127–144` but no live caller or retry drainer was found. The actual SSE stream does not emit event ids or honor Last-Event-ID (`events.py:416–464`), so comments about replay are not implemented recovery.

**Diagnostic:** exact `handle_event` with queue capacity reduced to 2 for a bounded branch test: three events left `[1,2]`; event 0 was discarded before persistence. Capacity reduction changes only when overflow occurs, not overflow behavior. No throughput or real-disk saturation claim is made.

The custom bridge's transactional intake hook makes canonical message and bridge-input insertion atomic **once transcoding runs**. It does not make the preceding RAM queue durable. If its added intake fails and rolls back the canonical transaction, this existing worker still logs and moves on; recovery then depends on later reconciliation.

**Remediation direction:** durable raw ingress before acceptance, replayable processing with explicit status/retries and poison-event parking, bounded backpressure, and graceful draining. Moderate-to-large infrastructure change; track queue depth/drop/failure metrics as correctness metrics, not only liveness.

### S2 — History recovery has a bounded-gap problem after a large interruption

**Classification:** confirmed recovery limitation; code-established and production fetch function test-demonstrated. **Severity:** high where missing interval matters. **Affected:** both when relying on shared scraping; an independently complete bridge poller could mitigate for eligible new text, but is not assumed here.

`_fetch_recent_end` stops after newest **100** messages by default or 40 pages (`automation_executor.py:190–197,1191–1236`). `_scrape_one_chat` computes the largest collected id and `_upsert_chat_and_history` advances the durable high-water mark to that id (`1353–1405`, `1170–1188`). If more than 100 messages arrived since the previous cursor, intermediate unseen messages below the latest 100 are no longer fetched on the next scan, because the cursor is already the newest id. There is no saved continuation for the gap.

**Diagnostic:** prior high-water id 1, provider synthetic ids 250 downwards, 50 per page. Actual fetch returned ids 250–151 (100 records); next fetch with the production caller's new high-water 250 returned zero. IDs 2–150 remained missing. This differs from the intentional initial-history policy of sampling first/last 100: the problem applies to later catch-up after an interruption.

Whole-account scan also defaults to only the **100 most recent chats**, paginating by actual row count and checking `hasMore` (`1411–1467`). That is bounded, but not complete coverage of an arbitrarily large fleet. Newest-page cursor repetition is bounded by caps, yet not explicitly detected; duplicate fetched rows can consume the cap.

**Remediation direction:** separate “newest seen” from “contiguously recovered through,” persist paginated catch-up continuations, enforce monotonic cursors/progress, and partition complete chat discovery. Moderate change; requires provider-history tests.

### S3 — Message-row dedup does not dedup side effects or preserve latest metadata

**Classification:** confirmed defect; test-demonstrated. **Severity:** medium by itself, higher if scheduling relies on corrupted summary timestamps. **Affected:** both shared transcoder paths.

Canonical Message uses an idempotent composite key (`event_transcoder.py:413–443`), but Fan.last_message_received_at is set unconditionally to the incoming frame time (`471–473`); Chat.last_message_id/time/preview is overwritten and unread incremented on every duplicate (`503–512`). Dispatch is also invoked on every inbound frame after upsert, rather than only newly inserted messages (`574–579`). Native dispatcher dedup and eligibility reduce duplicate sends, but are not a unique per-inbound consume guard.

**Diagnostic:** exact transcoder against actual SQLite, synthetic newer frame twice then older frame. Result: **2 message rows, unread_count 3, latest id regressed to 101, fan last_received regressed to 11:00 from 12:00**. This proves side-effect non-idempotency and out-of-order metadata regression, not cross-fan identity leakage. The separate REST chat update does use a monotonic condition (`automation_executor.py:1162–1165`), so safeguards differ between ingestion mechanisms.

**Remediation direction:** use insert outcome for once-only side effects and monotonic max/ordered tuple comparisons for latest timestamps/id; atomic dispatch key tied to account/fan/message. Small-to-moderate focused change.

### S4 — Timestamp parsing discards non-UTC offset

**Classification:** credible input-contract risk, confirmed parsing behavior. **Severity:** medium under offset/future-clock conditions. **Affected:** both shared native parsers; custom normalizers may differ.

`event_transcoder._parse_iso` (`87–95`) and executor equivalent (`225–232`) call `.replace(tzinfo=None)` without conversion to UTC. Synthetic `2026-10-16T12:00:00+10:00` becomes `12:00` naive rather than `02:00` UTC. Expected ordinary provider `Z/+00:00` values avoid the defect; actual non-UTC provider behavior is unverified. Missing/invalid timestamps are replaced by receipt time on the WS message path (`387`); there is no future-time bound in that path. Newer-inbound detection compares only `created_at > inbound_at`, so a new message sharing the same timestamp precision is not caught by that query (`ai_chatter.py:3651`).

**Remediation direction:** normalize aware values to UTC and use deterministic tie breakers/provider ids; validate timestamp range. Small focused change with provider-shaped fixtures.

### N5 — Original raw POST retry policy is broader than its stated CONNECT-only intent

**Classification:** credible risk requiring an ambiguous `ProxyError`; code-established. **Severity:** high if that error can occur after request transmission. **Affected:** B and unchanged native sender routes in A. **Not** A's bridge-specific single-POST route.

`OFClient._proxy_retry` catches all `requests.exceptions.ProxyError` and retries up to three times (`of_client.py:512–532`), while its caller is generic `_http_call` for GET and writes (`441–463`). It tests neither method nor evidence that the request failed before transmission. Comments say CONNECT 403 but the exception test is broader. Whether the pinned curl library can classify a post-acceptance failure this way was **not** established; do not assert a real provider duplicate rate from this code alone.

Current custom `send_text_once_body` passes `proxy_tries=1`, a useful explicit differentiation. Co-tag fallback after clear 400/422 rejection and paced retries after the specific rate-limit rejection are different mechanisms; they should not be called duplicate defects without contradictory provider semantics.

**Remediation direction:** restrict automatic write retries to proven pre-transmission failures or provider idempotency; record ambiguous outcomes. Small transport change plus broader recovery design.

### S5 — Deployed database recovery and schema upgrades require more than restarting the app

**Classification:** confirmed operational assumptions/credible data-loss risk under specified deployment. **Severity:** high for committed ledger/history loss; medium-high for schema drift. **Affected:** both shared deployment.

- `db/engine.py:init_db` creates missing tables, adds nullable/defaulted columns, and attempts indexes; it does **not** execute Alembic upgrades. Existing nonadditive constraints, data transitions, or mandatory columns outside its special cases do not automatically migrate. Index creation failures are logged and startup continues. Treat the migration directory as intended schema evolution, not proof that a populated production database reached it.
- SQLite uses WAL, `synchronous=NORMAL`, and 30 second busy timeout (`db/engine.py:105–114`). `docker-compose.yml:108–112` binds only the `.db` file; WAL/SHM live in the container's service directory. Its comments rely on orderly shutdown checkpoint. Abrupt container replacement/removal before checkpoint can lose acknowledged transactions held only in the container WAL. This was not tested with a live container and is conditional on actual deployment matching the file.
- Dockerfile specifies a single worker because of process-local pumps and SQLite. Merely changing `DATABASE_URL` does not establish a PostgreSQL deployment: current code uses SQLite-specific inserts and raw SQL patterns, requirements do not include the asyncpg driver, and upgrade/recovery/concurrency need testing on the target database. This report does not claim every SQLite insert is intrinsically uncompilable for PostgreSQL; the unsupported leap is treating migration as a proven configuration-only switch.
- Shutdown cancels the supervisor, but the supervisor's detached `_inflight_tasks` are not joined/cancelled by that shutdown function (`server.py:1259–1262`; `automation_executor.py:1777–1787,1824–1825`). Runtime eventual loop teardown may cancel them later. There is no orderly durable per-send shutdown handoff demonstrated.

**Remediation direction:** persist the SQLite directory including WAL or use a managed transactional database; tested backup/restore/checkpoint procedures; versioned transactional migration deployment with preflight/rollback; explicit worker shutdown handling. Moderate operational and infrastructure work, major for distributed operation.

## Positive controls and material native safeguards

These are real implementation strengths, not production reliability claims:

- Per-account/fan/message composite keys and account-filtered queries in inspected paths prevent the simplest cross-account collision. No confirmed wrong-fan routing or cross-tenant memory leak was found in this subset. Broader authorization is a separate audit.
- Atomic fan lease upsert rejects two simultaneous **unexpired** owners; tested positive control.
- Durable cooldown upsert handles missing Fan rows and survives process restart (`automation_executor.py:382–428`). ai_chatter retains its lease if setting the cooldown after confirmed send fails (`10375–10384`).
- Per-process same-kind locks, independent bulk lanes, and bounded executor concurrency reduce overlap/starvation in the supported single-process deployment. Detached scheduling avoids one slow scrape blocking the supervisor itself.
- `_thread_moved_on` prevents an already-known new message or attributed answer before its check; it does not protect subsequent awaited delay.
- Webhook dispatch folds in backup SLA and cooldown, and scopes jobs to one fan (`webhook_dispatch.py:607–667`). New events while the cooldown is active can be deferred rather than dropped. Extremely long cooldowns intentionally leave work to recurring sweeps.
- Dead-session health stops claiming jobs and probes for recovery (`automation_executor.py:1548–1576,1633–1636`), avoiding endless sends with known broken credentials. Exception in the health check logs and proceeds, an availability choice requiring monitoring.
- Fetching uses actual returned counts and `hasMore`, not `len(page) == requested_limit`; chat discovery dedups fan ids. First/last history sampling is an intentional bounded-context choice, separate from the catch-up gap finding.
- Attribution is idempotent by provider message id, advances preview only for a real insert, and can backfill tags when scraping wins the race (`attribution.py:459–482`). Purchase is_paid uses a ratchet to avoid downgrading a recorded purchase (`event_transcoder.py:433–437`).
- Mass automation uses a shared **process-local** broadcast lock and fail-closed audience/exclusion preparation (`send_mass_message.py:322–350`), opens a mass run before send, and records recipient attribution/optimistic placeholders after response (`352–455`). These make normal tracing and UI useful; a mass run record is not a complete per-attempt acknowledgement ledger.

## Manual, scheduled, mass, and restart behavior

| Path | Implemented protection | Remaining boundary |
|---|---|---|
| Manual relay DM | Auth/account resolution outside this subset; resale precheck; post-send attribution; optional per-fan human yield | No pre-send fan lease in original; can race native typing hold; failed attribution loses takeover evidence; arbitrary user/client retry is not idempotent |
| Near-term scheduled human DM | Durable queue; employee attribution; only pending jobs can be canceled in `server.py:7134–7157`; paced sending | No fan lease by design; native claim and unknown-send replay defects; cancellation once running does not revoke in-flight send |
| Longer scheduled provider DM | Provider queue via `server.py:6937–6996`/`of_client.schedule_message` | Future send occurs on provider side and local bot has no transactional ownership of provider execution; provider schedule behavior unverified |
| Native mass automation | Audience/exclusion gates, process-local broadcast lock, mass run, per-recipient/placeholder records | No durable per-request delivery uncertainty state; crash/retry can replay whole broadcast; account/fan lease does not fence provider mass execution |
| Official-app creator message | Outgoing echo invalidates caches; later REST fetch may import history | Outgoing WS canonical row skipped; no instant durable human takeover; native bot ignores unattributed outbounds in stale check |
| Worker restart before POST | Requeued jobs and preserved native state commonly allow continuation | No exact per-turn phase ownership; regeneration can spend again |
| Restart after provider acceptance | Scraping can later rediscover provider message | No bind from recovered message to uncertain attempt; requeue can happen first; first/last sampling and attribution ambiguity remain |
| Event-pump restart | Reconnect/backoff and fresh auth | No committed provider replay cursor; bounded REST scan is fallback, not complete proven recovery |

## Scale contribution: formulas and architectural limits

These are reasoning assumptions, **not measured capacity numbers**:

- If default global sender concurrency is `C=4` and mean run occupancy is `T` seconds, scheduler service capacity is at most approximately `C/T` **runs/second**, before database, model, and provider limits. A fan-scoped job is one run; a sweep may handle several fans, but can occupy its slot for their serial work. With `T=5,30,120` seconds, illustrative limits are `0.8,0.133,0.033` runs/s. They are sensitivity examples, not predictions about real model latency or supported fans.
- ai_chatter includes a **240s per-run inline delay budget** (`ai_chatter.py:220,9751–9830`), plus model calls and I/O. Four slow reply runs can occupy the default sender lane and queue other accounts. Separate bulk slots help with scraping, not slow conversational runs.
- Native paced sender seam allocates a process-local 11s per-account gap (`automation_executor.py:500–540`). For paths using it, its configured gate alone limits that process/account to about `1/11=0.091` writes/s. Main chat and manual paths bypass it, so this is **not** a fleet-wide provider request budget or a claim of platform allowance.
- A burst of 2001 unpersisted events with no drain loses at least one at the RAM queue boundary. Sustainable arrival rate must stay below the serial persistence/transcoding drain rate; that drain rate was not measured. A process restart loses any remainder even below that rate.
- Native webhook pending-job dedup loads all due-enough jobs for `(account, kind)` then parses JSON to find a fan (`439–488`), rather than a fan-key indexed queue lookup. Large concentrated tenants amplify scans and cannot rely on per-fan ordering across processes.
- Whole-account history scan defaults to 100 recent chats and about 100 recent plus 100 initial messages per targeted fan. Cost for chat listing is proportional to pages returned; actual provider short pages determine amplification. Full-history/complete-missed-interval recovery is not implemented by that bounded scan.
- One million registered mostly dormant fans is predominantly a storage/index/retention concern and is not equivalent to a million daily actives. One million daily actives generating even 5 incoming messages/day means 5M/day, about **57.9/s average** before peak concentration; this can already exceed low default scheduler throughput without any simultaneous-million assumption. One million concurrently active conversations creates a fundamentally distributed queue/model/provider-budget requirement absent here. Many creator tenants also imply one pump/client/cache state per account and fairness/partition requirements beyond one module-level process.
- Query indexes and quotas improve a single-node service, but do not demonstrate horizontal tenancy partitioning, distributed conversation ownership, independently scalable ingestion/model/send workers, multi-region recovery, or tested restore times.

## Diagnostics and limits

Command (one bounded run):

```powershell
& 'C:\Users\conta\AppData\Local\Temp\of-preflight\venv\Scripts\python.exe' '.\output\independent-audit-20261016\original_fastt_diagnostics.py'
```

Result: exit code **0**; 16 asserted observations recorded in `original_fastt_diagnostics_results.json`, grouped into job-claim concurrency, ownerless boot recovery, fan lease fencing, duplicate/out-of-order intake, offset parsing, queue overflow, scheduled uncertain delivery/missing id, and history catch-up. The positive lease control passed alongside defect reproductions. Deprecation warnings arise from production-compatible `datetime.utcnow()` semantics and are not test failures.

| Suspected failure | Correct boundary expected | Real production boundary tested | Excluded/mocked | Conclusion |
|---|---|---|---|---|
| Double job claim | One claimant or second CAS miss | `_claim_due_job`, ORM commits, real SQLite | Two SELECTs synchronized to known interleaving | Same job returned twice; actual non-atomic claim established |
| Startup steals live work | Recover only expired owned jobs | `_reconcile_orphans`, SQLite updates | No OS process spawned | All running jobs requeued, owner absence established |
| Expired holder clears successor | Release unique acquisition only | Acquire/release SQL against real table | Time advanced by setting synthetic expiry | Same-kind successor removed by stale release |
| Duplicate/out-of-order summaries | Idempotent unread, monotonic latest | `_transcode_chat_message`, real message/fan/chat tables | Dispatch hook/cache operations no-op; synthetic text only | Row dedup works; summaries regress/inflate |
| Offset drift | UTC normalization | `_parse_iso` exact function | Synthetic +10:00 input | Offset discarded; actual provider incidence unknown |
| Queue overflow | Durable backpressure/replay | `handle_event` actual overflow branch | Queue size reduced to 2; broadcast no-op | Oldest event discarded pre-persistence |
| Unknown scheduled outcome | Reconcile unknown, no blind resend | `scheduled_send.run` → `run_once` → claim/failure/done SQL | Provider accepts-then-times-out fake; no model; recorder fake | Actual scheduler sends same payload twice under stated uncertainty |
| Malformed successful body | Visible unresolved outcome | Same sender/executor | Provider returns `{}` | Job done despite absent provider id |
| Catch-up gap | Continue until previous cursor reached | `_fetch_recent_end` twice, with real caller's high-water policy | Synthetic provider pages; no real OF history | Cap + max-id update misses interval thereafter |

No mock-generated text is used as conversation-quality or conversion evidence. These tests do not establish provider actual timeout taxonomy, real duplicate frequency, full-app startup success, throughput, or million-user behavior.

## Coverage and unresolved evidence

**Inspected in detail:** native event pump/intake/transcoder; job claim/retry/boot/supervisor; fan lease/cooldown; shared transport POST/retry; manual DM and scheduled DM; mass-send caller and audience lock; outbound attribution; history scrape and cursor; relevant native chat send/stale/pacing/replay boundaries; shared DB initialization and Docker deployment.

**Inspected related patterns:** autoreply and legacy gathering send loops, mass recipient attribution, SSE reconnect implementation, raw-event processed fields/callers, current transport diff. The same final-pacing window and post-send persistence split recur; this is not one isolated line.

**Other agents cover:** full native sales/prompt behavior, Twin memory/engine, bridge delivery machine, application-wide security/config/inventory, and outcome data.

**Not executed:** live provider/model calls; full application startup; broad test suite; Windows vault suite; real Docker abrupt-stop/restore; populated production database migrations; real multiple server processes; provider history completeness; actual loads/outcomes. The claim concurrency test models a valid process interleaving with real database sessions, not a claim to have run a distributed deployment.

**Smallest evidence that could materially change conclusions:** show durable provider idempotency/reconciliation at all native sends, owner-aware atomic job claims under actual deployment, final-wire cancellation covering human/provider activity, and complete durable ingress recovery under restart. A larger number of successful normal conversations would not resolve these specific failure boundaries. A temporary controlled pilot can refine provider semantics but cannot prove architectural scale.

## Ordered prerequisites from this investigation

1. Keep autonomous rollout bounded until accepted-but-unknown send handling and acknowledgement reconciliation are explicit for the selected route.
2. Coordinate actual sends with manual/other automation and revalidate after all asynchronous waits; provide visible operator takeover and recovery.
3. Make ingress durable/replayable and fix duplicate/out-of-order side effects and catch-up gaps.
4. Correct job claim/recovery ownership and lease fencing before adding any processes or machines.
5. Validate migration status, persistent WAL storage, backup/restore, retention, and graceful shutdown on the chosen deployment.
6. Establish per-tenant model/provider budgets, queue fairness, latency/backlog SLOs, alerting and overload policy, then measure representative workloads.

Original Fastt supplies substantially broader functioning application and sales plumbing than a text-only bridge, but those capabilities cannot be counted as proof of reliable delivery. A proposed direction retaining native catalogue/entitlement/manual UI while putting its autonomous delivery behind stronger ownership and uncertainty handling is justified by these findings; that proposal is **not** an already tested third system.

## Recommendation challenge and late cross-checks

The strongest reason **not** to choose a proposed hybrid immediately is that native sales and conversational state transitions are deeply interleaved with sending and acknowledgement. Extracting only offer selection while promising delivery through a different ledger is not a trivial adapter: partial multi-bubble replies, gift/paid deliveries, purchases arriving mid-turn, post-send quote/ladder/cadence transitions, and interrupted attempts must all agree about what actually reached the fan. Current A adds extra runtime/service/state dependencies and does not yet offer equivalent native media/PPV capability. For a small, supervised operation, native Fastt can therefore be simpler to operate at its existing feature level despite its weaker failure semantics. This complexity challenge argues for a narrow bounded target and explicit migration criteria, not for trusting native blind retry.

Independent bridge investigation reported a reservation beginning only after bridge aggregation/quiet-window processing. Native webhook default delay is zero (`webhook_dispatch.py:243–251`); native ai_chatter's default mode, when enabled, is `always` (`ai_chatter.py:389–396`). No native scheduler/dispatcher scope exclusion for Twin was found. Thus enabling both engines can let native sending win before bridge reservation; later bridge preflight may correctly park, yielding interference/lost autonomous continuity rather than necessarily a duplicate. Root inventory reports the frozen current local native configs/rules absent and A sending disabled with its pilot budget exhausted, so this is **a configuration-dependent latent conflict**, not a claim of concurrent live sends in the audited snapshot.

The security/operations investigator separately confirmed `server.py:3098–3139` prunes raw events older than two days without inspecting processing status. Because the live event worker does not replay failed canonical transcoding, this bounds the time available for manual raw-event recovery and can delete the only archived copy of an intake failure. It is part of the shared durability/recovery limitation, not proof that native scheduled jobs are deleted by that pruning rule.
