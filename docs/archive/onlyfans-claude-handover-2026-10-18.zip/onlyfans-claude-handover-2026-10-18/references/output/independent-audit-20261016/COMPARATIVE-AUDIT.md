| Question | Verdict | Main evidence | Confidence | What could change this verdict |
|---|---|---|---|---|
| Reliability for autonomous text messaging today | **A is the safer choice for a tightly controlled text pilot, principally for delivery safety. Neither is generally reliable enough for unattended broad operation.** | A persists send attempts, treats ambiguous acceptance as unknown, avoids automatic reposts and separates drafts from delivered memory. B demonstrably replays an accepted scheduled send after a lost response. A still has missing intake recovery, unfair scheduling and a dangerous multiple-writer store condition. | Moderate for the overall preference; high for the specific tested boundaries. No comparative error rate measured. | Representative interruption/reconnect testing showing materially more missed or indefinitely stalled A conversations, or a native implementation with equivalent durable delivery controls. |
| Readiness for broad commercial deployment today | **Neither.** | Shared authentication/tenant leaks, unsafe populated-schema upgrades, incomplete intake recovery and deployment durability; additional A and B defects below. | High. | Corrected boundaries plus verified migrations, recovery, consent controls and representative operational validation. Three replies cannot supply this evidence. |
| Best architectural foundation for the stated scale scenarios | **Retain A's delivery-state design and Fastt's relational account/message/commerce domain. Replace the current scheduling and Twin file storage. Neither complete implementation is a million-scale foundation unchanged.** | Durable intent/uncertainty/fencing is preferable to blind replay; native Fastt has useful relational domain models. A's directory scans/full journals and B's process-local supervisor/claims prevent a simple horizontal scale-out. | High on constraints; moderate on engineering direction. | A workload-specific prototype proving a simpler unified implementation can preserve the same safety and context requirements at lower operational cost. |
| Conversation naturalness and continuity | **B has the stronger implemented continuity architecture. Actual naturalness has no measured winner.** | B can use existing platform history, profiles, creator canon, purchase facts and question tracking. A supplies only its own last 30 messages and still uses Telegram-specific instructions. B also has stale-memory and fabricated-life risks. | High for capability/wiring; low/insufficient for generated-output superiority. | Blinded matching-persona/input/model evaluation, including corrections, old preferences, stop requests and capability truthfulness. |
| Sales-engine capability | **B clearly wins the connected autonomous OnlyFans sales comparison.** | Reachable native content selection, ownership filtering, pricing, PPV sending and purchase/offer tracking. A's autonomous bridge sends free text only, with an empty catalogue. Shared Fastt manual commerce still exists in A. | High. | A completed and verified commerce integration, or operational evidence that particular B sales paths cannot function with the intended catalogue/provider. |
| Evidence of actual sales effectiveness | **No winner established.** | No matched output trial, conversion experiment, margin/retention/complaint dataset or independently verified outcome cohort. Source modules and simulated replies are not conversion evidence. | High confidence that available evidence is insufficient. | A controlled, appropriately authorized pilot measuring purchases, net margin, repeat buying, refunds, unwanted contact and intervention time. |
| Overall recommended production direction | **Do not copy original Fastt wholesale and do not broadly deploy current A. Keep A as the controlled text baseline; build a consolidated system with one durable delivery authority, grounded Fastt context/commerce and transactional storage. This hybrid is a proposal, not a tested third option.** | It preserves the demonstrated safety advantage without pretending Twin already supplies a superior OnlyFans memory or sales engine. Original/shared risks must be corrected regardless. | Moderate. | Equivalent safety in a simpler native-only design, strong matched conversation evidence favoring Twin after context parity, or evidence that the integration cost outweighs retaining A's implementation rather than its design. |

# Independent comparative audit — 16 October 2026

The recommendation concerns the frozen local source and the explicit workloads below. It is not approval to activate workers or spend the exhausted pilot allowance. No production source/configuration was changed, no workers were activated, no messages were sent, no paid model calls were made, and no credentials or private conversation bodies were printed. Synthetic diagnostics used temporary state and mocked external services. This audit makes no uptime, failure-probability, supported-user-count or conversion claim.

The decision prioritizes wrong-recipient/duplicate/uncertain sends, consent and tenant isolation before availability, then recoverability, conversation continuity, connected commerce and operating cost. This is not an issue-count score. If immediate supervised sales breadth is the overriding priority, B's native functionality is simpler to use after its shared/security blockers are addressed. If duplicate avoidance and controlled autonomous text are the priority, A's delivery semantics are preferable. No reasonable weighting makes either frozen implementation ready for the million-active-conversation scenario.

## 1. Exact snapshots, scope and runtime assumptions

Workspace: C:\Users\conta\Documents\ChatGPT\TWIN CLONE CREATION.

| Component | Verified branch | Full HEAD/base | Audited state |
|---|---|---|---|
| Twin | codex/onlyfans-integration | 7b0036bf4d1a58413c57d19434fa4bcad3a1c4f4 | Current working tree, including untracked channel implementation and tests |
| Fastt | codex/onlyfans-integration | e72316fd9c34092f767bc6e425ca9faea340da27 | A: current working tree; B: committed original source retrieved with git show/git archive |

Both recorded revisions were correct. HEAD alone does **not** describe A. The initial inventory records filenames, status, sizes and source/build SHA-256 hashes. It includes 81 nonignored tracked/untracked Twin files and 949 Fastt files; these are inventory counts, not quality scores. Original service source was archived separately under fastt-base-src/service. The Twin test snapshot excludes runtime data, logs and .env.

Inventory: [initial manifest](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/inventory-start.json>). Safe configuration and aggregate ledger evidence: [metadata](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/safe-runtime-metadata.json>). The initial metadata query used the wrong native rule column; a corrected read of is_enabled returned zero rules. This diagnostic query error did not mutate the database.

Tracked modifications:

- Twin: package.json, scripts/check-media.ts, src/turn.ts.
- Fastt: .gitignore, service/db/models.py, service/event_transcoder.py, service/of_client.py, service/server.py.

Relevant untracked implementation:

- Twin: src/channels/http.ts, identity.ts, serve.ts, service.ts, store.ts, text-turn.ts and types.ts; check-channel, check-recovery and check-http scripts.
- Fastt: service/twin_bridge/{cli,client,contract,coordination,delivery,errors,intake,normalize,pilot,platform,reconcile,scope,turns,worker}.py and package initializer; migrations 20261015_0100_twin_bridge_intake, 20261016_0100_twin_bridge_turns, 20261016_0200_twin_bridge_reserved; bridge tests/helper and Windows test runner.
- Untracked historical audit/preflight documents were treated as leads, not proof. The app/AGENTS.md file is documentation, not bridge functionality. No frontend files were changed.

Runtime and deployment:

- Fastt Docker declares Python 3.13; the repository .venv is Python 3.11.9. Diagnostics used the already-available Python 3.13.16 preflight venv at C:\Users\conta\AppData\Local\Temp\of-preflight\venv\Scripts\python.exe. Its SQLAlchemy 2.0.35, SQLModel 0.0.22, aiosqlite 0.20.0, httpx 0.28.1, curl_cffi 0.15.0, FastAPI 0.136.1 and Pydantic 2.13.4 match inspected direct pins. Python 3.14/3.13 global installations lacked these packages. The old .venv is not the supported full-application runtime.
- Twin diagnostics used Node 24.18.0; Docker declares Node 22. Package-lock exists, but no Node engines constraint. Tests on Node 24 do not establish identical container behavior on Node 22. Fastt direct dependencies are pinned; a complete transitive Python lock with hashes was not identified.
- Fastt starts service.server:app as one Uvicorn worker. Startup creates/upgrades schema, loads sessions and starts background work. A test-mode flag is not sufficient isolation, so the real application was not started.
- Twin's npm start/Docker default runs the Telegram bot. The OnlyFans adapter requires the explicit start:onlyfans-bridge entry point. Its loopback bind requires intentional colocated routing; separate containers do not share localhost automatically. A also needs the Python bridge worker/pilot, appropriate trusted scope and coordinated persistent storage. The provided Twin compose file is not an OnlyFans deployment.
- The Windows run_tests.cmd points to the older .venv; it was inspected, not used for the supported-runtime test run. The prohibited test_vault_upload.py suite was not run.

Configuration names/defaults and actual saved selectors:

| Area | Code/default behavior | Evidence in this workspace |
|---|---|---|
| Bridge intake | TWIN_BRIDGE_ENABLED defaults off; one ACCOUNT_ID, one CREATOR_SLUG, explicit FAN_ALLOWLIST and stable ACTIVATION_CUTOFF required | Enabled for one account and one fan; cutoff 2026-10-16T00:53:59.707Z |
| Bridge sends | TWIN_BRIDGE_SEND_ENABLED plus positive SEND_LIMIT; explicit worker CLI can override enablement but must respect durable cap | Saved SEND_ENABLED=0, SEND_LIMIT=3; durable used=3, limit=3 |
| Twin endpoint | ONLYFANS_BRIDGE_TOKEN required, at least 32 characters; default port4311; loopback-only | Port4311; secret values not inspected or shown |
| Python client | TWIN_BRIDGE_BASE_URL and TOKEN required | URL presence checked, no credential values shown |
| Twin persona/model | GIRL defaults riley; dynamic vars loader; fixed deepseek/deepseek-v4.1-flash through OpenRouter, providers deepinfra/fp8 then together, fallback disabled | GIRL=riley; no VARS_DIR override in saved file or audit shell. Running process overrides were not inspected |
| Twin generation | temperature0.9, top_p0.95, frequency0.2, presence0.1, max output400 tokens; last30 messages; at most2×45s attempts | Source-established; provider availability/behavior unverified |
| Native engine | ai_chatter ships disabled; mode always, payer-only closer, separate gather route for nonpayers; webhook dispatch also opt-in | Local account_ai_config has0 rows and automation_rules has0 rows. No active native responder is established here |
| Native model | Configurable payload/purpose/account/default selection; default deepseek-v4-flash; reply temperature0.85; up to3×120s attempts | Defaults only; no matched configured native persona/model trial |

The two loopback listeners, ports8787 and4311, existed when inspected. Their presence is not proof that a worker is active, that its inherited configuration matches the saved file, or that a remote deployment matches this machine.

Pilot verification was bounded and read-only. SQL selected state/count/commit metadata, not message bodies; Twin files were scanned only for lifecycle metadata. Local records contain three delivered turns, three non-null transcript commits, three distinct provider IDs and three sent attempts with attempt_no1. One prior parked turn remains. There is one conversation, budget3/3; Twin's latest journal contains three delivered/committed records plus one completed draft. This corroborates the reported three-reply pilot in retained local evidence. The platform was not contacted to independently revalidate those IDs; the evidence proves neither long-run reliability nor sales success.

Source shorthand below: F0 means original Fastt in fastt-base-src/service; F means current inflowwkiller/service; T means current twin-sexbot/src. All are beneath the workspace above. Line references identify the inspected symbol boundary; companion reports contain further exact ranges. These aliases avoid conflating original and modified server/of_client lines.

## 2. Architecture and end-to-end comparison

| Stage | A: Fastt + custom bridge + Twin | B: original native Fastt |
|---|---|---|
| Platform intake | Shared per-account WebSocket pump → bounded in-memory queue → raw event → transcoder | Same shared intake; account-bound client/session/pump |
| Identity/normalization | Shared canonical keys, then stricter raw provider-ID validation, UTC conversion, HTML-to-text and scope checks | Creator/fan/message composite keys; native coercion/timestamp handling is weaker |
| Persistence | Canonical message + eligible bridge input in same transaction; unique account/fan/provider-message identity | Canonical Message/Fan/Chat transaction; summaries are not idempotent on duplicate frames |
| Eligibility | Allowlist and both provider/receipt cutoff, free inbound text only; rejects media, paid/tip/GIF/deleted/oversized/unsupported input | Configured native route, account/fan status, blacklist/skip, spend/payer/manual/quiet/SLA policies |
| Scheduling/grouping | Durable pending inputs; 7s quiet window; receive-time + provider-ID order; deterministic burst membership | Webhook jobs or recurring rules; reads current conversation rather than consuming a durable per-input reply key |
| Ownership | Durable conversation reservation, turn owner/revision, expiring claims, send-boundary markers and local coordination | Per-process run locks/semaphores, DB fan lease/cooldown; native job claim and expired-owner fencing incomplete |
| Context | Only post-admission Twin input and acknowledged Twin output, last30; no manual/history/purchase import | Stored platform history, structured profiles/canon, purchase and quote information, question tracking and optional memory enrichment |
| Model | Fixed model/provider/settings; generated draft journaled; failed generation not sent as canned fallback | Configurable model/purpose layer, audit/cost reservation; several optional secondary model calls |
| Validation | Regex safety/style, tag parsing; text-only capability boundary has an unresolved-tag hole | Deterministic output guards, optional persona check, sales/media audits; some guards fail open or differ by route |
| Media/offer | Empty catalogue; free text only, no OnlyFans PPV or purchase event wiring | Native sales planner → catalogue/vault/ownership/price → PPV send; many optional branches have independent enablement |
| Pre-send | Rechecks source/eligibility, current authority, fetched history, manual activity and budget; writes attempt before POST | Native stale check usually precedes typing/pacing; later changes and later bubbles can escape the check |
| Provider request | Dedicated send_text_once; one POST per admitted attempt; literal text escaping, no auto co-tag retry | send_message and other native helpers; generic proxy retry and scheduler replay lack full delivery-uncertainty protocol |
| Platform response | Validated positive provider ID and consistent identity required; ambiguous response → delivery_unknown | Some routes accept missing IDs as completed, or treat ambiguous exceptions as retryable errors |
| Acknowledgement | Confirmed send recorded in SQL, then Twin delivery decision, then transcript commit; retry acknowledgement without repost | Best-effort outbound attribution and subsequent profile/offer/job updates, not one atomic external-send/receipt transaction |
| Recovery | dispatching becomes unknown; does not infer unsent; completed drafts survive; cancellation and partial ack supported | Pending/running job replay and provider/history rediscovery; crash phase is not adequately represented |

Key sources: F0/server.py:_ws_pump_for_account:870; F0/events.py:handle_event:129, _persist_worker:318; F0/event_transcoder.py:339; F/twin_bridge/intake.py:142, turns.py:371, worker.py:199/791/1283; T/channels/service.ts:291/411; F0/automation_executor.py:576/1624/1695; F0/automations/ai_chatter.py:7197/9865/9995.

Manual/scheduled/mass and payment paths:

- Both options retain Fastt's CRM, composer, catalogues, vault, scheduled/mass UI, attribution and payment-related ingestion. These are shared application capabilities, not exclusive B strengths.
- In A, existing native automation can coexist with the bridge. There is no single global mode switch removing all competing writers. Reserved bridge conversations cause instrumented local native/manual/broadcast sends to be refused; explicit manual takeover records a revision change and coordinates in-flight writes. The reservation can be released when work resolves. Running both responders over the same fan population therefore still needs an explicit routing policy.
- Original native manual and scheduled sends are not universally protected by the native fan lease. Provider-scheduled messages execute later outside local transactions. Native mass locks are process-local. A's guard cannot revoke a provider-side schedule or lock the official OnlyFans app.
- A fetches bounded recent history before dispatch and recognizes non-bridge outgoing activity as interruption. The repaired boundary uses the earliest frozen source provider time, floored to milliseconds; older creator messages do not count as a current takeover. Strictly unreadable/incomplete history causes a safe stop. Real official-app activity arriving after the final history check remains an external race; neither design establishes provider-atomic ownership.
- Fastt fetches historical messages into its SQL domain. A's model does not consume those messages automatically. A's separate reconcile_pending function also lacks a production caller, so database catch-up does not automatically become Twin work.
- B's purchase/offer/ownership paths are reachable through native commerce. A retains those in Fastt for native/manual operations, but passes none of that state to Twin's autonomous text context.

## 3. Shared risks and genuine differentiators

| Shared or inherited by both | Genuine A additions | Genuine B autonomous advantages |
|---|---|---|
| Platform signer/session/proxy, WS ingestion, canonical SQLite storage, security weaknesses, schema/deployment and history catch-up limitations | Strict intake identity/scope; durable turn membership, reservation/revision, one-POST path, unknown delivery, persisted cap, draft-versus-delivered transcript | Existing history/profile/canon/purchase-aware context, optional language/style handling, broader native scheduling and connected content/PPV decisions |
| Native manual/scheduled/mass risks wherever those routes are used | Extra Python↔Node protocol, duplicate ledgers, single-writer file store, explicit worker lifecycle, missing reconciliation scheduling and missing OF commerce | One main Python service for the same native feature set; existing relational commerce entities |
| External model truthfulness, provider rate limits/reconnect/acceptance semantics, incomplete production evidence | Fixed simpler generator; narrow text scope reduces action surface but also capability | More decision branches and side effects; richer feature set adds consistency and operating complexity |

A refusal on unreadable history, an exhausted budget or uncertain delivery is not automatically a defect. It protects against a worse duplicate or stale send. It becomes an availability/operational problem when the reason is too broad, has no alert or bounded resolution path, or blocks unrelated work. The unfair formation page is a defect; an unresolved accepted POST waiting for evidence is an intentional safety choice.

## 4. Prioritized material findings

Severity here describes practical consequence and exposure, not a numerical probability. “Test-demonstrated” means the named synthetic boundary reproduced; it never means the real provider was load-tested. Small/medium/large scope means a localized change / several coordinated modules / architectural or release work, not an estimated delivery date.

### F1. Shared event, cache and administrative boundaries are unsafe for public tenancy

**Both; original/shared; critical at public tenant exposure. Confirmed defects plus an intentional unsafe administration tradeoff.** Unauthenticated WebSocket acceptance exposes all synthetic accounts/events; SSE accepts a malformed cookie through the perimeter and skips tenant isolation. Cache hits can return private media before account authorization. Concurrency configuration and PID1 restart routes deliberately bypass authentication.

Sources: F0/server.py:ws_events:9038; F/server.py:9070, _share_token_gate:505, account-isolation exclusions:329, image cache:3299; F0/events.py:207/432; F/lane_config_api.py:187/277; app/next.config.ts:95/126. The security probe exercised original and current real function bodies with fake sockets/requests and synthetic accounts. No external endpoint was attacked; actual proxy reachability remains deployment-dependent. A known cached reference is required for the cache finding; enumeration is not claimed.

Fix direction: authenticate and authorize every transport/cache hit, derive scopes server-side, restrict operator actions and cap connections. Medium cross-cutting work. Detection is poor if leaked subscriptions look like ordinary clients; copying original retains the holes.

### F2. Original native accepted-send recovery can duplicate or silently retire work

**B autonomous and both options' retained native sends; original; high. Confirmed recovery defect under ambiguous acceptance.** A fake provider accepted a scheduled POST then raised timeout. Real scheduled_send/run_once requeued and posted the same payload again: two recorded POSTs. A response without ID retired the job as done/sent_no_id. Native conversational delivery has analogous missing durable phase evidence, though the complete conversational retry was not dynamically reproduced.

Sources: F0/automations/scheduled_send.py:83/133; automation_executor.py:617/1653/1695; ai_chatter.py:9993/10026; attribution.py:438. Attribution DB errors are swallowed, so they can lose local outgoing evidence rather than themselves force a retry. Generic OFClient proxy retries are a further **credible** risk if ProxyError can follow transmission; that exact curl/provider failure was not reproduced.

Fix direction: durable send intents, receipts, explicit unknown outcomes and reconciliation across all native senders. Large coordinated scope. A's send_text_once plus ledger materially improves its own text path; it does not automatically fix native PPV/mass paths.

### F3. Original multi-process claims and lease release are unsafe

**Both shared native scheduler; B native responders; high when multiple supervisors or expired owners overlap. Confirmed defects with specified conditions.** Two actual _claim_due_job calls against temporary SQLite both claimed job1; the attempts counter advanced once. Startup requeues all running jobs without checking owner liveness. A stale release can delete a successor's same-kind fan lease. Initial unexpired lease acquisition correctly rejects overlap, which is a useful positive control.

Sources: F0/automation_executor.py:271/336/576/1624/1695. Single-process deployment avoids the duplicate-supervisor trigger; “add workers” is not a safe scaling setting. Scheduled human/mass paths do not all acquire the fan lease.

Fix direction: atomic conditional job claim, unique lease generation, renewal/fencing and owner-aware recovery; separate scheduler/pump ownership from web startup. Medium-to-large scope. Errors can remain invisible until duplicate sends occur.

### F4. Shared intake is lossy and bounded history catch-up can skip a permanent gap

**Both; original/shared; high under queue overflow, persistence errors, restart or large catch-up intervals. Intentional lossy queue tradeoff plus confirmed recovery defect.** The 2,000-item RAM queue drops its oldest item before persistence, shutdown cancels without draining, and processing exceptions are logged then discarded. A raw-event processed/retry API exists but has no live replay consumer. A's transactional intake begins too late to fix this preceding loss.

F0/events.py:158/335/366 and db/repo.py:127. The exact overflow branch was demonstrated using capacity2, not a throughput benchmark.

The recovery fetch collects newest100 then advances high-water to the newest ID. With synthetic IDs250 downward and prior cursor1, it returned250–151, then a subsequent catch-up from250 returned zero, leaving2–150 missing. F0/automation_executor.py:1191/1353/1170. Default account discovery is also bounded to100 recent chats. This is distinct from intentionally sampling initial history.

Fix direction: durable ingest/replay/backpressure and contiguous recovery cursors with continuation/progress checks. Medium-to-large scope. Alerts must cover missing work and oldest pending age, not only process liveness.

### F5. A's tested intake reconciliation is unwired in production

**A; custom bridge integration; high availability gap. Missing capability, code-established.** reconcile_pending can recover eligible committed messages that lack bridge inputs, and its tests exercise this. Search found calls only in tests; the worker, pilot and CLI do not invoke it. Shared REST/history persistence does not call the WS-only enqueue hook. A missed event or later REST-recovered input may exist in messages yet never reach Twin.

Sources: F/twin_bridge/reconcile.py:80; worker.py:199–260; event_transcoder.py:53/548; all reconcile_pending callers inspected. The atomic hook also rolls back canonical ingestion if bridge insertion fails; the lossy event worker then requires independent recovery. Atomicity is correct, but automatic replay is absent.

Fix direction: schedule bounded checkpointed reconciliation and connect every canonical ingestion route through an idempotent inbox, with visibility for refused records. Medium scope. Native B can use recovered SQL history in candidate selection; its own history-gap limitation still applies.

### F6. A's Twin store can delete a competing writer's committed state

**A; custom store; high if two processes write the same creator directory. Confirmed defect, test-demonstrated.** writeState chooses a sequence, opens with exclusive creation, then its failure handler deletes that filename even when the open failed because another writer already created it. A controlled interleaving using the real writeState deleted the competing committed snapshot and made the old state authoritative again. This can roll back delivery/memory evidence.

Sources: T/channels/store.ts:358/370/387. Related code risk: startup recovery treats another run ID as dead; http.ts:549 performs recovery before its port bind at555, so an accidental second launch can alter claims even if it then fails to bind.

Fix direction: owned-file-only cleanup plus enforced process/store exclusivity immediately; transactional versioned storage for commercial scaling. Small containment, large eventual redesign. A correctly enforced single writer was not shown to exhibit this interleaving.

### F7. A's global formation page lets one fan starve another

**A; custom turns; high for multi-fan scope, not exposed by singleton pilot. Confirmed defect.** A continuously active fan occupies the oldest100 pending rows. form_turns repeatedly reads that page, holds the open burst and never visits another quiet fan outside it. Three real formation passes left the quiet fan unanswered at55/61/67 seconds; changing only the page to500 allowed that fan's turn to form. Continuous traffic can sustain the condition; there is no maximum wait policy.

Sources: F/twin_bridge/turns.py:137/371/393/429. The5,000-row burst-walk bound does not force closure while newest input is still inside the quiet window. The probe used real SQLite/functions, no generation or sends.

Fix direction: fair per-conversation ready queue, bounded burst age and overload policy. Medium scope. Raising a page size is not a general fix.

### F8. A's supposedly non-increasing send cap can widen under concurrent updates

**A; custom coordination; medium, high if relied upon as a hard safety ceiling. Confirmed conditional race.** Two workers read cap5, stricter2 commits, then a stale calculation commits4. set_budget_limit uses SELECT then unconditional UPDATE, and is called before acquiring conversation ownership.

Sources: F/twin_bridge/coordination.py:1319–1334; worker.py:399–406. Real SQLite deterministic concurrency probe reproduced2→4 without sending. Current singleton pilot with one cap is not the demonstrated trigger; consumed budget was not reset.

Fix direction: SQL-side atomic minimum/CAS tied to used/reserved budget, consistent configuration ownership. Small-to-medium scope.

### F9. Explicit no-contact and durable adult-service safety controls are incomplete

**Both, through different engines; high. Missing durable boundaries, with tested transitions.** Twin filters an age disclosure for that turn before retaining it as input history, then the next neutral message reaches generation with no durable exclusion. Its prompt nevertheless assumes prior adulthood confirmation. The synthetic test generated no sexual content. The channel has no persistent global contact opt-out.

Sources: T/turn.ts:119, channels/service.ts:131, girls/template.ts:31; safety.ts. B recognizes “stop messaging” as a hard decline, but the tested native transition pauses offers72h and returns ladder state to idle, not a global no-contact state. Its dedicated hard-decline branch also depends on a disabled-by-default qualification gate; other complaint paths can enqueue an apology while continuing operation.

Sources: F0/automations/upsell.py:205/332; ai_chatter.py:5730/7942; _objection.py:179. Affordability/declining one product is different from refusing further contact.

Fix direction: explicit persisted age/safety/consent/handoff state enforced by every sender immediately before dispatch. Medium cross-lane scope; output politeness and prompt instructions cannot substitute.

### F10. A's platform/capability instructions do not match the OnlyFans integration

**A; existing Twin prompt reused by custom route; medium-to-high trust/sales impact. Confirmed integration/validation defects; frequency is model-dependent.** The reachable prompt describes Telegram, Telegram Stars and media capabilities, while the bridge supplies an empty catalogue and cannot send PPV. A stubbed “here is the photo [photo 1]” became a deliverable “here is the photo” after its unresolved tag was stripped.

Sources: T/girls/template.ts:31/57/66/77; turn.ts:163; channels/service.ts:299/369; channels/text-turn.ts:38. This proves an output-validation hole, not a measured tendency of the configured model.

Fix direction: channel-specific capability/payment facts and action/prose consistency validation; medium scope. Historical messages, manual replies, purchases and entitlements also need explicit context integration before selling.

### F11. Native stale checks and partial-bubble accounting leave unsafe gaps

**B native autonomous, including native routes retained in A; original; high under concurrent input or partial send. Code-established.** ai_chatter checks conversation movement, then waits typing/pacing—including some45–115s holds—and sends without rechecking each bubble. New messages/human intervention during the gap can receive stale output. First-bubble missing ID is treated differently from later missing IDs, so an earlier sent_ok can let a partial turn advance and create offer metadata without confirming its final media bubble.

Sources: F0/automations/ai_chatter.py:3642/9865/9988/10026/10261; replay:5194/5201; autoreply.py:857; welcome_chatter_for_info.py:2175. Official-app outbounds are skipped by WS canonical ingestion and ambiguous unattributed outbounds are excluded from some native stale checks.

Fix direction: persistent plan/turn revision and per-bubble receipts, final authority validation and cancellation. Medium-to-large scope; do not port native direct-send helpers into A as if they were pure planners.

### F12. Conversation memory and factual grounding have material limitations on both sides

**A:** last30 only, no history import, no persistent semantic summary/facts/correction policy; confirmed missing capability and simplicity tradeoff. The real context test omitted an older preference and verified drafts are absent until acknowledgement. T/config.ts:37; turn.ts:137; channels/service.ts:142/186.

**B:** richer memory, but gen_info merges old+fresh events then keeps the first20. The real persistence transformation discarded a new event from the flat memory once full; the separate timeline is not used by those readers. Immediate extraction fills empty facts only; later refresh can overwrite, so corrections are delayed/model-dependent rather than wholly impossible. F0/automations/gen_info.py:834/846; welcome_chatter_for_info.py:1398. Medium defect/risk, small transformation fix plus medium provenance work.

B also generates fictional daily activities from tone seeds and can treat prior creator claims as truth for that fan. F0/automations/_daylog.py:637/668/738; _persona.py:392. This is an implemented product-policy risk, not evidence of good naturalness. Ground personal facts in creator-approved information; do not retain false claims merely for consistency.

### F13. Populated database startup can report success without required schema migration

**Both; original/shared; high for affected legacy schemas. Confirmed defect, test-demonstrated.** init_db does not execute the Alembic chain. A synthetic populated legacy llm_daily_costs table acquired a provider column but retained its old primary key; the current provider-scoped ON CONFLICT then failed. Both original/current startup functions returned success and left the old revision.

Sources: F/db/engine.py:143/162/173/215; migrations/versions/20260604_0200_llm_provider.py:67; models.py:2256; llm_client.py:535. This does not establish that the pilot database has that particular old key. New bridge tables and the reserved column with server_default are compatible with the additive catch-up.

Fix direction: canonical migrations, schema compatibility checks, populated upgrade fixtures and tested roll-forward/restore. Medium-to-large deployment work; blindly executing migrations against inaccurately stamped databases is not a safe audit action.

### F14. Shared build, credential and recovery practices are not production-grade

**Both; original/shared; high under exposure or abrupt replacement.**

- Confirmed plaintext user/chatter password handling and incomplete copied-session revocation: F/auth.py:516/540/555; chatters.py:436/471. Password values were not read. Medium authentication migration.
- Confirmed packaging exclusion gap: Dockerfile:52 copies service; .dockerignore excludes root .env but not service/.env or service/secrets. Building from this populated workspace could bake credentials/config into layers. No image was built or inspected. Small packaging fix plus verification if prior exposure is established. [Docker's pattern semantics](https://docs.docker.com/build/concepts/context/#syntax).
- Credible crash durability risk: docker-compose.yml:112 mounts only chatterly.db, while engine.py:109 enables WAL/NORMAL. Abrupt replacement can discard committed WAL outside the mounted file. SQLite explicitly treats WAL as persistent state. Small volume correction plus substantial restore validation; no crash-container test performed. [SQLite WAL behavior](https://sqlite.org/wal.html).
- Runtime dependency condition: audit Python3.13 uses SQLite3.50.4; legacy3.11 uses3.45.1. SQLite documents a rare concurrent WAL-reset corruption issue fixed in3.51.3, including3.50.7 backport. No corruption reproduced; actual container SQLite unknown. Verify and patch the effective production library rather than assuming Python version suffices. [SQLite's advisory](https://sqlite.org/wal.html).

### F15. Scale, retention and failure containment remain structural blockers

**A store; both operations; high at broad scope. Operational assumptions/missing capabilities, code-established.** Twin scans the entire creator directory per read/write, rewrites and fsyncs all historical request records, and retains two snapshots without pruning the cumulative journal. Startup repeatedly scans the directory for every conversation. One corrupt newest journal can fail global recovery before listening. F/T specifics: T/channels/store.ts:130/307/354; service.ts:225; http.ts:549. This is safe refusal with too large a failure domain.

Fastt does have retention: raw events2d, message raw payloads60d, run logs14d, model logs30d, terminal jobs7d, actions/quota90d. Normalized messages/fans remain. These are not complete deletion or backup policies; large sweeps can hold SQLite's writer. F/server.py:2769/2841/3098. A adds unrotated full-context logs and an optional monitor without application authentication; loopback/tailnet exposure determines risk. T/turn.ts:68/139; dashboard/server.ts:159/178/196.

Fix direction: indexed transactional storage, bounded maintenance/recovery, per-tenant quotas, coordinated backups and retention/deletion that preserve minimal idempotency tombstones. Large architecture/operations work. Resetting a transcript does not erase logs or delivery records.

### F16. Model cost/telemetry and commercial effect remain inadequately established

**Both; model/configuration/external behavior; medium operating risk.** Twin's real retry test made2 stub calls but returned usage.attempts0 because the journal does not copy attempts. T/channels/store.ts:438; service.ts:378. Small telemetry defect. Native llm_client's output estimate is not an output-token request limit; retries/secondary calls can expand latency and spend. F0/llm_client.py:827/872. Provider-reported usage on failed calls may be incomplete for either system.

Neither codebase establishes better conversion, lifetime value, margin, complaint rate or staffing requirements. Capability and source-level cost controls are inspectable; these commercial outcomes require actual outcome data.

### F17. A's conservative stops and immutable turns need a complete operating workflow

**A; custom worker; medium/high availability and response-relevance impact. Intentional tradeoffs plus missing operational capability.** Transient history/status-read failure can permanently park a turn; assigned input is not automatically revisited. Parked is excluded from unresolved work, so later turns may proceed. In contrast, delivery_unknown properly keeps the conversation reserved/paused, but no inspected CLI action provides a complete evidence-based resolution of that bridge attempt. recover marks uncertainty; reconcile-writes concerns legacy write markers, not bridge delivery resolution. Broad deployment would otherwise require ad hoc intervention in authoritative state.

Sources: F/twin_bridge/worker.py:864/911/1350; coordination.py:1349; cli.py:200. The pilot reports turn-parked and stops, so this is not asserted to be silent in the pilot. Fix direction: bounded retry of provably pre-send reads, alerts and an audited resolve-confirmed/resolve-not-sent workflow that preserves caps and receipts. Medium-to-large operational work.

New inbound arriving during generation is queued as another immutable turn; it does **not** automatically invalidate the existing draft. Source withdrawal, manual takeover and authority changes are separately rechecked. This is a meaningful relevance weakness against a well-timed B stale check, and a gap for stop requests arriving mid-turn. Neither system establishes a universal “latest customer intent wins at the wire” rule. A needs an explicit pending-turn supersession/consent policy, not merely more retries.

Additional boundedness mismatches: preflight normally fetches10×20=200 history rows, despite a separate1,000-item maximum. A very large burst can require more source IDs than preflight can prove and be parked. Changing the whole allowlist changes the scope fingerprint of existing conversations; onboarding is not a transparent scope expansion. These are safe boundaries with substantial operating consequences (platform.py:184/281; turns.py:67; worker.py:378).

### F18. A's default client and worker lifecycle is pilot-oriented

**A; custom; medium sustained-operation risk. Confirmed lifecycle omission; resource exhaustion unmeasured.** Default run_once creates an httpx-owning TwinBridgeClient on every pass and never calls its aclose API. The pilot passes client=None repeatedly. Open-conversation discovery is unbounded and processing is serial; batch_size limits formation, not pass duration. Source validation repeatedly scans historical conversation membership. The supported autonomous pilot requires exactly one fan and lasts at most one hour.

Sources: F/twin_bridge/worker.py:224/317/455/1121; client.py:238/259; pilot.py:81/120. Fix direction: owned reusable client with finally-close, fair scheduled work and indexed bounded scans; small lifecycle correction, large production worker redesign. The bridge's coordination/dispatch explicitly requires on-disk SQLite; it is not a tested PostgreSQL URL switch.

## 5. Common failure-mode and conversation scenario matrix

This is one matrix applied to both complete systems. “Test” refers to the boundary described in section8; other entries are code-established/inferred behavior. No mocked sentence was scored for conversational quality.

| Scenario | A behavior and limitation | B behavior and limitation | Evidence |
|---|---|---|---|
| New fan, no history | Persona + new text, no imported platform context | Gather/nonpayer route; payer-only closer is not universal coverage; requires configured rules | Code |
| Returning fan, long conversation | Only its own latest30 messages | Native stored exchanges plus profile; default40-row/12h window with6-row floor | Code; context/window tests |
| Preference mentioned much earlier | Gone outside retained window unless repeated | Available if extracted into profile/facts; middle of mining history can be omitted | Code; A exclusion test |
| Incorrect/conflicting memory | No structured correction policy; recent statements left to model | Immediate fill-empty logic may preserve error; later gen_info/operator update possible; recent-event cap bug | Code; native memory test |
| Several messages quickly | Wait7s quiet, deterministic grouping/source-boundary size split | Reads current history, native dispatch delay/cooldown/pacing vary | A tests; B code |
| Continuous burst / hot fan | Can defer own reply indefinitely and starve another fan beyond first100 | Bounded tick/sender capacity and candidate selection; no demonstrated global fair-tenant guarantee | A fairness test; B code |
| New input while generating | Old frozen draft remains eligible unless other invalidation occurs; newer input waits | Can abandon draft if newer inbound is already persisted at stale check; later/same-time input can escape | Code |
| Long silence then new message | No elapsed-message timestamps in model context; recent window only |6-row floor and rhythm/old-fan policies; no guarantee of natural return greeting | Native pure window test; code |
| Creator manually intervenes locally | Checked takeover/revision invalidates unsent work; refuses unresolved send | Selection hold/cooldown and stale check; no universal final-wire fence | A ownership tests; B code |
| Creator intervenes through official app | History catches already-visible relevant outgoing; race after check remains | Outgoing WS persistence incomplete; fetched/unattributed evidence imperfect | Code; external race unverified |
| Old outgoing appears in history | Correct earliest-source boundary ignores older messages; equal/newer interrupts | Native stale check uses later timestamps; shared timestamp defects remain | A history tests; B code |
| Duplicate inbound via WS/REST | Bridge key/membership dedup; shared summary side effects still wrong; REST intake hook missing | Message row dedup, but unread/latest/dispatch side effects repeat | Real SQLite tests |
| Out-of-order inbound | Receive-time ordering, not restoration of provider chronology; normalized raw timestamps retained | Native history uses timestamps; shared latest summaries can regress | Code; transcoder test |
| Unicode/HTML/malformed IDs | Strict UTF-8/string-ID/size contract; tags removed before entity decoding; output escaped literally | Native parsing/coercion varies by route; no equivalent end-to-end strict contract proved | A contract/intake tests; B inspection |
| Future/offset timestamps | Offset normalization works; no future-time sanity ceiling; history/quiet policies may stall | Shared parser strips offset; missing time can become receipt-now | A tests; original parser test |
| Long/oversized messages | Single text above4,000 UTF-16 units excluded; aggregate split at source boundaries;16KiB request cap | Per-history/body clipping varies; end-to-end input/token limits less consistent | Code; A tests |
| Model timeout/malformed response | Max2 model attempts; transport status recovery by same identity; bounded stop on failed/invalid draft | Max3 HTTP attempts plus optional secondary calls; failed generation skips/retries by route; some checks fail open | A unit tests; B code |
| Platform accepts, response lost | Unknown/paused/reserved, cap consumed; no automatic repost | Native scheduled path requeues and can repost; native conversation ledger absent | A delivery tests; original repeated-POST test |
| Platform sends successfully, Twin ack lost | Durable sent evidence; retry ack only; transcript commit idempotent | No equivalent cross-service ack; attribution/job/offer steps can fail independently | A recovery/roundtrip tests; B code |
| Worker restart during turn | Source/turn/attempt/cap durable; abandoned POST unknown, confirmed evidence repairs sent; interrupted Twin generation may park | Running jobs globally requeued; draft may be lost or separately deferred; accepted-send phase not represented | A recovery tests; original orphan test |
| Two workers/processes | SQL controls protect many Fastt boundaries; cap race remains; two Twin writers unsafe | Same job can be claimed twice; stale lease release and process-local guards | Targeted concurrency tests |
| Price question/objection | No OF product price data; Telegram instructions conflict | Real product/price/decline policies, some disabled by default; no evidence of optimal persuasion | Code |
| Previously purchased content | No purchase context in Twin route | Ownership filters across messages/transactions/vault/offers, dependent on ingest completeness | Code |
| No suitable product/content | Empty menu says do not offer, but unresolved tag can leave false claim | Strict resolver refuses; non-strict request may use framed substitute; relies on catalogue accuracy | A validation test; B code |
| Declined offer / request to stop | No persistent no-contact enforcement; model/operator dependent | Offer pause/cooldown is not global no-contact; apology path may continue | Native transition test; A inspection |
| Unsupported capability/custom request | Text route cannot execute media/payment action; prose may overpromise | More actual capabilities, custom-work handoff/owed-work constraints, human refund flags; unsupported prose still possible | Code |
| Session expiry/provider unavailable | Shared reconnect/health gates plus bridge parks/uncertainty; no live expiry test | Shared reconnect/backoff and health pauses; no verified provider outage recovery SLO | Code, unverified external behavior |
| Corrupt store / failed upgrade | Twin fail-closed startup can stop all creator conversations; shared schema gap | Shared schema gap and DB recovery assumptions | Twin corruption tests; schema test |

## 6. Commercial scale: assumptions, bottlenecks and capacity reasoning

One million people is not a load specification. The following are deliberately different workloads. A “conversation” is an account–fan pair; one human following several creators creates several such pairs. These are planning assumptions, **not measured capacity**.

Common assumptions: two inbound messages coalesce to one reply on average (reply ratio r=0.5),3-message/2-second bursts,10× peak/average daily traffic unless specified. A hot-tenant sensitivity concentrates50% of traffic on1% of creators, a50× per-hot-creator multiplier relative to uniform load. Planning latency target: p95 reply within30s after a completed burst and no unnoticed backlog older than2min. These are proposed service targets, not user-provided requirements or achieved results.

| Scenario | Creators/accounts and active pairs | Input assumption | Derived average / peak inbound | Derived reply demand |
|---|---|---|---|---|
|1m registered fans |1,000 creators;1,000 registered each;1% daily active →10,000 active/day,10/creator |20 inbound/active/day |200,000/day;2.31/s average;23.15/s peak |100,000/day;1.16/s average;11.57/s peak |
|1m daily active fans |10,000 creators;100 active/day each |20 inbound/active/day |20m/day;231.48/s average;2,314.81/s peak |10m/day;115.74/s average;1,157.41/s peak |
|1m simultaneous active conversations |10,000 creators;100 concurrent each |One inbound/60s during active plateau; sensitivity30–300s |16,666.67/s base;3,333–33,333/s sensitivity;3× synchronized burst gives50,000/s base peak |8,333.33/s base;25,000/s burst; this is a concurrent plateau, not an assumed24h daily profile |
|Many creators/tenants |100,000 creators;10 registered fans each;1 active/day each →100,000 active/day |10 inbound/active/day;8× peak |1m/day;11.57/s average;92.59/s peak |500,000/day;5.79/s average;46.30/s peak; per-account polling may dominate |

Sensitivity: r=0.25–1 multiplies reply/model/POST demand by0.5–2 relative to the table. The1m-registered case at0.1–10% daily activity spans20,000–2m inbound/day. Thus even the “registered” case can vary100× without changing its registered count. Geography and celebrity concentrations can dominate averages.

### Service and provider budgets

For reply rate λ and mean generation duration L, at least λ×L simultaneous generation slots are occupied, before retries, secondary calls and latency headroom. Twin's HTTP default admits4 reply requests; the current Python worker visits conversations serially, so actual orchestration can be more restrictive than4/L. At assumed L=5s,4 slots imply at most0.8 replies/s before all other work; this is an arithmetic ceiling, not a measured result. For the1m-DAU peak, roughly5,787 occupied slots would be needed at5s, or23,148 at20s, before headroom. Increasing a semaphore cannot establish safe database/provider capacity.

A pre-send history walk adds normally1–20 provider GETs per reply; source coverage may fail before the1,000-item cap because the page limit normally allows200 rows. At the1m-DAU peak, one POST plus H history GETs means approximately2,315–24,306 provider requests/s for H=1–20, excluding polling, reconnect, media and other Fastt work. The provider's allowed rate and stable pagination behavior were not measured. B already refreshes/scrapes profiles, transactions and catalogues and may send several bubbles plus PPV; its amplification is different and not inherently lower in every configuration.

Polling amplification is account_count / polling_interval before page expansion.100,000 accounts polled once/30s already require3,333 account polls/s even if their fans are quiet. WebSocket subscriptions, proxies, auth refresh, session files and account health become fleet-management work. Neither repository demonstrates that fleet.

With queue capacity2,000, a stalled shared persistence consumer at2,315 incoming/s fills it in about0.86s; with consumption μ below arrival λ, time-to-fill is remaining_capacity/(λ−μ). This illustrates why the current lossy queue cannot be made reliable by a larger buffer alone. A10-minute outage at the1m-DAU average creates about138,889 inbound events before catch-up and amplification.

### Context, model cost and storage

Use input-context sensitivity2,000–12,000 tokens and output50–200 tokens/reply, with current Twin maximum400. These are workload assumptions; neither token distribution nor mean latency was measured. Fixed30-message context is not a fixed token count. Native profiles, catalogues, fact extraction, persona checks and vision can add separate calls. Let a be average model-attempt/secondary-call cost multiplier, pin/pout the actual price per million tokens:

    model cost/day = replies/day × a × (Tin × pin + Tout × pout) / 1,000,000

At10m replies/day and a=1, this implies20–120billion input and0.5–2billion output tokens/day. There is no fetched-price assumption and no fabricated dollar margin. Failed calls may incur uncertain cost; model savings cannot compensate for unmeasured refunds, support or lost customers.

Assume2KiB per normalized message record before indexes/raw envelopes/ledgers/backups. Inbound+outbound records at r=0.5 give approximately0.61GB/day in the registered baseline,61.44GB/day at1m DAU, and3.07GB/day in the many-creator case. A one-hour concurrent plateau at the60s interval produces60m inbound+30m outbound records, about184.32GB. At0.5–8KiB per record these values vary0.25–4×. These are byte formulas, not measured row sizes.

Fastt additionally keeps raw input and LLM logs for the retention windows above; A duplicates input/draft/evidence across SQL and Twin journals. If an average retained Twin request record were3KiB,10m new turns add30.72GB logical journal content, roughly twice that in two full snapshots before backups. Worse, rewriting a growing conversation's full history each transition creates cumulative quadratic write amplification over its lifetime. Only the short transcript is bounded.

For C conversations per creator and R requests in a conversation, Twin reads/mutations require O(C+R) work from directory enumeration and full-state parse/serialize; startup can require O(C²+sum R) filename processing. One million inactive historical conversations under one creator is therefore a recovery problem even without one million simultaneous calls. This is code complexity, not a clock-time benchmark.

Recovery targets must include consistent Fastt SQL/Twin journal snapshots, provider reconciliation and backlog drain. A hypothetical1TB copy at sustained100MB/s takes about2.8h before validation/replay; neither speed nor target is achieved evidence. Restore only one A ledger and the two services may disagree about whether a message was delivered. No RPO/RTO has been demonstrated for either.

### What fails first and what scaling requires

| Dimension | A | B |
|---|---|---|
|Current intended operating shape | One scoped account/fan pilot, finite cap/duration, one Twin writer, serial Python passes | Single FastAPI process/local SQLite, configured native rules, process-local pools and account sessions |
|First likely bottlenecks | Serial generation/history work, starvation, global file scans/journal fsync,4-slot adapter; inherited SQLite/pumps | Native scheduler/candidate scans, shared SQLite writer and global lanes, model/pacing/provider budget |
|Horizontal expansion | Requires replacing file store and SQLite-specific coordination, fair partitions and explicit service ownership | Requires atomic jobs/fenced fan leases, separating pumps/supervisor, database/dialect port and tenant partitions |
|Ordering | Durable source membership and immutable turns; weak supersession semantics | Timestamp/history selection with leases; no durable per-turn/per-bubble receipt protocol |
|Overload/failure containment | Explicit HTTP429 and uncertain-send stops are useful; per-fan starvation, account-wide broadcast block and global corrupt-store startup are too broad | Bounded lanes/health gates useful; lossy ingress, unscoped subscribers, large shared sweeps and retry ambiguity are too broad |
|Multi-tenancy | Strong local identity tuple; shared app leaks remain, one service token/creator scope, no fair fleet scheduler | Useful account keys/authorization in many paths; demonstrated event/cache bypasses and noisy-neighbour global resources |

Classification for all four workloads: **A suitable as currently implemented:** only its explicitly bounded pilot shape has corroborated live evidence, not these workloads. **B suitable as currently implemented:** no broad autonomous deployment demonstrated; native supervised functionality exists. **Suitable after engineering:** the selected domain models and delivery principles are reusable after the named changes, not a warranty that a patch list achieves scale. **Not demonstrated:** capacity, latency, error rate, provider budgets, fleet isolation and recovery at every million-user interpretation.

Effort/risk: production hardening spans authentication, transport, consent, migrations and operations in both. A adds a significant storage/scheduler consolidation; B adds pervasive delivery-intent/receipt and ownership changes. Million-DAU/concurrent operation is an architectural program with staged correctness/performance gates, not a “larger server” task. No honest calendar or headcount estimate follows from this audit alone.

## 7. Conversation and sales capability assessment

| Capability | A autonomous path | B native autonomous path |
|---|---|---|
|Creator-specific voice/facts | Reachable persona variables and style cleanup, one configured creator | Per-account prose/canonical facts/language/voice; some fact blocks gated on detected question |
|Recent delivered continuity | Strong separation of draft and acknowledged output;30-message window | Broader platform history but post-send attribution may be missing;40-row/12h/floor6 default |
|Historical and long-term memory | Missing import/summary/fact retrieval | Implemented scrape/profile/extraction paths; completeness and freshness defects |
|Fact contradiction/correction | Model-dependent within window | Fill-empty immediate extraction, overwrite on refresh/operator correction; no complete provenance/conflict resolver |
|Questions, slang, ambiguity, language | Mainly configured model; English regex/style heuristics | Model plus quote context/question tracker/language-specific guards; no measured comprehensive language accuracy |
|Naturalness/repetition | Deterministic cleanup can make style consistent but also flatten useful structure | More pacing/bubbles/echo checks; generated typos/daily life do not establish honest naturalness |
|Offer intent/timing | Prompt-only; cannot execute OF sales | Reachable on-ask planner, regex/model signals, ladder/cooldown/spend policies; false positives remain possible |
|Catalogue/matching/description | Empty catalogue in OF path; broader Telegram keyword menu is unwired | Curated shelves/full vault, content contract/audit, preference matching and substitutes |
|Price/discount/budget | No OF data or entitlement workflow | Prices/discount rules, offer/count/spend bounds; some qualification caps disabled or unwired |
|Ownership/repeat-sale avoidance | No OF purchase event in channel | Media ownership/seen/purchase evidence and resale rules; missed purchase linkage undermines correctness |
|PPV/media delivery | Missing in bridge | Implemented; send/recovery limitations in findings |
|Refund/access support | Missing in bridge | make_right incident handling and human refund flags; it does not itself execute refunds |
|Handoff/stop | Operator cancel/pause/takeover exists; no global semantic opt-out | Spend/manual/skip/handoff policies; hard decline does not equal no-contact |
|Analytics/experimentation | Shared Fastt dashboard remains; Twin logs, no integrated sales attribution | Revenue/cost/run/quote/price-arm records and offline replay tools; not causal effectiveness proof |

B's strongest connected sales path is on-ask vault planning. Overall ai_chatter is disabled by default; prompt_sell_catalog=False and qualification_gate_enabled=False. pack_send_enabled and pack_on_ask_enabled are true inside an enabled responder. Thus the repository has implemented but disabled branches as well as active-by-default subcomponents. It is incorrect to attribute every sales helper to every generated reply.

The native path is: classify/gate → SellLane.plan → contract/catalogue/ownership/price → content audit → conversational text → final media re-audit → PPV POST → attribution/VaultSend/ContentOffer → transaction/ownership reconciliation. A locked message offered successfully is not proof of purchase or payment. Some source comments blur that distinction; the audit does not.

For commercial outcomes, code supports judgments about available controls, catalogue wiring, context limits, cost instrumentation and failure risks. It cannot determine conversion, net margin, retention, repeat purchasing, refund/complaint rates or operator hours. No real conversation content was inspected for quality and no external model comparisons were authorized/executed. Therefore there are no X/Y output scores; inventing anonymized mock scores would be misleading. A matched blind replay would compare the engines under the same model first, then the actual configured combinations separately.

## 8. Diagnostics, commands, results and limits

All original-source diagnostics avoided full application import. AST extraction executes the actual selected production function bodies, with inspected dependencies and explicit mocks; it is not a reimplementation of the algorithm. It proves those boundaries, not full ASGI/deployment composition. Existing bridge tests use temporary SQLite, mock integrations and inspected runners that propagate assertion failures through nonzero exit status. Audit defect probes exit0 when their expected defect observations are reproduced: that is not a product pass certificate.

PY below is C:\Users\conta\AppData\Local\Temp\of-preflight\venv\Scripts\python.exe (Python3.13.16). AUDIT is the directory containing this report. SNAP is AUDIT\twin-source-snapshot. Commands are records of completed diagnostics, not instructions to activate a live service.

|Diagnostic / suspected failure and correct behavior |Command / actual boundary |Mocks/exclusions and result |What it establishes|
|---|---|---|---|
|Original claim/recovery/intake: no duplicate claim/repost, preserve newest metadata and catch-up continuity |PY AUDIT\original_fastt_diagnostics.py |Original function bodies + real temp SQLite; fake provider accepted then timed out; no app/network. Exit0, observations in JSON |Same job claimed twice; stale release; duplicate/latest corruption; offset bug; queue drop; two POSTs; sent_no_id done; skipped catch-up gap. Also positive live-lease rejection |
|Public streams: reject unauthenticated/foreign tenant data |PY AUDIT\security_boundary_probe.py |Real gates, cookie parser/middleware, stream/broadcast functions; fake requests/socket/registry; original+current. Exit0 |Missing authentication/scoping at those boundaries. Does not test public proxy routing |
|Populated migration: current conflict target should work after successful init |PY AUDIT\schema_upgrade_probe.py |Actual init_db + model declarations, real disposable populated SQLite; no server. Exit0 |Both snapshots retain incompatible legacy PK; current SQL conflict target fails |
|Native stop/memory/silence |py -3.13 AUDIT\fastt-sales-diagnostics.py |Actual classifier/transition/_persist with fake SQL sinks; pure history window. Exit0 |Offers-only72h pause; new event lost after20;6-message floor after long silence |
|Bridge history: old outgoing must not interrupt, missing/looped history must refuse |PY service/tests/test_twin_bridge_history.py |Real adapter walker with fake provider pages.141 checks passed |Boundary repair, source coverage and cursor handling; no real provider guarantee |
|Bridge intake/turn/delivery/ownership |PY service/tests/test_twin_bridge_{intake,turns,delivery,ownership}.py, run individually |Python dotenv disabled; disposable DB before imports; model/cache/HTTP seams mocked.165/83/115/205 assertions passed, exits0 |Real state boundaries and relevant regression cases, not provider realism or a quality score |
|Bridge fairness: quiet fan should be admitted despite hot fan |PY AUDIT\bridge-starvation-probe.py |Real formation/SQLite; synthetic times/messages. Exit0 |Three blocked quiet-fan passes and larger-page positive control |
|Budget: simultaneous tightening must never widen cap |PY AUDIT\bridge-budget-race-probe.py |Real update functions/sessions, controlled post-SELECT interleaving. Exit0 |Cap2 overwritten by4 after both read5; no sends |
|Twin identity/recovery/HTTP |node --import tsx SNAP/scripts/check-channel.ts; check-recovery.ts; check-http.ts, individually |Source-only copy, no .env/data/logs, temp state, mock fetch and ephemeral loopback.133/267/136 checks passed |Input/identity, draft/ack recovery and adapter behavior. Some HTTP operations are stubs; no provider |
|Twin competing writer/context/safety/action/telemetry |node --import tsx SNAP/scripts/audit-diagnostics.ts |Actual store/service/generateTurn/complete, stub fetch.6 diagnostics, exit0 |Competing snapshot deletion;30-window/draft-ack separation; forgotten safety disclosure; unsupported media claim;2 calls reported as0 attempts; prompt mismatch |
|Python↔Twin integration: same delivered conversation must continue without replay |PY service/tests/test_twin_bridge_roundtrip.py |Real Python worker/client + Twin HTTP/store + OFClient single-POST route; lowest provider HTTP and generator mocked; dotenv blocked and audit Node preload blocks .env/fetch.14 assertions plus listener passed |2 drafts,2 POSTs,2 committed assistant entries; second generation sees first. Fake provider ID reused, so not proof of provider-ID uniqueness or generated quality |

Bridge tests ran from inflowwkiller with PYTHON_DOTENV_DISABLED=1 in child command environment. The roundtrip additionally used AUDIT/bridge-roundtrip-preload.mjs through NODE_OPTIONS; complete command details are in the bridge report. Twin commands ran from twin-sexbot to resolve installed tsx, targeting the isolated snapshot with VARS_DIR cleared. No package installation was required.

Existing broad suites were not repeatedly run. check-turn.ts uses default data paths and was not run unchanged against real state. Full npm test and the unsafe vault upload suite were unnecessary for the named uncertainties. Direct exit codes were checked; a textual success marker alone was not treated as success. The source-only native sales harness initially lacked a dependent regex constant; fixing the isolated harness resolved that diagnostic error without production changes.

Retained evidence:

- [Original diagnostics and observations](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/original_fastt_diagnostics_results.json>).
- [Twin targeted results](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/twin-targeted-results.txt>).
- [Bridge fairness log](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/bridge-starvation-probe.log>) and [cap race log](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/bridge-budget-race-probe.log>).
- [Roundtrip log](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/bridge-roundtrip-test.log>) and named component test logs in this directory.

No bounded hardware load benchmark was needed to establish the scheduling/storage algorithm defects, and none is claimed. All scale numbers in section6 are explicit workload arithmetic.

## 9. Deployment, operating and missing-feature requirements

Broad production requires one clearly assigned author per conversation and one durable authority for every automated, manual, scheduled and mass delivery. Current local reservations are valuable; they do not give distributed ownership of provider-side scheduled or official-app actions. Human intervention needs an explicit policy for in-flight/unknown sends and an operator interface that preserves evidence.

Required visibility includes: accepted-versus-persisted input counts; queue drops, depth and oldest age; reconciliation cursor/gaps; generation/429/timeout rates; draft age and supersession; unknown/parked/reserved age; cap usage; duplicate suppression; schema compatibility; DB lock wait, disk/WAL growth and checkpoint health; authentication reconnect gaps; backups/restore checks; tenant cost and provider quota. Process liveness alone cannot detect lost replies or an indefinitely quarantined conversation.

Operations need scheduled ownership/queue services, graceful shutdown, bounded retry/dead-letter handling, alert routing and staffed resolution. The number of operators is unmeasured; use incident frequency×handling time and peak coverage requirements to plan it, not an invented “one operator per X fans.”

Fastt's retention loops and restore script are useful starting points. They do not demonstrate an encrypted/offsite backup schedule, generic small-pilot restore, coordinated A-ledger recovery, tenant/fan deletion or rehearsed recovery objectives. A's reset preserves delivery evidence and logs; it is not a privacy erasure feature. The visible Fastt top-level licence is MIT with notice requirements; Twin has no identified top-level licence. This is not a claim against ownership of user-created code. Transitive licences, platform permissions/terms and model-provider commercial terms need separate verified review before commercialization; no legal conclusion is made here.

## 10. Coverage and exact evidence gaps

|Area|Inspected/tested|Excluded or unknown; smallest useful next validation|
|---|---|---|
|Source snapshot/config|Both git states, current tracked/untracked implementation, original source, safe selectors, aggregate pilot ledger|Remote deployed artifact/process environment not captured; inspect sanitized deployment manifest if it is the intended launch target|
|Intake/identity/order|WS queue/transcoder, bridge normalization/cutoff/dedup/formation, REST recovery, real temp-DB tests|Real provider duplicate/reorder/cursor distribution; replay recorded redacted envelopes in a no-send environment|
|Ownership/send/restart|Native claims/leases/sends, bridge state/guards/history/ack, Twin journals, controlled interleavings and child restarts|All possible interruption points and machine/power failures not exhaustively tested; focused crash matrix with synthetic service stack and directory persistence|
|Human/scheduled/mass|Caller/guard/state traces and native scheduled ambiguity test|Real provider schedule cancellation and official-app races; bounded authorized validation would refine operating limits|
|Model/conversation|Both context/prompt/validation paths, native memory/stop transformations, Twin actual deterministic construction|No actual generated comparison. Matched blinded replay is the smallest evidence for naturalness; could change engine preference|
|Sales/purchases|Native planner/content/ownership/prices/PPV/attribution/make_right interfaces; A missing wiring|Actual catalogue quality, provider purchase completeness, refund/access outcomes and conversion; instrumented constrained pilot required after blockers|
|Security/tenancy|Core middleware/session/event/cache/admin families, real isolated function probes|Not every route or a full penetration test; route-integration tests through actual ASGI/proxy composition can refine exposure, not erase demonstrated missing checks|
|Schema/storage/operations|Representative populated upgrade, bridge additive schema, SQLite/durability/retention/deploy/source locks|Every historical schema, live image layers, backup encryption and restore RPO/RTO; synthetic upgrades and crash/rebuild/restore drills|
|Scale/dependencies|Algorithmic limits, available runtimes, pinned direct deps, official Docker/SQLite documentation|No supported capacity/benchmark/SBOM/CVE sweep/full licensing review. Representative bounded workload tests after structural fixes|

No confirmed wrong-fan routing or cryptographic hash collision was found in the inspected bridge identity path. That does not negate the demonstrated cross-tenant application event leak. No test result proves immunity to prompt injection: fan/provider text remains untrusted model context, deterministic guards are incomplete, and capability/state validation must remain outside the model.

Component reports provide the complete source ranges, additional positive controls, diagnostic code boundaries and rejected suspicions:

- [Original Fastt reliability](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/original-fastt-findings.md>).
- [Custom bridge reliability](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/bridge-findings.md>).
- [Twin engine/channel](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/twin-findings.md>).
- [Native conversation/sales](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/fastt-conversation-sales.md>).
- [Security/operations](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/security-ops-findings.md>).

These supplement this complete decision report; none represents a tested third implementation. Prior suspicions rejected by source tracing include “every bridge worker restart invalidates a valid draft,” “successful Twin ack can precede transcript commit,” and “the old-history interruption bug remains.” The current code protects those boundaries.

## 11. Final recommendation, explicit answers and ordered prerequisites

**Would copying original Fastt one-for-one reduce our risk?** It would remove an extra runtime/protocol/file journal and restore native context/commerce within one service. It would also remove useful one-POST/unknown-delivery/draft-ack controls while retaining original security, retry, concurrency, history and migration defects. It is not a defensible overall risk-reduction strategy. Reuse selected code; do not treat “original” as a reliability certification.

**Which custom components add avoidable failure risk?** Twin's synchronous shared-directory journal and startup ownership assumptions; Python global-oldest formation page; read-modify-write cap update; unclosed per-pass HTTP clients; unwired reconciliation; duplicated ledger/ack operating workflow; platform-mismatched prompt; unsupported-action handling. The two-store architecture also raises coordinated restore and release complexity.

**Which custom components add useful protections?** Strict identity/scope and UTC/text normalization; immutable source membership; durable reservation and fencing around instrumented senders; a real one-POST transport; pre-POST attempt/cap accounting; unknown-delivery quarantine; corrected bounded history check; draft/confirmed-delivery separation and idempotent transcript acknowledgement. Preserve these invariants even if the implementation is consolidated.

**Which original problems remain after copying?** Lossy ingress, skipped catch-up gaps, duplicate summary side effects, native ambiguous replay, concurrent job claim/stale release, human intervention timing and partial-bubble gaps, event/cache/admin security exposure, plaintext credential handling, incomplete schema upgrades and WAL packaging/recovery assumptions. Original sales also lacks a global no-contact guarantee and has stale-memory/factual-grounding weaknesses.

**What would switching lose from Twin?** Its specific persona/style/configured model combination, recent delivery-aware transcript, channel validation and durable request/ack semantics if the whole bridge is discarded. It would not lose proven conversion superiority, historical OnlyFans memory or connected PPV, because those were not established in the current Twin route.

**Is a hybrid justified, and exactly what should it retain?** Yes as an engineering proposal: retain Fastt's account/session/platform access, relational message and commerce entities, catalogues, ownership/purchase facts, useful CRM/manual tools and grounded context builders; retain A's input idempotency, intent/attempt/unknown states, one-send boundary, budget accounting and ack-before-history principle. Replace the file journal and unfair scheduler; make native sales return validated persisted plans routed through that one send authority. Correct consent, security, memory and truthfulness defects first. Do not simply invoke native send helpers from Twin: those helpers interleave delivery, ladder, quote, cadence and ownership mutations.

**Which is simpler and less costly at equivalent functionality?** B uses fewer runtimes/state stores and already has the native commerce feature set, so it is simpler structurally and cheaper to reach feature parity than implementing all of it anew in A. A's smaller generator can use fewer decision calls, but it buys less context/functionality and adds operating/recovery work. At equivalent reliability and commerce, cost has not been measured; model, support, incident and integration costs can reverse a naive server-count comparison. A unified design preserving delivery controls may ultimately be simpler than either unchanged architecture.

**Strongest reason not to choose this recommendation:** the proposed consolidation is substantial integration work with no demonstrated conversion payoff. Native sales depends deeply on immediate side effects and multiple mutable state machines; adapting it can create new inconsistencies or an unwanted third ownership layer. A supervised native product with repaired delivery/security may be a lower-effort commercial route than keeping Twin code. This is why the recommendation preserves safety principles and useful assets, not every custom line.

**What evidence would reverse it?** A representative matched failure/recovery trial in which native delivery is as safe and easier to operate; evidence that A's parked/missed-input/manual-resolution rate is commercially unacceptable; a blinded conversation evaluation showing a materially better engine after equalizing persona/model/context; and controlled sales/retention/complaint/margin results. Broadly exposing unmodified B or claiming the current A supports a million users is not supported even if an engine wins a conversation test.

Before broad deployment, in order:

1. Close shared public authentication/tenant/cache/admin holes; correct packaging and credential/session controls. Preserve current restricted send state and ledger evidence.
2. Establish one autonomous author per conversation, durable no-contact/age/handoff enforcement and truthful channel capability/persona facts.
3. Fix demonstrated custom/native correctness defects in the chosen path: unsafe writer cleanup/startup, cap race/fairness/reconciliation, native claims/leases/ambiguous sends and final-wire/partial-bubble accounting as applicable.
4. Provide an operator workflow for parked and unknown outcomes, with alerts, evidence-based resolution and no blanket resets/reposts.
5. Prove populated migrations and complete persistent storage/backups; rehearse compatible SQL/Twin recovery and graceful shutdown using synthetic accepted-send states.
6. Replace scale-blocking file/state/worker design, partition by tenant/account/conversation, enforce fair quotas/backpressure and complete durable ingress/history catch-up. Port databases and coordination deliberately rather than changing a URL.
7. Integrate authenticated platform history, manual delivered messages, corrected memories and purchase/catalogue facts. Add commerce only through the common durable action/receipt interface.
8. Run matched blinded conversation evaluation, then separately authorized bounded live validation with realistic provider failures and measured business/support outcomes. Use explicit workload/latency/recovery targets before any scale claim.

The decision is to keep the safer delivery baseline while building toward a grounded, consolidated system. **It is not a recommendation to continue repairing indefinitely or to launch now.** The audit is complete for the frozen scope; the prerequisites above are identified engineering work, not changes made during this investigation.

Final integrity verification: both HEADs, full tracked/untracked Git status and all initially hashed source/build files remained unchanged. Read-only pilot turn/attempt/budget aggregates also remained unchanged. [Final verification](<C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/output/independent-audit-20261016/verification-complete.json>). The audit verifier needed two harness corrections: normalizing Python tuples versus JSON lists, and excluding its own not-yet-created result from the missing-link check. Intermediate outputs are retained; no product or ledger change was involved.

