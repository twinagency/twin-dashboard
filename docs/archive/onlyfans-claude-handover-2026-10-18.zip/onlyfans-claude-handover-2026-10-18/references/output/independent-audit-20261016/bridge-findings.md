# Option A bridge: independent reliability evidence

Audit date: 2026-10-16 (Australia/Brisbane). This subreport covers the current Fastt working-tree bridge, its integration edits, and the Twin HTTP acknowledgement contract. Original Fastt analysis and repository/configuration inventory are separate reports. Source references below are relative to `C:/Users/conta/Documents/ChatGPT/TWIN CLONE CREATION/inflowwkiller/` unless explicitly marked Twin. No production source/configuration was changed and no live workers, providers or model calls were started.

## Decision contribution

The custom bridge contains meaningful delivery protections worth retaining: immutable account/fan/source identity, transactional intake and turn membership, durable attempt evidence before POST, an actual no-retry transport path, explicit unknown-delivery quarantine, cross-process SQLite reservations, checked manual takeover, and delivery acknowledgements before assistant history. These are evidence-based differentiators, not a claim of exactly-once provider delivery or broad production readiness. Several prior repairs are real and exercised by tests.

Two new defects were demonstrated using production functions and isolated databases: multi-fan starvation by one continuous burst, and concurrent cap changes that can widen a previously tightened durable limit. Operational gaps include unwired intake reconciliation, permanent discard after some transient preflight failures, no supported evidence-based resolution of uncertain sends, a pilot-only runner, and a connection lifecycle leak. The current bounded singleton pilot is not exposed to the multi-fan starvation trigger; expanding it changes the exposure substantially.

## Actual flow and boundaries

1. **Ingress/persistence:** `service/event_transcoder.py:417-567` persists the incoming Message/Fan/Chat and calls bridge intake in the same auto-committing session. `service/twin_bridge/intake.py:142-232` reads the canonical row, validates original provider evidence, builds a frozen event and inserts using the composite account/fan/provider-message key. Identical duplicates are no-ops; different normalized payload under an existing identity raises `IntakeConflictError` and rolls back this transaction. The event hook is optional on import (`event_transcoder.py:49-55`); an import failure disables it rather than stopping original Fastt.
2. **Eligibility:** `normalize.py:295-368` requires configured account and explicit allowlisted fan, original readable provider IDs matching canonical IDs, inbound free text, usable provider/receipt timestamps at or after the explicit cutoff. It excludes paid/unlocked paid messages, tips, media and media captions, GIFs, unsent messages, empty text and text over 4,000 UTF-16 units. `intake.py:194` also caps the serialized event at 16KiB. These are deliberately text-only capabilities; no paid-message/purchase/media pipeline is wired through the bridge.
3. **Normalization:** `normalize.py:48-65` removes markup before entity decoding, preserving literal escaped tags; timestamps convert offsets to UTC instead of using original Fastt's offset-stripping parser (`normalize.py:69-97`). Receipt time is the stored first ingestion time. There is no provider future-time/skew sanity threshold (`normalize.py:352-361`); correctness assumes trustworthy provider timestamps. Future/late receipt data can extend the quiet wait; old delayed provider messages can require a larger history walk.
4. **Scheduling/order:** `turns.py:137-174,178-192,371-457` selects globally oldest pending receipts, groups per fan and waits until the latest member is at least seven seconds old. Sequence is receipt order with provider-ID tiebreaks, not provider-time order. It walks a continuation up to 5,000 rows, checks the actual newest pending receipt if the walk cap is reached, and splits oversized turns only at source boundaries (`turns.py:293-338,460-498`). The frozen synthetic ID hashes account/creator/fan/conversation/scope/member list. Turn, unique source membership and source assignment share a transaction/savepoint (`turns.py:517-575`). Multiple turns may be frozen; only the oldest unresolved one advances (`coordination.py:1338-1354`).
5. **Ownership:** `worker.py:398-432` applies the configured cap, then takes a durable reservation and per-turn claim. `coordination.py:905-1011` serializes reservation versus legacy writer registration using SQLite `BEGIN IMMEDIATE`, process-local admission state and durable write markers. Claim TTL is 120 seconds, but the reservation itself does not expire and therefore survives pauses, unknown outcomes and restart. A legitimate replacement preserves the conversation revision when already reserved (`coordination.py:950-960`), so an accepted draft can survive restart. One worker process is not the same as one Twin service process; Twin has its own single-process storage restriction.
6. **Drafts:** `worker.py:553-627` persists submission state/attempt count before request, sends the exact frozen event to Twin, and treats transport uncertainty as status work. Bounded status reads and same-identity resubmission on proven not-found are in `worker.py:676-785`. Submission max3, status max60, acknowledgement max3, cancellation max3. `client.py:320-438` bounds payload/response, checks the exact request and conversation IDs, disables redirects and environment proxies, and distinguishes before-connect failures from uncertain after-send failures. A definitively failed connection or malformed/server rejection generally parks instead of retrying generation indefinitely.
7. **Final validation:** `worker.py:809-1009` rechecks active state, token, expiry/revision, canonical source eligibility, provider history and live Twin draft status; participates in the existing native fan cooldown/skip list/lease; validates all source members again in send-admission's write transaction. The provider history is a safety preflight only; it is **not** supplied to Twin as conversation history.
8. **Provider send:** `delivery.py:96-227` validates canonical sources and reserves one budget unit plus a durable dispatching attempt in a single `BEGIN IMMEDIATE` transaction. Worker then conditionally transitions the turn, authorizes the transport and sends (`worker.py:954-1013`). `platform.py:330-352` wraps the one-shot call in the shared writer guard; `of_client.py:1639-1663` sets free-text-only payload and `proxy_tries=1`. Literal text is escaped consistently (`platform.py:82-101`). The actual provider minimum response assumption is a positive exact ID with any supplied author/recipient/direction fields consistent (`platform.py:104-178`); fields may be omitted, so tests cannot prove provider semantics.
9. **Evidence/ack/history:** Exact provider ID is persisted before bookkeeping and Twin acknowledgement (`worker.py:1050-1079`). Failed attribution/cache emission is logged and never causes a second POST. The comment that bookkeeping is independently retried (`worker.py:1177`) has no retry implementation visible in this worker. Twin acknowledgement success is returned only after the durable ack-decision and transcript commit: Twin `src/channels/service.ts:421-459`, HTTP `src/channels/http.ts:505-508`. Therefore Fastt's marking delivered after successful ack despite a failed follow-up status read is **not** evidence of lost transcript history. Partial ack commits are recovered by Twin on restart/next request.
10. **Recovery/control:** `delivery.py:267-360` reconstructs a sent turn from confirmed sent ledger evidence without reposting, or marks dispatching attempts older than30s unknown and pauses. `worker.py:1283-1347` retries only acknowledgement. `coordination.py:1135-1254` uses a conditional takeover update that refuses while dispatching/unknown evidence exists; a human send cannot just clear a live attempt. Pause/cancel preserve evidence. Resume/cancel boundaries tombstone unsent earlier turns and park earlier receipts (`worker.py:263-315`, `turns.py:195-222,404-418`); resume intentionally starts from fresh inputs, not an automatic backlog replay.

## Prior history-interruption defect verified repaired

The current call chain is `worker._history_source_boundary` (`worker.py:1082-1108`) -> `OnlyFansTextAdapter.preflight_history` (`platform.py:241-326`) -> `external_outbound_ids(..., since=history_since)` (`worker.py:872-884`; `delivery.py:401-523`).

The boundary is the **earliest provider timestamp of all frozen source members**, floored to milliseconds. It is not the turn creation time or first receipt. The provider walk is descending and bounded, rejects malformed or nonprogressing pages/cursors, requires **every frozen source ID** to have been seen, and stops only at an older row or explicit exhaustion. A short page alone is not exhaustion. Unknown outbound creator messages strictly earlier than that boundary are historical; equal/newer rows still interrupt. Bound creator/fan identity and contradictory direction are checked even for old rows. Only bridge ledger-confirmed sent IDs are exempted as the bridge's own sends.

This repair is code-established and tested: existing history suite141 assertions, delivery suite's old/equal/newer/unreadable boundary scenarios, and the real Python/TypeScript round trip all passed. This does not establish that an actual provider returns a stable complete history, or remove the race with a creator writing through the official app after preflight. Remote clients do not participate in local reservations.

## Prioritized findings

### BR-01 — One open burst can starve unrelated quiet fans

**Confirmed defect; Option A; new bridge; high impact when multi-fan scope is enabled; code-established and test-demonstrated.**

`turns.py:137-158` takes globally oldest pending100 rows by default. `form_turns:396-446` never advances a cursor across passes for a still-open burst. If one fan owns those oldest rows and keeps sending less than7s apart, that fan remains held and later fans are never considered. Raising the batch only shifts the threshold. The same behavior can persist for as long as the burst remains live, without lost input rows or an explicit error.

Reproduction: `bridge-starvation-probe.py` seeds110 small messages at6s intervals for fanA and one already-quiet message for fanB at600s. At655/661/667s, the real formation function scans100, holds1, freezes0; B has waited55/61/67s. With unchanged DB/time and batch500, B immediately freezes. Production schema and production function; only scheduling/data synthetic. Current singleton pilot cannot exhibit cross-fan starvation, but one fan can still postpone its own reply indefinitely.

**Remediation direction/scope:** per-conversation fair admission/round-robin queue plus explicit maximum turn age; medium queueing redesign. A batch increase is not the fix. The7s quiet policy itself can be an intentional tradeoff; starving a different already-quiet conversation is the defect.

### BR-02 — Concurrent cap changes can widen a tightened durable send budget

**Confirmed defect; Option A; new bridge; medium severity, safety-control significance; code-established and test-demonstrated.**

`coordination.set_budget_limit` at`1319-1334` reads the existing limit, computes min/max in Python, then performs an unconditional UPDATE. Calls occur before ownership acquisition (`worker.py:402-406`). Two workers with different CLI/configured caps can both read5; caller2 commits limit2; caller4 commits4 from its stale read, widening the persisted cap despite the documented never-raise invariant. No budget consumption is erased, but additional sends become admissible later.

`bridge-budget-race-probe.py` schedules two real `set_budget_limit` calls at their completed SELECT boundary in independent real SQLite sessions. It observes2 after the stricter update and4 after the concurrent looser update. No provider/model call occurs. This does not claim the current single runner is violating its cap, or that ordinary serial restarts reset the allowance; those cases pass existing tests.

**Remediation:** atomic conditional SQL min/max/CAS, and contention regression at this boundary; small change plus concurrency validation.

### BR-03 — Intake recovery exists but is not scheduled or exposed by the bridge CLI

**Missing capability; Option A; medium/high impact during missed event admission; code-established.**

`reconcile.py:80-160` correctly scans canonical persisted messages lacking bridge inputs using the same admission function and an explicit page cursor. Repository-wide caller search finds the definition and tests only; no production caller. `worker.run_once:242-244` forms turns directly, and `pilot.py:119-124` only calls run_once. CLI parser/actions contain no intake reconciliation command. The hook is in event_transcoder; REST/history/catch-up persistence is not itself a bridge intake hook.

Consequently a relevant message persisted while bridge intake was disabled/unavailable, or via another persistence mechanism, remains absent from bridge work until someone explicitly invokes reconciliation. Messages lost before canonical persistence remain a shared Fastt ingestion risk and are outside even this helper's coverage. Do not count the existence of this helper as automatic loss recovery.

**Remediation:** bounded durable reconciliation scheduling/cursor, separate provider-to-canonical catch-up coverage and operator visibility; medium integration effort.

### BR-04 — Conservative refusal permanently abandons some retryable work; uncertain sends have no complete resolution workflow

**Intentional safety tradeoff plus missing operational recovery; Option A; medium operational impact; code-established.**

An unreadable provider history (`worker.py:864-884`) or transient final Twin status failure (`worker.py:911-915`) calls `_park` without retry. `_park:1350-1373` records parked but normally leaves the conversation active. `unresolved_turn` explicitly excludes parked (`coordination.py:1349`), so later work can proceed and ownership can be released. Original input stays assigned and that reply is never automatically revisited. This is safe from blind reposting but loses availability after a transient pre-send read failure. Pilot surfaces it as `turn-parked` and stops (`pilot.py:129-139`); manual CLI status also shows parked work (`cli.py:67-105`). It is therefore not automatically silent in the supported pilot, but there is no production alert/retry workflow.

Unknown sends deliberately remain paused/reserved with no automatic repost (`worker.py:1020-1048`). That is correct. `cli recover` only changes abandoned dispatching to unknown (`cli.py:200-205`). `reconcile-writes` clears legacy writer markers (`coordination.py:510-539`), not bridge unknown-send ledger evidence. Human takeover refuses unknown attempts. Resume does not resolve unknown attempts. There is no examined command that validates provider evidence and records a confirmed-or-not-sent resolution for an unknown bridge attempt; operational instructions require hand resolution. This is a deployment blocker for broad unattended use, not a request to loosen the quarantine.

**Remediation:** distinguish retryable pre-send read failures from invalid evidence; add bounded retries and alerts. Add an audited evidence-resolution workflow preserving ledger/cap/history, never blind resend; medium/high operational engineering.

### BR-05 — Resource lifecycle and scaling are pilot-oriented

**Confirmed lifecycle omission and operational assumptions; Option A; medium at sustained volume; code-established, exhaustion not measured.**

Every `worker.run_once` with no supplied client constructs a new `TwinBridgeClient` (`worker.py:224-232,455-463`). That constructs its own `httpx.AsyncClient` (`client.py:238-253`) with an explicit `aclose` API (`client.py:259-267`). No run_once/CLI/pilot path calls it. The default pilot passes its default client=None every pass (`pilot.py:64-67,120-124`). Connections therefore have no deterministic closure, even on idle passes. Actual handle growth/exhaustion depends on runtime garbage collection and was not benchmarked.

The worker discovers all open conversations without a limit and visits them serially (`worker.py:246,317-330`). `batch_size` bounds formation inputs, not total per-pass work or network duration. Model requests can hold up following fans; no creator/fan fair throughput budget. `_sources_still_valid` scans every membership for the fan (`worker.py:1121-1130`) on repeated gates, growing with historical turns. The actual safe runner supports exactly one allowlisted fan, max1hour and finite durable cap (`pilot.py:81-99`); there is no supported general service scheduler here. SQLite sync coordination also blocks the event loop during lock waits (2/5s direct SQLite timeouts) and hard-requires an on-disk SQLite store for dispatch. Switching DATABASE_URL to Postgres does not make the bridge horizontally scalable; admission refuses when the SQLite store is absent (`delivery.py:116-124`, `coordination.py:913-918,1004-1009`).

**Remediation:** owned reusable client with finally-close; fair durable work scheduler, indexed restricted membership query, per-tenant quotas and metrics, partitioned coordination/store design; small lifecycle fix, substantial production architecture work.

### BR-06 — Bridge/native/remote coexistence has specific limits

**Operational assumption / credible risk under specified conditions; Option A; medium/high depending configuration; code-established and inferred.**

The bridge does not reserve at intake or disable native rule creation; it reserves only after turn formation (`worker.py:398-408`). Native automation may run during the7s preformation interval or after a delivered turn releases ownership. The original Fastt auditor verified native `_response_delay` defaults to zero plus zero jitter (`webhook_dispatch.py:243-251` at base), so this is a reachable timing gap when native automation is enabled, not a hypothetical minimum-delay bypass. A later bridge preflight will treat a native outbound as external and park rather than knowingly duplicate it; there is still nondeterministic engine selection/extra draft cost if both engines are enabled for the same fans. Durable shared transport fencing is useful during the actual reserved interval and survives restart. Current config choice must ensure one autonomous author per scope, not assume code globally switches engines. Root's frozen config found no enabled native rules, so this is latent activation risk rather than a claimed current dual-send incident.

Remote official-app/manual sends cannot participate in local fencing. History is read before several further awaits/model-status/DB checks (`worker.py:860-1009`), so a remote creator write after preflight can still race the automated send. No software-only claim of total human-send exclusion is justified without a provider atomic/versioned precondition.

The shared broadcast guard rejects account-wide broadcasts whenever **any** conversation is reserved (`coordination.py:375-410,737-763`). A single paused/unknown fan can block mass sends for the whole account. This is an intentional broad safety boundary, not cross-account mixing.

Optional import guards fail open for ordinary sends if the coordination module cannot import (`of_client.py:1517-1521,1615-1621`). With the bridge enabled, a broken/mismatched deployment can therefore bypass the intended reservation boundary. Tested ordinary deployments import successfully; this is a conditional deployment risk, not an observed live breach.

**Remediation:** explicit engine ownership configuration, health-check enabled bridge dependencies, finer broadcast recipient exclusions where provable, and documented remote-human operational boundary; medium scope.

### BR-07 — Bounds protect load but can cause permanent skip under large backlog/history

**Intentional tradeoff with credible availability risk; Option A; low/medium under large bursts; code-established.**

Default preflight requests10 messages/page with a20-page cap (`platform.py:30-31,184-189,281-326`), so normally at most200 history rows are fetched, even though the separate maximum item count is1000. A formed text turn can contain more than200 very short source messages; every source must be observed. Large bursts/backlogged sources then safely fail history coverage and are parked. Formation's5000-row continuation tests use fake adapters and do not prove actual bounded history can dispatch those turns. An enormous single input (>4000 UTF-16 units) is excluded instead of truncated; oversized aggregate turns are split. No false confidence should be inferred from formation-only long-burst tests.

Changing the global allowlist changes `scope_fingerprint` for every conversation (`turns.py:67-83`), and existing conversations with different fingerprints are held/parked (`worker.py:378-396`). This is a safe response to changed trust scope, but routine creator/fan onboarding requires explicit migration/versioning semantics; simply expanding the allowlist is not a transparent scale-up.

## Test commands, results and limits

Interpreter: `C:/Users/conta/AppData/Local/Temp/of-preflight/venv/Scripts/python.exe`, Python3.13.16 (supplied runtime verification by root auditor). The installed default3.13 interpreter lacks SQLAlchemy; it was not used for tests. Local older3.11 environment was not used. All commands run from the Fastt repository. For Python suites, `$env:PYTHON_DOTENV_DISABLED='1'` was set in the child PowerShell. Existing fixtures set DATABASE_URL to newly-created private temporary SQLite files before importing db.engine; they stub relay/cache/hooks or lowest HTTP layers, do not instantiate live account clients, and dispose/delete only their own temp directories. The known unsafe `test_vault_upload.py` was not run. Startup/init_db side effects were inspected and restricted to synthetic DBs.

| Diagnostic | Command after environment prefix | Result | Proves / does not prove |
|---|---|---|---|
| History coverage | `& <python> service/tests/test_twin_bridge_history.py` | Exit0,141 checks | Real adapter page walking/caps/cursors/source coverage with explicit fake client; not real provider pagination behavior. |
| Durable turns | `& <python> service/tests/test_twin_bridge_turns.py` | Exit0,83 `ok` assertions | Production turn formation/dedupe/membership/coordination on synthetic SQLite. No external model/platform. Log `bridge-turns-test.log`. |
| Intake | `& <python> service/tests/test_twin_bridge_intake.py` | Exit0,165 `ok` assertions | Real admission/transcoder paths with automation/cache/webhook stubs; synthetic restart/subprocess/schema additive checks. Does not validate real ingress completeness. Log `bridge-intake-test.log`. |
| Delivery | `& <python> service/tests/test_twin_bridge_delivery.py` | Exit0,115 `ok` assertions | Real state machine and some real OFClient lowest-layer tests; fake Twin/adapter in many scenarios. Validates no-repost/ack/boundary transitions, not live provider behavior. Log `bridge-delivery-test.log`. |
| Ownership/repair regression | `& <python> service/tests/test_twin_bridge_ownership.py` | Exit0,205 `ok` assertions | Real coordination/delivery/worker plus staged concurrency/low transport seams, restart/lease/history/long-burst regressions. Large-burst cases do not prove complete end-to-end history coverage. Log `bridge-ownership-test.log`. |
| New fairness reproduction | `& <python> ../output/independent-audit-20261016/bridge-starvation-probe.py` | Exit0; failing fairness reproduced on3passes, positive larger-page control | Real production formation and schema; synthetic110+messages/two fans. No waits/network/models; does not measure fan incidence. Log same basename `.log`. |
| New cap race reproduction | `& <python> ../output/independent-audit-20261016/bridge-budget-race-probe.py` | Exit0; stricter2 overwritten by4 | Two real production cap updates and real DB sessions, scheduler seam pauses after SELECT; demonstrates lost minimum, no sends. Log same basename `.log`. |
| Cross-language round trip | `& <python> service/tests/test_twin_bridge_roundtrip.py` | Exit0;14 assertions plus listener status | Real Fastt intake/worker/client + real Twin loopback HTTP/service/store + real OFClient single-POST boundary. Model generation and lowest OF HTTP mocked.2drafts,2POSTs,2delivered turns,2assistant transcript entries; second generation sees first committed entry. Not output-quality/conversion evidence. |

Round-trip safety: existing test starts only an ephemeral loopback Twin test server with supplied stub generator/recovery and temporary data/log directories. The test source was not modified. Audit-only `bridge-roundtrip-preload.mjs`, supplied via `$env:NODE_OPTIONS='--import="file:///C:/Users/conta/Documents/ChatGPT/TWIN%20CLONE%20CREATION/output/independent-audit-20261016/bridge-roundtrip-preload.mjs"'`, prevents Twin config.ts reading its live `.env` and makes Node global fetch throw. Python dotenv disabled; no credential values read/printed by the diagnostic. `VARS_DIR` was absent from inherited environment (name/existence checked only); with `.env` blocked, the optional persona-import copy side effect had no target. Log `bridge-roundtrip-test.log`. The existing test's fixed fake provider ID is reused across both messages, so it does not establish uniqueness behavior of provider IDs. Its transcript model stub records only prior delivered assistant entries rather than exercising real LLM input persistence or naturalness. The two attribution warnings about synthetic Automation employee absence do not fail delivery and show bookkeeping is outside send confirmation.

The existing suites' failure collectors are inspected: failures lead to nonzero process exit. Direct commands recorded `$LASTEXITCODE`, not just success text; suite count is not used as quality score. No additional broad reruns were performed.

## Scenario implications for the common matrix

| Scenario | Option A bridge deterministic behavior |
|---|---|
| New fan, no history | Only new admitted inputs enter Twin; successful assistant output is remembered after ack. |
| Returning fan / old preference | Provider history preflight does not import content. Engine context depends on Twin's separate limited transcript; no automatic legacy history migration. |
| Several fast messages | Merge by receipt gaps<7s, freeze after quiet; size split at source boundary. |
| New message during generation | New input waits as subsequent turn; existing draft is not automatically invalidated by newer inbound. Canonical unsend/reclassification does invalidate. Potentially stale conversational answer is an intentional immutable-turn policy, not a measured quality result. |
| Long continuous input | No maximum quiet-wait age; one fan can postpone own reply and BR-01 can starve others. |
| Duplicate inbound | Same identity/snapshot dedupes in DB; changed same-identity snapshot conflicts and current canonical transaction rolls back. |
| Out-of-order inbound | Receipt-order text; earliest source provider time used for interruption boundary. No claim of restored chronological semantics. |
| Historical creator outbound | Correctly ignored only if provably before earliest source boundary; equal/newer or unreadable evidence blocks. |
| Manual Fastt creator reply | Conditional takeover invalidates unsent work; refuses if dispatching/unknown evidence exists. |
| Official-app creator reply | Preflight catches already-visible relevant outbounds; later remote activity remains a race. |
| Model timeout | Client uncertainty status-polls same frozen identity; bounded stops; no new ID regeneration on uncertain admission. |
| Malformed model/provider output | Strict schema/identity checks; undeliverable work parks; no fallback send. |
| Send accepted, response lost | Unknown pause, reservation and spent cap retained; no automatic repost or assistant ack. |
| Successful send, lost ack | Durable sent evidence; only idempotent ack retries. |
| Worker restart | Source/turn/attempt/cap survive; expired worker can be replaced without changing draft fence if reservation remained; abandoned dispatch unknown; confirmed attempt evidence reconstructs sent state. Twin generation interrupted on its own restart is separate. |
| Price/purchase/product/media | Not a bridge capability; paid/media/tip events excluded and free-text-only output. Other native features must not be attributed to Twin bridge. |
| Stop/handoff request in fan text | No bridge semantic stop classifier; depends on selected engine/operator controls. New inbound during generation does not automatically cancel old reply. |

## Evidence boundaries and rejected suspicions

- **Not a finding:** restart necessarily invalidates accepted drafts. Current `_reserve_atomic` advances the conversation revision only on reopening a released reservation, not every process token change; existing ownership tests pass.
- **Not a finding:** Fastt ack marks delivered without guaranteed transcript commit just because its follow-up status can fail. Twin HTTP success occurs after commit; partial failure recovery is implemented.
- **Not a finding:** all history-boundary checks still use an unbounded old creator message. Current earliest-source millisecond boundary is correctly wired and tested.
- **Not a finding:** uncertainty quarantine is a duplicate-send bug. It is useful conservative protection; missing operator recovery/alerting is a separate availability problem.
- No numerical failure rate, uptime, maximum user count or sales conversion claim follows from these diagnostics.
- Tests do not establish platform atomic delivery/idempotency, real creator/fan timestamp guarantees, session/cookie refresh behavior or behavior of official-app races. Those are shared/provider/deployment evidence gaps.
- Root and Twin agent cover multi-process journal corruption, authentication, data retention, restore consistency, full configuration, model/persona selection and the original Fastt comparison. This subreport does not turn their areas into implied audited guarantees.
