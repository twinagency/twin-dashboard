# Independent Twin engine and channel audit — 16 October 2026

This is component evidence for Option A, not a comparison of Twin alone against the whole Fastt application. Original Fastt and the Fastt-side bridge worker are covered by other audit components. No external model call, real message, live worker, credential inspection or production mutation was made in this component audit. Model text in diagnostics is a synthetic stub and supplies no evidence of naturalness or conversion.

## Snapshot and execution boundary

- Repository: `C:\Users\conta\Documents\ChatGPT\TWIN CLONE CREATION\twin-sexbot`.
- Branch independently verified: `codex/onlyfans-integration`.
- HEAD independently verified: `7b0036bf4d1a58413c57d19434fa4bcad3a1c4f4`.
- Working tree: tracked modifications in `package.json`, `scripts/check-media.ts`, `src/turn.ts`; untracked implementation in `src/channels/`, with untracked `scripts/check-channel.ts`, `scripts/check-http.ts`, `scripts/check-recovery.ts`, and `docs/`. All current channel implementation and the changed turn path were inspected, rather than assuming HEAD includes them.
- Installed Node runtime used for diagnostics: `v24.18.0`. Dockerfile declares `node:22-slim`; package.json has no Node engines requirement. TypeScript targets ES2022. `package-lock.json` exists. Package dependencies are grammy plus development-time tsx, TypeScript and Node typings. No dependency vulnerability scan or external package-version verification was done here.
- `npm start` and Docker default start `src/bot.ts`, the Telegram application, **not** the OnlyFans channel. The OnlyFans entry point is `npm run start:onlyfans-bridge` / `src/channels/serve.ts`.
- `src/bot.ts` has live startup side effects: catalogue fetch at line 16, refresh interval line 18, Stars poller line 257, Telegram start line 260. It was read but never imported or run.
- `src/config.ts:10-21` reads `.env` on import. `src/girls/riley.ts:13-18` can create/copy a vars file if `VARS_DIR` is set. To prevent those side effects against the working tree, tests used an audit-only source snapshot containing `src`, `scripts`, package.json and tsconfig.json, with no `.env`, logs or data and `VARS_DIR` cleared in the subprocess environment. Production source was not changed.
- `src/channels/http.ts` builds without listening on import; only `startBridgeServer()` listens. Existing HTTP tests created ephemeral loopback listeners with synthetic credentials, isolated state and mocked model calls. These were diagnostic servers, not live workers.

## Reachable Option A engine flow

1. `serve.ts:23-39` validates token/port and starts the channel adapter; no CLI switches load an OnlyFans catalogue.
2. `http.ts:303-311,440-490` authenticates a single Bearer header before routing; parses bounded strict UTF-8 JSON; validates version, direction, strings, timestamps, byte limits and server-side creator binding.
3. `identity.ts:55-64` requires account binding to the one configured creator. `identity.ts:71-95` length-prefixes UTF-8 fields and SHA-256 hashes the full conversation tuple and message tuple. IDs stay strings; malformed surrogates, path/control characters and excessive lengths are rejected in `types.ts:145-157`. Conversation state includes channel/account/creator/conversation/fan, reducing accidental cross-account collisions.
4. `requestReply()` (`service.ts:291-349`) runs global startup recovery, persists queued admission before waiting, chains work per conversation in a process-local Map, claims generation and invokes real `generateTurn()` with an empty catalogue by default.
5. `generateTurn()` / `runTurnInner()` (`turn.ts:100-181`) checks the input regex filter, reads channel transcript, appends incoming text, constructs the persona plus catalogue menu followed by the last 30 history messages, then invokes `complete()`.
6. `llm.ts:8-31,44-60` posts to OpenRouter with a fixed model/provider list and generation settings, with 45 seconds per attempt and at most two attempts. Empty replies/errors resample without backoff. No paid call was made during the audit; current provider/model availability is unverified.
7. `turn.ts:156-181` checks output regexes, extracts/removes tags, cleans style, lowercases, removes emojis and certain trailing questions, flattens lines to one message, and commits **only the inbound user message** in the channel mode. Output content is a plain string, not a validated capability/action schema.
8. `service.ts:369-401` persists a completed draft, or a failure. Filter deflections are deliverable (`outcome=blocked`); model-failure canned text is not deliverable on this channel. Actual media results are rejected as unsupported.
9. Fastt-side worker performs eligibility/revalidation/OnlyFans send. Twin itself never sends to OnlyFans.
10. `acknowledgeDelivery()` (`service.ts:411-459`) serializes on the same conversation lock, persists the delivery decision, then commits the assistant text by request identity. HTTP success follows both operations (`http.ts:505-508`). The delivery decision is permanently non-deliverable even if transcript commit fails. Recovery or the next mutating reply reconciles outstanding commits. A status-only read does not reconcile (`service.ts:475-481`).

The context is Twin-observed fan messages and acknowledged Twin replies. The wire contract accepts no historical message list, purchase, manual creator message or entitlement field (`types.ts:43-55,256-267`). It does not import previous OnlyFans conversation history. Provider event timestamps are validated but are not supplied to the LLM or retained as conversation timing facts; conversational pacing after a long silence is therefore primarily model guesswork.

## Material findings

### T1 — Competing journal writer can delete another writer's committed snapshot

- **Option / origin:** A; new custom Twin channel store.
- **Class:** Confirmed defect under a specified unsupported deployment condition. **Severity:** High if two processes access the same creator store; not evidence that a correctly enforced single process currently duplicates sends.
- **Evidence:** Test-demonstrated and code-established. `store.ts:358` selects next sequence; line 370 opens with `wx`; lines 378-391 catch failures and line 387 unconditionally removes that filename even when exclusive open failed because another writer owns it. There is no acquired-file flag or cross-process compare-and-swap. A second state writer can also publish stale snapshots sequentially because `writeState()` has no expected-version check.
- **Diagnostic:** The real `writeState()` test fault hook scheduled a successful competing `writeState()` after sequence selection and before exclusive open. The losing write threw, deleted the competitor's valid committed file and made the old seed snapshot authoritative again. This was a deterministic interleaving in one harness, not a multi-host load test; it directly exercises the production failure-cleanup boundary.
- **Impact:** Loss of durable admission/delivery evidence; rollback of memory; potential duplicate or missed work depending on lost transition. File exclusivity does not establish a safe multi-writer protocol.
- **Related risk:** `service.ts:232-258` regards every different run ID as a dead process, without checking process liveness. Starting a second server can interrupt the first server's valid claims. `http.ts:549` recovery happens before bind, so an accidentally launched second server on the same port can mutate live claims **before** its port bind fails. Unique port alone is not a single-writer guard.
- **Remediation direction / scope:** Small immediate correction to owned-file cleanup plus explicit exclusive service/store ownership; substantial replacement with transactional/versioned state and fencing for horizontal scaling. Do not scale by pointing multiple Twin processes at this directory.

### T2 — Journal layout is a structural commercial-scale bottleneck

- **Option / origin:** A; new custom Twin store. **Class:** Operational assumption / architectural limitation. **Severity:** High for large active fan populations.
- **Evidence:** Code-established. Every `readState()` calls `stateFilesFor()` (`store.ts:130-147,307-310`), which reads and filters the entire creator bridge directory. Every write again lists that directory to choose a sequence, validates and serializes the whole per-conversation request map, fsyncs, then lists again for pruning (`354-393`). Operations are synchronous and block the Node event loop. Only the newest two generation files remain, but **all request records remain in both snapshots forever** (`ConversationState.requests`, no deletion/retention path). Startup lists all conversations then runs mutation/read per conversation (`service.ts:225-265`).
- **Scaling consequence:** With C conversations and R historical requests for one conversation, ordinary state lookup has O(C) filename work plus O(R) parsing/validation, and mutations rewrite O(R) bytes. Repeated full snapshots produce approximately quadratic cumulative bytes written with lifetime turns per conversation. Startup's directory scans are O(C²) in filename processing. This is code complexity, not a measured throughput number.
- **Failure containment:** A damaged newest snapshot or legacy file causes fail-closed reads. Global recovery encounters it before listening, so one corrupt conversation can prevent the entire creator server from starting (`http.ts:547-551`). This is a defensible safety stop with a broad operational failure domain, not silent data acceptance.
- **Remediation direction / scope:** Durable transactional indexed store, compacted request/delivery records with explicit retention, partitioned tenant ownership, background recovery and operator quarantine. Large change. Keep idempotent delivery evidence while redesigning storage; do not simply delete old request records.

### T3 — OnlyFans path uses Telegram/payment/capability instructions

- **Option / origin:** A; existing Twin prompt reused unchanged by custom channel integration. **Class:** Confirmed configuration/integration defect; exact generated misstatement is model-dependent. **Severity:** Medium to high for customer trust and sales.
- **Evidence:** `template.ts:31` says the chat is on Telegram and the fan confirmed adulthood; lines 57 and 66-74 advertise pictures/videos and locked content; line 77 instructs Telegram Stars payment/access guidance. `service.ts:294,299,349` selects that same girl and passes an empty catalogue. `turn.ts:135-137` concatenates that prompt unchanged. `media.ts:183` does append “none left … don't offer any”, which helps but does not remove conflicting platform/entitlement instructions. There is no OnlyFans-specific renderer.
- **Impact:** Wrong-platform guidance can answer price/access questions incorrectly; nonexistent capability promises remain possible even though the catalogue is empty. The prompt forbids saying item prices (`template.ts:73`), so it is also poorly aligned with direct OnlyFans price questions.
- **Remediation direction / scope:** Explicit channel capability/payment facts in the prompt and output action validation; bounded medium change. No need to discard persona facts to correct channel facts.

### T4 — Unsupported media tags can leave a sendable false delivery claim

- **Option / origin:** A; existing Twin tag handling plus new text-only integration. **Class:** Confirmed output-validation defect conditional on model emitting an invalid/unavailable tag. **Severity:** Medium.
- **Evidence:** `turn.ts:163-182` strips the tag, resolves it to null against an empty menu, but sets note `ok+tag`; `text-turn.ts:38-43` rejects only a non-null media item, so `service.ts:369-391` persists a deliverable draft. No error is raised for an unresolved requested item.
- **Diagnostic:** Real channel request with the real turn engine and stub output `here is the photo [photo 1]` returned `outcome=ok`, `deliverable=true`, text `here is the photo`, with an empty catalogue. This tests validation and routing, not how often a model produces that output.
- **Remediation direction / scope:** Fail or regenerate safely when a requested action cannot resolve, and check prose/action agreement. Small to medium change.

### T5 — Underage disclosure is filtered for one turn but not retained as a safety state

- **Option / origin:** A; existing Twin filter/pipeline plus custom channel persistence. **Class:** Confirmed missing persistent safety boundary. **Severity:** High for this adult-service deployment.
- **Evidence:** `turn.ts:119-123` returns immediately on blocked input, before history is loaded or user text saved. The channel journal stores outcome/category but `bridgeTranscript.load()` (`service.ts:131-145`) returns only transcript/sent/owned/epoch and hardcodes `ageConfirmed=false`; the turn engine ignores that field. `template.ts:31` nevertheless asserts prior adulthood confirmation. The next turn never queries prior blocked categories.
- **Diagnostic:** “I'm 16.” produced a blocked deflection with zero model calls. After acknowledging it, the transcript had no user disclosure. A subsequent neutral “I like reading books.” reached the model, without that disclosure in context. No sexual content was generated or tested. This establishes missing durable exclusion, not any observed harmful model output.
- **Related boundary:** `checkText()` uses English regexes with NFKC normalization, not a semantic/multilingual safety classifier. No durable fan opt-out/stop/handoff field exists in the channel schema; a stop request must be obeyed by the model or an upstream feature, not by this engine. The regex's non-consent category is not a general unsubscribe mechanism.
- **Remediation direction / scope:** Explicit durable age/safety/consent state and enforcement before generation and delivery, with operator handoff; policy decisions should not be embedded only in remembered chat text. Medium change across bridge and engine.

### T6 — Conversation continuity is a 30-message sliding window

- **Option / origin:** A; existing Twin engine and custom transcript. **Class:** Missing capability / intentional simplicity tradeoff. **Severity:** Medium, high for long-term relationship claims.
- **Evidence:** `config.ts:37` fixes history limit at 30; `turn.ts:137` limits model history; `service.ts:142,186` truncates persisted transcript. No summary, fact extraction, retrieval, conflict resolution, memory provenance or historical OnlyFans import is called. The permanent request ledger contains output drafts/identity, not a retrievable fan fact memory. A long-term preference disappears when outside the window. The prompt's instruction to remember does not supply storage.
- **Diagnostic:** Seeded a historical preference before 30 recent messages; real context construction supplied exactly 30 messages and excluded the preference. Separately verified that an assistant draft is absent from history until delivery acknowledgement.
- **Positive:** Short recent context is coherent by construction; undelivered drafts are not mistaken for delivered chat; identities are separated; previous user text survives model failure. These are useful foundations, not proof of conversational naturalness.
- **Remediation direction / scope:** Import/reconcile authenticated platform history, preserve delivered manual messages, and add provenance-aware summaries/facts with conflict handling if long-term continuity is required. Medium to large change.

### T7 — Logs retain full sensitive context; optional monitor lacks application authentication

- **Option / origin:** A; existing Twin diagnostics. **Class:** Credible exposure/retention risk requiring access to log files or monitor reachability. **Severity:** High if monitor is exposed to untrusted networks; limited to host/tailnet access under intended deployment.
- **Evidence:** `turn.ts:68-72,139-148` writes system prompt, full model input history, fan input and raw output to `requests.jsonl`; `safety.ts:109-112` logs blocked input/output text. No rotation/deletion/retention mechanism was found in this path. `/api/turns`, `/api/blocked`, `/api/logs` expose content in `dashboard/server.ts:178-188`; `/api/vars` writes persona vars without an auth or origin check (`159-163`, `107-115`). Default host is loopback but `DASH_HOST` can expose it and an available Tailscale IPv4 address is bound automatically (`196-199`).
- **Impact:** Runtime privacy/access-control requirements extend beyond the well-authenticated bridge HTTP endpoint. A reset only clears current transcript; retained request output, logs and prior generation may remain. Reset is not a complete data-erasure implementation.
- **Remediation direction / scope:** Authentication/authorization and origin controls for any remote monitor, explicit bind policy, bounded logs with retention/redaction and coordinated deletion. Small to medium scope, depending on tenancy requirements. Monitor was not started or probed.

### T8 — Channel telemetry always reports zero model attempts

- **Option / origin:** A; custom journal metadata. **Class:** Confirmed defect. **Severity:** Low, with cost/incident investigation implications.
- **Evidence:** `store.ts:438` initializes attempts to zero; `service.ts:378-385` copies provider/tokens/cost/ms but not attempts; `service.ts:170` returns unchanged zero. Turn-level request logging separately records actual `llm.complete` attempts (`turn.ts:148`).
- **Diagnostic:** Stub model returned one HTTP 500 then success. Two model calls occurred; channel response `usage.attempts` remained 0. Costs/tokens are separately accumulated, subject to provider reporting; zero attempts does not establish zero cost.
- **Remediation direction / scope:** Carry attempts through TurnResult/GenerationResult and journal metadata; small change.

## Useful protections and deliberate operational choices

- **Authentication and input integrity:** loopback-only bridge, token minimum length, constant-time comparison, duplicate auth header rejection, strict UTF-8, 16 KiB total payload and 4,000-character text limit, timestamp timezone normalization, safe string IDs. These are genuinely implemented, not README claims (`http.ts:164-186,303-387`; `types.ts:35-41,145-222`). The one shared service token authorizes all bound accounts; this is service authentication, not per-tenant user authorization.
- **Per-conversation generation serialization:** process-local chain with separate conversations able to progress (`service.ts:99-113`). HTTP cap is four concurrent reply requests (`http.ts:69-76,465-475`), including same-conversation queues/duplicate requests. There is no separate fair tenant scheduler. Capacity rejection is explicit HTTP 429 before admission, not silently discarded work; Fastt retry policy determines eventual service.
- **Bounded model attempts:** at most two 45-second attempts (`llm.ts:24,46`). Total model time can approach 90 seconds; HTTP response deadline 100 seconds does not cancel generation or release capacity early (`http.ts:402-436`). Max theoretical generation throughput is no greater than 4/T replies/sec with four occupied slots and mean service time T seconds; actual bridge concurrency, state I/O and provider budgets can reduce it. This is a formula, not measured throughput.
- **Draft/receipt separation:** identity-based, ordered delivery decision then transcript commit. A delivery decision never becomes deliverable again after cancellation/reset/recovery. Existing child-process tests cover interrupted generation, abandoned queue, interrupted acknowledgement and already-delivered requests.
- **Cancellation:** explicit cancel does not wait behind the model lock; finalization rereads cancellation. Reset bumps epoch and cancels queued/running/completed requests but preserves delivery evidence (`service.ts:484-537`). Neither operation aborts the model fetch; cancelled generation can still consume model time/cost. Incoming messages alone do not bump epoch or cancel an older completed draft; bridge ownership logic supplies those policies.
- **Safe stops:** failed/interrupted generation is not automatically regenerated; a duplicate returns that terminal record. This prevents blind replays but requires an operator/upstream recovery policy to avoid permanent missed replies. New messages can create new requests. Completed old undelivered drafts remain stored and deliverable by their old IDs until cancel/reset; they do not block a new Twin turn.
- **Corruption/migration:** latest-snapshot checksum/schema validation, exclusive creation, fsync and retention of previous generation prevent many same-process partial-write errors. A partial newest file is an explicit stop, not implicit fallback. Legacy unsuffixed version-1 stores are rejected as requiring migration (`store.ts:125-126,142,162,258`); no automated migration was found. File fsync is present; directory fsync/power-loss durability was not demonstrated. Restoring only one side of Fastt/Twin ledgers would need a coordinated recovery plan.
- **Graceful shutdown:** adapter waits at most 5 seconds for ongoing generation before closing; executable exits after close (`http.ts:574-586`, `serve.ts:46-53`). Work still running is interrupted on restart, not resumed, by design. An HTTP-only close without exiting can leave generation alive; the executable does exit.

## Conversation and sales capability inventory

| Capability | Actual Option A engine status | Evidence / limit |
|---|---|---|
| Creator facts, voice and boundaries | Implemented and reachable | Structured per-creator vars, current local time, example texts, style constraints; `template.ts`, `riley.ts:19-27`. Only Riley registered (`girls/index.ts:17`). More prompt detail is not measured naturalness. |
| Honest AI disclosure | Prompted, model-dependent | `template.ts:31` instructs truthful disclosure if asked; cleanup preserves ordinary “AI clone” wording in existing tests. `cleanReply()` can still remove lines containing “as an AI”; no semantic guarantee. |
| Short responses/pacing | Implemented style cleanup; bridge decides timing | One output bubble, lowercasing, emoji/dash removal; hard maximum is 400 generated tokens, not a reliable character/sentence cap. Telegram typing delay/merge timer in `bot.ts` is not automatically an OnlyFans feature. |
| Historical OnlyFans continuity | Missing integration | No import contract or fetch caller in Twin; only observed inbound and acknowledged Twin output. |
| Long-term preferences / contradictory facts | Missing durable semantic memory | Last 30 messages only; prompt asks consistency, but no provenance/update policy. |
| Multilingual/slang/ambiguity | Model-dependent | English persona and regexes; no language-specific understanding or evaluation. Media keyword matching strips non-English letters (`media.ts:34-35`). |
| Context during timeout/cancellation | Partly implemented | Input retained after ordinary model failure, assistant draft withheld; interrupted request admission stores identity but not user text, so a crash before generation commit leaves no input transcript in Twin. Fastt intake remains source for recovery. |
| Catalogue matching / content descriptions | Implemented in reusable engine, unwired to OF | 3 locked photos, 1 video, 1 free photo selected by keyword overlap/random tie-break, excluding sent items; latest text weighted. Empty catalogue in actual OF service. |
| Correct content action | Partly implemented | Resolves chosen menu item; rejects actual media at channel boundary. Unresolved tags still permit prose (T4); description accuracy depends on catalogue/model. |
| Price/spend/discount policy | OF missing | Template tells model not to quote price and discusses Telegram Stars; no OF budget/cooldown/purchase controls. |
| Payment recognition / ownership | Telegram-only broader implementation | `payments.ts` polls Telegram Stars and dedupes charge IDs; `bot.ts:90-96` updates owned/sent history. Not reachable through channel server. |
| Repeat-offer avoidance | Telegram implemented, OF unwired | `sent` exclusion in menu; `owned` persisted only by Telegram purchase path. Twin OF transcript initially has empty lists and no purchase-ingestion operation. |
| Refund/access handling | Telegram-only limited test command | `bot.ts:243-253` refund command restricted to configured admin, only own latest purchase; no OF refund/entitlement workflow. |
| Sales timing/objections/follow-up | Prompt-only and model-dependent | No OF sales state machine, purchase intent classifier, measurable frequency limits or persistent declined-offer controls. |
| Sales analytics/experiments | OF absent | Local monitor analyses Telegram purchase/offer logs; no A/B assignment/outcome learning in channel engine. |
| Real conversion/retention/margin | Unmeasured | Code and mocked results cannot establish conversion performance. |

The broader Telegram implementation should not be credited as connected OnlyFans PPV capability. Its default Stars price mode is a test value (`payments.ts:22-29`); its poller fetches one page of 100 transactions every 30 seconds (`payments.ts:70-85`), with no paging recovery. Purchase ledger is append-only JSONL with in-memory seen IDs added before disk append (`payments.ts:41-55`), another potential durability gap for that separate Telegram product. These are scope/context observations, not reasons to rank A's OnlyFans text path below B.

## Common scenario responses from this component

| Scenario | Deterministic Twin-side response; full A includes upstream bridge |
|---|---|
| New fan, no history | Persona + empty catalogue + incoming text; no imported platform context. |
| Returning fan / old preference | Recent 30 messages only; old preference unavailable beyond window. |
| Conflicting memory | Both recent statements remain; no structured correction rule. |
| Rapid burst | Twin service serializes calls but has no burst-merging itself. Fastt bridge controls grouping. |
| New input during generation | New request queues; does not inherently invalidate old draft. Upstream cancellation governs stale send prevention. |
| Long silence | No message timestamps supplied in prompt; current local persona time available, elapsed conversation time not. |
| Creator intervenes | No manual creator message import API; cancel/reset endpoints available to bridge/operator. |
| Historical outgoing fetched | Not processed directly by Twin; upstream transport ownership/history policy decides. |
| Duplicate inbound ID | Same saved record, no regeneration in single process; acknowledged records never return sendable text. |
| Out of order | No provider-time ordering inside Twin; invocation ordering and upstream grouping determine transcript order. |
| Timeout / malformed model output | Two bounded attempts; terminal failed result for generation failure. Metadata validation rejects malformed provider/tokens/cost before success journal. No semantic response validator. |
| Send succeeds, acknowledgement lost | If ack reached durable decision, duplicate/recovery cannot resend from Twin state. If ack never arrived, draft remains completed; Fastt delivery ledger/reconciliation must avoid duplicate send. |
| Worker/server restart active turn | Twin marks other-run queued/in-progress as interrupted; does not automatically regenerate. Completed drafts survive; partial delivered-memory commits are reconciled. |
| Price question / objection | Model sees Telegram-specific pricing instructions; no OF product price data. |
| Already bought content | No OF purchase data; cannot accurately recognize entitlement. |
| No suitable content | Empty menu tells model not to offer; action/prose mismatch can still pass (T4). |
| Declined offer / stop | Model instruction/context only; no durable opt-out enforcement in Twin. |
| Unsupported request | Media action resolved to real item is rejected; invalid action or unsupported prose can pass. Calls/voice unavailable in prompt, but alternate pic/video suggestion is itself unavailable on OF integration. |

## Diagnostics and evidence limits

All commands were run with cwd `...\twin-sexbot` to resolve the installed tsx runtime, against source snapshot `...\output\independent-audit-20261016\twin-source-snapshot`; `.env`, real data and real logs were excluded. `VARS_DIR` was cleared only in child command environment. The application entry points were never started. Node v24.18.0 was used.

| Command (snapshot-relative script) | Real boundary / mocking | Result | What this establishes / excludes |
|---|---|---|---|
| `node --import tsx <snapshot>/scripts/check-channel.ts` | parseInboundEvent, identity and old runTextTurn wrapper; synthetic creator/temp dirs; fetch stub | 133 checks passed, exit 0 | Boundary validation/identity and wrapper properties. This wrapper is not the live durable service, so its tests alone are not sufficient. |
| `node --import tsx <snapshot>/scripts/check-recovery.ts` | Real requestReply/ack/cancel/reset/store; synthetic model; some fault hooks and real child-process restarts | 267 checks passed, exit 0 | Same-process ordering, dedupe, commit separation, corruption and restart decisions. Does not establish provider send semantics or multiwriter safety. |
| `node --import tsx <snapshot>/scripts/check-http.ts` | Real ephemeral loopback HTTP, auth, strict input, overload/deadline paths; mixed service stubs and real service with mock model | 136 checks passed, exit 0 | HTTP boundary plus real-service integration where not stubbed. No OF transport involved. |
| `node --import tsx <snapshot>/scripts/audit-diagnostics.ts` | Real store/service/generateTurn/complete; mock fetch only; six targeted diagnostics | Exit 0; four limitations/defects reproduced plus context/prompt checks | T1/T4/T5/T8 reproduced; draft/ack and 30-message context verified; template mismatch verified. No model-output quality or conversion measurement. |

Evidence files: `twin-channel-results.txt`, `twin-check-recovery-results.txt`, `twin-check-http-results.txt`, `twin-targeted-results.txt`. The custom diagnostic source is retained in the snapshot. Its synthetic journal/log evidence is in the temp directory named in targeted results. Test source was not modified except for adding the new audit-only harness.

Existing runners count failed assertions and call `process.exit(fail ? 1 : 0)`; child exit statuses are asserted by the recovery runner. They therefore propagate failures, rather than merely print PASS-like output. Some HTTP auth/limit tests deliberately replace the service with permissive operations, so their results prove adapter behavior only. Existing recovery tests use model stubs and injected write failures, plus real subprocess restart to cover persistence boundaries. They do not cover competing simultaneous processes, which the new T1 diagnostic exposed. `check-turn.ts` writes synthetic memory into the default dataDir before cleanup; it was not run unchanged in the production repository. A full broad npm test was not necessary to resolve this component's specific uncertainties.

## Decision contribution

Twin contributes creator-specific persona construction, controlled short-form style, fixed model invocation and a channel interface with useful identity and draft/delivery safety properties. Switching away loses those **implemented controls**, not proven naturalness or sales superiority. It does not currently contribute historical/long-term OnlyFans memory or an integrated OnlyFans sales engine. Its independent Node process, private HTTP protocol, separate file journal, mirrored acknowledgement state and single-writer requirements increase operational surface compared with a single native Fastt engine; that complexity buys protections that should be retained conceptually if architecture is consolidated.

The one-million-user question cannot be supported by this store or fixed four-slot server as implemented. Registered inactive fans, active daily conversations and simultaneous conversations create very different load, but directory-wide scans and whole-ledger snapshots become worse even when most fans are inactive. A transactional state/queue design, explicit tenant partitioning and model/platform budgets are prerequisites to broad deployment. The strongest argument against retaining current Twin as the production engine is its cold/short memory, Telegram-specific prompt mismatch and entirely unwired OnlyFans sales capability, in addition to its store design. The strongest argument for retaining selected Twin concepts is its clear separation of generation from confirmed delivery and explicit identity/validation boundary. A hybrid that reuses those concepts while using a better context/sales layer remains a proposal, not a tested third implementation.

### Coverage and unknowns

Inspected: all channel modules, config, LLM client, turn engine, memory, persona template/loader, safety filter, media selection, payment functions, pertinent Telegram callers, dashboard boundary, package/runtime entry points and relevant test runners. Executed: only the four isolated commands above. Excluded: real fan content, secret values, live model/provider behavior, live Telegram/OnlyFans operations, actual conversion/refund/retention data, deployment traffic, long unbounded load, filesystem power-loss behavior and remote tenancy attack testing. Original Fastt/native sales, shared transport and Fastt-side bridge runtime/config require the companion reports. These gaps materially limit naturalness/conversion claims and production-capacity claims, but do not invalidate code-established channel/store findings.
