# Security, tenancy, storage and deployment audit supplement

Audit date: 16 October 2026 (Australia/Brisbane). This supplement concerns Option A (current Fastt plus Twin bridge) and Option B (Fastt at `e72316fd9c34092f767bc6e425ca9faea340da27`). It is part of the independent comparative audit, not a deployment approval. No live application, worker or network client was started; no credential or private-message values were read. Two bounded diagnostics used synthetic data and production function bodies extracted through Python AST. Runtime: `C:\Users\conta\AppData\Local\Temp\of-preflight\venv\Scripts\python.exe`, Python 3.13.16.

## Decision implications

Neither option is ready for public, multi-tenant commercial deployment. Most severe exposure in this slice is **original/shared Fastt**, not the custom bridge: live event routes omit effective authentication/tenant filtering; publicly reachable concurrency configuration and process restart are deliberately unauthenticated; passwords are stored plaintext. Copying original Fastt retains those problems.

The custom Twin HTTP interface adds useful local-service authentication, identity separation and bounded work. Its durable store nevertheless has substantial scale and deployment constraints: synchronous directory-wide enumeration for each state operation, retained per-request journals, one creator/process, and a single-writer assumption. These are engineering limitations, not evidence that a registered-user count by itself causes failure.

## Attribution and source conventions

All source paths below are relative to the workspace. Lines refer to the inspected current working tree unless explicitly marked original. `git diff BASE -- service/auth.py service/db/engine.py service/lane_config_api.py service/lane_config.py docker-compose.yml Dockerfile LICENSE app/next.config.ts` was empty. Fastt `server.py` has one 32-line custom insertion after original line 5261: references at or below current 5262 must subtract 32 for the original snapshot; references before that are identical. The source-only probes independently run original `git show` and current bodies.

### SO-1 — Event routes expose cross-account data and permit unauthenticated subscriptions

- **Classification:** confirmed defect; high severity (critical confidentiality boundary for a public multi-tenant deployment).
- **Affected:** both A and B; original/shared Fastt.
- **Trigger:** attacker or unrelated tenant can reach the relay event endpoints through the UI proxy/direct relay. No knowledge of another account ID is required for `all` subscriptions.
- **Evidence:** `inflowwkiller/service/server.py:9070` (`ws_events`; original 9038) accepts the websocket immediately at 9079, registers an unscoped subscriber at 9082, exposes the entire account roster at 9088, and sends unfiltered events at 9096 unless the caller voluntarily supplies a filter. Registered middleware is HTTP-only. `inflowwkiller/app/next.config.ts:95`–96 rewrites `/events` and `/ws/:path*` to the relay. The exact public deployment's websocket proxy behavior was not tested.
- **SSE family:** `server.py:9045` (original 9013) defaults `scope="all"`; `events.py:432` directly subscribes that scope; `events.py:207`–216 delivers every event to `all`. `_account_isolation_middleware` at `server.py:329`–331 skips `/events`. `_share_token_gate` at 505–506 accepts the presence of either session cookie before validating it. `auth.py:356`–363 rejects a malformed cookie, but its middleware falls through to the route at 750; absence of a valid principal is not a rejection there. Thus a valid low-privilege tenant can read all events, and an arbitrary invalid cookie also bypasses the share perimeter for SSE.
- **Diagnostic:** `security_boundary_probe.py` extracts unchanged production function bodies (decorators removed), supplies two synthetic accounts, and verifies unauthenticated websocket acceptance, both account names in the roster and a foreign-account event. It also exercises the real share gate, account-isolation gate, cookie parser, session middleware, SSE subscription/broadcast/stream, verifying the invalid cookie passes through and foreign data is streamed. Both original and current source pass the defect assertions. No socket/server was bound and no real data was involved.
- **Impact:** cross-tenant customer/platform events and account roster can be disclosed; arbitrary subscriptions also consume server queues and connections. Per-subscriber queues are bounded at 500, but the number of subscribers has no visible global cap in these routes.
- **Fix direction/scope:** medium cross-cutting security work: authenticated websocket handshakes, server-derived tenant subscription scopes, fail-closed principal validation on SSE and explicit tests through actual middleware/router composition. Do not rely on voluntarily supplied account filters. Public transport verification and connection quotas are necessary follow-up tests.
- **Evidence level:** code-established and test-demonstrated at real function boundaries; external network exploitability depends on deployment reachability and remains unverified.

### SO-2 — Cached media is served before account authorization

- **Classification:** confirmed missing authorization check; high conditional confidentiality risk.
- **Affected:** both; original/shared Fastt.
- **Trigger:** a caller knows a cached CDN URL or a live image hash belonging to another account and can reach `/img`; arbitrary invalid session cookie also clears the share perimeter as SO-1 demonstrates.
- **Evidence:** `server.py:3299`–3304 returns a global disk-cache hit before `_get_client(request)` at 3307. `server.py:3556`–3584 resolves a global hash and delegates to the same path. These routes are skipped by the account middleware at 330. `_resolve_account_id` at 1348–1358 only rejects an identified principal with an unowned account and otherwise permits the request.
- **Impact:** access to a known cached private asset is not bound to account membership. This is not a claim that the hash is guessable or that all media is enumerable. The event leak makes exposure of asset references more concerning.
- **Fix direction/scope:** medium; bind cache access to authorized tenant/account before any cache hit, and distinguish global public assets from private assets. Include cache-hit and hash-alias authorization tests.
- **Evidence:** code-established; not externally exercised.

### SO-3 — Public concurrency settings and process restart intentionally bypass authentication

- **Classification:** intentional tradeoff unsuitable for the requested commercial exposure; high operational risk, not an accidental missing check.
- **Affected:** both; original/shared configuration/API.
- **Trigger:** public reachability of `/lanes-panel/config` and `/lanes-panel/restart`; restart additionally requires the relay to be PID 1, the normal Docker configuration.
- **Evidence:** `server.py:303`–307 and 497–498 explicitly exempt the three panel routes. `app/next.config.ts:126`–127 proxies the panel publicly. `service/lane_config_api.py:187`–206 persists caller-supplied ceilings. `service/lane_config.py:114`–123 floors values at 1 but sets no upper bound. `lane_config_api.py:277`–327 allows a JSON-confirmed process restart without identity validation; it has PID-1 and on-disk restart-budget guards. `Dockerfile:81` starts uvicorn as the primary process.
- **Impact:** an unauthenticated requester can persist ceilings that take effect on restart, or interrupt all creators' work. A two-per-hour restart budget limits frequency; it does not establish authorization or tenant isolation. A body/content-type guard prevents some browser-origin requests but not a caller making their own HTTP request.
- **Fix direction/scope:** small-to-medium product/security change: operator authentication and role enforcement; hard safe maximums; restart authorization/audit; test existing deployments' intended administration path. Do not silently change this during the audit.
- **Evidence:** code-established. No restart or config-write endpoint was invoked.

### SO-4 — Plaintext passwords and weak session lifecycle are inherited

- **Classification:** confirmed insecure credential handling; high if the database/backups/image are exposed. Session revocation is a missing capability.
- **Affected:** both; original/shared Fastt.
- **Evidence:** `auth.py:516`–520 stores the user password directly; 540 compares it directly. `chatters.py:436` and 471 do the same for chatter passwords. `auth.py:419`–428 sets HttpOnly/SameSite cookies but `Secure` is opt-in; `auth.py:350`–363 verifies an HMAC yet ignores issuance time, and inactivity is checked against the user's shared `last_seen_at` at 628–633. `auth.py:555`–561 only clears browser cookies on logout; it does not invalidate other copies of a session. No login throttle appears in the inspected login handlers.
- **Impact:** database compromise reveals reusable passwords immediately. A copied signed cookie remains valid while the user row remains active; logout alone does not revoke the stolen copy. Secure-flag and TLS exposure depend on deployment configuration.
- **Fix direction/scope:** medium; migrate to a password KDF with a transparent rehash/reset policy, server-side revocable sessions, bounded login attempts, secure production cookie defaults and tests. Avoid treating a shared URL token as a substitute for per-tenant authorization.
- **Evidence:** code-established. No credential values were read.

### SO-5 — Startup succeeds with an incompletely upgraded populated database

- **Classification:** confirmed defect for specified legacy schemas; high operational impact.
- **Affected:** both; original/shared `db/engine.py` (unchanged by the custom integration).
- **Trigger:** an older database whose schema requires primary-key/constraint/data migration, then normal application startup without an explicit migration procedure.
- **Evidence:** `service/db/engine.py:143`–154 creates current metadata for a new DB but stamps only `0001_initial`. For an existing DB, 162 calls `create_all`, 173–195 adds missing nullable/defaulted columns, and 215–230 adds missing model-declared indexes while logging-and-continuing on index failure. It never runs the actual Alembic upgrade chain, does not alter existing primary keys/unique constraints and skips non-null columns lacking server defaults. `service/db/migrations/versions/20260604_0200_llm_provider.py:67`–94 contains the missing table-copy migration to add provider to the cost primary key. Current model at `models.py:2256`–2262 expects `(day, account_id, provider)`, as does the reachable budget reservation upsert in `llm_client.py:535`–554.
- **Diagnostic:** `schema_upgrade_probe.py` AST-extracts the exact `init_db` function and safely compiles schema declarations into an isolated module, supplying a disposable populated SQLite DB at revision 0006 with `(day,account_id)` PK. Both original and current `init_db` return success and add `provider`, but retain the old PK and revision. An SQL operation using the production upsert conflict target fails with `ON CONFLICT clause does not match any PRIMARY KEY or UNIQUE constraint`. The synthetic row survives. This proves the upgrade boundary, not that the current pilot DB has that old schema.
- **Custom nuance:** `20261016_0200_twin_bridge_reserved.py:27`–31 adds `reserved` with a non-null server default; this particular addition is compatible with the startup catch-up. New bridge tables and their indexes are created from metadata. Do not present the shared migration mechanism as a defect introduced by the bridge.
- **Fix direction/scope:** medium-to-large deployment engineering: canonical versioned migrations, startup schema compatibility validation, populated upgrade fixtures, verified rollback/roll-forward procedures and restore drills. A blanket `alembic upgrade head` on today's stamped databases needs care because stamping and actual schema have diverged.
- **Evidence:** code-established and test-demonstrated.

### SO-6 — File-only SQLite volume does not persist the whole WAL database

- **Classification:** credible conditional data-loss risk; high under abrupt container replacement.
- **Affected:** both; original/shared deployment.
- **Trigger:** writes exist only in WAL when a container is killed/lost/replaced and its writable layer is discarded rather than gracefully checkpointed.
- **Evidence:** `docker-compose.yml:108`–112 mounts only `chatterly.db`, explicitly leaving `-wal` and `-shm` beside it inside the container. `db/engine.py:109`–113 enables WAL, `synchronous=NORMAL`, FK enforcement, a 64 MiB per-connection page cache, and 30-second busy timeout. The WAL is part of persistent database state, not disposable scratch space; SQLite's [WAL documentation](https://sqlite.org/wal.html) explains the sidecar's persistence/recovery role. A graceful stop may checkpoint; it is not a crash guarantee.
- **Impact:** acknowledged local state/ledgers can be rolled back or lost on replacement; A's duplicate prevention depends on retaining its Fastt delivery ledger as well as Twin state. Power-failure durability is also weaker with NORMAL than a fully synchronized commit policy; process crash and machine/power loss must not be conflated.
- **Fix direction/scope:** small deployment change plus substantial validation: persist the directory containing DB and sidecars, use SQLite-aware online backups, evaluate durability settings, then simulate crash/recreate/recover with synthetic sent/acknowledged turns. No destructive live test was run.
- **Evidence:** code-established configuration; crash effect inferred from SQLite documented behavior, not reproduced here.

### SO-7 — Relay build context can include service environment/secrets

- **Classification:** confirmed packaging exclusion gap; high conditional secret-disclosure risk.
- **Affected:** both; original/shared Dockerfile and ignore rules.
- **Trigger:** build directly from a workspace containing `service/.env` or `service/secrets/`, then expose image layers/build cache or run the image in another environment. The root audit confirmed `service/.env` exists without inspecting its values.
- **Evidence:** `Dockerfile:52` copies the entire `service/` tree. `.dockerignore:19` excludes root `.env` but not `service/.env` or `**/.env`; `service/secrets/` is not excluded. Specific session-secret files and captured sessions are excluded at 6–9 and 36. [Docker build-context pattern documentation](https://docs.docker.com/build/concepts/context/#syntax) establishes rooted matching; an empty root environment file exclusion does not exclude all nested environment files. `db/engine.py:35` then loads `service/.env` at runtime.
- **Impact:** sensitive build material may remain in layers even when bind mounts shadow it at runtime, and copied configuration can alter the deployed process. A separate curated deployment export could prevent the trigger; its actual deployed artifacts were not examined.
- **Fix direction/scope:** small packaging correction plus artifact inspection and rotation only if exposure is established. Avoid an image build during this audit because building would copy the very secrets under investigation.
- **Evidence:** code-established exclusion gap, deployment exposure conditional; no image inspected/built.

### SO-8 — Runtime/dependency validation remains a commercial prerequisite

- **Classification:** credible external dependency risk and operational assumption; not a locally reproduced application defect.
- **Affected:** both Fastt variants. Twin adds its Node runtime/dependencies.
- **Evidence:** `inflowwkiller/Dockerfile:16` uses Python 3.13; dependency versions are pinned directly in `requirements.txt` but no complete transitive lock/hash set was identified. Docker base images and autoheal/cloudflared images use floating tags (`docker-compose.yml:230`, 261), and autoheal receives the read-write Docker socket at 241. That is a privileged host component. Twin's `Dockerfile:1` uses Node 22 and `npm ci` consumes `package-lock.json`; it runs `tsx` from installed development dependencies.
- **SQLite advisory:** root audit verified that the available audit Python 3.13 runtime bundles SQLite 3.50.4; [SQLite WAL documentation section 11](https://sqlite.org/wal.html) describes the WAL-reset bug fixed in 3.51.3 and backported to 3.50.7. Concurrent WAL writing/checkpointing supplies the relevant class of conditions. No corruption was reproduced, and the actual deployed container SQLite version was not established. Python version support alone does not prove the bundled SQLite is patched.
- **Fix direction/scope:** medium release engineering: pin reproducible artifacts, inventory effective runtime libraries, patch the affected SQLite line before production if present, review privileged sidecars, dependency security/licence inventory and build provenance. No numerical exploit/failure likelihood is inferred.

### SO-9 — Twin file store has poor asymptotic scaling and no process fencing

- **Classification:** operational assumption/architectural limitation; high under large creator histories or multiple writers.
- **Affected:** A only; custom channel store added to Twin.
- **Evidence:** `twin-sexbot/src/channels/store.ts:130`–147 calls synchronous `readdirSync` on the entire creator bridge directory and filters it for one conversation. `readState` at 307–334 uses that enumeration, reads and validates the full snapshot. `writeState` at 358 again enumerates to choose sequence, then serializes/fsyncs the whole snapshot at 361–375; pruning at 338–345 enumerates again and retains two generations. Transcript length is bounded by `service.ts:142`/186, but request records accumulate at 271–273 and are not pruned by reset at 521–537. `recoverInterruptedRequests` at `service.ts:225`–245 walks every key, calls `mutateState`, and therefore re-enumerates the shared directory for each conversation.
- **Complexity:** let C be conversations stored for one creator, F approximately 2C snapshot files, R be cumulative requests in one conversation, and k the number of state transitions/read polls for a turn. A single mutation performs roughly three directory scans plus full-state parse/serialize: O(F + R), multiplied by k; startup discovery/recovery costs O(CF + sum(R)), hence O(C²) directory-entry inspection for fixed two generations. These are structural operation counts, not measured times. A million historical conversations concentrated under one creator imply order-trillion directory-entry examinations on restart; partitioning across creators reduces concentration but does not remove the algorithm.
- **Concurrency:** code explicitly assumes one synchronous writer (`store.ts:29`–30). `writeState:370` uses exclusive create, but its error handler at 386–387 can remove the competing writer's file after an `EEXIST` failure. The Twin-engine audit owns the direct reproduction; do not duplicate its test count. Starting another process is not a supported horizontal-scaling mechanism.
- **Fix direction/scope:** large architecture change before broad scale: transactional indexed storage for requests/conversations, bounded retention with safe idempotency tombstones, atomic/fenced writes, partitioned queues and per-conversation ownership, bounded recovery scans. Retain delivered-history semantics and strict identity binding when replacing persistence.
- **Evidence:** code-established scaling/fencing conditions; hardware capacity unmeasured.

### SO-10 — Retention and restoration are partially implemented, not a coordinated recoverability system

- **Classification:** missing capability/operational gap; medium-to-high depending on recovery target.
- **Affected:** shared Fastt plus additional A stores.
- **Implemented Fastt retention:** `server.py:2769` defaults raw message payload retention to 60 days; message rows remain. `2841`–2850 defaults automation run logs to 14d, model call logs to 30d, terminal scheduled jobs to 7d, actions and quota audit to 90d. `prune_event_inbox_once:3098`–3139 removes events after two days, with 2,000-row batches. `_payload_bytes:2986`–2995 scans payload lengths across the event and message tables; the 1.5GB raw-payload target at 2950 is not a hard total DB limit and honors a two-day event floor. Daily raw-payload/audit sweeps issue single large write transactions (`2786`–2792, `2884`–2887); large populations can hold the single SQLite writer for longer than source comments' historic timings. No timing from comments was adopted as an audit measurement.
- **Restore tooling:** `scripts/restore-prod-db.sh:35`–50 checks SQLite integrity and heuristic table counts; 64–85 uploads to a separate filename and verifies the copy; 88–96 swaps with services stopped. It is a deployment-specific manual script with thresholds requiring >100,000 messages/>1,000 fans, not a generic successful recovery test. No scheduled encrypted/offsite backup, RPO/RTO guarantee or restore rehearsal was verified.
- **Deletion:** account removal `server.py:8784`–8808 removes sessions and caches then triggers an importer (`db/repo.py:218`–248), not a complete account-data purge. `auth.py:892` onward removes users while deliberately retaining OF accounts. A dedicated `scripts/purge_stale.py` exists for manually selected stale fixtures; it is not automatic fan/tenant deletion. Twin reset at `service.ts:521`–537 retains delivered request records/text and durable evidence; its old-generation prune is not retention of the current journal. Retaining idempotency evidence is intentional and useful, but needs an explicit minimization/archive/deletion design.
- **A-specific recovery:** Fastt SQL state, filesystem account sessions and Twin file journals must be backed up/restored at a compatible boundary. Restoring only one ledger can produce disagreement about generated/delivered/acknowledged state. No coordinated recovery protocol was demonstrated.
- **Fix direction/scope:** medium-to-large operations work: backup/restore consistency specification, immutable delivery evidence policy, private-data retention/deletion workflow, archived idempotency tombstones, measured recovery drills and maintenance batching. Native retention is a useful existing capability; do not describe Fastt as having no retention.

## Useful protections and limits

- Fastt uses composite account/fan/message keys in its main message model (`models.py:477`–479), FK checks and transactional sessions (`db/engine.py:64`–79), plus scoped ownership checks on many HTTP routes (`auth.py:279`–310). SO-1/SO-2 are bypasses in reachable families, not proof that every endpoint lacks tenancy checks.
- Twin bridge has a hardcoded loopback bind (`channels/http.ts:51`, 555), minimum 32-character bearer token with constant-time digest comparison (165–168, 182–186, 302–312), account-to-creator server-side binding (`channels/identity.ts:55`–64) and hashed length-prefixed tuple keys (71–95). The token authorizes a trusted local adapter; it is not per-fan authentication or a public tenant IAM system.
- Twin input bodies are bounded at 16KiB, read with fatal UTF-8 decoding, and have 10-second read/header budgets; default generation admission is four concurrent requests and a 100-second response deadline (`http.ts:69`–76, 317–387, 465–475). Full slots are rejected before body reads. Work retains its slot until it actually settles (433–437); status/cancel remain available. This is valuable backpressure, but does not allocate fair per-tenant capacity.
- `channels/identity.ts:58` limits one creator per process; multiple mapped accounts must match that creator. The included `twin-sexbot/docker-compose.yml` starts the Telegram bot and monitor, and `Dockerfile:7` defaults to `src/bot.ts`; deploying the OnlyFans bridge needs an explicit command/service and colocated loopback routing. Separate containers do not automatically share localhost. This is a missing deployment integration, not evidence the manually launched pilot failed.
- Fastt deliberately uses a single uvicorn worker (`Dockerfile:79`–81). Per-process websocket pumps, admission pools, filesystem registries and SQLite write serialization mean adding uvicorn workers is not a proven scaling procedure. The global lanes at `server.py:3587` onward are shared across accounts; a noisy tenant can consume them. Generic event clients are unbounded in count.
- Fastt's visible top-level licence is MIT (`LICENSE:5`–13); retain the notice. Twin manifest is private and no top-level licence file was identified. This is not an adverse legal conclusion about user-owned code. Ownership/provenance and transitive dependency/provider commercial terms were not comprehensively audited.

## Transparent scale worksheet (illustrative, not measured capacity)

Use `daily inbound = active fans × inbound/fan/day`; `average inbound/s = daily inbound / 86,400`; `peak = average × concentration factor`. Distinguish registered users from active conversations and number of creators.

| Scenario | Explicit workload assumption | Derived arrival rate | Key implication |
|---|---|---|---|
| 1m registered fans | 1,000 creators; 1,000 registered/creator; 1% daily active; 20 inbound messages/active fan/day; 10× peak | 200,000/day; 2.31/s average; 23.1/s peak globally | Historical storage/recovery may dominate even with modest traffic; do not equate idle fan count with simultaneous generation. |
| 1m daily active fans | 10,000 creators; 100 active/creator; 20 inbound/day; 10× peak | 20m/day; 231.5/s average; 2,315/s peak | Shared single relay/SQLite and process-local schedulers need replacement/partitioning; provider budgets become material. |
| 1m simultaneous active conversations | 10,000 creators; 100 concurrent/creator; one inbound per 30–300s | 3,333–33,333 inbound/s | Sustained distributed service requirement; neither current implementation establishes capacity or correctness here. |
| Concentrated burst | Same global totals, but 50% traffic on 1% creators, and 2–10 rapid messages/fan | Per-hot-creator rate increases roughly 50× relative to uniform distribution | Global/per-creator queues, fair quotas and burst coalescing must be load-tested; averages conceal bottlenecks. |

For mean generation duration L seconds and one generation per reply, four Twin slots imply a service ceiling of `4/L replies/s` before serialization/storage overhead. An illustrative L of 2–15s gives 2–0.267 replies/s per process, **not a measured supported capacity**. Required active slots are approximately `reply arrival/s × L`; batching inbound bursts changes reply arrival rate. Tail latency and retries require headroom, not operation at 100% utilization. At 23.1 reply/s a flat four-slot pool would accumulate backlog unless work is partitioned/admission restricted; at 2,315 reply/s the slot requirement is roughly 4,630–34,725 under those L assumptions.

Model cost/day = `reply count × (input tokens × input-price-per-million + output tokens × output-price-per-million) / 1e6`, plus extraction/summarization/classification/vision calls if the chosen engine makes them. With 20m replies/day, assumed 2,000 input + 300 output tokens, this is `40,000 × input price + 6,000 × output price` currency units/day. No provider price or conversion-margin claim is made here. P95/p99 response duration, 2k–8k history context sensitivity, throttle/retry budgets, text vs media amplification and provider account limits must be measured before staffing/cost commitments.

Storage arithmetic: 20m inbound records/day × assumed 2KB normalized record = 40GB/day before indexes/backups; equal outgoing records approximately double that. At 2–10KB raw envelopes, the same arrivals yield 40–200GB raw data/day and a two-day retained window of 80–400GB before other tables. This is an illustrative byte assumption, not a measured Fastt row size. The current raw-payload floor can exceed the nominal 1.5GB target. Each Twin snapshot additionally holds all retained request records; two generations, replicas and backups multiply physical storage. Recovery time must include scanning/replaying/checking ledgers, not just downloading bytes.

Minimum production visibility should include accepted/persisted inbound lag, queue depth and oldest age, generation failures and provider throttles, send-unknown age, reservation age, manual-handoff/park counts, duplicate suppression, schema version, DB lock wait, disk/WAL growth, checkpoint/backup health, reconnect gaps, tenant budget usage, and successful restore verification. Existing log/health surfaces do not establish 24/7 alerts or staffed response. A safe stop can protect against duplicate sends while still requiring a visible operator resolution queue.

## Diagnostic commands and limits

```powershell
& 'C:\Users\conta\AppData\Local\Temp\of-preflight\venv\Scripts\python.exe' 'output\independent-audit-20261016\security_boundary_probe.py'
& 'C:\Users\conta\AppData\Local\Temp\of-preflight\venv\Scripts\python.exe' 'output\independent-audit-20261016\schema_upgrade_probe.py'
```

Both exit 0 when the described defect observations hold in both snapshots. They are regression/reproduction evidence, not pass certificates for the applications. Production functions are extracted instead of importing the application to prevent startup session/worker/network side effects. The security probe mocks transport and registry, excludes ASGI/Next/Traefik wire routing, and never accesses customer data. The schema probe exercises actual init logic with real SQLite/SQLAlchemy; its post-upgrade conflict statement uses the real production conflict target, not a full LLM call. Temporary DB directories are automatically cleaned by the harness.

Inspected: core authentication, tenant middleware, event stream families, image cache entry path, account-session registry/file writes, engine initialization, model keys, representative old and custom migrations, retention loops, restore tooling, Docker files/ignore rules, manifest/licence definitions, Twin HTTP/identity/store/recovery/deployment paths. Not exhausted: every one of Fastt's many admin routes, every migration on every historical schema, browser/frontend authorization behavior, external perimeter configuration, image layers, all third-party licences/CVEs, cryptographic recovery/backup procedures, actual provider rate limits and runtime fleet. Those gaps prevent any claim of a complete penetration test or million-user validation.

## Prerequisite ordering from this slice

1. Close confirmed shared authentication/tenant leaks and operator endpoints before exposing either option beyond a trusted bounded environment.
2. Fix secret packaging, credential storage/session revocation and audit effective runtime security patches.
3. Establish verified migrations plus full persistent DB/WAL storage and coordinated backups of every authoritative delivery/memory store.
4. Enforce exactly one writer for the current Twin store and deploy its loopback service explicitly; do not scale by adding duplicate processes against the same directory.
5. Replace Twin directory-wide state access and cumulative snapshot journals, and partition Fastt workers/queues/data with per-conversation ordering and fair tenant budgets.
6. Measure real provider and storage tails, restore time and operator intervention before increasing workload; “one million registered” and “one million concurrent” require distinct acceptance criteria.

These changes are not implemented by this audit. Shared security/operations debt alone cannot decide A versus B's conversation/delivery winner; it does rule out a one-for-one copy of original Fastt as a sufficient commercial risk reduction.
