$ErrorActionPreference = 'Stop'
$package = $PSScriptRoot
$workspace = Split-Path (Split-Path $package -Parent) -Parent
$state = Get-Content -LiteralPath (Join-Path $package 'SOURCE_STATE.json') -Raw | ConvertFrom-Json
$sourceManifest = [System.Collections.Generic.List[object]]::new()
$captureManifest = [System.Collections.Generic.List[object]]::new()

function Copy-Verified([string]$source, [string]$relativeDestination, [string]$kind) {
    $destination = [System.IO.Path]::GetFullPath((Join-Path $package $relativeDestination))
    if (-not $destination.StartsWith($package + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Destination escaped handover directory: $relativeDestination"
    }
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing source: $source" }
    if (Test-Path -LiteralPath $destination) { throw "Refusing to overwrite existing snapshot: $destination" }
    $before = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    [System.IO.Directory]::CreateDirectory((Split-Path $destination -Parent)) | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination
    $copied = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
    $after = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    if ($before -ne $copied -or $before -ne $after) { throw "Source changed during capture: $source" }
    $record = [pscustomobject]@{
        Kind = $kind
        Original = $source
        PackagedPath = $relativeDestination.Replace('\','/')
        Bytes = (Get-Item -LiteralPath $destination).Length
        SHA256 = $copied
    }
    $captureManifest.Add($record)
    return $record
}

$targets = @('twin-dashboard-of-d0', 'inflowwkiller-of-b1')
foreach ($name in $targets) {
    $repo = @($state.repositories | Where-Object { $_.name -eq $name })[0]
    if (-not $repo) { throw "Missing repository metadata: $name" }
    $current = @(& git -C $repo.path status --porcelain=v1 --untracked-files=all)
    if ($LASTEXITCODE -ne 0) { throw "git status failed: $name" }
    if (($current -join "`n") -ne ($repo.status -join "`n")) { throw "Source inventory changed: $name. Refresh metadata before capture." }
    foreach ($entry in $repo.status) {
        if ($entry.Substring(0, 3) -notin @(' M ', '?? ')) { throw "Unreviewed status kind: $entry" }
        $relative = $entry.Substring(3)
        if ($relative.StartsWith('"') -or $relative -match '(^|/)(\.\.|node_modules|\.venv|shots)(/|$)') { throw "Unexpected path: $relative" }
        $source = [System.IO.Path]::GetFullPath((Join-Path $repo.path $relative))
        if (-not $source.StartsWith($repo.path + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Source escaped repository: $relative" }
        $leaf = [System.IO.Path]::GetFileName($source)
        $extension = [System.IO.Path]::GetExtension($source)
        if ($leaf -notin @('.gitignore', '.env.example') -and $extension -notin @('.md','.tsx','.ts','.mjs','.json','.css','.py','.ini')) { throw "Unreviewed file type: $relative" }
        $record = Copy-Verified $source "accepted-source/$name/$relative" 'source'
        $sourceManifest.Add($record)
    }
}
if ($sourceManifest.Count -ne 89) { throw "Expected 89 source files, got $($sourceManifest.Count)" }

$references = @(
    'twin-sexbot/docs/onlyfans/CONSOLIDATION_PLAN.md',
    'twin-sexbot/docs/onlyfans/DASHBOARD_HANDOVER.md',
    'twin-sexbot/docs/telegram/CLAUDE_HANDOFF.md',
    'twin-sexbot/docs/telegram/IMPLEMENTATION_PLAN.md',
    'twin-sexbot/docs/telegram/START_HERE.md',
    'twin-sexbot/docs/telegram/PROGRESS.md',
    'twin-sexbot/docs/telegram/REVIEW_FINDINGS.md',
    'twin-sexbot/docs/telegram/P2_INCREMENT4_REVIEW.md',
    'twin-sexbot/docs/telegram/P1R_ACCEPTANCE.md',
    'twin-sexbot/docs/telegram/P1PG_ACCEPTANCE.md',
    'twin-sexbot/docs/telegram/SENDER_INVENTORY.md',
    'twin-sexbot/docs/telegram/CONFIG_MAPPING.csv',
    'twin-sexbot/docs/telegram/CAPABILITIES.csv',
    'inflowwkiller/service/twin_bridge/README.md',
    'inflowwkiller/service/native_pilot/README.md',
    'inflowwkiller-of-b1/CLAUDE.md',
    'twin-dashboard-of-d0/CLAUDE.md',
    'output/independent-audit-20261016/COMPARATIVE-AUDIT.md',
    'output/independent-audit-20261016/fastt-conversation-sales.md',
    'output/independent-audit-20261016/bridge-findings.md',
    'output/independent-audit-20261016/original-fastt-findings.md',
    'output/independent-audit-20261016/twin-findings.md',
    'output/independent-audit-20261016/security-ops-findings.md'
)
foreach ($relative in $references) {
    Copy-Verified (Join-Path $workspace $relative) "references/$relative" 'reference' | Out-Null
}

$shots = @(
    'desktop-01-inbox.png', 'desktop-02-accounts.png', 'desktop-03-unknown-delivery.png',
    'desktop-04-read-only.png', 'desktop-05-stale.png', 'desktop-06-session-expired.png',
    'desktop-07-all-channels.png', 'desktop-08-telegram-fans.png',
    'desktop-09-second-account.png', 'desktop-10-paginated.png', 'desktop-11-accounts-all-creators.png',
    'mobile-01-inbox.png', 'mobile-02-drawer.png', 'mobile-03-accounts.png'
)
foreach ($name in $shots) {
    Copy-Verified (Join-Path $workspace "twin-dashboard-of-d0/preview/onlyfans/shots/$name") "screenshots/$name" 'screenshot' | Out-Null
}

$sourceManifest | Export-Csv -LiteralPath (Join-Path $package 'SOURCE_FILES.csv') -NoTypeInformation -Encoding UTF8
$captureManifest | Export-Csv -LiteralPath (Join-Path $package 'CAPTURE_MANIFEST.csv') -NoTypeInformation -Encoding UTF8

# Manifest paths are relative to the package; the manifest excludes itself.
$files = @(Get-ChildItem -LiteralPath $package -File -Recurse -Force | Where-Object { $_.Name -ne 'PACKAGE_MANIFEST.csv' } | Sort-Object FullName)
$manifest = foreach ($file in $files) {
    [pscustomobject]@{
        Path = $file.FullName.Substring($package.Length + 1).Replace('\','/')
        Bytes = $file.Length
        SHA256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
    }
}
$manifest | Export-Csv -LiteralPath (Join-Path $package 'PACKAGE_MANIFEST.csv') -NoTypeInformation -Encoding UTF8

$zipPath = "$package.zip"
if (Test-Path -LiteralPath $zipPath) { throw "Refusing to overwrite existing archive: $zipPath" }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($package, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $true)
[pscustomobject]@{ SourceFiles=$sourceManifest.Count; References=$references.Count; Screenshots=$shots.Count; TotalFiles=$files.Count+1; Archive=$zipPath; ArchiveBytes=(Get-Item -LiteralPath $zipPath).Length } | ConvertTo-Json
