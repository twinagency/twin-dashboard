"""service/scripts_api.py — the ai_chatter content catalog + config + monitor API.

Everything the Scripts UI needs, owner-gated, all under /admin (covered by the
Next `/admin/:path*` rewrite — no next.config.ts change):

  GET  /admin/ai-chatter-config?account_id=     → {config, defaults, timezone,
                                                  utc_offset, tz_offset_minutes,
                                                  derived_sleep_window,
                                                  effective_sleep_window,
                                                  script_pack,
                                                  starter_singles, slot_help}
  PUT  /admin/ai-chatter-config                 → validate + upsert the JSON
                                                  (+ optional `timezone` column)
  GET  /admin/catalog/singles?account_id=       → the singles payload (+stats)
  PUT  /admin/catalog/singles                   → REPLACE the singles
  POST /admin/catalog/singles/simulate          → dry prompt+LLM, returns the
                                                  bubbles + parsed offer
  GET  /admin/ai-chatter/sessions?account_id=   → open offers
  POST /admin/ai-chatter/offers/{id}/cancel     → chatter kill switch

Items are saved wholesale (the editor owns the full singles list).
`description_for_ai` is the pitch contract: what the fan actually sees,
present tense.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Body, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import delete as sa_delete, func, select, update
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

import llm_client
import vault_ai_config
from auth import assert_account_owned
# The one copy of "a settings tab's Enabled owns this engine's rule row" — see
# its docstring for why five config endpoints used to hand-roll their own.
from automation_rules_api import ensure_kind_rule
from db.engine import get_session
from jsonsafe import truthy
from db.models import (
    CATALOG_IS_SINGLE, AccountAiConfig, CatalogItem,
    ContentOffer, Fan, Message, created_at_text, parse_ts,
)
from automations import (_ghost, _hook_upsell, _sell_signal, _voice, rhythm,
                         script_packs, starter_catalog)
from automations._common import load_voice_blocks
# The bound on the operator's typing-pace knob. Read from the engine rather than
# retyped, so the API cannot advertise a maximum the send path would clamp away.
from automations.pacing import MAX_DRIFT_CAP_S as _PACING_MAX_DRIFT_CAP_S
from automations.ai_chatter import (
    _CONTENT_ASK_RE,
    _DEFAULTS as _AI_CHATTER_DEFAULTS,
    _build_messages, _load_catalog, _load_persona, _manifest_block,
    _offerable_for_fan, _parse_offer_marker, _turn_kind,
)
from automations.welcome_chatter_for_info import split_for_bubbles

log = logging.getLogger("of-relay.scripts_api")

router = APIRouter()

# Ceiling for any daily-quota knob (item 21c). Well above any sane ration, low enough
# that a fat-fingered value can't become an effectively-infinite leash by accident.
# Defined before _INT_KNOBS because that dict literal reads it at import time.
_DAILY_QUOTA_MAX = 500

_INT_KNOBS = {
    "sla_minutes": (0, 1440),
    "max_lifetime_spend_cents": (0, 100_000_000),
    "max_offers_per_fan_per_day": (0, 50),
    "min_fan_msgs_between_offers": (0, 100),
    "min_fan_msgs_before_escalation_pitch": (0, 100),
    "max_fans_per_tick": (1, 100),
    "resume_after_manual_hours": (0, 168),
    "stall_ttl_hours": (1, 720),
    # Cadence controller (items 10/17/18/21).
    "session_gap_minutes": (5, 1440),
    "post_purchase_minutes": (0, 1440),
    "offer_expiry_minutes": (0, 10_080),
    "nudge_after_minutes": (1, 1440),
    # Old-fan engagement: ~one info question per this many replies.
    "old_fan_question_every": (1, 100),
    # Upsell "after a buy" knobs.
    "stop_after_unpaid_rungs": (1, 5),
    "spend_velocity_cap_7d_cents": (0, 100_000_000),
    # Flat ratchet on the proven-spend floor: +100 ⇒ every sale lifts his floor $1,
    # so a fan who keeps buying is never re-asked the same price. Pairs with
    # proven_spend_floor_mult in _FLOAT_KNOBS.
    "proven_spend_floor_add_cents": (0, 20_000),
    # How many asks may sit unanswered at once (runtime floors this at 2).
    "max_open_offers": (1, 10),
    # FASTT runner offer limits (native_pilot.engine.offer_limits); unset = 2 / 2.
    "fastt_max_open_offers": (2, 10),
    "fastt_max_offers_per_day": (0, 50),
    # Daily quota (item 21c) — the ceiling above the burst cap. 0 anywhere means
    # "no ceiling from this knob", never "cap at zero".
    "daily_quota_replies": (0, _DAILY_QUOTA_MAX),
    # The history window (plans/chat-window). Rows: how many of the newest thread
    # rows the reply model reads — ceiling 100 because at ~13.6 tokens per rendered
    # line even that is ~1,400 tokens of transcript, already the size of today's
    # whole prompt. Hours: the recency bound measured from HIS newest line; 0 means
    # "no ceiling from this knob" (plain N), per the house convention above, and 720
    # is a month. Floor: the last-resort minimum the age cut may never go below — 0
    # disables it and restores a floorless window.
    "history_window_rows": (1, 100),
    "history_window_hours": (0, 720),
    "history_window_floor": (0, 100),
    "daily_quota_after_sale": (0, _DAILY_QUOTA_MAX),
    "daily_quota_buying_signal": (0, _DAILY_QUOTA_MAX),
    # Days since his last money event inside which a fan walks the SHORT backoff
    # ladder instead of the long non-payer one. 0 retires the split entirely.
    "quota_recent_buyer_days": (0, 365),
    # The per-fan runway: HER replies to this fan before any ceiling applies. 0 retires
    # the runway (the quota then applies from his first reply) — set it deliberately.
    "daily_quota_free_replies": (0, 10_000),
    # Post-purchase objection judge — the window it watches, in hours, and how many
    # of HIS replies to the unlock it will spend a call on. Both are also the OFF
    # switch (0 either side disarms it), which is why the ranges start at 0. The
    # upper bounds are the spend guard: this is the only gate in the chat engine
    # that buys an LLM call, and it is bounded by purchases × max_msgs.
    "post_purchase_window_hours": (0, 168),
    "post_purchase_max_msgs": (0, 20),
    # She steps out (automations/_stepout.py): how many of HER replies between one
    # step-out and the next, how long she is gone, and how many messages from him
    # end it early. Whole numbers on purpose — an exchange count and a message count
    # are not fractional, and _INT_KNOBS is what keeps them from being stored as
    # 7.0 by a float coercion.
    "rhythm_stepout_min_exchanges": (1, 500),
    "rhythm_stepout_max_exchanges": (1, 500),
    # Minutes, matching the field the operator types into. The seconds every consumer
    # wants are derived once, in _stepout._minutes_to_s.
    "rhythm_stepout_min_minutes": (1, 24 * 60),
    "rhythm_stepout_max_minutes": (1, 24 * 60),
    # 0 = no early exit; she stays gone for the full draw. A real configuration.
    "rhythm_stepout_break_msgs": (0, 20),
    # Gather-close PPV (welcome_chatter_for_info's parting set). Price is clamped to OF's wire
    # range at the send site too; these bounds keep the stored value sane. Count
    # floors at 2 = pack_farewell.FAREWELL_MIN_ITEMS — a stored 1 would be a knob
    # position the planner refuses forever (the 2026-07-31 value shape).
    "gather_close_price_cents": (300, 20_000),
    "gather_close_count": (2, 10),
}

# Float-valued knobs (ladder aggressiveness). Clamped to sane ranges: the ceiling
# knob may exceed 3x (the "to the moon" lever), but not unbounded.
_FLOAT_KNOBS = {
    "escalation_mult": (1.0, 10.0),
    "max_ask_history_mult": (1.0, 20.0),
    # Proven-spend floor: never ask below his biggest single paid × this.
    "proven_spend_floor_mult": (0.0, 2.0),
    # Discounts. Capped well under 1.0 — a 100%-off "sale" is a giveaway, not a nudge.
    "haggle_discount_pct": (0.0, 0.9),
    "teaser_discount_pct": (0.0, 0.9),
    # Human typing pacing (automations/pacing.py). How often a bubble draws a real
    # "she stopped" pause, and how long one may last.
    "pacing_drift_pct": (0.0, 100.0),
    # Upper bound is pacing.MAX_DRIFT_CAP_S, not a round number: an inline hold must
    # stay under rhythm.INLINE_MAX_S (120s) or it outlives the 900s fan lease and
    # burns one of the executor's 4 GLOBAL run slots. The engine clamps to the same
    # constant, so a blob written by any other path cannot exceed it either.
    "pacing_drift_cap_s": (0.0, _PACING_MAX_DRIFT_CAP_S),
    # The flat reply bonus — added to EVERY reply (rhythm.RhythmCtx.reply_bonus_s).
    # Bounded by rhythm.INLINE_MAX_S rather than a round number, and that bound is
    # load-bearing: past it EVERY reply crosses the inline threshold, releases its
    # lease and enqueues a scheduled wake, so a pacing knob becomes a job-queue flood
    # against the executor's 4 GLOBAL run slots. Same reasoning as pacing_drift_cap_s
    # above. (The shipped value is 10s — see ai_chatter._DEFAULTS.)
    "rhythm_reply_bonus_s": (0.0, float(rhythm.INLINE_MAX_S)),
    # After a silence this long her reply returns as ONE bubble. Up to a day: the
    # ceiling only has to be past any gap she can actually take.
    "rhythm_return_single_bubble_s": (0.0, 24 * 3600.0),
    # How far apart two of his messages must be to read as a second ATTEMPT rather
    # than one thought arriving in bubbles.
    "rhythm_stepout_break_gap_s": (0.0, 3600.0),
}
_MODES = ("backup", "always")
# Where her sleep window comes from with no explicit override — the house night, or
# her own outbound histogram. See ai_chatter._DEFAULTS["rhythm_sleep_source"].
_SLEEP_SOURCES = ("default", "derived")
# msg_limits_by_signal is a NESTED object; validate its four tier caps against the
# built-in defaults (single source of truth) and always emit the COMPLETE dict so
# _load_config's shallow merge can never drop a tier. 0 = unlimited (see _cadence_gate).
_MSG_LIMIT_DEFAULTS: dict = dict(_AI_CHATTER_DEFAULTS["msg_limits_by_signal"])
_MSG_LIMIT_MAX = 500
# Each DISTINCT spend-rule window costs _spend_caps two grouped queries per sweep
# AND per fan-status poll (a 15s hot path) — bound the list, not just its fields.
_MAX_SPEND_RULES = 12
_MAX_ITEMS = 60
_TXT = 2000

# Editable line pack: bounds on what the UI may store per slot.
_MAX_PACK_LINES = 30
_PACK_LINE_MAX = 400
# How many recent outbound rows the sleep-window derivation reads. The histogram
# only needs a SHAPE, and derive_sleep_window ignores anything under 200 samples
# anyway — an unbounded scan here would starve the relay's thread pool.
_HOUR_HIST_LIMIT = 5000


def _validate_sleep_window(raw: Any) -> list[str] | None:
    """None ⇒ derive it from the account's own history. A 2-tuple of "HH:MM"
    strings ⇒ the operator overrode it in Advanced."""
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple)) or len(raw) != 2:
        raise HTTPException(422, "sleep_window must be null or two HH:MM strings")
    out: list[str] = []
    for v in raw:
        s = str(v or "").strip()
        h, _, m = s.partition(":")
        try:
            hh, mm = int(h), int(m or 0)
        except (TypeError, ValueError):
            raise HTTPException(422, f"bad sleep_window time: {s!r}")
        if not (0 <= hh <= 23 and 0 <= mm <= 59):
            raise HTTPException(422, f"bad sleep_window time: {s!r}")
        out.append(f"{hh:02d}:{mm:02d}")
    if out[0] == out[1]:
        raise HTTPException(422, "sleep_window start and end can't be the same")
    return out


def _validate_pace_curve(raw: Any) -> list[dict[str, float]] | None:
    """None ⇒ use the shipped 85/10/4/1 bands. Otherwise a list of
    {"pct", "up_to_min"} cut points, checked HERE with real errors so a bad curve
    is a 422 the operator can see — `rhythm.parse_pace_curve` deliberately returns
    None for garbage on the send path, which would make a typo look like a
    successful save that quietly changed nothing."""
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple)) or not raw:
        raise HTTPException(422, "rhythm_pace_curve must be null or a non-empty list")
    if len(raw) > rhythm.PACE_CURVE_MAX_ROWS:
        raise HTTPException(422, f"at most {rhythm.PACE_CURVE_MAX_ROWS} pace bands")
    out: list[dict[str, float]] = []
    prev = 0.0
    for i, row in enumerate(raw):
        if not isinstance(row, dict):
            raise HTTPException(422, f"pace band {i + 1} must be an object")
        try:
            pct = float(row.get("pct"))
            up_to = float(row.get("up_to_min"))
        except (TypeError, ValueError):
            raise HTTPException(422, f"pace band {i + 1}: pct and up_to_min must be numbers")
        if pct < 0:
            raise HTTPException(422, f"pace band {i + 1}: pct can't be negative")
        if not (0 < up_to <= rhythm.PACE_CURVE_MAX_MINUTES):
            raise HTTPException(
                422, f"pace band {i + 1}: up_to_min must be between 0 and "
                     f"{rhythm.PACE_CURVE_MAX_MINUTES}")
        if up_to <= prev:
            raise HTTPException(422, f"pace band {i + 1}: up_to_min must be larger "
                                     f"than the band above it ({prev:g})")
        prev = up_to
        out.append({"pct": pct, "up_to_min": up_to})
    if sum(r["pct"] for r in out) <= 0:
        raise HTTPException(422, "at least one pace band needs a percentage above 0")
    return out


def _validate_ghost_cycle(raw: Any) -> list[dict[str, float]] | None:
    """None ⇒ the shipped 3/1, 4/2, 5/2.5 cycle. Otherwise a list of
    `{"chat_days", "ghost_days"}` stages that REPEAT from the top.

    Half days are legal (the shipped cycle ends on 2.5), so these stay floats.
    A stage may declare `ghost_days: 0` — "chat 3 days, then chat 4 more" is odd
    but honest, and rejecting it would lose a row's typing to a transient zero.
    What is rejected is a cycle with no length at all: every stage zero means no
    fan has a position inside it. Checked HERE with real errors, because
    `_ghost.parse_cycle` deliberately returns None for garbage on the send
    path — which would make a typo look like a save that silently changed
    nothing (and, for THIS setting, silently reverted the account to the shipped
    cycle rather than doing nothing at all)."""
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple)) or not raw:
        raise HTTPException(422, "rhythm_ghost_cycle must be null or a non-empty list")
    if len(raw) > _ghost.MAX_ROWS:
        raise HTTPException(422, f"at most {_ghost.MAX_ROWS} ghost stages")
    out: list[dict[str, float]] = []
    for i, row in enumerate(raw):
        if not isinstance(row, dict):
            raise HTTPException(422, f"ghost stage {i + 1} must be an object")
        try:
            chat = float(row.get("chat_days"))
            ghost = float(row.get("ghost_days"))
        except (TypeError, ValueError):
            raise HTTPException(
                422, f"ghost stage {i + 1}: chat_days and ghost_days must be numbers")
        for name, v in (("chat_days", chat), ("ghost_days", ghost)):
            if not (0 <= v <= _ghost.MAX_DAYS):
                raise HTTPException(
                    422, f"ghost stage {i + 1}: {name} must be between 0 and "
                         f"{_ghost.MAX_DAYS:g}")
        out.append({"chat_days": chat, "ghost_days": ghost})
    if sum(r["chat_days"] + r["ghost_days"] for r in out) <= 0:
        raise HTTPException(422, "a ghost cycle needs at least one stage longer than 0 days")
    # Belt to the per-row braces above. The checks here exist to name the offending
    # ROW, which `_ghost.parse_cycle` cannot do (it degrades silently by contract) —
    # but that means two predicates for one rule, and the day they drift is the day a
    # cycle saves clean, reads back clean, and then quietly runs as the SHIPPED one
    # because the engine's parser rejected it. Store nothing the engine won't run.
    if _ghost.parse_cycle(out) is None:
        raise HTTPException(422, "that ghost cycle isn't one the engine can run")
    return out


def _validate_pack_overrides(raw: Any) -> dict[str, list[str]]:
    """{slot: [lines]} over the SHIPPED slots only. A slot whose lines are all
    blank is DROPPED, not stored empty — script_packs.render falls back to the
    shipped default for a missing slot, so an empty override can never turn into
    an empty message."""
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise HTTPException(422, "script_pack_overrides must be an object")
    known = set(script_packs.slots())
    out: dict[str, list[str]] = {}
    for slot, lines in raw.items():
        if slot not in known:
            continue                     # a renamed/removed slot is dropped, not an error
        if not isinstance(lines, (list, tuple)):
            raise HTTPException(422, f"script_pack_overrides.{slot} must be a list")
        clean = [str(x).strip()[:_PACK_LINE_MAX]
                 for x in lines[:_MAX_PACK_LINES] if str(x).strip()]
        if clean:
            out[slot] = clean
    return out


# ── life-expense tip ask knobs (see automations/_life_tip.Settings) ──────────
# key → the outer bounds a pair may sit in. Counts are HIS messages; days are days;
# the dollar range is what she draws from when no amount is configured.
_LIFE_TIP_PAIRS: dict[str, tuple[int, int]] = {
    "life_tip_ask_every": (1, 500),
    "life_tip_ask_every_tipped": (1, 500),
    "life_tip_ask_retry": (1, 500),
    "life_tip_ask_days": (1, 365),
    "life_tip_ask_range_dollars": (1, 500),
    # The BIG ask's own bands: a month rather than a week, and a range that has
    # to reach a locksmith bill — hence the wider dollar ceiling.
    "life_tip_big_days": (1, 365),
    "life_tip_big_range_dollars": (1, 2000),
}
_LIFE_TIP_POOL_MAX = 80        # reasons per lane
_LIFE_TIP_REASON_MAX = 60      # chars per reason
_LIFE_TIP_EXTRA_MAX = 400      # chars of operator note


def _validate_life_tip_pair(key: str, raw: Any, lo: int, hi: int) -> list[int] | None:
    """None ⇒ drop the key (the shipped constant applies). Otherwise [a, b] ints
    clamped into [lo, hi] with a ≤ b."""
    if raw in (None, "", []):
        return None
    if not isinstance(raw, (list, tuple)) or len(raw) != 2:
        raise HTTPException(422, f"{key} must be [min, max]")
    try:
        a, b = int(raw[0]), int(raw[1])
    except (TypeError, ValueError):
        raise HTTPException(422, f"{key} must be two numbers")
    a, b = max(lo, min(a, hi)), max(lo, min(b, hi))
    if a > b:
        raise HTTPException(422, f"{key}: min must not exceed max")
    return [a, b]


def _validate_life_tip_pool(key: str, raw: Any) -> list[str]:
    """A list of short reasons; a string is split on newlines/commas (the textarea).
    Empty ⇒ [] and the caller drops the key."""
    if raw in (None, ""):
        return []
    if isinstance(raw, str):
        raw = re.split(r"[\n,]", raw)
    if not isinstance(raw, (list, tuple)):
        raise HTTPException(422, f"{key} must be a list of short phrases")
    return [str(x).strip()[:_LIFE_TIP_REASON_MAX]
            for x in raw[:_LIFE_TIP_POOL_MAX] if str(x or "").strip()]


# ── ai_chatter config (mirrors tip_reward_config_api) ────────────────────────

def _validate_cfg(cfg: dict) -> dict:
    if not isinstance(cfg, dict):
        raise HTTPException(422, "config must be an object")
    out: dict[str, Any] = {}
    if "enabled" in cfg:
        out["enabled"] = bool(cfg["enabled"])
    if "engage_old_fans" in cfg:
        out["engage_old_fans"] = bool(cfg["engage_old_fans"])
    # The payer floor (ships ON — see ai_chatter._DEFAULTS). Listed here because this
    # validator DROPS any key it does not name, so an operator turning the seller
    # loose on non-buyers would have saved a config the engine never sees.
    if "payers_only" in cfg:
        out["payers_only"] = bool(cfg["payers_only"])
    # The life-expense tip ask (ships OFF — see ai_chatter._DEFAULTS). Named here
    # because this validator DROPS any key it does not name. The amount is
    # nullable on purpose: None means "she names a modest figure herself".
    if "life_tip_ask_enabled" in cfg:
        out["life_tip_ask_enabled"] = bool(cfg["life_tip_ask_enabled"])
    if "life_tip_ask_amount_dollars" in cfg:
        _amt = cfg["life_tip_ask_amount_dollars"]
        out["life_tip_ask_amount_dollars"] = (
            None if _amt in (None, "") else max(1, min(500, int(_amt))))
    # Its knobs (one card in the tab). A pair is [lo, hi] ints with lo ≤ hi; a
    # pool is a list of short strings (a newline/comma string is accepted from
    # the textarea). Blank/empty → the key is DROPPED so the shipped constant
    # applies — an operator clearing a box gets the default, not an empty pool.
    for _k, (_lo, _hi) in _LIFE_TIP_PAIRS.items():
        if _k in cfg:
            _pair = _validate_life_tip_pair(_k, cfg[_k], _lo, _hi)
            if _pair is not None:
                out[_k] = _pair
    for _k in ("life_tip_ask_reasons_her", "life_tip_ask_reasons_him"):
        if _k in cfg:
            _pool = _validate_life_tip_pool(_k, cfg[_k])
            if _pool:
                out[_k] = _pool
    if "life_tip_ask_reasons_shown" in cfg and cfg["life_tip_ask_reasons_shown"] not in (None, ""):
        try:
            out["life_tip_ask_reasons_shown"] = max(1, min(12, int(cfg["life_tip_ask_reasons_shown"])))
        except (TypeError, ValueError):
            raise HTTPException(422, "life_tip_ask_reasons_shown must be a number")
    if "life_tip_ask_extra" in cfg:
        _x = str(cfg["life_tip_ask_extra"] or "").strip()[:_LIFE_TIP_EXTRA_MAX]
        if _x:
            out["life_tip_ask_extra"] = _x
    # The BIG ask (ships OFF on its own switch — see ai_chatter._DEFAULTS). Same
    # blank-drops-the-key discipline; its pairs are in _LIFE_TIP_PAIRS above.
    if "life_tip_big_enabled" in cfg:
        out["life_tip_big_enabled"] = bool(cfg["life_tip_big_enabled"])
    for _k in ("life_tip_big_reasons_her", "life_tip_big_reasons_him"):
        if _k in cfg:
            _pool = _validate_life_tip_pool(_k, cfg[_k])
            if _pool:
                out[_k] = _pool
    if "life_tip_big_extra" in cfg:
        _x = str(cfg["life_tip_big_extra"] or "").strip()[:_LIFE_TIP_EXTRA_MAX]
        if _x:
            out["life_tip_big_extra"] = _x
    if "pivot_on_escalation" in cfg:
        out["pivot_on_escalation"] = bool(cfg["pivot_on_escalation"])
    # FASTT fan scope: which fans the FASTT runner owns for this account (see
    # onlyfans_runtime/fastt_scope.py; the deployment env is still the upper bound). Strict, and
    # `null` clears it. The PUT below carries the stored value over when the key is not sent, so a
    # tab that does not know this key cannot wipe it by saving.
    if "fastt_scope" in cfg:
        if cfg["fastt_scope"] is None:
            out["fastt_scope"] = None
        else:
            from onlyfans_runtime.fastt_scope import normalize as _fastt_scope_normalize
            try:
                out["fastt_scope"] = _fastt_scope_normalize(cfg["fastt_scope"])
            except ValueError as exc:
                raise HTTPException(422, str(exc))
    if "unsend_expired_offer" in cfg:
        out["unsend_expired_offer"] = bool(cfg["unsend_expired_offer"])
    if "cadence_enabled" in cfg:
        out["cadence_enabled"] = bool(cfg["cadence_enabled"])
    if "nudge_enabled" in cfg:
        out["nudge_enabled"] = bool(cfg["nudge_enabled"])
    # Quote-reply context in the prompt (ships ON — see ai_chatter._DEFAULTS). Listed
    # here because this validator DROPS any key it does not name, so an operator
    # turning it off in the UI would otherwise silently keep it on.
    if "reply_context_enabled" in cfg:
        out["reply_context_enabled"] = bool(cfg["reply_context_enabled"])
    # The history window (ships OFF — see ai_chatter._DEFAULTS). Named here for the
    # usual reason: this validator DROPS every key it does not name, so without this
    # line the switch could never be turned on at all. Its three numbers live in
    # _INT_KNOBS below, which clamps them.
    if "history_window_enabled" in cfg:
        out["history_window_enabled"] = bool(cfg["history_window_enabled"])
    # Prompt SHAPE (arm G) — three independent transforms, all default OFF. Same
    # reason again: unnamed keys are DROPPED here, so without these lines the flags
    # could never be turned ON at all and the rollout would look like a no-op.
    for _shape_key in ("prompt_regroup_enabled", "prompt_drop_facts_enabled",
                       "prompt_task_line_enabled"):
        if _shape_key in cfg:
            out[_shape_key] = bool(cfg[_shape_key])
    # Post-purchase objection judge (ships ON — see ai_chatter._DEFAULTS). Same
    # reason as the line above: this validator DROPS any key it does not name, so
    # an operator turning it off to stop the spend would have kept paying for it.
    if "post_purchase_objection_check" in cfg:
        out["post_purchase_objection_check"] = bool(cfg["post_purchase_objection_check"])
    # 🚨 The model-written PPV caption in 1:1 (ships ON — see ai_chatter._DEFAULTS).
    # This validator DROPS every key it does not name, and this one is ON by default,
    # so without this line the OFF SWITCH DOES NOT EXIST: an operator unticks it, the
    # save returns 200, the key never lands and `_load_config` hands the default back
    # on the next turn. `truthy`, not `bool()`, for the same reason the pack flags use
    # it — this decides whether a model writes the line on a PRICED send, and
    # `bool("false")` is True.
    if "ppv_caption_1to1" in cfg:
        out["ppv_caption_1to1"] = truthy(cfg["ppv_caption_1to1"])
    # 1:1 offer engine + human pacing + the editable line pack (all ship OFF).
    if "qualification_gate_enabled" in cfg:
        out["qualification_gate_enabled"] = bool(cfg["qualification_gate_enabled"])
    # force_ask: attach the ask when the THREAD IS HOT and the model wrote no offer
    # marker. Inert without the gate (guarded at runtime), and it only ever fires on
    # thread_heat — a 24.3x signal, vs the gate's ~1x.
    if "force_ask" in cfg:
        out["force_ask"] = bool(cfg["force_ask"])
    # The floor: ask after this many of his messages with no ask on the table. 0 = off.
    # Clamped — a 1 here would price a man on his first hello.
    if "ask_after_fan_msgs" in cfg:
        out["ask_after_fan_msgs"] = max(0, min(100, int(cfg["ask_after_fan_msgs"] or 0)))
    if "smart_pricing_enabled" in cfg:
        out["smart_pricing_enabled"] = bool(cfg["smart_pricing_enabled"])
    # ── Answer a content-ask with the content (both ship OFF) ──────
    #
    # 🚨 These MUST be named here. This validator drops every key it does not
    # list, and that has silently eaten UI keys twice on this map already — an
    # operator ticks the box, the save returns 200, and the flag never lands.
    #
    # `pack_send_enabled` is the master switch for selling a pack at all;
    # `pack_on_ask_enabled` is the trigger that answers "send me feet pics" with
    # a priced pack instead of a sentence. The trigger is inert without the
    # master (guarded in `plan_pack`/`plan_ask`), so ticking it alone does
    # nothing — which is why the tab ties them together rather than showing two
    # independent boxes.
    #
    # ⚠️ `truthy`, not `bool()`. Every other flag in this validator uses `bool()`,
    # and `bool("false")` is True — a raw-JSON edit or a migration that writes the
    # STRING "false" turns the feature ON. For a display toggle that is a wart;
    # for the two switches that send priced messages it is money, so these three
    # do not inherit it.
    if "pack_send_enabled" in cfg:
        out["pack_send_enabled"] = truthy(cfg["pack_send_enabled"])
    if "pack_on_ask_enabled" in cfg:
        out["pack_on_ask_enabled"] = truthy(cfg["pack_on_ask_enabled"])
    # Gather-close PPV: the vault folder welcome_chatter_for_info's parting set is drawn from.
    # The FOLDER IS THE SWITCH (empty = off), so this string must be named here —
    # the validator DROPS unnamed keys, and a picker whose choice never lands is
    # the exact silent-eaten-key bug this map has shipped twice. Its two numeric
    # knobs ride _INT_KNOBS above.
    if "gather_close_folder" in cfg:
        out["gather_close_folder"] = str(cfg["gather_close_folder"] or "").strip()[:120]
    # ── The same lane, called by the OTHER chat engines (both ship OFF) ────
    #
    # Auto Convo and OF AI Chat sell through `sell_lane`, which re-checks every
    # seller brake plus the qualification gate, so these two grant a permission
    # and not a bypass. They live in THIS blob rather than each engine's own
    # because the shelf flags above, the offer caps and the gate they depend on
    # are all here — two engines reading two copies of a cap is two caps.
    #
    # `truthy` for the same money reason as the two above.
    if "autoreply_sell_on_ask" in cfg:
        out["autoreply_sell_on_ask"] = truthy(cfg["autoreply_sell_on_ask"])
    if "welcome_chatter_for_info_sell_on_ask" in cfg:
        out["welcome_chatter_for_info_sell_on_ask"] = truthy(cfg["welcome_chatter_for_info_sell_on_ask"])
    # One LLM call per answer in the closer (ships ON — see ai_chatter._DEFAULTS).
    # Named here or the validator drops it silently, like every other key.
    if "closer_extract_claims_only" in cfg:
        out["closer_extract_claims_only"] = truthy(cfg["closer_extract_claims_only"])
    # Her canon only when he asks (ships ON — see ai_chatter._DEFAULTS).
    if "persona_facts_on_ask_only" in cfg:
        out["persona_facts_on_ask_only"] = truthy(cfg["persona_facts_on_ask_only"])
    # Catalogue selling in the PROMPT (ships OFF — the vault ask lane sells instead).
    if "prompt_sell_catalog" in cfg:
        out["prompt_sell_catalog"] = truthy(cfg["prompt_sell_catalog"])
    # The model's own "he asked to buy" line. SHADOW while it ships — it changes
    # the prompt and logs whether the model agreed with the regex; the regex still
    # decides. Named here or the validator drops it silently, as it has twice.
    if "sell_signal_enabled" in cfg:
        out["sell_signal_enabled"] = truthy(cfg["sell_signal_enabled"])
    # The CODE readers of the same question — "how much?" and "yes" to an offer we
    # just made (`_sell_signal.wide_ask`). Ships ON with the rest of the seller.
    if "wide_ask_enabled" in cfg:
        out["wide_ask_enabled"] = truthy(cfg["wide_ask_enabled"])
    # …and how often a "yes" to a TEASE is played as a sale (0.33 by ruling).
    # Clamped by the same helper the engines read it with, so the number stored is
    # the number that acts — a `33` typed for "33%" becomes 1.0 here rather than
    # turning the dice into "always" at send time.
    if "tease_sell_rate" in cfg:
        out["tease_sell_rate"] = _sell_signal.clamp_rate(cfg["tease_sell_rate"])
    # The rate card is a BASELINE, not a ceiling (operator ruling 2026-08-11).
    # This restores the old hard veto for an account that wants it: never charge
    # more than the attached content is worth.
    if "value_caps_price" in cfg:
        out["value_caps_price"] = truthy(cfg["value_caps_price"])
    # The ask/vault price ladder (operator ruling 2026-08-12), default ON.
    #
    # 🚨 It shipped WITHOUT this line and the commit message claimed "false
    # restores the old quote without a deploy" — which was untrue for exactly
    # the reason named above: an unlisted key is dropped, the save returns 200,
    # and a default-on money feature has no brake but a redeploy. `truthy`, not
    # `bool()`, for the same reason the two switches above use it.
    if "pack_price_ladder" in cfg:
        out["pack_price_ladder"] = truthy(cfg["pack_price_ladder"])
    if "rhythm_enabled" in cfg:
        out["rhythm_enabled"] = bool(cfg["rhythm_enabled"])
    if "rhythm_no_sleep" in cfg:
        out["rhythm_no_sleep"] = bool(cfg["rhythm_no_sleep"])
    if "rhythm_pace_buckets" in cfg:
        out["rhythm_pace_buckets"] = bool(cfg["rhythm_pace_buckets"])
    if "rhythm_pace_curve" in cfg:
        out["rhythm_pace_curve"] = _validate_pace_curve(cfg["rhythm_pace_curve"])
    # Human TYPING pacing (automations/pacing.py) — the gaps BETWEEN the bubbles of
    # one reply. Independent of rhythm_enabled: rhythm owns bubble 0's latency,
    # pacing owns bubbles 1+, and an account may want either without the other.
    # The two numerics ride _FLOAT_KNOBS below (bounds live there); these are the
    # switches. Named HERE because this validator DROPS any key it does not name —
    # an operator ticking the box in the UI would otherwise have it silently vanish
    # on save, which is exactly the bug class this comment block exists to prevent.
    if "pacing_enabled" in cfg:
        out["pacing_enabled"] = bool(cfg["pacing_enabled"])
    if "pacing_think_gaps" in cfg:
        out["pacing_think_gaps"] = bool(cfg["pacing_think_gaps"])
    # The ghost cycle — whole days dark on a fan, repeating. Inert without
    # rhythm_enabled (guarded at runtime); we still persist the operator's choice.
    if "rhythm_ghost_enabled" in cfg:
        out["rhythm_ghost_enabled"] = bool(cfg["rhythm_ghost_enabled"])
    if "rhythm_ghost_cycle" in cfg:
        out["rhythm_ghost_cycle"] = _validate_ghost_cycle(cfg["rhythm_ghost_cycle"])
    # The step-out's switch. Its numerics ride _INT_KNOBS / _FLOAT_KNOBS above
    # (bounds live there, with the reasoning beside each). Named HERE for the reason
    # the pacing block spells out: this validator DROPS any key it does not name, so
    # a knob that exists in _DEFAULTS and not here is one the operator can turn and
    # never actually change.
    if "rhythm_stepout_enabled" in cfg:
        out["rhythm_stepout_enabled"] = bool(cfg["rhythm_stepout_enabled"])
    if "rhythm_sleep_source" in cfg and cfg["rhythm_sleep_source"] is not None:
        if cfg["rhythm_sleep_source"] not in _SLEEP_SOURCES:
            raise HTTPException(
                422, f"rhythm_sleep_source must be one of {_SLEEP_SOURCES}")
        out["rhythm_sleep_source"] = cfg["rhythm_sleep_source"]
    # v2/v3 upsell lane — the hard takeover + the "after a buy" behaviors. All are
    # gated by qualification_gate_enabled at RUNTIME, so storing True with the gate
    # off is inert; we still persist the operator's choice.
    if "upsell_takes_over" in cfg:
        out["upsell_takes_over"] = bool(cfg["upsell_takes_over"])
    if "post_buy_rung_enabled" in cfg:
        out["post_buy_rung_enabled"] = bool(cfg["post_buy_rung_enabled"])
    if "gift_enabled" in cfg:
        out["gift_enabled"] = bool(cfg["gift_enabled"])
    if "filming_stall_enabled" in cfg:
        out["filming_stall_enabled"] = bool(cfg["filming_stall_enabled"])
    # The hook upsell (plans/hook-upsell) — the fourth after-a-buy surface, and the
    # early-ask window under it. Both ship OFF and both ride the gate at runtime.
    if "hook_upsell_enabled" in cfg:
        out["hook_upsell_enabled"] = bool(cfg["hook_upsell_enabled"])
    if "hook_upsell_early_ask" in cfg:
        out["hook_upsell_early_ask"] = bool(cfg["hook_upsell_early_ask"])
    # …and the read's reasoning effort (R4-c). A value outside the vocabulary lands
    # as "auto" rather than raising, deliberately: this switch exists to be TUNED in
    # production against a live account, and a 422 on a stale UI build or a typo
    # would take the whole config save down with it. "auto" is the shipped meaning
    # anyway, and `_hook_upsell.effort_for` narrows it again per model — a pick the
    # account's model does not offer never reaches the wire.
    if "hook_upsell_effort" in cfg:
        _eff = str(cfg["hook_upsell_effort"] or "").strip().lower()
        out["hook_upsell_effort"] = (_eff if _eff in _hook_upsell.EFFORT_PICKS
                                     else "auto")
    # Proven-spend floor. Ships OFF; the numeric knobs ride in
    # _INT_KNOBS / _FLOAT_KNOBS below.
    if "proven_spend_floor_enabled" in cfg:
        out["proven_spend_floor_enabled"] = bool(cfg["proven_spend_floor_enabled"])
    # Daily quota (item 21c). `daily_quota_enabled` computes it; `daily_quota_enforce`
    # decides whether a hold actually withholds a reply. They are deliberately separate
    # so an account can run a shadow day and read the real numbers first.
    if "daily_quota_enabled" in cfg:
        out["daily_quota_enabled"] = bool(cfg["daily_quota_enabled"])
    if "daily_quota_enforce" in cfg:
        out["daily_quota_enforce"] = bool(cfg["daily_quota_enforce"])
    # gen_info openers — the "deepen" phase. `enabled` is the switch; `rate` is how
    # often it may ride an ordinary reply. The rate is NOT a checkbox: at 1.0 every
    # reply to a gathered fan carries a question, which is a permanent interrogation
    # cadence. Clamped here so a bad payload can't reach a send path.
    if "profile_openers_enabled" in cfg:
        out["profile_openers_enabled"] = bool(cfg["profile_openers_enabled"])
    if "profile_openers_rate" in cfg:
        try:
            out["profile_openers_rate"] = min(1.0, max(0.0, float(cfg["profile_openers_rate"])))
        except (TypeError, ValueError):
            pass          # unparseable → leave it unset, the house default applies
    # Smart pricing without the gate is meaningless (there is no ladder to price),
    # and letting the pair drift apart would be a state the UI can't represent.
    if out.get("smart_pricing_enabled") and not out.get(
            "qualification_gate_enabled", cfg.get("qualification_gate_enabled")):
        out["smart_pricing_enabled"] = False
    if "sleep_window" in cfg:
        out["sleep_window"] = _validate_sleep_window(cfg["sleep_window"])
    if "script_pack_overrides" in cfg:
        out["script_pack_overrides"] = _validate_pack_overrides(cfg["script_pack_overrides"])
    if "mode" in cfg and cfg["mode"] is not None:
        if cfg["mode"] not in _MODES:
            raise HTTPException(422, f"mode must be one of {_MODES}")
        out["mode"] = cfg["mode"]
    for k, (lo, hi) in _INT_KNOBS.items():
        if k in cfg and cfg[k] is not None:
            try:
                out[k] = max(lo, min(int(cfg[k]), hi))
            except (TypeError, ValueError):
                raise HTTPException(422, f"{k} must be a number")
    for k, (lo, hi) in _FLOAT_KNOBS.items():
        if k in cfg and cfg[k] is not None:
            try:
                out[k] = max(lo, min(float(cfg[k]), hi))
            except (TypeError, ValueError):
                raise HTTPException(422, f"{k} must be a number")
    # Cross-field: min <= max. Read off `out` (post-clamp) so the two sides are the
    # same kind of value. This is a better ERROR MESSAGE, not the safety guarantee —
    # a PUT carrying only one half drops the other back to its default and can leave
    # an inverted stored pair this check never sees. `_stepout.Config.from_cfg` does
    # `hi = max(lo, hi)` at read time, and THAT is what keeps `randrange` from being
    # handed a negative width inside the candidate loop.
    for _lo_k, _hi_k in (("rhythm_stepout_min_exchanges", "rhythm_stepout_max_exchanges"),
                         ("rhythm_stepout_min_minutes", "rhythm_stepout_max_minutes")):
        if _lo_k in out and _hi_k in out and out[_lo_k] > out[_hi_k]:
            raise HTTPException(422, f"{_lo_k} must be <= {_hi_k}")
    ml = cfg.get("msg_limits_by_signal")
    if ml is not None:
        if not isinstance(ml, dict):
            raise HTTPException(422, "msg_limits_by_signal must be an object")
        merged = dict(_MSG_LIMIT_DEFAULTS)
        for tier in _MSG_LIMIT_DEFAULTS:
            if ml.get(tier) is not None:
                try:
                    merged[tier] = max(0, min(int(ml[tier]), _MSG_LIMIT_MAX))
                except (TypeError, ValueError):
                    raise HTTPException(422, f"msg_limits_by_signal.{tier} must be a number")
        out["msg_limits_by_signal"] = merged   # always complete → shallow-merge safe
    # Proven-spender cap floor (item 21b): a LIST of {days, min_cents, cap}. Each field
    # is a bounded non-negative int; a rule with a 0 cap/threshold is kept but is inert
    # in the gate (never caps at 0). Emitted whole so _load_config's shallow merge stores
    # the complete list, and only when the key is present (absent ⇒ keep the default).
    msp = cfg.get("msg_limits_by_spend")
    if msp is not None:
        if not isinstance(msp, (list, tuple)):
            raise HTTPException(422, "msg_limits_by_spend must be a list")
        if len(msp) > _MAX_SPEND_RULES:
            raise HTTPException(
                422, f"msg_limits_by_spend: at most {_MAX_SPEND_RULES} rules")
        rules: list[dict] = []
        for i, r in enumerate(msp):
            if not isinstance(r, dict):
                raise HTTPException(422, f"msg_limits_by_spend[{i}] must be an object")
            try:
                days = max(0, min(int(r.get("days") or 0), 365))
                min_cents = max(0, min(int(r.get("min_cents") or 0), 10_000_000))
                cap = max(0, min(int(r.get("cap") or 0), _MSG_LIMIT_MAX))
            except (TypeError, ValueError):
                raise HTTPException(
                    422, f"msg_limits_by_spend[{i}] days/min_cents/cap must be numbers")
            rules.append({"days": days, "min_cents": min_cents, "cap": cap})
        out["msg_limits_by_spend"] = rules
    # Spend-driven DAILY quota (item 21c): a LIST of {days, min_cents, quota}. Same
    # shape and bounds as above with one difference that matters — `quota: 0` means
    # UNCAPPED (a whale is never rationed), so unlike `cap` it is not clamped away as
    # inert. A rung is retired by deleting it.
    dqs = cfg.get("daily_quota_by_spend")
    if dqs is not None:
        if not isinstance(dqs, (list, tuple)):
            raise HTTPException(422, "daily_quota_by_spend must be a list")
        qrules: list[dict] = []
        for i, r in enumerate(dqs):
            if not isinstance(r, dict):
                raise HTTPException(422, f"daily_quota_by_spend[{i}] must be an object")
            try:
                days = max(0, min(int(r.get("days") or 0), 365))
                min_cents = max(0, min(int(r.get("min_cents") or 0), 10_000_000))
                quota = max(0, min(int(r.get("quota") or 0), _DAILY_QUOTA_MAX))
            except (TypeError, ValueError):
                raise HTTPException(
                    422,
                    f"daily_quota_by_spend[{i}] days/min_cents/quota must be numbers")
            qrules.append({"days": days, "min_cents": min_cents, "quota": quota})
        out["daily_quota_by_spend"] = qrules
    # The backoff ladders: LISTS of positive hour values, cycled rather than climbed.
    # Two of them — the long one a non-payer walks and the short one a recent buyer
    # walks instead — validated by the same loop so they cannot drift apart. Emitted
    # whole (shallow-merge safe). An empty list is legal and means "compute the quota
    # but never hold" for that cohort — the ladder is what does the holding.
    for _key in ("quota_backoff_hours", "quota_backoff_hours_recent_buyer"):
        qbh = cfg.get(_key)
        if qbh is None:
            continue
        if not isinstance(qbh, (list, tuple)):
            raise HTTPException(422, f"{_key} must be a list")
        try:
            hours = [max(0.0, min(float(h), 720.0)) for h in qbh]
        except (TypeError, ValueError):
            raise HTTPException(422, f"{_key} must be numbers")
        out[_key] = [h for h in hours if h > 0]
    return out


async def _outbound_hour_histogram(account_id: str,
                                   tz_offset_minutes: int | None) -> dict[int, int]:
    """Hour-of-day histogram of our OWN outbound messages, in CREATOR-LOCAL hours.

    Local, not UTC: a US creator's 3am dip sits at 08:00 UTC, and a window derived
    in UTC would put her to sleep through her peak. Bounded scan (the derivation
    only needs a shape, and it discards anything under 200 samples).

    Reads created_at as TEXT (created_at_text) and parses it here: the None-guard
    below used to cover only a SQL NULL, but a created_at of '' is not NULL — it
    made SQLAlchemy raise `Invalid isoformat string: ''` while materialising the
    rows, i.e. before this loop ever ran, 500-ing the whole Rhythm view. A
    histogram is a SHAPE; a handful of unreadable rows can simply be left out."""
    async with get_session() as s:
        rows = (await s.execute(
            select(created_at_text())
            .where(Message.account_id == account_id, Message.direction == "out")
            .order_by(Message.created_at.desc())
            .limit(_HOUR_HIST_LIMIT))).scalars().all()
    counts: dict[int, int] = {h: 0 for h in range(24)}
    bad = 0
    for raw in rows:
        ts = parse_ts(raw)
        if ts is None:
            if raw is not None:
                bad += 1            # unreadable, as opposed to simply absent
            continue
        counts[rhythm.local_now(ts, tz_offset_minutes).hour] += 1
    if bad:
        log.warning("rhythm histogram[%s]: skipped %d outbound row(s) with an "
                    "unreadable created_at", account_id, bad)
    return counts


async def _rhythm_view(account_id: str, row: AccountAiConfig | None,
                       stored: dict) -> dict[str, Any]:
    """Everything the Human Rhythm UI needs, RESOLVED server-side — the operator is
    never asked a question the data already answers."""
    tz = getattr(row, "timezone", None) if row else None
    utc_offset = int(getattr(row, "utc_offset", 0) or 0) if row else 0
    tz_off = rhythm.tz_offset_for(tz, utc_offset)
    derived = rhythm.derive_sleep_window(
        await _outbound_hour_histogram(account_id, tz_off))
    override = stored.get("sleep_window")
    # Same precedence as ai_chatter._sleep_window, and it has to STAY the same: this
    # is the number the card shows as "she sleeps X–Y", so a divergence here is the
    # UI confidently reporting a window the engine isn't running.
    source = str(stored.get("rhythm_sleep_source") or "default")
    if isinstance(override, (list, tuple)) and len(override) == 2:
        effective = list(override)
    elif source == "derived":
        effective = list(derived)
    else:
        effective = list(rhythm.DEFAULT_SLEEP)
    return {
        "sleep_source": source,
        "timezone": tz,
        "utc_offset": utc_offset,
        # None ⇒ neither a timezone nor a non-zero utc_offset is set. Rhythm stays
        # OFF for the account in that state (rhythm.tz_offset_for), so the UI blocks
        # the checkbox instead of letting her sleep through her best hours.
        "tz_offset_minutes": tz_off,
        "derived_sleep_window": list(derived),
        "effective_sleep_window": effective,
        "default_sleep_window": list(rhythm.DEFAULT_SLEEP),
    }


@router.get("/admin/ai-chatter-config")
async def get_ai_chatter_config(account_id: str = Query(...)) -> dict[str, Any]:
    assert_account_owned(account_id)
    async with get_session() as s:
        row = await s.get(AccountAiConfig, account_id)
        if row is not None:
            s.expunge_all()
    stored: dict = {}
    if row is not None and row.ai_chatter_config_json:
        try:
            stored = json.loads(row.ai_chatter_config_json) or {}
        except Exception:
            stored = {}
    voice = _voice.norm_voice(getattr(row, "voice", None) if row is not None else None)
    return {
        "account_id": account_id,
        "config": stored,
        "defaults": dict(_AI_CHATTER_DEFAULTS),
        # "Load starter pack" — ten prewritten sellable pieces, resolved for this
        # account's lane. Server-side for the same reason the pack below is:
        # `description_for_ai` is the pitch contract the model is told the fan will
        # SEE, and one click persists it onto the account. Deliberately NO `voice`
        # field on this response — after these two, nothing in the browser needs to
        # know what a lane is, and a second answer to "which lane?" on the far side
        # of the wire is the thing that goes stale.
        "starter_singles": starter_catalog.starter_singles(voice),
        # {slot: "when it fires"} for the editor's hint line. Server-side because it
        # NAMES the slots, and the slot schema is the server's — a copy in TypeScript
        # would be a third enumeration, and the one that fails quietly (a renamed slot
        # renders a blank hint rather than an error).
        "slot_help": dict(script_packs.SLOT_HELP),
        # The shipped lines, PRE-FILLED in the editor. An account with no config
        # row at all still gets the full pack — that is the "plug in your content
        # and go" surface: the words are already written.
        #
        # Served for THIS account's voice. It used to be `script_packs.PACK`
        # unconditionally, which put female lines in a male account's editor — and
        # because one keystroke in a box persists the whole box as an override, that
        # was one edit away from a male creator sending them verbatim to a fan.
        "script_pack": script_packs.shipped_pack(voice),
        **await _rhythm_view(account_id, row, stored),
    }


class _ConfigBody(BaseModel):
    account_id: str
    config: dict
    # The creator's IANA timezone — a COLUMN, not part of the config blob (rhythm,
    # welcome and the daily rollover all read it). Absent ⇒ leave it alone; ""  ⇒
    # clear it back to NULL.
    timezone: str | None = None


@router.put("/admin/ai-chatter-config")
async def put_ai_chatter_config(body: _ConfigBody = Body(...)) -> dict[str, Any]:
    assert_account_owned(body.account_id)
    clean = _validate_cfg(body.config)
    tz: str | None = None
    if body.timezone is not None:
        tz = body.timezone.strip() or None
        if tz:
            try:
                from zoneinfo import ZoneInfo
                ZoneInfo(tz)
            except Exception:
                raise HTTPException(422, f"unknown timezone: {tz!r}")
    now = datetime.utcnow()
    async with get_session() as s:
        _stored_row = await s.get(AccountAiConfig, body.account_id)
        _stored_scope = None
        if _stored_row is not None and _stored_row.ai_chatter_config_json:
            try:
                _stored_scope = (json.loads(_stored_row.ai_chatter_config_json) or {}).get("fastt_scope")
            except Exception:
                _stored_scope = None
        s.expunge_all()
    if "fastt_scope" not in clean:
        if _stored_scope is not None:
            clean["fastt_scope"] = _stored_scope
    elif clean["fastt_scope"] is None:
        del clean["fastt_scope"]
    payload = json.dumps(clean)
    async with get_session() as s:
        values: dict[str, Any] = {"ai_chatter_config_json": payload, "updated_at": now}
        if body.timezone is not None:
            values["timezone"] = tz
        await s.execute(
            sqlite_insert(AccountAiConfig)
            .values(account_id=body.account_id, utc_offset=0, **values)
            .on_conflict_do_update(index_elements=["account_id"], set_=values)
        )
    # "Enabled" is the WHOLE of on: this blob AND the `automation_rules` row that
    # runs the engine, which used to be a second checkbox on the tab that nobody
    # could tell apart from this one. `ensure_kind_rule` owns what that means.
    #
    # ⚠️ Only when the key was actually SENT. Every caller that merges a patch
    # over the stored config (the tab, prod-config.sh) carries it — but an
    # account that has NEVER saved has no `enabled` key at all, and reading that
    # absence as "off" would park a running rule on the first unrelated save.
    #
    # Nothing but the switch is passed: the cadence, payload and name are the
    # operator's, tuned in the rules editor, and a config save must not stamp on
    # them. A brand-new row gets the cadence the editor would have offered.
    if "enabled" in clean:          # `_validate_cfg` keeps the key iff it was sent
        async with get_session() as s:
            action = await ensure_kind_rule(
                s, body.account_id, "ai_chatter", enable=clean["enabled"])
        log.info("ai_chatter_rule_sync account=%s action=%s enabled=%s",
                 body.account_id, action, clean["enabled"])
    log.info("ai_chatter_config_saved account=%s tz=%s cfg=%s",
             body.account_id, tz, clean)
    async with get_session() as s:
        row = await s.get(AccountAiConfig, body.account_id)
        if row is not None:
            s.expunge_all()
    return {"account_id": body.account_id, "config": clean,
            **await _rhythm_view(body.account_id, row, clean)}


# The three prompt-shape flags (arm G). Named here so the ONE bulk toggle can't drift
# from the per-account editor's allowlist.
_PROMPT_SHAPE_FLAGS = (
    "prompt_regroup_enabled", "prompt_drop_facts_enabled", "prompt_task_line_enabled")


class _PromptShapeBody(BaseModel):
    enabled: bool = True


@router.post("/admin/ai-chatter-config/prompt-shape-all")
async def set_prompt_shape_all(body: _PromptShapeBody = Body(default=_PromptShapeBody())
                               ) -> dict[str, Any]:
    """Turn the three prompt-shape flags on (or off) for EVERY account the signed-in
    principal owns — one click instead of editing 20 raw-JSON blobs.

    Gated by the session, not a magic word: it only ever touches
    `_actor_account_ids()`, which is the caller's own set (the full registry for a
    master). An unauthenticated call raises 401 the same as the per-account editor.

    Each account is a MINIMAL raw read-merge-write — only the three flag keys change,
    every other stored key is preserved byte-for-byte. Deliberately NOT run through
    `_validate_cfg`: that validator DROPS any key it does not name, which is correct
    for the full-config PUT (the UI sends a clean blob) but would silently wipe an
    unrecognised knob here, where the stored blob is read raw. The flags are plain
    bools this endpoint sets itself, so there is nothing to validate. Idempotent, and
    reversible with enabled=false. Same non-destructive path prod-config.sh uses."""
    from auth import _actor_account_ids   # lazy: mirrors auth.py's own late imports
    ids = _actor_account_ids()
    if ids is None:
        raise HTTPException(status_code=401, detail="sign in required")
    patch = {k: bool(body.enabled) for k in _PROMPT_SHAPE_FLAGS}
    now = datetime.utcnow()
    applied: list[str] = []
    async with get_session() as s:
        rows = (await s.execute(
            select(AccountAiConfig).where(AccountAiConfig.account_id.in_(list(ids)))
        )).scalars().all()
        for row in rows:
            try:
                merged = json.loads(row.ai_chatter_config_json or "{}")
                if not isinstance(merged, dict):
                    merged = {}
            except (TypeError, ValueError):
                merged = {}
            merged.update(patch)
            await s.execute(
                sqlite_insert(AccountAiConfig)
                .values(account_id=row.account_id, utc_offset=0,
                        ai_chatter_config_json=json.dumps(merged), updated_at=now)
                .on_conflict_do_update(
                    index_elements=["account_id"],
                    set_={"ai_chatter_config_json": json.dumps(merged),
                          "updated_at": now}))
            applied.append(row.account_id)
    log.info("prompt_shape_all enabled=%s count=%d", body.enabled, len(applied))
    return {"enabled": bool(body.enabled), "count": len(applied),
            "account_ids": sorted(applied)}


# ── vault-ai config (account_ai_config.vault_ai_config_json) ─────────────────
# The default blob and the merge live in `vault_ai_config` — the ONE home, shared
# with `automations/describe_media` so the GET view and the sweep's view can't
# drift. GET returns the EFFECTIVE view (defaults + stored); PATCH deep-merges a
# partial into the stored blob and returns the new effective view.


def _load_vault_ai_stored(row: AccountAiConfig | None) -> dict:
    """The operator's stored partial ({} when absent or unreadable)."""
    if row is None:
        return {}
    return vault_ai_config.parse_stored(row.vault_ai_config_json) or {}


def _effective_vault_ai(stored: dict) -> dict:
    """Defaults + operator overrides = the blob the UI + consumers see."""
    return vault_ai_config.effective(stored)


@router.get("/admin/account-ai-config/vault-ai")
async def get_vault_ai_config(account_id: str = Query(...)) -> dict[str, Any]:
    assert_account_owned(account_id)
    async with get_session() as s:
        row = await s.get(AccountAiConfig, account_id)
    return {"account_id": account_id, "config": _effective_vault_ai(_load_vault_ai_stored(row))}


class _VaultAiPatchBody(BaseModel):
    account_id: str
    config: dict


@router.patch("/admin/account-ai-config/vault-ai")
async def patch_vault_ai_config(body: _VaultAiPatchBody = Body(...)) -> dict[str, Any]:
    assert_account_owned(body.account_id)
    if not isinstance(body.config, dict):
        raise HTTPException(422, "config must be an object")
    now = datetime.utcnow()
    async with get_session() as s:
        row = await s.get(AccountAiConfig, body.account_id)
        # Persist the operator's PARTIAL (stored ∪ patch), never the effective
        # view — baking defaults into the row would freeze today's defaults.
        stored = vault_ai_config.deep_merge(_load_vault_ai_stored(row), body.config)
        payload = json.dumps(stored)
        await s.execute(
            sqlite_insert(AccountAiConfig)
            .values(account_id=body.account_id, utc_offset=0,
                    vault_ai_config_json=payload, updated_at=now)
            .on_conflict_do_update(
                index_elements=["account_id"],
                set_={"vault_ai_config_json": payload, "updated_at": now})
        )
    log.info("vault_ai_config_patched account=%s keys=%s",
             body.account_id, sorted(body.config.keys()))
    return {"account_id": body.account_id, "config": _effective_vault_ai(stored)}


@router.get("/admin/vault-ai/ppv-week")
async def generate_vault_ppv_week(
    account_id: str = Query(...),
    weeks: int = Query(4, ge=1, le=4),
    use_llm: bool = Query(False),
    combine: bool | None = Query(None),
) -> dict[str, Any]:
    """Build a WEEK (weeks=1) or MONTH (weeks>1) escalation arc from the account's
    already-described vault and return it as a self-contained HTML review page.

    Read-only and suggest-only — nothing is armed or sent. `use_llm=true` writes
    every caption in-voice (PAINFUL_TEXTING); it makes ~7·weeks model calls, so
    the operator opts into the slower path deliberately. The account's Vault-AI
    config (price bands + combine toggle) drives the plan.
    """
    assert_account_owned(account_id)
    import vault_ppv_week as vw

    async with get_session() as s:
        row = await s.get(AccountAiConfig, account_id)
    config = _effective_vault_ai(_load_vault_ai_stored(row))
    weeks = max(1, min(int(weeks or 4), 4))
    if combine is not None:
        config.setdefault("ppv_week", {})["combine_feed_and_dm"] = bool(combine)

    if weeks == 1:
        plan = await vw.build_week(account_id, config=config, use_llm=bool(use_llm))
        html = vw.render_week_html(plan, title=f"Vault PPV week · {account_id}")
        coverage = plan["coverage"]
    else:
        plan = await vw.build_month(account_id, weeks=weeks, config=config,
                                    use_llm=bool(use_llm))
        html = vw.render_month_html(plan, title=f"Vault PPV month · {account_id}")
        coverage = plan["weeks"][0]["coverage"] if plan.get("weeks") else {}

    return {"account_id": account_id, "weeks": weeks,
            "summary": plan["summary"], "coverage": coverage, "html": html}


# ── PPV arc arming (the one place suggest-only is spent, on an explicit confirm)

class _ArcApproveBody(BaseModel):
    account_id: str
    weeks: int = 1
    use_llm: bool = False
    combine: bool | None = None


@router.post("/admin/vault-ai/ppv-week/approve")
async def approve_vault_ppv_arc(body: _ArcApproveBody = Body(...)) -> dict[str, Any]:
    """Arm the arc the operator just reviewed: book every day's drop as its own
    future-dated job so the week runs itself, then stop when it runs out.

    The plan is REBUILT here rather than accepted from the client — the browser
    only ever received rendered HTML, and taking media ids and prices back from a
    request body would make "what was approved" forgeable. Same account config and
    same exclusivity rules as the preview, so what was read is what is armed."""
    assert_account_owned(body.account_id)
    import vault_arc
    import vault_ppv_week as vw

    async with get_session() as s:
        row = await s.get(AccountAiConfig, body.account_id)
    config = _effective_vault_ai(_load_vault_ai_stored(row))
    if not config.get("enabled"):
        raise HTTPException(409, "vault_ai_off")
    weeks = max(1, min(int(body.weeks or 1), 4))
    if body.combine is not None:
        config.setdefault("ppv_week", {})["combine_feed_and_dm"] = bool(body.combine)

    if weeks == 1:
        plan = await vw.build_week(body.account_id, config=config,
                                   use_llm=bool(body.use_llm))
    else:
        plan = await vw.build_month(body.account_id, weeks=weeks, config=config,
                                    use_llm=bool(body.use_llm))

    res = await vault_arc.approve(body.account_id, plan)
    if res.get("status") == "refused":
        raise HTTPException(409, res.get("reason") or "refused")
    log.info("vault_arc_armed account=%s weeks=%d drops=%d",
             body.account_id, weeks, len(res.get("drops") or []))
    return res


@router.get("/admin/vault-ai/ppv-week/status")
async def vault_ppv_arc_status(account_id: str = Query(...)) -> dict[str, Any]:
    """What the armed arc is doing — live job state per drop. Read-only."""
    assert_account_owned(account_id)
    import vault_arc
    return await vault_arc.status(account_id)


@router.post("/admin/vault-ai/ppv-week/cancel")
async def cancel_vault_ppv_arc(account_id: str = Body(..., embed=True)) -> dict[str, Any]:
    """Stand the arc down — every drop that has not fired yet is dropped. Drops
    already sent are history and stay sent."""
    assert_account_owned(account_id)
    import vault_arc
    return await vault_arc.cancel(account_id)


# ── Catalog read (singles + per-item conversion stats) ───────────────────────

def _item_out(it: CatalogItem, stats: dict[int, dict]) -> dict:
    return {
        "id": int(it.id), "kind": it.kind, "label": it.label,
        "description_for_ai": it.description_for_ai,
        "media_ids": json.loads(it.media_ids or "[]"),
        "preview_media_ids": json.loads(it.preview_media_ids or "[]"),
        "duration_sec": it.duration_sec, "price_cents": int(it.price_cents or 0),
        "tip_unlock_cents": int(it.tip_unlock_cents or 0),
        "is_free_teaser": bool(it.is_free_teaser),
        "tags": json.loads(it.tags or "[]"), "enabled": bool(it.enabled),
        "stats": stats.get(int(it.id), {"offers": 0, "delivered": 0}),
    }


@router.get("/admin/catalog/singles")
async def list_singles(account_id: str = Query(...)) -> dict[str, Any]:
    """The singles payload. Legacy script items (`script_id NOT NULL`) are not
    listed — they are inert data, filtered off the shelf at offer time too."""
    assert_account_owned(account_id)
    async with get_session() as s:
        items = (await s.execute(
            select(CatalogItem).where(CatalogItem.account_id == account_id,
                                      CATALOG_IS_SINGLE)
            .order_by(CatalogItem.id)
        )).scalars().all()
        offer_rows = (await s.execute(
            select(ContentOffer.item_id, ContentOffer.status,
                   func.count()).where(ContentOffer.account_id == account_id)
            .group_by(ContentOffer.item_id, ContentOffer.status))).all()
        s.expunge_all()
    stats: dict[int, dict] = {}
    for item_id, status, n in offer_rows:
        d = stats.setdefault(int(item_id), {"offers": 0, "delivered": 0})
        d["offers"] += int(n)
        if status == "delivered":
            d["delivered"] += int(n)
    return {
        "account_id": account_id,
        "singles": [_item_out(it, stats) for it in items],
    }


# ── Items (wholesale replace) ────────────────────────────────────────────────

def _validate_item(raw: Any) -> dict:
    if not isinstance(raw, dict):
        raise HTTPException(422, "each item must be an object")
    def _ints(key):
        v = raw.get(key) or []
        if not isinstance(v, (list, tuple)):
            raise HTTPException(422, f"{key} must be a list")
        out = []
        for x in v:
            try:
                out.append(int(x))
            except (TypeError, ValueError):
                raise HTTPException(422, f"{key} entries must be ints")
        return out
    kind = str(raw.get("kind") or "video")
    if kind not in ("video", "image", "image_set"):
        raise HTTPException(422, "kind must be video|image|image_set")
    def _cents(key):
        try:
            return max(0, min(int(raw.get(key) or 0), 100_000_00))
        except (TypeError, ValueError):
            raise HTTPException(422, f"{key} must be a number")
    media = _ints("media_ids")
    previews = [m for m in _ints("preview_media_ids") if m in media]
    dur = raw.get("duration_sec")
    try:
        dur = max(0, int(dur)) if dur is not None else None
    except (TypeError, ValueError):
        dur = None
    return {
        "kind": kind, "label": str(raw.get("label") or "").strip()[:80] or None,
        "description_for_ai": str(raw.get("description_for_ai") or "").strip()[:_TXT] or None,
        "media_ids": json.dumps(media), "preview_media_ids": json.dumps(previews),
        "duration_sec": dur, "price_cents": _cents("price_cents"),
        # Accepted-and-zeroed: PPV is the only lane (2026-08-19), nothing reads
        # a single's tip price, and a knob that saves fine and does nothing
        # lies to the next operator. Legacy script rows keep theirs — this
        # editor never touches them.
        "tip_unlock_cents": 0,
        "is_free_teaser": bool(raw.get("is_free_teaser")),
        "tags": json.dumps([str(t)[:40] for t in (raw.get("tags") or [])][:12]),
        "enabled": bool(raw.get("enabled", True)),
    }


class _ItemsBody(BaseModel):
    account_id: str
    items: list[dict]


@router.put("/admin/catalog/singles")
async def put_singles(body: _ItemsBody = Body(...)) -> dict:
    """REPLACE the singles wholesale. The delete is scoped to singles — legacy
    script rows are inert data this editor never touches (deleting one would
    CASCADE its content_offers away)."""
    assert_account_owned(body.account_id)
    if len(body.items) > _MAX_ITEMS:
        raise HTTPException(422, f"too many items (max {_MAX_ITEMS})")
    clean = [_validate_item(it) for it in body.items]
    now = datetime.utcnow()
    async with get_session() as s:
        await s.execute(sa_delete(CatalogItem).where(
            CatalogItem.account_id == body.account_id,
            CATALOG_IS_SINGLE))
        for it in clean:
            s.add(CatalogItem(account_id=body.account_id,
                              created_at=now, updated_at=now, **it))
    return {"status": "ok", "items": len(clean)}


@router.get("/admin/catalog/singles/suggest")
async def suggest_singles_content(
    account_id: str = Query(...),
    only_empty: bool = Query(True),
) -> dict[str, Any]:
    """Propose vault media for singles that have TEXT but no CONTENT.

    Read-only and free — no LLM, no OF traffic; the match is derived from each
    row's own `label`/`description_for_ai` against the stored V2 describe
    fields. Nothing is saved: the UI patches the rows it likes and the operator
    still presses Save, so a proposal can always be thrown away.

    `only_empty=false` re-proposes over rows that already carry media, for
    comparison — it still does not write.
    """
    import vault_solo_fill

    assert_account_owned(account_id)
    res = await vault_solo_fill.suggest_singles(account_id, only_empty=only_empty)
    # `items` carries whole vault rows (describe blobs); the client only needs
    # the ids, and the thumbs come from the existing by-id vault read.
    return {
        **{k: v for k, v in res.items() if k != "proposals"},
        "proposals": [{k: v for k, v in p.items()
                       if k not in ("items", "previews")}
                      for p in res["proposals"]],
    }


class _GenerateLinesBody(BaseModel):
    account_id: str
    limit: int = 8


@router.post("/admin/catalog/singles/generate-lines")
async def generate_catalog_lines(body: _GenerateLinesBody = Body(...)) -> dict[str, Any]:
    """Write NEW caption lines from the vault's own vision facts.

    The sibling of `/suggest-texts`: that one offers 14 fixed captions that are
    identical for every account, this one writes lines about the media THIS
    creator actually has and nothing is selling yet. Same row shape, so the same
    pick-list / Fill content / Save path handles both.

    POST because it costs money — one cheap DeepSeek call per media group,
    through `llm_client` so it is capped and audited. Writes nothing to the
    catalog; the operator still picks and saves.
    """
    import vault_catalog_copy

    assert_account_owned(body.account_id)
    return await vault_catalog_copy.generate_lines(
        body.account_id, limit=max(1, min(int(body.limit), 12)))


class _DraftFillBody(BaseModel):
    account_id: str
    only_empty: bool = True
    # Unsaved editor rows — label / description_for_ai / kind each.
    drafts: list[dict[str, Any]] = []
    # Let a row take media another row already sells. Operator toggle: with 18
    # rows over 101 items a caption can match 69 photos and still fill with
    # none, because every one is spoken for.
    allow_reuse: bool = False


@router.post("/admin/catalog/singles/suggest")
async def suggest_singles_content_with_drafts(
    body: _DraftFillBody = Body(...),
) -> dict[str, Any]:
    """Same as the GET, but also fills rows that are not saved yet.

    "Suggest text sets" appends caption rows to the editor with no row id, and
    the GET form reads its targets from the DB — so Fill content was a no-op on
    exactly the rows it existed to serve (verified: 0 of 13 filled). Posting the
    drafts lets them compete for the vault alongside the saved rows. Still
    writes NOTHING; the operator saves.
    """
    import vault_solo_fill

    assert_account_owned(body.account_id)
    res = await vault_solo_fill.suggest_singles(
        body.account_id, only_empty=body.only_empty, drafts=body.drafts,
        allow_reuse=body.allow_reuse)
    return {
        **{k: v for k, v in res.items() if k != "proposals"},
        "proposals": [{k: v for k, v in p.items()
                       if k not in ("items", "previews")}
                      for p in res["proposals"]],
    }


@router.get("/admin/catalog/singles/suggest-texts")
async def suggest_singles_texts(account_id: str = Query(...)) -> dict[str, Any]:
    """Propose CAPTION rows to add — text, price and kind, no media.

    The other half of `/singles/suggest`: that one fills content into a row that
    already has text, but nothing produced the text, so an empty catalog stayed
    empty. These rows drop straight into the singles editor and are then filled
    by "Fill content" and written by "Save singles" — so this endpoint writes
    NOTHING and a suggestion can always be thrown away.

    Read-only and free — no LLM, no OF. Every proposal is checked against the
    UNBOUND vault first, so a caption is only offered if this vault can honestly
    fill it; the rest come back under `shoot` as a shot-list. If the vault has
    no V2 describe fields, `blocked` says to run Describe rather than reporting
    a content gap that isn't one.
    """
    import vault_catalog_seed

    assert_account_owned(account_id)
    return await vault_catalog_seed.suggest_texts(account_id)


# ── Simulate (dry prompt + LLM — catches a bad single before any fan) ────────

class _SimulateBody(BaseModel):
    account_id: str
    fan_says: str = "ngl im kinda in the mood.. u got anything for me? 🥵"


@router.post("/admin/catalog/singles/simulate")
async def simulate(body: _SimulateBody = Body(...)) -> dict[str, Any]:
    assert_account_owned(body.account_id)
    from automations.ai_chatter import _Cand  # local: avoid cycles
    # The DRY RUN has to be built the way the live turn is, or it stops being a dry
    # run and becomes a different prompt that happens to return text. The live path
    # resolves this bundle and passes `v=` (ai_chatter's `_build_messages(... v=
    # voice_blocks)`); leaving it to the `_voice.HER` default previewed a male
    # account in a woman's voice — the one thing an operator opens Test it to check.
    v = await load_voice_blocks(body.account_id)
    items = await _load_catalog(body.account_id)
    offerable = await _offerable_for_fan(body.account_id, 0, items)
    # The live turn builds this surface for EVERY account now — customs included,
    # which is the case with no catalogue at all — so the preview must not gate on
    # `offerable` or it silently shows a bought-out account the no-offers prompt.
    sell = _manifest_block(offerable, sell_customs=v.sell_customs)
    persona = await _load_persona(body.account_id)
    c = _Cand(0)
    c.messages = [("in", body.fan_says.strip()[:400])]
    c.last_dir, c.last_body = "in", body.fan_says.strip()[:400]
    content_ask = bool(sell.close) and bool(_CONTENT_ASK_RE.search(c.last_body))
    # Same source the live turn reads, so the preview cannot drift from it.
    from automations._common import detect_pic_offer  # local: avoid cycles
    from automations.tip_reward_config import image_describe_flags
    describe_on, _seed, _scope = await image_describe_flags(body.account_id)
    msgs, _presented = _build_messages(
        persona, Fan(account_id=body.account_id, fan_id=0), c, set(), 20,
        sell=sell, v=v,
        content_ask=content_ask,
        # ⚠️ ASK THE SELECTOR, never hand-roll the answer. The prompt ladder dispatches
        # on `kind`, so a caller that omits it renders the plain-chat tail — which is
        # how this preview silently lost the content-ask directive: the operator typed
        # "send me that video", hit Test, and got banter with no pitch while the live
        # engine pitched. The preview's job is to render what production would.
        #
        # The other inputs are False by construction here: the simulator has one fan
        # message and no history, so there is no accusation, no inbound picture, no
        # armed dare and no thread heat to read.
        #
        # ⚠️ `pic_offer` IS NOT ONE OF THOSE. It reads `c.last_body` and nothing else —
        # the one line this simulator does have — so it is the one new input that can be
        # computed exactly, and it must be, because it OUTRANKS content_ask. Typing
        # "you wanna see my cock?" here scored as a content-ask and previewed her
        # pitching, while production answered "send it, i'll rate it" with no price.
        # Mirrors the live expression in ai_chatter.run(); `c.pic_sent` is False by
        # construction (the simulator carries no inbound media), and describe_on is
        # loaded because promising a rating the vision layer cannot deliver is the one
        # thing that turns this beat off in production.
        kind=_turn_kind(bot_accused=False, pic_desc="", content_ask=content_ask,
                        escalation=False, image_dare=False, dare_callback=False,
                        hot_thread=False, can_sell=bool(sell.close),
                        pic_offer=bool(describe_on and not c.pic_sent
                                       and detect_pic_offer(c.last_body))))
    model = await _resolve_sim_model(body.account_id)
    res = await llm_client.chat(model=model, messages=msgs,
                                purpose="ai_chatter_simulate",
                                account_id=body.account_id, fan_id=0,
                                temperature=0.85)
    raw = (res.content or "").strip()
    clean, offer_id = _parse_offer_marker(raw)
    item = offerable.get(offer_id) if offer_id is not None else None
    return {
        "bubbles": split_for_bubbles(clean, 6),
        "offer": None if item is None else {
            "item_id": int(item.id), "label": item.label,
            "price_cents": int(item.price_cents or 0),
            "tip_unlock_cents": int(item.tip_unlock_cents or 0),
            "is_free_teaser": bool(item.is_free_teaser),
        },
        "offerable_count": len(offerable),
        "manifest_present": sell.live,
    }


async def _resolve_sim_model(account_id: str) -> str:
    from automations._common import resolve_model
    return await resolve_model(account_id, "ai_chatter", None)


# ── Monitor: open offers + kill switch ───────────────────────────────────────

@router.get("/admin/ai-chatter/sessions")
async def sessions(account_id: str = Query(...)) -> dict[str, Any]:
    assert_account_owned(account_id)
    async with get_session() as s:
        offers = (await s.execute(
            select(ContentOffer, CatalogItem.label)
            .join(CatalogItem, CatalogItem.id == ContentOffer.item_id)
            .where(ContentOffer.account_id == account_id)
            .order_by(ContentOffer.offered_at.desc()).limit(200))).all()
        fan_ids = {int(o.fan_id) for o, _ in offers}
        names: dict[int, str] = {}
        if fan_ids:
            for fid, nick, disp in (await s.execute(
                    select(Fan.fan_id, Fan.custom_nickname, Fan.of_display_name)
                    .where(Fan.account_id == account_id,
                           Fan.fan_id.in_(fan_ids)))).all():
                names[int(fid)] = (nick or disp or "").split("/")[0]
    return {
        "offers": [{
            "id": int(o.id), "fan_id": int(o.fan_id),
            "fan_name": names.get(int(o.fan_id), ""),
            "item_label": label, "mode": o.mode, "status": o.status,
            "price_cents": int(o.price_cents or 0),
            "tip_unlock_cents": int(o.tip_unlock_cents or 0),
            "tips_accum_cents": int(o.tips_accum_cents or 0),
            "resolved_by": o.resolved_by,
            "offered_at": o.offered_at.isoformat() if o.offered_at else None,
        } for o, label in offers],
    }


class _CancelBody(BaseModel):
    account_id: str


@router.post("/admin/ai-chatter/offers/{offer_id}/cancel")
async def cancel_offer(offer_id: int, body: _CancelBody = Body(...)) -> dict:
    assert_account_owned(body.account_id)
    now = datetime.utcnow()
    async with get_session() as s:
        res = await s.execute(
            update(ContentOffer)
            .where(ContentOffer.id == int(offer_id),
                   ContentOffer.account_id == body.account_id,
                   ContentOffer.status == "open")
            .values(status="cancelled", resolved_by="manual",
                    resolved_at=now, updated_at=now))
    if (res.rowcount or 0) == 0:
        raise HTTPException(404, "no open offer with that id")
    return {"status": "ok"}
