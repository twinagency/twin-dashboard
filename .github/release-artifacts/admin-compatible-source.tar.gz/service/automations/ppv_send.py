"""service/automations/ppv_send.py — the PPV Library sender.

One premade PPV → fanned out to spend×recency fan SEGMENTS, the SAME media at a
DIFFERENT price per segment, with a rotated preview teaser. Self-registers via
`@register("ppv_send")`.

Where it fits:
  • Operator builds ~20 PPVs in the "PPV Library" tab (ppv_library_config_api),
    each = vault media ids + a caption-pool key + a base price + preview options
    + sends_per_week + resend_monthly.
  • On save the config API upserts ONE `ppv_send` AutomationRule for the whole
    account — the hourly rotator tick (`{account_id}`, no ppv_id). Which PPV a
    tick belongs to is decided HERE (`_pick_due_ppv`): each enabled PPV is due
    again `604800 / sends_per_week` seconds after its last delivered send, the
    most-starved due PPV wins the tick.
  • A payload that DOES name a PPV (`{account_id, ppv_id}`) skips rotation and
    sends exactly that one — the cap-defer one-shots, monthly resends, vault_arc
    drops and test drives all still work that way.

Per run it:
  1. reads the PPV from `account_ai_config.ppv_library_config_json`,
  2. buckets every fan into exactly ONE spend×recency cell (so nobody is double
     billed in a run) via the indexed `fans.lifetime_spend_cents` /
     `fans.last_message_received_at` columns,
  3. for each non-empty cell: price = base × spend_mult × recency_mult (rounded to
     .99, floored at $3.99 — OF rejects priced messages under $3.00), a day-ROTATED
     preview from the pool (every resend looks fresh), a random caption with the
     {now}/{was}/{off} discount tokens filled, then delegates to `send_mass_message.run`,
  4. if `resend_monthly`, enqueues a one-shot `ppv_send` at now+30d (a later day →
     a different rotated preview). Buyers drop out (exclude_buyers); non-buyers keep
     getting the same locked content re-pitched with a new teaser until they unlock.
  5. `owner_second_leg` (per account, default OFF): the fans step 3's ownership
     guard removed get a SECOND cell pass with a different library PPV instead of
     nothing. Cells only, and its ledger rows carry `{ppv_id}#sub` so neither the
     duplicate gate nor the rotator can see them. See `_pick_second_ppv`.

Idempotency / duplicate-fire protection:
  • duplicate-fire gate — skip when THIS ppv already sent (cells_sent>0) within
    `min_send_gap_minutes` (account cfg, default 60; 0 = off). Kills the
    executor's whole-job-retry double-blast seen live 2026-07-01/03: a proxy
    error mid-batch failed the job AFTER some cells had broadcast, and the
    retry re-sent them ~90s later.
  • per-cell containment — a cell/broadcast send failure is RECORDED in the
    stats (status 'error' per cell), never raised, so the executor NEVER
    retries a partially-sent batch wholesale. A failed cell's fans catch the
    next cadence fire instead.
  • ppv_caps even-spread spacing is ON BY DEFAULT (2/day, 14/week, 60/month —
    a 12h minimum gap between ANY two PPV sends on the account); saving explicit
    zeros in the PPV Library tab turns it off. The contact guard (`pause_hours`
    > 0) still applies on top, but its default 0 keeps it OFF.

Payload shape::

    {"account_id": "123456789",
     "ppv_id": "ppv_a3f9",           # optional — absent = rotate (the rule tick)
     "is_resend": false,            # true = the +30d monthly repeat (fresh preview)
     "dry_run": false,              # plan only — no send, no enqueue
     "force_ids": [123],            # test-scope: restrict the audience, BYPASSES the caps
     "only_fan_ids": [123]}         # scope the audience with EVERY GATE STILL ARMED

`force_ids` vs `only_fan_ids` (the ai_chatter convention, mirrored here):
  • force_ids   — a human live-test scope. Bypasses the per-account cap and the
    duplicate-fire gate on purpose. It is NOT a whitelist: it says WHO, never
    "and therefore anything goes".
  • only_fan_ids — a MACHINE scope (the Human Rhythm scheduler resuming a deferred
    send for one fan). Every gate stays armed: caps, duplicate-fire, the ownership
    guard. A resume that bypassed those would re-sell owned media / double-blast,
    which is precisely what the deferral was trying to avoid.
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
from datetime import datetime, timedelta
from typing import NamedTuple

from sqlalchemy import func, select

import audiences
import ownership
import vault_ai_to_chatter
from automation_registry import register
from db.engine import get_session
from db.models import (
    AccountAiConfig, Blacklist, Fan, MassRun, Message,
    Post, RhythmState, ScheduledJob, Transaction,
)
from ._common import load_hard_skip_ids, load_voice_blocks
from ._leash import _last_money_at
from . import _customs, _ghost, _voice
from . import describe_media

log = logging.getLogger("of-relay.automation.ppv_send")

# ── Price matrix (confirmed defaults: whale 2×, $100 whale cutoff, medium win-back)
# spend band: (name, min_cents_inclusive, max_cents_exclusive, multiplier)
SPEND_BANDS: list[tuple[str, int, float, float]] = [
    ("whale", 10_000, float("inf"), 2.0),   # $100+ lifetime
    ("mid",    2_500, 10_000,       1.0),    # $25–100
    ("low",        1,  2_500,       0.7),    # under $25
    ("free",       0,      1,       0.5),    # never paid
]
# recency band by days since last inbound message: (name, max_days_exclusive, mult)
RECENCY_BANDS: list[tuple[str, float, float]] = [
    ("hot",     3,            1.15),   # active in the last 3 days
    ("warm",   14,            1.0),    # this week-ish
    ("cool",   90,            0.8),    # cooling off
    ("quiet",  float("inf"),  0.55),   # gone quiet (also: never messaged)
]
# OF rejects any priced message below $3.00 ("Minimum message price is $3.00",
# verified live 2026-06-20; exactly $3.00 assumed inclusive — untested live).
# These are the HARD wire limits AND the defaults for the operator's per-account
# price_min_cents/price_max_cents; a clamped price sits exactly on the bound.
_PRICE_FLOOR_CENTS = 300
_PRICE_CEIL_CENTS = 20_000     # OF PPV max ($200)


def price_bounds(cfg: dict | None) -> tuple[int, int]:
    """Operator price limits from the top-level library config — (min_cents,
    max_cents), defaults $3/$200. Applied wherever a send/post price is COMPUTED
    (per-cell, broadcast, feed) — never rewrites the authored base_price_cents.
    min is held to OF's hard $3.00 floor; max is held into [min, $200]."""
    cfg = cfg if isinstance(cfg, dict) else {}
    try:
        lo = int(cfg.get("price_min_cents") or _PRICE_FLOOR_CENTS)
    except (TypeError, ValueError):
        lo = _PRICE_FLOOR_CENTS
    try:
        hi = int(cfg.get("price_max_cents") or _PRICE_CEIL_CENTS)
    except (TypeError, ValueError):
        hi = _PRICE_CEIL_CENTS
    lo = max(_PRICE_FLOOR_CENTS, min(lo, _PRICE_CEIL_CENTS))
    hi = max(lo, min(hi, _PRICE_CEIL_CENTS))
    return lo, hi


# Ceiling for the whale gate, in cents. Same key name and the same "0/absent =
# off" convention ai_chatter, autoreply and nudge_online already use, so an
# operator who has met this knob once has met it everywhere.
_SPEND_CAP_MAX_CENTS = 100_000_000   # $1M — a typo guard, not a policy
# Max entries in either half of the broadcast audience. A typo guard, not a
# policy — OF has its own limits and we don't know them.
_MAX_AUDIENCE_LISTS = 25


def spend_bound(cfg: dict | None) -> int | None:
    """Operator whale gate from the top-level library config — lifetime-spend
    ceiling in cents, or None when off. Fans AT OR ABOVE it leave the tier legs
    entirely (they stay in the broadcast's exclude set, so they get nothing from
    this lane at all — the whole point: whales are the closer's, not the blast's).

    0, absent, negative and unparseable all mean OFF. That is deliberate: this
    gate can only ever SHRINK the money lane, so every ambiguous value has to
    fail toward sending."""
    cfg = cfg if isinstance(cfg, dict) else {}
    raw = cfg.get("max_lifetime_spend_cents")
    if raw is None or isinstance(raw, bool):
        return None
    try:
        v = int(raw)
    except (TypeError, ValueError):
        return None
    return min(v, _SPEND_CAP_MAX_CENTS) if v > 0 else None

def is_list_id(x) -> bool:
    """Is `x` an OF fan-list id? The ONE definition — the sender drops what fails
    this and the save-time validator 422s on it, so a rule written twice would
    let the two disagree about the same value (accepted at save, dropped at send,
    and the exclusion protects nobody). `bool` is excluded explicitly: True is an
    int in Python and would otherwise read as list id 1."""
    return not isinstance(x, bool) and str(x).strip().lstrip("-").isdigit()


def broadcast_audience(cfg: dict | None) -> tuple[list[str] | None, list[int]]:
    """The "Send to everyone" audience, normalized: (include, exclude).

    ONE definition, shared by the save-time validator and the sender, because the
    two disagreeing is invisible — both keep sending, just to different people.

    include → OF `userLists`. None means the key was never configured, which is
    the historical fans + following; an EMPTY LIST is a real operator choice
    ("reach nobody new") and must survive as one. That distinction is why this
    returns None rather than falling back here.

    exclude → OF `excludedLists`, which takes list IDS ONLY and silently ignores
    the virtual names. Non-ids are dropped rather than trusted; the validator
    additionally 422s on a virtual name so an unsendable exclusion can never be
    stored in the first place."""
    cfg = cfg if isinstance(cfg, dict) else {}
    raw_inc = cfg.get("broadcast_lists")
    include: list[str] | None = None
    if isinstance(raw_inc, (list, tuple)):
        include = list(dict.fromkeys(
            v for v in (str(x).strip() for x in raw_inc[:_MAX_AUDIENCE_LISTS]) if v))
    raw_exc = cfg.get("broadcast_exclude_lists")
    exclude: list[int] = []
    if isinstance(raw_exc, (list, tuple)):
        seen: set[int] = set()
        for x in raw_exc[:_MAX_AUDIENCE_LISTS]:
            if not is_list_id(x):
                continue
            v = int(x)
            if v > 0 and v not in seen:
                seen.add(v)
                exclude.append(v)
    return include, exclude


# House-default spacing between PPV blasts: 2/day, 14/week, 60/month — all three
# even-spread to the SAME 12h minimum gap. Rides into runtime via the _DEFAULTS
# merge in _load_ppv, so it covers every account whose blob has no ppv_caps key
# (nothing ever wrote one before 2026-07). An explicitly SAVED caps dict — even
# all-zero = spacing off — always wins over this. Born after three Library PPVs
# hit the same fan at 06:43/06:48/06:51: the dup-fire gate is per-ppv and the
# sibling rules share a creation moment, so nothing else spaces them.
_DEFAULT_PPV_CAPS = {"per_day": 2, "per_week": 14, "per_month": 60}

_DEFAULTS = {"enabled": False, "ppvs": [], "ppv_caps": _DEFAULT_PPV_CAPS}

# ── Caption pools (mirror of library/PPV_CAPTIONS.md) ────────────────────────
# The library JSON stores a pool KEY per PPV (captions are global, not per-account);
# the runner random-picks one line at send time and fills {was}/{now}.
PPV_CAPTION_POOLS: dict[str, list[str]] = {
    "intro_new": [
        "ok i dont usually do this but i made somethin just for u 🙈 wanna see?",
        "u been so sweet to me so im lettin u in first... its only a lil to unlock, promise its worth it",
        "i was thinkin bout u when i shot this lol. open it, dont leave me hangin",
        "first one basically on me, barely costs anything. just unlock n tell me what u think",
        "im a lil nervous to send this ngl... but u get to see it before anyone. go on 👀",
        "new here so i wanna spoil u a bit. peek at this n lemme know",
    ],
    "standard_active": [
        "been thinkin about sendin u this all day... finally did it 🤭 unlock it for me",
        "u always know what i like so i made this with u in mind. go see",
        "okay this one might be my fav ive done. dont sleep on it babe",
        "i shouldnt be this naughty on a tuesday lol. its waitin for u",
        "filmed somethin earlier n immediately thought of u. its urs if u want it",
        "stop bein shy n open it already 😏 u know u wanna",
    ],
    "vip_whale": [
        "only sendin this to like 3 of my fav people n ur one of them. its special, dont share ok",
        "this is the one i dont post anywhere. made it for the ones who actually take care of me 🖤",
        "i went all out on this... its way more than i usually give. for u only",
        "u spoil me so im spoilin u back, this my best work hands down. go see what i did",
        "savin the real stuff for u. this aint the lil teasers i send everyone, unlock n youll get it",
    ],
    "winback_dormant": [
        "hey stranger... where u been? made this hopin itd bring u back. {off} off just for u, was {was} now {now}",
        "okay i miss u fr 🙈 heres a lil somethin to make up for it, basically nothing. come back to me",
        "u forgot about me?? rude lol. unlock this n ill forgive u, takin {off} off so its just {now}",
        "been a min since i heard from u. this used to be {was}, givin it {off} off for {now}, dont waste it",
        "i kept this one for when u came back... here. its only {now} ({off} off babe), just open it n say hi",
    ],
    "teaser_free": [
        "this is just the lil preview... the rest is so much better trust me 👀",
        "im only showin u this much for free lol. wait til u see what happens after",
        "lil taste. u want the full thing? say the word",
        "couldnt help myself today. this the soft version, the real one is comin",
        "consider this a teaser. ull be thinkin bout the rest all day promise",
    ],
    "photoset_striptease": [
        "starts cute n innocent... it does NOT stay that way lol. unlock to see where it goes",
        "i may have started dressed in these 🙈 may have not ended that way. ur call to find out",
        "it gets better with every single pic. dont stop til the last one",
        "watch me lose the outfit one pic at a time. the last few r my fav",
        "this set is a whole lil story... u gotta see how it ends",
    ],
    "video_ppv": [
        "couldnt keep my hands still in this one 🤭 its a video, unlock n watch",
        "made u a lil clip. first few seconds r tame, give it a min n youll see why i sent it",
        "this video is longer than i usually do... worth every second i promise. go play it",
        "filmed this in one take n didnt even edit much, its all me",
        "u said u wanted to actually see me move... here. press play",
    ],
    "followup_nonunlocker": [
        "u left me on read with that one 🥺 it dont expire yet but dont make me wait",
        "still sittin there waitin for u to open it lol. u good?",
        "ok ill sweeten it since u been busy. same one, lil cheaper now",
        "hellooo did u forget what i sent u 👀 its still there",
        "not gonna lie i kept checkin if u opened it. u gonna leave me hangin?",
    ],
    "bundle_anchor": [
        "okay im doin somethin crazy... a whole bundle of my stuff for like 80 off. its a LOT, unlock it",
        "cleanin out my vault n givin u everything for one price. this wont be up long babe",
        "ive never dropped this much at once. all of it, one unlock, way less than its worth. go fast",
        "huge drop just for my real ones. tons of content one price, dont overthink it just open it",
    ],
    # ── long-form, multi-paragraph sales copy (the "screenshot" look). \n\n =
    #    a blank line between paragraphs; {off}/{was}/{now} auto-fill the discount.
    "bundle_long": [
        "🌟 just for u babe 🌟\n\nim doin {off} off my full bundle today only ❤️‍🔥 unlock this n u get everything... all the pics, all the vids, the stuff i dont post anywhere else\n\nwas {was}, urs for {now} right now 🙈 i wont leave it up long so dont sleep on it 😘",
        "okay im finally droppin the big one 🔥\n\nthis is everything ive been holdin back from u. the whole set, nothin cut, n u keep it for life the second u open it\n\nnormally {was}... takin it down to {now} just for the ones who actually show up for me. thats u 🖤 go before i change my mind",
        "im doin somethin a lil crazy tonight 😳\n\nu always take such good care of me so heres my whole vault in one drop. every angle, every tease, the full thing\n\n{off} off so its only {now} (was {was}) babe. trust me ur gonna want this one forever 😈",
        "real talk i almost didnt post this 🙈\n\nbut i put together my biggest bundle yet n i want u to have it. tons of content, one unlock, way more than its worth\n\nwas {was}, urs for {now} today only. dont leave me waitin ok 💋",
    ],
    # ── short, punchy discount blasts with urgency
    "flash_discount": [
        "🔥 {off} OFF today only babe 🔥 ive literally never sold it this cheap... was {was} now just {now} 🙈 unlock before i put it back up",
        "okay sale time 😈 {off} off for the next few hours only. {now} instead of {was}. go go go before i change my mind 🤭",
        "{now}?? thats nothin for what u get 🙈 was {was}, droppin it just for today. unlock n thank me later 😘",
        "flash deal just for u 🔥 {off} off, only {now} (was {was}). ends tonight, dont leave it sittin there 👀",
        "spoilin u today babe 💋 {off} off my newest set. was {was}, urs for {now} rn. dont make me regret bein this generous 😏",
    ],
    # ── "you're on my special list" exclusivity + a bulleted what's-inside
    "exclusive_list": [
        "⚠️ this aint a mass dm babe ur on my special lil list 🙈\n\nso ur gettin my brand new bundle before i drop it to everyone. heres whats inside (n u keep it all for life):\n\n✨ the full set\n✨ all my fav angles\n✨ the views u always ask for\n✨ n more 😻\n\n{off} off so its just {now} (was {was}). dont tell the others 🤫",
        "psst... not sendin this to everyone ok 🙈 just my real ones\n\ni made a lil exclusive drop n ur on the list for it. whats included:\n\n✨ my newest pics\n✨ a video i never posted\n✨ the closeups u love\n\nonly {now} for u babe (was {was}, thats {off} off). keep it between us 🤍",
        "hey u 🙈 ur literally one of like a handful gettin this\n\nbrand new bundle, way too much to show all my fans on here haha. so its just for the special list. heres the rundown:\n\n✨ full set\n✨ behind the scenes\n✨ my absolute fav angles\n\nyours for {now} (was {was}) 😻 dont share ok",
    ],
    # ── vulnerable / personal "im finally ready to show u this side of me"
    "intimate_reveal": [
        "it took me a while to get this comfy with u but im finally ready to show u this side of me 🙈 please dont judge me ok... its a lot for me. unlock it n be sweet",
        "this is one of the most personal things ive ever filmed 😳 kinda nervous sendin it ngl. but i trust u. go see, just dont share it 🤍",
        "i guess we all got our secret lil kinks right 🙈 well this is mine. i never show this part of me but... here. dont disappoint me ok",
        "ive never been this open on here. unlockin this honestly feels like a big step for me. be gentle with it babe, its just for u 🥺",
        "okay i almost didnt send this one... its real intimate. but somethin bout u makes me wanna show u everything. its urs 😳",
    ],
}
_FALLBACK_CAPTION = "made somethin for u 🙈 unlock it"

# ── MALE caption pools (voice="him") ─────────────────────────────────────────
# Same 13 keys, same line counts, different person. Selected by `_pick_caption`
# off the account's `voice` column; anything not "him" gets the pools above,
# byte-identical.
#
# WHY THESE COULD NOT JUST BE THE FEMALE LINES WITH THE PET NAMES SWAPPED
# The register is the product here, not the vocabulary. Hers sells by lowering
# herself: "im a lil nervous to send this ngl", "please dont judge me ok",
# "be gentle with it", "dont leave me hangin", "u forgot about me?? rude". That
# works because the fan buys to reassure her — the ask and the flattery are the
# same sentence. Run it from a dom and every line reads as a man begging, which
# is the one thing the persona cannot survive.
#
# So his invert the direction of the favour. He is not nervous, not asking to be
# forgiven, and never seeking permission: the content is good, he decided the fan
# gets it, and the fan can take it or leave it. "dont make me wait" becomes "your
# call". The urgency stays (it sells) but it comes from his scarcity, not his
# need. No line asks a question that could read as fishing for approval.
#
# EMOJI: constrained to the male lane's own set (`_voice._EMOJI_VOCAB`) —
# 😏 😈 🔥 💪 👊 🖤 plus neutral 👀. Every 🙈 🥺 🥰 😘 💕 💋 😻 🤭 ✨ 🌟 🤍 in the
# pools above is BANNED for him by that same rule, which is exactly the
# contradiction that made these pools worth writing rather than reusing.
PPV_CAPTION_POOLS_HIM: dict[str, list[str]] = {
    "intro_new": [
        "dont normally send these out this early. you get one anyway, go look",
        "youve been solid with me so youre getting this first. barely costs anything",
        "shot this earlier and figured youd appreciate it. its yours if you want it",
        "first one is basically free. open it, tell me what you think",
        "not everyone gets this one. you do 👀",
        "new here, so consider this a hello. go see",
    ],
    "standard_active": [
        "been sitting on this one a while. sending it to you 😏 go on",
        "you know what you like and this is it. open it",
        "this might be the best thing ive shot. dont sleep on it",
        "shouldnt be doing this on a tuesday. its waiting for you",
        "filmed something earlier and thought of you. yours if you want it",
        "stop stalling and open it 😏 you already know",
    ],
    "vip_whale": [
        "three people are getting this. youre one. keep it to yourself",
        "this one never goes public. its for the ones who actually show up 🖤",
        "went all out on this. more than i usually give anyone",
        "you take care of me so heres my best work. go see what i did",
        "the real stuff stays off the feed. unlock it and youll get why",
    ],
    "winback_dormant": [
        "look who it is. made this a while back — {off} off, was {was} now {now}",
        "you went quiet. heres something to fix that, basically nothing 😏",
        "figured youd be back. unlock this and were good, {off} off so its {now}",
        "been a minute. this was {was}, taking {off} off for {now}. dont waste it",
        "kept this one aside for whenever you turned up. {now} ({off} off). go on",
    ],
    "teaser_free": [
        "thats the preview. the rest is a different thing entirely 👀",
        "this is all youre getting for free. the rest is better",
        "small taste. want the whole thing, say so",
        "couldnt help myself today. this is the tame version",
        "call it a teaser. youll be thinking about the rest 😏",
    ],
    "photoset_striptease": [
        "starts one way. does NOT end that way. unlock and see",
        "started this shoot in a lot more than i finished it in. your call 😏",
        "gets better with every shot. dont stop at the first one",
        "watch the kit come off one frame at a time. the last few are the point",
        "the whole set is a story. youll want to see how it lands",
    ],
    "video_ppv": [
        "couldnt keep still in this one 😏 its a video. unlock it",
        "made you a clip. first few seconds are tame, give it a minute",
        "this ones longer than i usually shoot. worth it. press play",
        "one take, barely edited. all me 💪",
        "you said you wanted to see me move. here. play it",
    ],
    "followup_nonunlocker": [
        "you left that one sitting there 👀 it hasnt expired yet",
        "still unopened. you good?",
        "ill make it easier since youve been busy. same one, cheaper",
        "you forget what i sent you? its still there",
        "not chasing you. just saying its still available 😏",
    ],
    "bundle_anchor": [
        "doing something stupid — the whole bundle for about 80 off. its a lot. take it",
        "clearing the vault. everything, one price. wont be up long",
        "never dropped this much at once. all of it, one unlock, well under what its worth",
        "big drop, real ones only. tons of content one price. dont overthink it",
    ],
    # ── long-form, multi-paragraph sales copy (the "screenshot" look)
    "bundle_long": [
        "🔥 {off} off the full bundle, today only\n\nunlock it and you get everything — every set, every clip, the stuff that never goes on the feed\n\nwas {was}, its {now} right now. i wont leave it up long 😏",
        "alright, dropping the big one 🔥\n\nthis is everything ive been holding back. the whole thing, nothing cut, and its yours for good the second you open it\n\nnormally {was}. taking it to {now} for the ones who actually show up 🖤 go before i change my mind",
        "doing something reckless tonight 😈\n\nyou take care of me so heres the whole vault in one drop. every angle, every tease, all of it\n\n{off} off, so {now} instead of {was}. youll be glad you did",
        "almost didnt put this together 👀\n\nbut its my biggest bundle yet and youre getting it. tons of content, one unlock, well past what its worth\n\nwas {was}, yours for {now} today. your call",
    ],
    # ── short, punchy discount blasts with urgency
    "flash_discount": [
        "🔥 {off} OFF today only 🔥 never sold it this cheap. was {was}, now {now}. unlock before it goes back up",
        "sale 😈 {off} off for the next few hours. {now} instead of {was}. move",
        "{now} for what youre getting? was {was}. today only. thank me after 😏",
        "flash deal 🔥 {off} off, {now} (was {was}). ends tonight 👀",
        "feeling generous 😏 {off} off the newest set. was {was}, its {now} now. dont make me regret it",
    ],
    # ── "you're on my list" exclusivity + a bulleted what's-inside
    "exclusive_list": [
        "⚠️ this isnt a mass dm. youre on a short list 😏\n\nyoure getting the new bundle before anyone else. whats in it (yours for good):\n\n▪️ the full set\n▪️ every angle\n▪️ the shots you keep asking about\n▪️ more\n\n{off} off so its {now} (was {was}). dont go telling people",
        "not sending this to everyone. just the real ones 🖤\n\nput together an exclusive drop and youre on the list. whats included:\n\n▪️ the newest shots\n▪️ a clip that never got posted\n▪️ the close-ups\n\n{now} for you (was {was}, thats {off} off). keep it between us",
        "youre one of a handful getting this 👀\n\nbrand new bundle, way too much to put in front of everyone. so its the short list only. the rundown:\n\n▪️ full set\n▪️ behind the scenes\n▪️ the best of it\n\nyours for {now} (was {was}) 😏 dont share it",
    ],
    # ── personal / rarely-shown, WITHOUT the apology. He is not nervous.
    "intimate_reveal": [
        "took a while before id show anyone this side of me. youre getting it. dont make me regret it",
        "this is about as personal as ive filmed 😈 dont share it",
        "everyone has one thing they keep to themselves. this is mine. here 🖤",
        "ive never put this on here before. thats all im going to say about it 😏",
        "almost kept this one. something about you made me send it anyway. its yours",
    ],
}
_FALLBACK_CAPTION_HIM = "made you something 😏 unlock it"

# ── Spanish message pools (es) — same keys as PPV_CAPTION_POOLS; _pick_caption
#    falls back to the English pool PER KEY for anything omitted, so a partial set
#    is safe. Add pt/fr/de/it/sl the same way: a PPV_CAPTION_POOLS_<CODE> dict + a
#    PPV_CAPTION_POOLS_BY_LANG entry. Discount tokens {now}/{was}/{off} preserved. ─
PPV_CAPTION_POOLS_ES: dict[str, list[str]] = {
    "intro_new": [
        "ok normalmente no hago esto pero hice algo solo para ti 🙈 quieres verlo?",
        "has sido tan lindo conmigo que te dejo entrar primero... solo cuesta un poquito abrirlo, prometo que vale la pena",
        "pensaba en ti cuando grabé esto jaja. ábrelo, no me dejes esperando",
        "el primero casi va por mi cuenta, apenas cuesta nada. solo ábrelo y dime qué piensas",
        "estoy un poco nerviosa de mandarte esto la verdad... pero lo ves antes que nadie. dale 👀",
        "soy nueva aquí así que quiero consentirte un poco. échale un ojo a esto y dime",
    ],
    "standard_active": [
        "llevo todo el día pensando en mandarte esto... por fin lo hice 🤭 ábrelo por mí",
        "siempre sabes lo que me gusta así que hice esto pensando en ti. míralo",
        "ok este quizás es mi favorito que he hecho. no lo dejes pasar bebé",
        "no debería ser tan traviesa un martes jaja. te está esperando",
        "grabé algo hace rato y pensé en ti al instante. es tuyo si lo quieres",
        "deja de ser tímido y ábrelo ya 😏 sabes que quieres",
    ],
    "vip_whale": [
        "solo le mando esto a como 3 de mis personas favoritas y tú eres una. es especial, no lo compartas ok",
        "este es el que no publico en ningún lado. lo hice para los que de verdad me cuidan 🖤",
        "me esforcé muchísimo en este... es mucho más de lo que suelo dar. solo para ti",
        "tú me consientes así que yo te consiento a ti, este es mi mejor trabajo sin duda. mira lo que hice",
        "guardo lo bueno de verdad para ti. esto no son los teasers que le mando a todos, ábrelo y lo verás",
    ],
    "winback_dormant": [
        "hey extraño... dónde te metiste? hice esto esperando que te trajera de vuelta. {off} de descuento solo para ti, era {was} ahora {now}",
        "ok te extraño en serio 🙈 aquí un detallito para compensar, casi nada. vuelve conmigo",
        "te olvidaste de mí?? qué grosero jaja. abre esto y te perdono, te doy {off} de descuento así queda en {now}",
        "hace rato que no sé de ti. esto costaba {was}, te doy {off} de descuento por {now}, no lo desperdicies",
        "guardé este para cuando volvieras... toma. son solo {now} ({off} menos bebé), ábrelo y saluda",
    ],
    "teaser_free": [
        "esto es solo el adelantito... lo demás está muchísimo mejor créeme 👀",
        "solo te muestro esto gratis jaja. espera a ver lo que pasa después",
        "una probadita. quieres la cosa completa? dilo",
        "no me pude aguantar hoy. esta es la versión suave, la de verdad viene en camino",
        "considera esto un teaser. vas a estar pensando en lo demás todo el día prometido",
    ],
    "photoset_striptease": [
        "empieza tierno e inocente... pero NO se queda así jaja. ábrelo para ver hasta dónde llega",
        "puede que haya empezado vestida con esto 🙈 puede que no haya terminado así. tú decides si averiguas",
        "se pone mejor con cada foto. no pares hasta la última",
        "mírame quitarme la ropa una foto a la vez. las últimas son mis favoritas",
        "este set es toda una historia... tienes que ver cómo termina",
    ],
    "video_ppv": [
        "no pude quedarme quieta en este 🤭 es un video, ábrelo y míralo",
        "te hice un clip. los primeros segundos son tranquilos, dale un momento y verás por qué te lo mandé",
        "este video es más largo de lo que suelo hacer... vale cada segundo prometido. dale play",
        "grabé esto de una sola toma y casi no lo edité, soy toda yo",
        "dijiste que querías verme moverme de verdad... aquí está. dale play",
    ],
    "followup_nonunlocker": [
        "me dejaste en visto con ese 🥺 todavía no expira pero no me hagas esperar",
        "ahí sigue esperando a que lo abras jaja. estás bien?",
        "ok te lo endulzo ya que has estado ocupado. el mismo, un poquito más barato ahora",
        "holaaa se te olvidó lo que te mandé 👀 sigue ahí",
        "no te voy a mentir seguía revisando si lo abriste. me vas a dejar esperando?",
    ],
    "bundle_anchor": [
        "ok voy a hacer una locura... todo un bundle de mis cosas por como {off} menos. es un montón, ábrelo",
        "estoy limpiando mi vault y te doy todo por un solo precio. esto no va a estar mucho tiempo bebé",
        "nunca había soltado tanto de una vez. todo, un solo pago, muchísimo menos de lo que vale. corre",
        "drop enorme solo para mis de verdad. montón de contenido un solo precio, no lo pienses tanto solo ábrelo",
    ],
    "bundle_long": [
        "🌟 solo para ti bebé 🌟\n\nhoy hago {off} de descuento en mi bundle completo ❤️‍🔥 abre esto y tienes todo... todas las fotos, todos los videos, lo que no publico en ningún lado\n\nera {was}, tuyo por {now} ahora mismo 🙈 no lo dejo mucho tiempo así que no te duermas 😘",
        "ok por fin voy a soltar el grande 🔥\n\nesto es todo lo que te he estado guardando. el set completo, nada cortado, y es tuyo de por vida en cuanto lo abras\n\nnormalmente {was}... te lo dejo en {now} solo para los que de verdad aparecen por mí. ese eres tú 🖤 corre antes de que cambie de opinión",
        "voy a hacer algo un poco loco esta noche 😳\n\nsiempre me cuidas tan bien así que aquí tienes todo mi vault en un solo drop. cada ángulo, cada tease, la cosa completa\n\n{off} de descuento así queda en solo {now} (era {was}) bebé. créeme que vas a querer este para siempre 😈",
        "en serio casi no publico esto 🙈\n\npero armé mi bundle más grande hasta ahora y quiero que lo tengas. montón de contenido, un solo pago, mucho más de lo que vale\n\nera {was}, tuyo por {now} solo por hoy. no me dejes esperando ok 💋",
    ],
    "flash_discount": [
        "🔥 {off} DE DESCUENTO solo por hoy bebé 🔥 literal nunca lo he vendido tan barato... era {was} ahora solo {now} 🙈 ábrelo antes de que lo vuelva a subir",
        "ok hora de sale 😈 {off} de descuento por las próximas horas nada más. {now} en vez de {was}. corre corre antes de que cambie de opinión 🤭",
        "{now}?? eso no es nada por lo que recibes 🙈 era {was}, lo bajo solo por hoy. ábrelo y me agradeces después 😘",
        "oferta flash solo para ti 🔥 {off} de descuento, solo {now} (era {was}). termina esta noche, no lo dejes ahí 👀",
        "consintiéndote hoy bebé 💋 {off} de descuento en mi set más nuevo. era {was}, tuyo por {now} ahorita. no me hagas arrepentirme de ser tan generosa 😏",
    ],
    "exclusive_list": [
        "⚠️ esto no es un dm masivo bebé estás en mi listita especial 🙈\n\nasí que recibes mi bundle nuevecito antes de que se lo suelte a todos. esto es lo que trae (y te lo quedas todo de por vida):\n\n✨ el set completo\n✨ todos mis ángulos favoritos\n✨ las vistas que siempre pides\n✨ y más 😻\n\n{off} de descuento así queda en solo {now} (era {was}). no le digas a los demás 🤫",
        "psst... no le mando esto a todos ok 🙈 solo a mis de verdad\n\narmé un drop exclusivo y estás en la lista. lo que incluye:\n\n✨ mis fotos más nuevas\n✨ un video que nunca publiqué\n✨ los closeups que te encantan\n\nsolo {now} para ti bebé (era {was}, eso es {off} menos). que quede entre nosotros 🤍",
        "hey tú 🙈 eres literal de como un puñado que recibe esto\n\nbundle nuevecito, demasiado para mostrárselo a todos mis fans aquí jaja. así que es solo para la lista especial. el resumen:\n\n✨ set completo\n✨ detrás de cámaras\n✨ mis ángulos favoritos absolutos\n\ntuyo por {now} (era {was}) 😻 no lo compartas ok",
    ],
    "intimate_reveal": [
        "me tomó un rato agarrar esta confianza contigo pero por fin estoy lista para mostrarte este lado mío 🙈 por favor no me juzgues ok... es mucho para mí. ábrelo y sé lindo",
        "esto es una de las cosas más personales que he grabado 😳 la verdad un poco nerviosa de mandarlo. pero confío en ti. míralo, solo no lo compartas 🤍",
        "supongo que todos tenemos nuestros kinks secretos verdad 🙈 pues este es el mío. nunca muestro esta parte de mí pero... aquí está. no me decepciones ok",
        "nunca he sido tan abierta aquí. abrir esto honestamente se siente como un gran paso para mí. sé gentil con él bebé, es solo para ti 🥺",
        "ok casi no mando este... es bien íntimo. pero algo de ti me hace querer mostrarte todo. es tuyo 😳",
    ],
}
_FALLBACK_CAPTION_ES = "hice algo para ti 🙈 ábrelo"

# ── Slovenian message pools (sl). GENDER: female speaker → male fan (HER verbs
#    feminine: naredila/posnela/pripravljena; HIS masculine: si bil/boš videl). ──
PPV_CAPTION_POOLS_SL: dict[str, list[str]] = {
    "intro_new": [
        "ok ponavadi tega ne počnem ampak naredila sem nekaj samo zate 🙈 hočeš videt?",
        "bil si tako prijazen z mano zato te spustim prvega... samo malo stane da odkleneš, obljubim da je vredno",
        "mislila sem nate ko sem tole posnela lol. odkleni, ne pusti me viset",
        "prvi je skoraj zastonj, komaj kaj stane. samo odkleni in povej kaj misliš",
        "malo sem živčna da ti tole pošljem ngl... ampak ti to vidiš pred vsemi. daj 👀",
        "nova sem tukaj zato te hočem malo razvajat. poglej tole in mi povej",
    ],
    "standard_active": [
        "cel dan razmišljam da bi ti to poslala... končno sem 🤭 odkleni zame",
        "vedno veš kaj mi je všeč zato sem tole naredila s tabo v mislih. poglej",
        "ok tale je mogoče moj najljubši kar sem jih naredila. ne spreglej ga srček",
        "ne bi smela bit tako poredna v torek lol. čaka te",
        "nekaj sem posnela prej in takoj pomislila nate. tvoj je če hočeš",
        "nehaj bit sramežljiv in ga že odkleni 😏 saj veš da hočeš",
    ],
    "vip_whale": [
        "tole pošiljam samo kakim 3 najljubšim ljudem in ti si eden od njih. posebno je, ne deli ok",
        "tale je tisti ki ga ne objavim nikjer. naredila sem ga za tiste ki zares skrbijo zame 🖤",
        "res sem se potrudila pri tem... veliko več kot ponavadi dam. samo zate",
        "ti me razvajaš zato te jaz razvajam nazaj, tole je moje najboljše delo brez dvoma. poglej kaj sem naredila",
        "pravo stvar hranim zate. to niso tisti mali teaserji ki jih pošiljam vsem, odkleni in boš dobil 😈",
    ],
    "winback_dormant": [
        "hej tujec... kje si bil? tole sem naredila v upanju da te pripelje nazaj. {off} popusta samo zate, bilo {was} zdaj {now}",
        "ok res te pogrešam 🙈 tukaj nekaj malega da se odkupim, skoraj nič. vrni se k meni",
        "si me pozabil?? nesramno lol. odkleni tole in ti odpustim, dam ti {off} popusta da je samo {now}",
        "že dolgo se nisi oglasil. tole je bilo {was}, dajem ti {off} popusta za {now}, ne zapravi ga",
        "tega sem hranila za ko se vrneš... izvoli. samo {now} je ({off} manj srček), samo odkleni in pozdravi",
    ],
    "teaser_free": [
        "tole je samo mali predogled... ostalo je veliko boljše verjemi 👀",
        "samo tolikane ti pokažem zastonj lol. počakaj da vidiš kaj pride potem",
        "mala pokušina. hočeš celo stvar? samo reci",
        "nisem se mogla zadržat danes. tole je nežna verzija, prava pride",
        "vzemi to kot teaser. cel dan boš razmišljal o ostalem obljubim",
    ],
    "photoset_striptease": [
        "začne se srčkano in nedolžno... ampak NE ostane tako lol. odkleni da vidiš kam gre",
        "mogoče sem bila oblečena v tem 🙈 mogoče nisem tako končala. tvoja izbira da izveš",
        "boljše je z vsako sliko. ne ustavi se do zadnje",
        "glej me kako se slačim sliko za sliko. zadnje so moje najljubše",
        "tale set je cela zgodbica... moraš videt kako se konča",
    ],
    "video_ppv": [
        "nisem mogla držat rok pri miru v tem 🤭 video je, odkleni in glej",
        "naredila sem ti posnetek. prvih par sekund je mirnih, daj mu minuto pa boš videl zakaj sem ti ga poslala",
        "tale video je daljši kot ponavadi delam... vreden vsake sekunde obljubim. daj predvajaj",
        "posnela sem to v enem posnetku in skoraj nič urejala, vse sem jaz",
        "rekel si da me hočeš res videt kako se premikam... izvoli. pritisni play",
    ],
    "followup_nonunlocker": [
        "pustil si me na prebrano s tem 🥺 še ne poteče ampak ne pusti me čakat",
        "še vedno tam čaka da ga odkleneš lol. si ok?",
        "ok osladim ti ga ker si bil zaposlen. isti, malo ceneje zdaj",
        "haloo si pozabil kaj sem ti poslala 👀 še vedno je tam",
        "ne bom lagala ves čas sem preverjala če si odklenil. me boš pustil viset?",
    ],
    "bundle_anchor": [
        "ok delam noro stvar... cel bundle mojih stvari za kakih {off} manj. veliko je, odkleni",
        "čistim svoj vault in ti dam vse za eno ceno. tole ne bo dolgo gor srček",
        "nikoli nisem spustila toliko naenkrat. vse, eno plačilo, veliko manj kot je vredno. pohiti",
        "ogromen drop samo za moje prave. kup vsebine ena cena, ne razmišljaj preveč samo odkleni",
    ],
    "bundle_long": [
        "🌟 samo zate srček 🌟\n\ndanes dajem {off} popusta na cel bundle ❤️‍🔥 odkleni tole in imaš vse... vse slike, vse videe, stvari ki jih ne objavim nikjer\n\nbilo {was}, tvoje za {now} prav zdaj 🙈 ne pustim ga dolgo gor zato ne zaspi 😘",
        "ok končno spuščam velikega 🔥\n\ntole je vse kar sem ti prihranila. cel set, nič odrezano, in obdržiš ga za vedno v trenutku ko odkleneš\n\nponavadi {was}... dajem ti ga za {now} samo za tiste ki se zares pojavijo zame. to si ti 🖤 pohiti preden si premislim",
        "delam malo noro stvar nocoj 😳\n\nvedno tako lepo skrbiš zame zato ti dam cel svoj vault v enem dropu. vsak kot, vsak tease, cela stvar\n\n{off} popusta da je samo {now} (bilo {was}) srček. verjemi da boš tole hotel za vedno 😈",
        "res skoraj nisem objavila tega 🙈\n\nampak sestavila sem svoj največji bundle do zdaj in hočem da ga imaš. kup vsebine, eno plačilo, veliko več kot je vredno\n\nbilo {was}, tvoje za {now} samo danes. ne pusti me čakat ok 💋",
    ],
    "flash_discount": [
        "🔥 {off} POPUSTA samo danes srček 🔥 dobesedno še nikoli nisem prodala tako poceni... bilo {was} zdaj samo {now} 🙈 odkleni preden ga dam nazaj gor",
        "ok čas za razprodajo 😈 {off} popusta za naslednjih par ur. {now} namesto {was}. pohiti pohiti preden si premislim 🤭",
        "{now}?? to ni nič za to kar dobiš 🙈 bilo {was}, spuščam samo za danes. odkleni in se mi zahvali kasneje 😘",
        "flash deal samo zate 🔥 {off} popusta, samo {now} (bilo {was}). konča se nocoj, ne pusti ga tam 👀",
        "razvajam te danes srček 💋 {off} popusta na moj najnovejši set. bilo {was}, tvoj za {now} zdaj. ne pusti da obžalujem da sem tako radodarna 😏",
    ],
    "exclusive_list": [
        "⚠️ tole ni množičen dm srček na mojem posebnem seznamčku si 🙈\n\nzato dobiš moj čisto nov bundle preden ga spustim vsem. tukaj je kaj je notri (in vse obdržiš za vedno):\n\n✨ cel set\n✨ vsi moji najljubši koti\n✨ pogledi ki jih vedno prosiš\n✨ in več 😻\n\n{off} popusta da je samo {now} (bilo {was}). ne povej drugim 🤫",
        "psst... tega ne pošiljam vsem ok 🙈 samo mojim pravim\n\nnaredila sem ekskluziven drop in si na seznamu zanj. kaj vključuje:\n\n✨ moje najnovejše slike\n✨ video ki ga nisem nikoli objavila\n✨ close upi ki jih obožuješ\n\nsamo {now} zate srček (bilo {was}, to je {off} manj). naj ostane med nama 🤍",
        "hej ti 🙈 dobesedno eden od peščice si ki to dobi\n\nčisto nov bundle, preveč da bi ga pokazala vsem svojim fanom tukaj haha. zato je samo za posebni seznam. povzetek:\n\n✨ cel set\n✨ zakulisje\n✨ moji absolutno najljubši koti\n\ntvoj za {now} (bilo {was}) 😻 ne deli ok",
    ],
    "intimate_reveal": [
        "trajalo je nekaj časa da sem se ti tako odprla ampak končno sem pripravljena da ti pokažem to plat sebe 🙈 prosim ne obsojaj me ok... veliko je zame. odkleni in bodi prijazen",
        "tole je ena najbolj osebnih stvari kar sem jih posnela 😳 res malo živčna da pošiljam ngl. ampak zaupam ti. poglej, samo ne deli 🤍",
        "verjetno imamo vsi svoje skrivne kinke ne 🙈 no tale je moj. nikoli ne pokažem te plati sebe ampak... izvoli. ne razočaraj me ok",
        "nikoli nisem bila tako odprta tukaj. odkleniti tole se iskreno zdi kot velik korak zame. bodi nežen z njim srček, samo zate je 🥺",
        "ok skoraj nisem poslala tega... res je intimno. ampak nekaj pri tebi me naredi da ti hočem pokazat vse. tvoj je 😳",
    ],
}
_FALLBACK_CAPTION_SL = "nekaj sem naredila zate 🙈 odkleni"

# Language registries — 'en' authoritative; _pick_caption falls back per-key.
PPV_CAPTION_POOLS_BY_LANG: dict[str, dict[str, list[str]]] = {
    "en": PPV_CAPTION_POOLS, "es": PPV_CAPTION_POOLS_ES, "sl": PPV_CAPTION_POOLS_SL}
_FALLBACK_CAPTION_BY_LANG: dict[str, str] = {
    "en": _FALLBACK_CAPTION, "es": _FALLBACK_CAPTION_ES, "sl": _FALLBACK_CAPTION_SL}

# ── Message-pool → feed-pool mapping ─────────────────────────────────────────
# When a PPV has no explicit feed_captions/feed_caption_pool_key, the feed post
# must still use PUBLIC-feed voice — never the 1:1 message caption. This maps each
# message caption_pool_key to the closest-matching feed pool key.
_MSG_TO_FEED_POOL: dict[str, str] = {
    "photoset_striptease": "feed_photoset",
    "video_ppv": "feed_video_drop",
    "bundle_anchor": "feed_bundle_drop",
    "bundle_long": "feed_bundle_drop",
    "flash_discount": "feed_flash_sale",
    "exclusive_list": "feed_teaser",
    "intimate_reveal": "feed_teaser",
    "followup_nonunlocker": "feed_new_drop",
}

# ── Feed-post caption pools ──────────────────────────────────────────────────
# Public-FEED voice (a post is broadcast to everyone, NOT a 1:1 DM) — so NO "just
# for u" / "ur on my special list" framing. Used ONLY by the "post to feed" path
# (ppv_library_config_api.post_ppv_to_feed); one line is random-picked + the
# {now}/{was}/{off} discount tokens filled, same as the message pools.
PPV_FEED_CAPTION_POOLS: dict[str, list[str]] = {
    "feed_new_drop": [
        "just posted somethin new 🙈 unlock it below babe",
        "new set is up 🔥 go unlock it, u wont regret it",
        "couldnt wait to share this one... its locked below, go see 👀",
        "fresh content just dropped 😏 tap to unlock",
        "posted somethin a lil spicy today 🙈 its all urs below",
    ],
    "feed_flash_sale": [
        "🔥 {off} OFF today only 🔥 was {was} now just {now}, unlock before i put it back up",
        "flash sale time 😈 {off} off, only {now} (was {was}). dont sleep on it",
        "{now} instead of {was} for the next few hours only 🙈 go go go",
        "spoilin u today 💋 {off} off, was {was} now {now}. unlock below",
        "puttin this on sale for a bit — {off} off, just {now} (was {was}) 👀",
    ],
    "feed_bundle_drop": [
        "huge bundle just dropped 🔥 everything in one unlock, way more than its worth",
        "dropped my biggest set yet 🙈 tons of content, one price below. go unlock",
        "new bundle is live 😈 all the pics + vids in one, dont miss it",
        "{off} off my full bundle today 🌟 was {was} now {now}, unlock everything below",
    ],
    "feed_teaser": [
        "this is just the preview... the full thing is locked below 👀",
        "lil taste of what i posted 🙈 unlock for the rest",
        "u want the full version? its right below babe, go unlock 😏",
        "consider this the soft version... the real one is locked below",
    ],
    "feed_video_drop": [
        "new video is up 🔥 unlock it below n press play",
        "posted a lil clip today 🙈 its locked below, go watch",
        "filmed somethin special... its all urs below, unlock to see 😈",
        "new vid just dropped 👀 worth every second i promise, unlock below",
    ],
    "feed_photoset": [
        "new photo set is up 🙈 starts cute... does NOT stay that way. unlock below",
        "posted a whole set today 🔥 it gets better with every pic, go unlock",
        "dropped a striptease set 😏 watch me lose the outfit one pic at a time, below",
        "new pics are live 👀 the last few r my fav, unlock to see",
    ],
}

# MALE feed pools — same keys and counts as PPV_FEED_CAPTION_POOLS. Public-feed
# voice, so no "just for you" framing in either lane; what changes is the same
# thing as in the DM pools — no coy 🙈, no pleading, no "babe".
PPV_FEED_CAPTION_POOLS_HIM: dict[str, list[str]] = {
    "feed_new_drop": [
        "posted something new 😏 its locked below",
        "new set is up 🔥 go unlock it",
        "couldnt sit on this one. locked below 👀",
        "fresh content just dropped 😈 tap to unlock",
        "put something up today. its all below",
    ],
    "feed_flash_sale": [
        "🔥 {off} OFF today only 🔥 was {was}, now {now}. unlock before it goes back up",
        "flash sale 😈 {off} off, {now} (was {was}). dont sleep on it",
        "{now} instead of {was} for the next few hours 👀 move",
        "feeling generous 😏 {off} off, was {was} now {now}. unlock below",
        "on sale for a bit — {off} off, {now} (was {was}) 🔥",
    ],
    "feed_bundle_drop": [
        "huge bundle just dropped 🔥 everything in one unlock, well past what its worth",
        "biggest set ive put up 😈 tons of content, one price below",
        "new bundle is live 💪 every shot and clip in one. dont miss it",
        "{off} off the full bundle today 🔥 was {was} now {now}. everything below",
    ],
    "feed_teaser": [
        "thats the preview. the full thing is locked below 👀",
        "small taste of what went up 😏 unlock for the rest",
        "want the full version? its right below",
        "call that the tame one. the real version is locked below 😈",
    ],
    "feed_video_drop": [
        "new video is up 🔥 unlock below and press play",
        "put a clip up today 👀 its locked below",
        "filmed something worth watching. all yours below 😈",
        "new vid just dropped 😏 worth every second. unlock below",
    ],
    "feed_photoset": [
        "new set is up 😏 starts one way, does NOT end that way. unlock below",
        "put a whole set up today 🔥 gets better with every shot",
        "strip set is live 😈 kit comes off one frame at a time. below",
        "new shots are up 👀 the last few are the point. unlock to see",
    ],
}

# Spanish feed pools (es) — public-feed voice. Same keys; English per-key fallback.
PPV_FEED_CAPTION_POOLS_ES: dict[str, list[str]] = {
    "feed_new_drop": [
        "acabo de publicar algo nuevo 🙈 desbloquéalo abajo bebé",
        "nuevo set arriba 🔥 ve a desbloquearlo, no te vas a arrepentir",
        "no me pude aguantar a compartir este... está bloqueado abajo, ve a ver 👀",
        "contenido fresco recién soltado 😏 toca para desbloquear",
        "publiqué algo un poquito picante hoy 🙈 es todo tuyo abajo",
    ],
    "feed_flash_sale": [
        "🔥 {off} DE DESCUENTO solo hoy 🔥 era {was} ahora solo {now}, desbloquéalo antes de que lo vuelva a subir",
        "hora de sale 😈 {off} menos, solo {now} (era {was}). no te duermas",
        "{now} en vez de {was} solo por las próximas horas 🙈 corre corre corre",
        "consintiéndote hoy 💋 {off} menos, era {was} ahora {now}. desbloquea abajo",
        "poniendo esto en oferta un rato — {off} menos, solo {now} (era {was}) 👀",
    ],
    "feed_bundle_drop": [
        "bundle enorme recién soltado 🔥 todo en un solo desbloqueo, mucho más de lo que vale",
        "solté mi set más grande hasta ahora 🙈 montón de contenido, un solo precio abajo. ve a desbloquear",
        "nuevo bundle en vivo 😈 todas las fotos + videos en uno, no te lo pierdas",
        "{off} de descuento en mi bundle completo hoy 🌟 era {was} ahora {now}, desbloquea todo abajo",
    ],
    "feed_teaser": [
        "esto es solo el adelanto... lo completo está bloqueado abajo 👀",
        "una probadita de lo que publiqué 🙈 desbloquea por el resto",
        "quieres la versión completa? está justo abajo bebé, ve a desbloquear 😏",
        "considera esta la versión suave... la de verdad está bloqueada abajo",
    ],
    "feed_video_drop": [
        "nuevo video arriba 🔥 desbloquéalo abajo y dale play",
        "publiqué un clip hoy 🙈 está bloqueado abajo, ve a verlo",
        "grabé algo especial... es todo tuyo abajo, desbloquea para ver 😈",
        "nuevo video recién soltado 👀 vale cada segundo prometido, desbloquea abajo",
    ],
    "feed_photoset": [
        "nuevo set de fotos arriba 🙈 empieza tierno... NO se queda así. desbloquea abajo",
        "publiqué un set completo hoy 🔥 se pone mejor con cada foto, ve a desbloquear",
        "solté un set de striptease 😏 mírame perder el outfit foto por foto, abajo",
        "nuevas fotos en vivo 👀 las últimas son mis favoritas, desbloquea para ver",
    ],
}

# Slovenian feed pools (sl) — public-feed voice; female speaker (HER verbs feminine).
PPV_FEED_CAPTION_POOLS_SL: dict[str, list[str]] = {
    "feed_new_drop": [
        "pravkar sem objavila nekaj novega 🙈 odkleni spodaj srček",
        "nov set je gor 🔥 pojdi odkleni, ne boš obžaloval",
        "nisem se mogla zadržat da delim tega... zaklenjen je spodaj, pojdi poglej 👀",
        "sveža vsebina pravkar spuščena 😏 tapni za odklep",
        "danes sem objavila nekaj malo pikantnega 🙈 vse tvoje spodaj",
    ],
    "feed_flash_sale": [
        "🔥 {off} POPUSTA samo danes 🔥 bilo {was} zdaj samo {now}, odkleni preden dam nazaj gor",
        "čas za razprodajo 😈 {off} manj, samo {now} (bilo {was}). ne zaspi",
        "{now} namesto {was} samo za naslednjih par ur 🙈 pohiti pohiti pohiti",
        "razvajam te danes 💋 {off} manj, bilo {was} zdaj {now}. odkleni spodaj",
        "dajem tole na razprodajo za malo — {off} manj, samo {now} (bilo {was}) 👀",
    ],
    "feed_bundle_drop": [
        "ogromen bundle pravkar spuščen 🔥 vse v enem odklepu, veliko več kot je vredno",
        "spustila sem svoj največji set do zdaj 🙈 kup vsebine, ena cena spodaj. pojdi odkleni",
        "nov bundle v živo 😈 vse slike + videi v enem, ne zamudi",
        "{off} popusta na moj cel bundle danes 🌟 bilo {was} zdaj {now}, odkleni vse spodaj",
    ],
    "feed_teaser": [
        "tole je samo predogled... celota je zaklenjena spodaj 👀",
        "mala pokušina tega kar sem objavila 🙈 odkleni za ostalo",
        "hočeš celo verzijo? je prav spodaj srček, pojdi odkleni 😏",
        "vzemi tole kot nežno verzijo... prava je zaklenjena spodaj",
    ],
    "feed_video_drop": [
        "nov video je gor 🔥 odkleni spodaj in pritisni play",
        "danes sem objavila posnetek 🙈 zaklenjen je spodaj, pojdi poglej",
        "posnela sem nekaj posebnega... vse tvoje spodaj, odkleni da vidiš 😈",
        "nov video pravkar spuščen 👀 vreden vsake sekunde obljubim, odkleni spodaj",
    ],
    "feed_photoset": [
        "nov foto set je gor 🙈 začne se srčkano... NE ostane tako. odkleni spodaj",
        "danes sem objavila cel set 🔥 boljše je z vsako sliko, pojdi odkleni",
        "spustila sem striptease set 😏 glej me kako se slačim sliko za sliko, spodaj",
        "nove slike v živo 👀 zadnje so moje najljubše, odkleni da vidiš",
    ],
}
PPV_FEED_CAPTION_POOLS_BY_LANG: dict[str, dict[str, list[str]]] = {
    "en": PPV_FEED_CAPTION_POOLS, "es": PPV_FEED_CAPTION_POOLS_ES,
    "sl": PPV_FEED_CAPTION_POOLS_SL}


def round_to_99(amount_cents: float, bounds: tuple[int, int] | None = None) -> int:
    """Round to the nearest whole dollar, then end in .99, clamped into the
    operator's [min, max] price bounds (default $3/$200). A clamped price sits
    EXACTLY on the bound (no .99 restyle). e.g. 5750 → 5799 ($57.99)."""
    lo, hi = bounds if bounds is not None else (_PRICE_FLOOR_CENTS, _PRICE_CEIL_CENTS)
    dollars = round(amount_cents / 100)
    cents = 99 if dollars < 1 else dollars * 100 - 1
    return max(lo, min(cents, hi))


def _spend_band(cents: int) -> tuple[str, float]:
    c = max(0, int(cents or 0))
    for name, lo, hi, mult in SPEND_BANDS:
        if lo <= c < hi:
            return name, mult
    return "free", 0.5


def _recency_band(last_dt: datetime | None, now: datetime) -> tuple[str, float]:
    if last_dt is None:
        return "quiet", 0.55
    days = max(0.0, (now - last_dt).total_seconds() / 86_400)
    for name, hi_days, mult in RECENCY_BANDS:
        if days < hi_days:
            return name, mult
    return "quiet", 0.55


def _money(cents: int) -> str:
    return f"${cents // 100}" if cents % 100 == 0 else f"${cents / 100:.2f}"


def _anchor_price(now_cents: int) -> int:
    """A believable 'was' price for the discount framing: ~4x what the fan actually
    pays, rounded to end in .99. Display only (NOT a real OF price) so no $200 ceiling
    — this keeps EVERY segment's caption reading like a genuine ~75% off deal, even
    the whale cell where the real price is high. {now} < {was} always holds."""
    dollars = max(1, round(now_cents * 4 / 100))
    return dollars * 100 - 1


def _pct_off(now_cents: int, was_cents: int) -> int:
    if was_cents <= 0 or now_cents >= was_cents:
        return 0
    return round((1 - now_cents / was_cents) * 100)


def _pick_caption(ppv: dict, cell_price_cents: int, lang: str = "en",
                  voice: str = _voice.VOICE_HER, hook: str | None = None) -> str:
    """Random caption (custom caption_texts win over the pool), discount tokens filled:
    {now} = this segment's price, {was} = an auto anchor ~4x above (always a discount),
    {off} = the resulting percent off (e.g. '75%'). `lang` selects the language pool
    (English per-key fallback); a custom caption_texts always wins, in any language.

    `voice` selects the POOL SET. A caption is the single highest-volume canned
    surface in the product — every PPV send is one of these lines, verbatim, with
    no model in the loop — so an unlaned pool means a male account markets itself
    in a woman's voice on every send it makes.

    Male + non-English falls back to his ENGLISH pool, not to her translated one:
    every localized line is female-voiced by construction (Spanish marks gender
    on the adjective — "empecé vestida" — and Slovene on the verb — "naredila").
    A grammatically female Spanish line from a male creator is worse than an
    English one. Adding real es/sl male pools is the same edit as the tables."""
    from automations import _language
    male = _voice.norm_voice(voice) == _voice.VOICE_HIM
    texts = ppv.get("caption_texts")
    if not (isinstance(texts, list) and texts):
        key = str(ppv.get("caption_pool_key") or "")
        texts = ((PPV_CAPTION_POOLS_HIM.get(key) or []) if male
                 else _language.localized(PPV_CAPTION_POOLS_BY_LANG, lang, key) or [])
    norm = _language.norm_lang(lang) or "en"
    if male:
        line = random.choice(texts) if texts else _FALLBACK_CAPTION_HIM
    else:
        line = random.choice(texts) if texts else _FALLBACK_CAPTION_BY_LANG.get(norm, _FALLBACK_CAPTION)
    if "{now}" in line or "{was}" in line or "{off}" in line:
        was = _anchor_price(cell_price_cents)
        line = (line.replace("{now}", _money(cell_price_cents))
                    .replace("{was}", _money(was))
                    .replace("{off}", f"{_pct_off(cell_price_cents, was)}%"))
    # `hook` is a model-written line about the MEDIA, generated once per run and
    # identical across every cell — the pool line under it is what carries this
    # cell's price. Composed AFTER the token fill on purpose: the hook is inert
    # text, never a template, so a stray brace in model output can never be
    # interpreted as a price token.
    return f"{hook}\n\n{line}" if hook else line


def _rotate_preview(pool: list, idx: int) -> list[int]:
    """Deterministic round-robin so each RESEND (a different day) shows a DIFFERENT
    teaser with NO stored state — pool[idx % len]. A fan who didn't buy keeps getting
    the same locked content with a fresh preview each cycle. Empty pool → no preview."""
    return [pool[idx % len(pool)]] if pool else []


def pick_feed_caption(ppv: dict, base_cents: int, lang: str = "en",
                      voice: str = _voice.VOICE_HER) -> tuple[str, bool]:
    """Caption for the FEED post (public voice, NEVER the 1:1 message caption).
    Priority: the PPV's own feed_captions → its feed_caption_pool_key
    (PPV_FEED_CAPTION_POOLS) → the feed pool mapped from the message caption_pool_key
    via _MSG_TO_FEED_POOL (default 'feed_new_drop'). `lang` selects the language feed
    pool (English per-key fallback). Returns (caption, used_feed_specific) —
    used_feed_specific is always True; this never falls through to the message pool.
    Tokens are filled at the base price (a feed post is one price for everyone)."""
    from automations import _language
    feed_caps = [s for s in (ppv.get("feed_captions") or []) if isinstance(s, str) and s.strip()]
    if feed_caps:
        return _pick_caption({"caption_texts": feed_caps}, base_cents, voice=voice), True
    key = str(ppv.get("feed_caption_pool_key") or "").strip()
    if not (key and key in PPV_FEED_CAPTION_POOLS):
        key = _MSG_TO_FEED_POOL.get(str(ppv.get("caption_pool_key") or "").strip(), "feed_new_drop")
    if _voice.norm_voice(voice) == _voice.VOICE_HIM:
        pool = PPV_FEED_CAPTION_POOLS_HIM[key]      # his english; see _pick_caption
    else:
        pool = (_language.localized(PPV_FEED_CAPTION_POOLS_BY_LANG, lang, key)
                or PPV_FEED_CAPTION_POOLS[key])
    return _pick_caption({"caption_texts": pool}, base_cents, voice=voice), True


async def post_to_feed(account_id: str, ppv: dict, *, employee_id: int | None = None,
                       caption: str | None = None,
                       media_files: list[int] | None = None,
                       previews_override: list[int] | None = None,
                       bounds: tuple[int, int] | None = None) -> dict:
    """Post ONE PPV to the OF FEED as a paid post at its BASE price, with the ⭐ free
    previews (preview_options) shown as the teaser and a feed-voice caption. Records a
    Post row. SHARED by the manual post-now endpoint and the auto 'also post to feed
    with each send' path in run(). No fan messaging — a feed post is one public drop.

    `caption`, when a non-empty string, is used VERBATIM (skips pick_feed_caption)
    with used_feed_caption forced True — this gives WYSIWYG: a caption shown in a
    preview step is exactly what gets posted on confirm.

    `media_files`, when a NON-EMPTY list, is the operator's chosen media in the EXACT
    order to post — it OVERRIDES the PPV's own media_ids, but is FILTERED to the PPV's
    own media_ids (never post ids the PPV doesn't own; OF rejects strays). An empty /
    absent list falls back to the PPV's media_ids (never post an empty media set).
    `previews_override`, when provided, replaces the preview_options-based previews;
    either way previews are filtered to a ⊆ subset of the media actually sent.
    `bounds` = the operator's (min_cents, max_cents) price limits (price_bounds(cfg));
    None → the hard OF defaults. The posted price is clamped into them.

    A feed post from here is ALWAYS priced (base_cents is clamped up to the $3
    floor), so on a paid-subscription page there is nothing to post — that page
    has no paid-post lane at all. Skipped, not downgraded to a free post: the
    set is the product and the DM PPV still sells it."""
    import automation_executor as ax
    import account_page
    if await account_page.is_paid_page(account_id):
        log.info("post_to_feed account=%s ppv=%s SKIPPED — paid-subscription page "
                 "has no paid-post lane", account_id, ppv.get("id"))
        return {"status": "skipped", "reason": account_page.PAID_PAGE_SKIP}
    lo, hi = bounds if bounds is not None else (_PRICE_FLOOR_CENTS, _PRICE_CEIL_CENTS)
    base_cents = max(lo, min(int(ppv.get("base_price_cents") or 0), hi))
    ppv_media = [int(x) for x in (ppv.get("media_ids") or []) if str(x).strip()]
    if not ppv_media:
        return {"status": "skipped", "reason": "no_media"}
    ppv_set = set(ppv_media)
    # Operator override: chosen media in EXACT order, filtered to the PPV's own ids
    # (never post a stray). Empty/absent → the PPV's own media (never an empty set).
    if media_files:
        media_ids = [int(x) for x in media_files if str(x).strip() and int(x) in ppv_set]
    else:
        media_ids = list(ppv_media)
    if not media_ids:
        return {"status": "skipped", "reason": "no_media"}
    media_set = set(media_ids)
    # Previews must be ⊆ media_files (OF rejects/ignores stray ids), mirroring the message path.
    prev_src = previews_override if previews_override is not None else (ppv.get("preview_options") or [])
    previews = [int(x) for x in prev_src
                if str(x).strip() and int(x) in media_set]
    if isinstance(caption, str) and caption.strip():
        used_feed_caption = True
    else:
        from automations import _language
        _feed_lang = await _language.load_account_language(account_id)
        _feed_v = await load_voice_blocks(account_id)
        caption, used_feed_caption = pick_feed_caption(
            ppv, base_cents, _feed_lang, _feed_v.voice)
    price = base_cents / 100   # OF wants dollars

    client = await asyncio.to_thread(ax._make_client, account_id)
    result = await ax.of_write_paced(
        account_id,
        lambda: client.create_post(text=caption, media_files=media_ids,
                                   price=price, previews=previews),
        send_purpose="not_fan_dm",   # feed post, not a fan DM
    )
    of_post_id = result.get("id") if isinstance(result, dict) else None
    if of_post_id is None:
        log.warning("post_to_feed account=%s ppv=%s create_post returned no id (%r)",
                    account_id, ppv.get("id"), result)
        return {"status": "error", "reason": "no_post_id", "caption": caption}
    of_post_id = int(of_post_id)

    now = datetime.utcnow()
    async with get_session() as s:
        s.add(Post(
            account_id=str(account_id), of_post_id=of_post_id, status="posted",
            text=caption, price_cents=base_cents, media_ids=json.dumps(media_ids),
            posted_at=now, created_by_employee_id=employee_id,
            raw_json=json.dumps(result, default=str)[:20000],
        ))
    log.info("post_to_feed account=%s ppv=%s of_post=%s price=%s previews=%d",
             account_id, ppv.get("id"), of_post_id, price, len(previews))
    return {
        "status": "ok", "of_post_id": of_post_id, "price": price, "caption": caption,
        "used_feed_caption": used_feed_caption, "media_count": len(media_ids),
        "preview_count": len(previews),
    }


def _segments(fan_rows: list, last_purchase: dict, now: datetime) -> dict[str, dict]:
    """Bucket fans into one spend×recency cell each. Spend = lifetime_spend_cents;
    recency = days since last PURCHASE (Transaction.occurred_at), NOT last message —
    a non-messaging buyer must still bucket by when they bought, and a never-buyer
    falls to 'quiet' (the cheapest intro price). Returns
    {cell_key: {spend, recency, spend_mult, rec_mult, fan_ids:[...]}}."""
    cells: dict[str, dict] = {}
    for fan_id, spend_cents in fan_rows:
        sname, smult = _spend_band(spend_cents)
        rname, rmult = _recency_band(last_purchase.get(int(fan_id)), now)
        key = f"{sname}:{rname}"
        cell = cells.get(key)
        if cell is None:
            cell = cells[key] = {
                "spend": sname, "recency": rname,
                "spend_mult": smult, "rec_mult": rmult, "fan_ids": [],
            }
        cell["fan_ids"].append(int(fan_id))
    return cells


class EligibleFans(NamedTuple):
    """What the PPV lane may send to, plus why the set shrank. `spend_capped` rides
    HERE rather than being recounted by the caller because it only means anything
    against the exact blacklist/bot/hard-skip set `rows` was drawn from."""
    rows: list
    last_purchase: dict
    spend_capped: int


async def _eligible_fans(account_id: str, *,
                         spend_cap: int | None = None) -> EligibleFans:
    """All non-bot, non-blacklisted fans for the account + their last-PURCHASE time.
    `spend_cap` (cents, None/0 = off) drops fans at or above a lifetime-spend
    ceiling — the whale gate every other money lane already has under this exact
    name (ai_chatter $1000, autoreply $20k, nudge_online min/max). See the caller
    for why it is NOT applied under force_ids.
    `spend_capped` in the result = how many fans the gate actually removed. Counted
    HERE, against the SAME blacklist/bot/hard-skip set the rows are drawn from,
    because a count taken at the call site drifts from the filter it claims to
    describe: a blacklisted or customs-owed whale was never in this blast, so
    blaming the gate for him sends the operator hunting a phantom.
    We filter bots/blacklisted HERE because ppv_send passes explicit included_users,
    and the send-side contact guard does NOT bot/blacklist-filter an explicit set.
    Recency is last purchase (Transaction.occurred_at), not last message.

    USER RULING (07-23): the blast audience is everyone in the matrix minus
    OPERATOR stops only — restricted / automation-off fans (hard skip_list reasons
    + blacklist + bots). AI-inferred 1:1 state must never shrink a blast: no
    offers-pause dedup, no mid-sale (hot-ladder) dedup. The blast is the money
    lane; the 1:1 engine's own pauses bind the 1:1 engine, not this one.
    (The measured history behind the ruling: gating ppv_send on chat signals cost
    −86% of sends. Ownership dedup — never re-sell what he already unlocked —
    is NOT audience gating and stays, in the send path below.)"""
    blacklisted = select(Blacklist.fan_id)
    # Operator stops (muted_creator / manual_restrict / of_restricted, plus any
    # not-yet-converted ladder_stop row). ppv_send read NONE of these before 07-23 — a
    # hand-restricted fan kept receiving priced blasts, and as a past payer he
    # landed in the HIGHEST spend-band cell.
    hard_skip = await load_hard_skip_ids(account_id)
    # A man with a custom PAID FOR and not yet delivered is not in the blast.
    #
    # This does NOT reopen the 07-23 ruling above. That ruling bars shrinking the
    # blast on AI-INFERRED 1:1 state — offers-pauses, hot-ladder mid-sale reads,
    # chat signals — because gating on those cost −86% of sends. `customs_owed_at`
    # is none of that: it is money we have already taken for work we have not yet
    # done, the same class of fact as the ownership dedup the ruling explicitly
    # keeps ("never re-sell what he already unlocked"). Selling a $200 PPV to a man
    # still waiting on the $200 voice note he bought is the single most expensive
    # thing this lane can do, and until now only the CHAT engines were stopped
    # from doing it — `_customs.is_owed` needs a Fan row, and this function
    # never loads one.
    hard_skip |= await _customs.owed_fan_ids(account_id)
    async with get_session() as s:
        fan_rows = (await s.execute(
            select(Fan.fan_id, Fan.lifetime_spend_cents).where(
                Fan.account_id == account_id,
                Fan.is_bot.is_(False),
                Fan.fan_id.not_in(blacklisted),
                # Whale gate. A SQL predicate, not a post-filter, so it costs
                # nothing on an indexed column. `lifetime_spend_cents` is NOT
                # NULL (default 0), so a fan we have no money history for reads
                # 0 and PASSES — "if we don't know him, send anyway".
                *([Fan.lifetime_spend_cents < int(spend_cap)] if spend_cap else []),
            )
        )).all()
        purchases = (await s.execute(
            select(Transaction.fan_id, func.max(Transaction.occurred_at)).where(
                Transaction.account_id == account_id,
                Transaction.amount_cents > 0,
                Transaction.fan_id.is_not(None),
            ).group_by(Transaction.fan_id)
        )).all()
    if hard_skip:
        fan_rows = [r for r in fan_rows if int(r[0]) not in hard_skip]
    spend_capped = 0
    if spend_cap:
        # Same predicate as the row query above, inverted — so this counts fans
        # the CAP removed and nothing else. hard_skip is subtracted in Python for
        # the same reason it is above: it is a set, not a column.
        async with get_session() as s:
            capped = (await s.execute(
                select(Fan.fan_id).where(
                    Fan.account_id == account_id,
                    Fan.is_bot.is_(False),
                    Fan.fan_id.not_in(blacklisted),
                    Fan.lifetime_spend_cents >= int(spend_cap),
                )
            )).scalars().all()
        spend_capped = sum(1 for f in capped if int(f) not in hard_skip)
    last_purchase = {int(fid): dt for fid, dt in purchases if fid is not None}
    return EligibleFans(fan_rows, last_purchase, spend_capped)


# Her own 1:1 rows — `ai_chatter._OUR_KINDS`, restated rather than imported because
# ai_chatter imports THIS module (`price_bounds`) and the cycle would be real.
_HER_KINDS = ("ai_chatter", "ai_upseller")


async def _ghost_dark_ids(account_id: str, fan_ids, now: datetime) -> set[int]:
    """The fans she is deliberately DARK on right now (`_ghost.py`) — they come out
    of the blast audience. READ-ONLY: this lane never writes `ghost_anchor`.

    Operator ruling 2026-08-08, and it is a deliberate exception to the 07-23 ruling
    in `_eligible_fans` above ("AI-inferred 1:1 state must never shrink a blast").
    The measured reason: on Ava a ghosted fan wrote twice into his dark day, got
    exactly the silence the cycle promises — and then took three priced PPV blasts
    and a wall promo inside the same 24 hours. That does not read as "she's busy",
    it reads as "she only writes when she wants money", which is the inverse of the
    scarcity the feature exists to manufacture. The −86% behind the 07-23 ruling came
    from gating the blast on chat SIGNALS (hot ladders, offer pauses) across the whole
    roster; this is a per-fan schedule an operator turned on by hand, and it can only
    ever reach fans ai_chatter has already anchored.

    NO ANCHOR ⇒ NEVER DARK. `ghost_anchor` is written by ai_chatter's gate and nothing
    else, so a fan it has never evaluated has no phase — and deriving one here, off
    this lane's own idea of a first inbound, would ghost fans the chat engine is not
    ghosting and disagree with it about which day.

    Both exemptions mirror `ai_chatter._ghost_gate`, and the dormancy one is
    load-bearing HERE in a way it is not there: the chat gate RESTARTS an exempt fan's
    cycle, so it meets each one once, while this lane sees a blast audience that is
    mostly cold fans whose anchors ai_chatter has not touched in weeks. Without it a
    stale anchor silently withholds the money lane from fans nobody is ghosting."""
    ids = {int(x) for x in fan_ids}
    if not ids:
        return set()
    async with get_session() as s:
        cfg_row = await s.get(AccountAiConfig, str(account_id))
        raw = getattr(cfg_row, "ai_chatter_config_json", None) if cfg_row else None
    try:
        cfg = json.loads(raw) if raw else {}
    except (TypeError, ValueError):
        cfg = {}
    # The two ai_chatter defaults this reads (`rhythm_enabled` True, ghost False),
    # restated for the same import-cycle reason as _HER_KINDS. Off ⇒ not one query.
    if not isinstance(cfg, dict) or not cfg.get("rhythm_enabled", True) \
            or not cfg.get("rhythm_ghost_enabled", False):
        return set()
    cycle = _ghost.parse_cycle(cfg.get("rhythm_ghost_cycle"))

    async with get_session() as s:
        # Every anchor for the account, intersected in Python: anchors are a handful
        # and the audience is hundreds, so this is the cheaper direction AND it keeps
        # a 400-fan blast off SQLite's bound-parameter limit.
        anchors = (await s.execute(
            select(RhythmState.fan_id, RhythmState.ghost_anchor).where(
                RhythmState.account_id == str(account_id),
                RhythmState.ghost_anchor.is_not(None),
            )
        )).all()
    windows = {}
    for fid, anchor in anchors:
        if int(fid) not in ids:
            continue
        win = _ghost.window(anchor, now, cycle)
        if win is not None:
            windows[int(fid)] = win
    if not windows:
        return set()

    async with get_session() as s:
        # `her_last_at`, NOT any outbound: a mass row is not her talking to him, and
        # counting one would let last week's blast pass as "she's been present".
        her = dict((await s.execute(
            select(Message.fan_id, func.max(Message.created_at)).where(
                Message.account_id == str(account_id),
                Message.fan_id.in_(list(windows)),
                Message.direction == "out",
                Message.mass_run_id.is_(None),
                Message.automation_kind.in_(_HER_KINDS),
            ).group_by(Message.fan_id)
        )).all())
    money = await _last_money_at(account_id, list(windows))

    dark = set()
    for fid, win in windows.items():
        her_at = her.get(fid)
        if her_at is None or her_at < win.chat_started_at:
            continue                 # she was never there this run — nothing withdrawn
        paid_at = money.get(fid)
        if paid_at is not None and paid_at >= win.chat_started_at:
            continue                 # he paid during this run — he is never dark
        dark.add(fid)
    return dark


async def _all_fan_ids(account_id: str) -> list[int]:
    """EVERY fan id we know for the account (NO bot/blacklist/buyer filter). Used as
    the broadcast exclude: a 'message fans + following' send skips everyone we've
    already handled per-fan above (tier-sent, or deliberately dropped as
    bot/blacklist/buyer), so ONLY the uncached rest get the default-price
    broadcast — no fan is messaged twice, the blacklist is honoured."""
    async with get_session() as s:
        rows = (await s.execute(
            select(Fan.fan_id).where(Fan.account_id == account_id)
        )).scalars().all()
    return [int(x) for x in rows]


# Media parsing + both ownership readers live in ownership.py (the one home
# for owned-media semantics — this used to be a "local mirror to avoid a
# circular import" situation; ownership.py is a dependency root, so the wart
# is gone). The `_owners_of_media` alias keeps this module's name for its
# call site and tests.
_owners_of_media = ownership.owners_of_media


# ── what a library entry's media IS ──────────────────────────────────────────
def _clean_media_ids(ppv: dict) -> list[int]:
    return [int(x) for x in (ppv.get("media_ids") or []) if str(x).strip()]


class PpvMedia(NamedTuple):
    """A library entry's media, resolved once: everything attached, and the slice
    of it shown FREE as the teaser. They travel together everywhere — the send
    payload, the ownership question, the preview rotation — so they are one value
    and not two locals that can drift apart on the second leg."""
    ids: list[int]
    previews: list[int]


def _ppv_media(ppv: dict) -> PpvMedia:
    """Resolve a library entry's media. OF `previews` are attached media shown FREE,
    so each preview id MUST also be in media_files — anything else → OF 400 "Wrong
    preview". Non-members are dropped; an empty pool = a fully locked PPV (valid)."""
    ids = _clean_media_ids(ppv)
    keep = set(ids)
    return PpvMedia(ids, [int(x) for x in (ppv.get("preview_options") or [])
                          if str(x).strip() and int(x) in keep])


async def _hero_media_ids(account_id: str, media_ids: list[int],
                          preview_ids: list[int]) -> list[int]:
    """Plain-id-list adapter over `ownership.hero_media_map` for the
    PPV-library blob shape — see it for the operator's hero/filler ruling."""
    return (await ownership.hero_media_map(
        account_id,
        {0: ([int(x) for x in media_ids],
             [int(x) for x in (preview_ids or [])])}))[0]


async def _split_owners(account_id: str, media: PpvMedia,
                        rows: list) -> tuple[list, list]:
    """Partition fan rows into (may be sent this PPV, already own it).

    HERO media only (operator ruling 07-23): the previews pool is the free-visible
    tease slice, so a fan who merely owns a shared preview frame is still sendable
    — only owning the payoff (a video, or a non-preview image) puts him on the
    right-hand side. Preview-listed ids the vault mirror knows are VIDEOS stay hero
    (a video is never mere filler). No previews ⇒ hero == the full media set.

    BOTH legs ask this, about different PPVs: the primary leg to find the owners it
    must not re-sell to, the owner leg to drop whoever owns the substitute as well.
    One function so the second pass can never become a weaker version of the first.
    Nobody owns the media ⇒ the right-hand list is empty and nothing moves."""
    owners = await _owners_of_media(
        account_id, await _hero_media_ids(account_id, media.ids, media.previews))
    if not owners:
        return list(rows), []
    keep, held = [], []
    for r in rows:
        (held if int(r[0]) in owners else keep).append(r)
    return keep, held


# ── Per-account cap: max PPV sends per rolling day / week / month ────────────
_CAP_WINDOWS = (("per_day", 86_400), ("per_week", 7 * 86_400), ("per_month", 30 * 86_400))

# Duplicate-fire gate: minimum minutes between two ACTUAL sends of the SAME ppv.
# Far below any real cadence (the rule sync's fastest is 604800/sends_per_week),
# so it only ever catches pathological double-fires: the executor's job retry,
# a double-enqueue, a manual fire landing on top of the rule's.
_DUP_GAP_MIN_DEFAULT = 60.0


# Nothing older than the widest cap window can gate anything, so that is how far
# back either gate ever has to look.
_CAP_LOOKBACK = timedelta(seconds=max(w for _, w in _CAP_WINDOWS))


async def _last_ppv_send(account_id: str, since: datetime,
                         ppv_id: str | None = None) -> datetime | None:
    """started_at of this account's newest DELIVERED ppv_send mass row since
    `since` — the ledger under both gates. Pass `ppv_id` to ask the duplicate
    gate's narrower question ("did THIS ppv go out?"); omit it for the cap's ("did
    ANY ppv go out?"). Rows are per CELL, so a partial fire counts too — a fire
    that broadcast 2 of 3 cells before dying is exactly what the gates exist for.

    The ledger is `mass_runs`, NOT the automation run's stats blob. Rows are
    written and stamped `ok` cell by cell as OF accepts each one; stats_json is
    written once, at the END of the whole fire. A run cancelled in flight (relay
    restart) is finalized `error` with NO stats — so keying on stats_json made a
    fire that had already broadcast most of its cells look like it never
    happened, and the requeued job re-blasted the whole audience. Live 2026-07-28
    on Ava: run 814092 sent 13 of 14 cells, was cancelled, and its retry 4
    minutes later re-sent the same PPV to the same 422 fans — under a 2/day cap.
    Those 13 rows sat there `ok` the whole time.

    `status == "ok"` carries exactly the weight the old `cells_sent > 0` did: OF
    ACCEPTED this broadcast. It is not decoration — a row whose OF call then
    RAISED stays `running` forever (nothing ever sets it to error), so counting
    every row would let a dead session or dead proxy fail every cell, deliver
    nothing, and still hold the account's next PPV for the whole even-spread gap.
    """
    q = select(func.max(MassRun.started_at)).where(
        MassRun.account_id == str(account_id),
        MassRun.automation_kind == "ppv_send",
        MassRun.status == "ok",
        MassRun.started_at >= since,
    )
    if ppv_id is not None:
        # `$.ref` is the ppv id ppv_send stamps on every send payload.
        q = q.where(func.json_extract(MassRun.audience_filter, "$.ref") == str(ppv_id))
    async with get_session() as s:
        return (await s.execute(q)).scalar_one_or_none()


def _cap_release(caps: dict, last: datetime | None, now: datetime):
    """Even-spread throttle. With cap N per window W, enforce a MINIMUM gap of W/N
    between PPV sends — so 2/day becomes one every 12h, 3/day every 8h, etc. — measured
    from `last`, the account's newest delivered send (None = never sent; the spacing
    restarts from the moment the previous one went / the cap lifted). The widest
    required gap across the day/week/month caps wins.
    Returns (capped, release_at, which_cap): release_at = the earliest the next send is
    allowed (last_send + that gap). Clear to send now → (False, None, None)."""
    if last is None:
        return (False, None, None)
    release = None
    which = None
    for key, window_s in _CAP_WINDOWS:
        try:
            limit = int(caps.get(key) or 0)
        except (TypeError, ValueError):
            limit = 0
        if limit <= 0:
            continue
        earliest = last + timedelta(seconds=window_s / limit)   # one slot every W/N
        if now < earliest and (release is None or earliest > release):
            release, which = earliest, key
    return (release is not None, release, which)


async def _cap_gate(cfg: dict, account_id: str, now: datetime):
    """The account-wide even-spread cap, as one question: (capped, release_at,
    which_cap), (False, None, None) when caps are off or the slot is clear. A
    blob with no ppv_caps key carries the house default (2/14/60 → 12h gap) via
    the _DEFAULTS merge; an explicitly saved all-zero caps dict is the
    operator's off switch and makes the any() False."""
    caps = cfg.get("ppv_caps") or {}
    if not any((caps.get(k) or 0) for k, _ in _CAP_WINDOWS):
        return False, None, None
    return _cap_release(caps, await _last_ppv_send(account_id, now - _CAP_LOOKBACK), now)


async def _defer_capped(account_id: str, ppv_id: str, release_at: datetime, now: datetime,
                        *, is_resend: bool = False):
    """Re-enqueue a one-shot ppv_send for this ppv at the cap-free time, UNLESS one is
    already pending (dedup → no pile-up across the rule's repeated fires; keyed on
    ppv_id ONLY — never on is_resend). is_resend must survive the defer, or a capped
    monthly resend comes back as a non-resend and enqueues a SECOND monthly one-shot."""
    import automation_executor as ax
    async with get_session() as s:
        existing = (await s.execute(
            select(ScheduledJob.id).where(
                ScheduledJob.account_id == account_id,
                ScheduledJob.kind == "ppv_send",
                ScheduledJob.status == "pending",
                ScheduledJob.run_at > now,
                func.json_extract(ScheduledJob.payload_json, "$.ppv_id") == ppv_id,
            ).limit(1)
        )).scalar_one_or_none()
    if existing is not None:
        return None
    payload = {"account_id": account_id, "ppv_id": ppv_id}
    if is_resend:
        payload["is_resend"] = True
    return await ax.enqueue_job(account_id, "ppv_send", payload=payload,
                                run_at=release_at)


async def segment_preview(account_id: str, base_price_cents: int,
                          bounds: tuple[int, int], spend_cap: int | None) -> dict:
    """Per-cell recipient counts + prices for a base price — the UI dry-run. Surfaces
    the 'everyone collapses into the cheap cell' case (thin data) BEFORE any send.

    Both knobs are REQUIRED and already resolved by the caller: it owns the merge of
    the operator's unsaved draft over the stored config, so deriving them here too
    would just be a second, lagging opinion about the same blob. `price_bounds` /
    `spend_bound` are the shared derivations — call those, then call this."""
    now = datetime.utcnow()
    elig = await _eligible_fans(account_id, spend_cap=spend_cap)
    fan_rows, last_purchase = elig.rows, elig.last_purchase
    base = max(bounds[0], min(int(base_price_cents or 0), bounds[1]))
    cells = _segments(fan_rows, last_purchase, now)
    plan = [
        {
            "cell": key, "spend": c["spend"], "recency": c["recency"],
            "recipients": len(c["fan_ids"]),
            "price": round_to_99(base * c["spend_mult"] * c["rec_mult"], bounds) / 100,
        }
        for key, c in sorted(cells.items())
    ]
    return {"total_fans": len(fan_rows), "cells": plan}


def _load_cfg(cfg_json: str | None) -> dict:
    cfg = dict(_DEFAULTS)
    if cfg_json:
        try:
            cfg.update(json.loads(cfg_json) or {})
        except Exception:
            pass
    return cfg


def _load_ppv(cfg_json: str | None, ppv_id: str) -> tuple[dict, dict] | tuple[None, dict]:
    cfg = _load_cfg(cfg_json)
    for p in cfg.get("ppvs") or []:
        if isinstance(p, dict) and str(p.get("id")) == str(ppv_id):
            return p, cfg
    return None, cfg


def _unsendable_reason(cfg: dict, ppv: dict) -> str | None:
    """Why this library entry cannot send right now — None means it can. THE
    definition of sendability, shared by run()'s gates and the rotator's
    candidate filter, so the two can never drift: a rotator that admitted an
    entry run() then refuses would burn that tick for the whole account.
    Reason strings are the historical ones (they are the run-row diagnostics).

    S8: a vault-AI-sourced draft (id `vai-…`) is a sendable offer ONLY once
    explicitly armed — the adapter is the single arm gate (library master ON +
    this entry `enabled`). An approved+exported-but-un-armed draft
    (enabled=False) is invisible here; approval alone never sends
    (correction #2). Non-vault-AI PPVs fall through to the generic gates.
    """
    if (vault_ai_to_chatter.is_vault_ai_offer(ppv)
            and vault_ai_to_chatter.pickable_offer(cfg, ppv.get("id")) is None):
        return "not_armed"
    if not cfg.get("enabled") or not ppv.get("enabled", True):
        return "disabled"
    try:
        if int(ppv.get("base_price_cents") or 0) <= 0:
            return "no_base_price"
    except (TypeError, ValueError):
        return "no_base_price"
    if not _clean_media_ids(ppv):
        return "no_media"
    return None


# ── the rotator behind the account's single `ppv_send` rule ─────────────────
# sends_per_week is a per-PPV MINIMUM GAP (a week ÷ N), not a proportional
# share: the account-wide ppv_caps even-spread above still owns total volume,
# rotation only decides WHICH enabled PPV the next clear slot belongs to.
_WEEK_S = 7 * 86_400
# The widest possible per-PPV gap is a full week (sends_per_week floors at 1),
# plus a day of slack so a send sitting right on that boundary still reads as
# "sent a week ago" rather than "never sent" (which would jump the queue).
_ROTATION_LOOKBACK = timedelta(seconds=_WEEK_S + 86_400)

# Process-local last-picked stamps, {account_id: {ppv_id: picked_at}}. Exists
# for the PPV that is due but DELIVERS nothing — audience exhausted (every fan
# already owns it, live on the second account) or every cell erroring. Such a run writes no
# `mass_runs` row, so on delivery time alone it would stay "most starved" and
# monopolize every future tick while deliverable siblings starve. Stamping the
# pick pushes it behind the other due PPVs until each has had a turn. A
# restart forgets the stamps and costs at most one repeated pick.
_LAST_PICKED: dict[str, dict[str, datetime]] = {}


# ── the owner leg's ledger ref ───────────────────────────────────────────────
# The second leg stamps `{ppv_id}#sub` instead of the bare id, and that suffix is
# LOAD-BEARING, not decoration. Exactly two things read `$.ref`, both in this
# module: the duplicate-fire gate (exact match on the id) and `_pick_due_ppv`
# (group-by). A suffixed ref is invisible to both with ZERO changes to either —
# which is the whole point. Deliver PPV B to ~13 owners under a BARE ref and the
# ledger says "B was delivered": the rotator then withholds B from its real
# ~400-fan audience until B's own gap expires, every tick burns two PPVs instead
# of one, and main blast throughput HALVES.
# Ownership stamping is unaffected either way — that rides
# mass_run_id → queue_id → the broadcast cache, never `$.ref`.
# `#` is RESERVED in a library id. The config API refuses it at the one place ids
# enter the system, which is what turns `_base_ref` from a hopeful string
# operation into a sound one: no operator-authored id can ever collide with, or
# be folded onto, another entry's starvation clock.
_REF_RESERVED = "#"
_SUB_REF_SUFFIX = _REF_RESERVED + "sub"


def _base_ref(ref) -> str:
    """A ledger ref back to the PPV id it belongs to — `p7#sub` → `p7`. Only the
    owner leg's OWN starvation ranking uses this; the dup gate and `_pick_due_ppv`
    deliberately keep reading the raw ref, which is how the suffix stays invisible
    to them."""
    r = str(ref or "")
    return r[:-len(_SUB_REF_SUFFIX)] if r.endswith(_SUB_REF_SUFFIX) else r


async def _delivered_by_ref(account_id: str, now: datetime) -> dict[str, datetime]:
    """Newest DELIVERED ppv_send per ledger ref, within the rotation window — the
    starvation clock both pickers rank on, read once.

    Keys are the ref exactly as it was STAMPED, never normalized here. That is the
    whole reason the two pickers can share this: `_pick_due_ppv` looks up a bare
    ppv id and so a `{id}#sub` row simply never matches it (which is what keeps the
    owner leg invisible to the rotator), while `_pick_second_ppv` folds the suffix
    itself because it must see its own deliveries. Normalizing here would silently
    hand the rotator the one fact it must not have."""
    ref = func.json_extract(MassRun.audience_filter, "$.ref")
    async with get_session() as s:
        rows = (await s.execute(
            select(ref, func.max(MassRun.started_at)).where(
                MassRun.account_id == str(account_id),
                MassRun.automation_kind == "ppv_send",
                MassRun.status == "ok",
                MassRun.started_at >= now - _ROTATION_LOOKBACK,
            ).group_by(ref))).all()
    return {str(r): t for r, t in rows if r and t is not None}


def _ppv_gap_seconds(sends_per_week) -> int:
    try:
        spw = int(sends_per_week or 1)
    except (TypeError, ValueError):
        spw = 1
    return _WEEK_S // max(1, min(spw, 14))


async def _pick_due_ppv(account_id: str, cfg: dict, now: datetime) -> dict | None:
    """Which library PPV does this rule tick belong to? None = nobody is due.
    Pure read — the caller stamps `_LAST_PICKED` when it actually takes the turn.

    Candidates are the entries `_unsendable_reason` clears (the same predicate
    run()'s own gates use, so a tick is never spent on a PPV run() would
    immediately skip) minus the arc-owned ones — those fire once via
    vault_arc's own one-shot, never on a cadence. A candidate is due again when
    its own gap (a week ÷ sends_per_week) has passed since its newest DELIVERED
    send in the `mass_runs` ledger (the same `$.ref` rows the dup-fire gate
    reads). Never-delivered counts as most starved; ties fall to library order.
    """
    cands = [p for p in (cfg.get("ppvs") or [])
             if isinstance(p, dict) and not p.get("arc_owned")
             and _unsendable_reason(cfg, p) is None]
    if not cands:
        return None

    last_sent = await _delivered_by_ref(account_id, now)
    picked = _LAST_PICKED.get(str(account_id)) or {}
    due: list[tuple[datetime, int, dict]] = []
    for idx, p in enumerate(cands):
        pid = str(p.get("id"))
        sent = last_sent.get(pid)
        if sent is not None and now < sent + timedelta(
                seconds=_ppv_gap_seconds(p.get("sends_per_week"))):
            continue
        anchor = max(sent or datetime.min, picked.get(pid) or datetime.min)
        due.append((anchor, idx, p))
    if not due:
        return None
    due.sort(key=lambda t: (t[0], t[1]))
    return due[0][2]


async def _pick_second_ppv(account_id: str, cfg: dict, now: datetime,
                           *, exclude_id: str) -> dict | None:
    """Which PPV does the OWNER leg send? The most-starved sendable entry that is
    not the one the primary leg just sent. None = the library has no substitute.

    Three ways this differs from `_pick_due_ppv`, all deliberate:

    • NO DUE GATE. `sends_per_week` is a minimum gap for the MAIN audience — the
      several-hundred-fan blast. This leg reaches the handful the ownership guard
      just removed (≤15 on the measured accounts), and going early to those is
      fine. Honouring the gate here would make the feature almost never fire on
      exactly the accounts that need it: Ava has 3 rotator PPVs against a 14/week
      cap, so `_pick_due_ppv` returns None most ticks.

    • ARC ENTRIES ARE ELIGIBLE. The rotator fences `arc_owned` out because those
      fire once, on their own day, via vault_arc's one-shot. Here they are
      inventory — and they are what makes the leg work on a thin library (Ava's
      pool goes 3 → ~19). ONE GUARD: an arc entry that still has a PENDING
      `ppv_send` job is an UNTOLD story beat and must not be pulled early (day 25
      landing before day 23). An arc day whose job already fired has no pending
      row and is just inventory. Batched into one query, same shape as
      `_defer_capped`'s dedup probe.

    • STARVATION IS MEASURED ACROSS BOTH LEGS (`_base_ref`). This leg's own rows
      carry `{id}#sub`, so ranking on the raw ref would never see them: it would
      re-pick the same PPV every tick, deliver to nobody once its owners owned it
      too, and never rotate to the next one.

    `_LAST_PICKED` is READ (same anchor formula as the rotator, so the two agree
    about who is starved) and never WRITTEN — a stamp here would push the entry
    down the rotator's own queue, which is the interference the `#sub` ref exists
    to prevent."""
    cands = [p for p in (cfg.get("ppvs") or [])
             if isinstance(p, dict) and str(p.get("id")) != str(exclude_id)
             and _unsendable_reason(cfg, p) is None]
    if not cands:
        return None

    if any(p.get("arc_owned") for p in cands):
        async with get_session() as s:
            rows = (await s.execute(
                select(func.json_extract(ScheduledJob.payload_json, "$.ppv_id")).where(
                    ScheduledJob.account_id == str(account_id),
                    ScheduledJob.kind == "ppv_send",
                    ScheduledJob.status == "pending",
                    ScheduledJob.run_at > now,
                ))).scalars().all()
        pending = {str(x) for x in rows if x}
        cands = [p for p in cands
                 if not (p.get("arc_owned") and str(p.get("id")) in pending)]
        if not cands:
            return None

    last_sent: dict[str, datetime] = {}
    for r, t in (await _delivered_by_ref(account_id, now)).items():
        base = _base_ref(r)
        if t > last_sent.get(base, datetime.min):
            last_sent[base] = t

    picked = _LAST_PICKED.get(str(account_id)) or {}
    ranked = sorted(
        ((max(last_sent.get(str(p.get("id"))) or datetime.min,
              picked.get(str(p.get("id"))) or datetime.min), idx, p)
         for idx, p in enumerate(cands)),
        key=lambda t: (t[0], t[1]))
    return ranked[0][2]


# ── the send legs: the cell loop, and the owner leg that reuses it ───────────
class _SendCtx(NamedTuple):
    """Everything a cell send needs that is FIXED for the whole run — the account,
    the operator price bounds, her language and voice, the contact-guard window,
    the day's preview rotation, the run id. Built once in `run()` and handed to
    both legs, so the only things that vary between them are the ones that
    genuinely do: the fan set, the PPV, and the ledger ref."""
    account_id: str
    bounds: tuple[int, int]
    lang: str
    voice: str | None
    pause_hours: int
    day_idx: int
    run_id: int
    # One model-written caption line about the media, or None for "pool only".
    # Fixed for the run BY DEFINITION: every cell ships the same media, so a
    # per-cell hook would pay a dozen times for one sentence. Defaulted so every
    # existing construction site keeps working untouched.
    ai_hook: str | None = None


class _LegResult(NamedTuple):
    """What one pass of the cell loop did. Returned rather than accumulated into
    the caller's locals: a leg that reached into `run()`'s `results` and
    `send_errors` could not be read — or tested — on its own."""
    cells: int
    recipients: int
    errors: int
    rows: list[dict]


async def _send_cells(ctx: _SendCtx, cells: dict, ppv: dict, media: PpvMedia,
                      ref: str, *, tag: str = "") -> _LegResult:
    """One mass call per non-empty cell: matrix price, rotated preview, this PPV's
    media, under `ref` as the ledger key.

    Called TWICE per run — once for the primary audience under the bare ppv id,
    once for the owners under `{id}#sub`. Sharing the body is the point: two copies
    would drift on exactly the parts that took live incidents to get right (the
    per-cell error containment, the recorded `reason`, the skipped/error
    accounting). `tag` prefixes the results-row cell key so the two legs stay
    distinguishable in `automation_runs.stats_json`."""
    from automations.send_mass_message import run as send_mass_run

    ppv_id = str(ppv.get("id"))
    base_cents = int(ppv.get("base_price_cents") or 0)
    cells_ok = 0
    recipients = 0
    errors = 0
    rows: list[dict] = []
    for key, cell in sorted(cells.items()):
        fan_ids = cell["fan_ids"]
        if not fan_ids:
            continue
        price = round_to_99(base_cents * cell["spend_mult"] * cell["rec_mult"],
                            ctx.bounds)
        row = {"cell": tag + key, "price": price / 100, "recipients": len(fan_ids)}
        if tag:
            row["ppv_id"] = ppv_id
        send_payload = {
            # Text is intentionally NOT locked — fans see the teaser caption free,
            # only the media sits behind the price (locked_text defaults off).
            "text": _pick_caption(ppv, price, ctx.lang, ctx.voice,
                                  hook=ctx.ai_hook),
            "media_files": media.ids,
            "previews": _rotate_preview(media.previews, ctx.day_idx),
            "price": price / 100,                 # OF wants dollars
            "included_users": fan_ids,
            "automation_kind": "ppv_send",        # Mass Messages tab attribution
            "automation_ref": ref,                # the duplicate gate's ledger key
            # Pause = the contact guard. 0 → guard OFF (send to everyone, the
            # default); >0 → skip fans messaged in the last N hours.
            "exclude_replied_hours": ctx.pause_hours,
            "exclude_inbound_hours": ctx.pause_hours,
        }
        try:
            res = await send_mass_run(ctx.account_id, send_payload,
                                      run_id=ctx.run_id)
        except Exception as e:  # noqa: BLE001 — one cell must NOT fail the batch
            # A raise here fails the WHOLE job and the executor retries it —
            # re-broadcasting every cell that already went out (the live
            # double-send of 2026-07-01/03). Contain it: record the error,
            # move on; this cell's fans catch the next cadence fire.
            log.warning("ppv_send cell send failed account=%s ppv=%s cell=%s: %r",
                        ctx.account_id, ppv_id, key, e)
            errors += 1
            rows.append({**row, "status": "error", "error": repr(e)[:200]})
            continue
        # `reason` is why a skip/error happened. Recording only `status` is what
        # kept the broadcast outage invisible for 45 days — the run still reads
        # 'ok' at the top.
        rows.append({**row, "status": res.get("status"),
                     "reason": res.get("reason")})
        if res.get("status") not in ("skipped", "error"):
            cells_ok += 1
            recipients += len(fan_ids)
    return _LegResult(cells_ok, recipients, errors, rows)


async def _run_owner_leg(ctx: _SendCtx, cfg: dict, now: datetime, *,
                         primary_id: str, owner_rows: list,
                         last_purchase: dict) -> tuple[dict, _LegResult]:
    """Send the fans the ownership guard removed a DIFFERENT library PPV, in this
    same tick, instead of nothing. Returns (report, leg): the report is what lands
    in the run's stats blob, and `leg` is an EMPTY result when nothing went out
    rather than None — the caller then has no special case to write.

    CELLS ONLY. No broadcast (that leg's audience is the uncached rest of the page,
    who are not owners of anything), no feed post (one wall drop per run, and the
    primary PPV is the one the run is about), no monthly resend (this leg reaches
    ≤15 fans on a schedule the rotator does not own — a +30d repeat booked off it
    would put a second, unrelated cadence into the library).

    Whoever owns the substitute as well is dropped by `_split_owners`, the same
    partition the primary leg just used, asked about a different PPV. There is no
    second ownership concept and no per-fan scoring: take the next PPV, let the
    existing guard skip whoever owns that one too.

    The cap needs nothing from us: both legs land inside this run's timestamp
    window, so the account's next even-spread gap is measured from the moment it
    would have been anyway, and each fan still receives exactly one PPV this tick
    (the two audiences are disjoint by construction — one is the complement of the
    other)."""
    owner_fans = len(owner_rows)
    ppv = await _pick_second_ppv(ctx.account_id, cfg, now, exclude_id=primary_id)
    if ppv is None:
        report = {"status": "skipped", "reason": "no_second_ppv",
                  "owner_fans": owner_fans}
        leg = _LegResult(0, 0, 0, [])
    else:
        ppv_id = str(ppv.get("id"))
        media = _ppv_media(ppv)
        rows, _ = await _split_owners(ctx.account_id, media, owner_rows)
        if not rows:
            report = {"status": "skipped", "reason": "owns_both", "ppv_id": ppv_id,
                      "owner_fans": owner_fans, "recipients": 0,
                      "owns_both": owner_fans}
            leg = _LegResult(0, 0, 0, [])
        else:
            leg = await _send_cells(
                ctx, _segments(rows, last_purchase, now), ppv, media,
                f"{ppv_id}{_SUB_REF_SUFFIX}", tag="sub:")
            report = {
                "status": "ok" if leg.cells else "skipped",
                "reason": None if leg.cells else "all_cells_empty",
                "ppv_id": ppv_id, "cells": leg.cells, "recipients": leg.recipients,
                # The owner group, and how much of it owns the substitute as well —
                # the number that says whether this library is deep enough for the
                # leg to keep working.
                "owner_fans": owner_fans, "owns_both": owner_fans - len(rows),
            }
    log.info("ppv_send owner-leg account=%s primary=%s owners=%d %s",
             ctx.account_id, primary_id, owner_fans, report)
    return report, leg


@register("ppv_send")
async def run(account_id: str, payload: dict, *, run_id: int) -> dict:
    payload = payload or {}
    ppv_id = payload.get("ppv_id")
    is_resend = bool(payload.get("is_resend"))
    dry_run = bool(payload.get("dry_run"))
    force_ids = {int(x) for x in (payload.get("force_ids") or [])}
    # only_fan_ids — the ai_chatter convention: scope the audience with EVERY gate
    # still armed (unlike force_ids, which is a human live-test escape hatch and
    # bypasses the cap + dup-fire gate). The Human Rhythm scheduler resumes a
    # deferred send by re-enqueueing THIS job scoped to one fan; if that resume
    # bypassed the gates it would happily re-sell media he bought in the meantime,
    # or re-blast a cell the original run already sent.
    only_fan_ids = {int(x) for x in (payload.get("only_fan_ids") or [])}

    now = datetime.utcnow()

    async with get_session() as s:
        cfg_row = await s.get(AccountAiConfig, account_id)

    if ppv_id:
        ppv, cfg = _load_ppv(cfg_row.ppv_library_config_json if cfg_row else None,
                             ppv_id)
        if ppv is None:
            return {"status": "skipped", "reason": "ppv_not_found"}
    else:
        # No PPV named — the account's single rule ticked. Rotate.
        cfg = _load_cfg(cfg_row.ppv_library_config_json if cfg_row else None)
        if not cfg.get("enabled"):
            return {"status": "skipped", "reason": "disabled"}
        # Account-wide cap FIRST: when the even-spread says "not yet", picking a
        # PPV now would only burn its rotation turn. And no defer one-shot here
        # either — this rule ticks hourly, so the rule itself is the retry (the
        # defer machinery below stays what it always was: the explicit-ppv
        # paths' way of keeping their slot).
        if not dry_run and not force_ids:
            capped, release_at, which = await _cap_gate(cfg, account_id, now)
            if capped:
                return {"status": "skipped", "reason": f"capped_{which}",
                        "retry_at": release_at.isoformat() + "Z"}
        ppv = await _pick_due_ppv(account_id, cfg, now)
        if ppv is None:
            return {"status": "skipped", "reason": "none_due"}
        ppv_id = str(ppv.get("id"))
        # Take the turn — see _LAST_PICKED. dry_run only peeks: a diagnostic
        # tick must not push the picked PPV to the back of live rotation.
        if not dry_run:
            _LAST_PICKED.setdefault(str(account_id), {})[ppv_id] = now
    # Account language for the DEFAULT caption pools (a PPV's own caption_texts still
    # win, in whatever language they were authored). cfg_row is already loaded above.
    from automations import _language
    account_lang = _language.norm_lang(getattr(cfg_row, "language", None)) or "en"
    # Same row, same read — the caption pool set is a second axis on this config,
    # exactly like the language above it. NULL/unknown → her, byte-identically.
    account_voice = _voice.norm_voice(getattr(cfg_row, "voice", None))
    # Cheap fail-fast gates (armed / enabled / priced / has media) before the fan
    # scan — the same predicate the rotator filters candidates by, so a rotated
    # pick passes these by construction and only an explicit-ppv payload can trip
    # them.
    skip = _unsendable_reason(cfg, ppv)
    if skip:
        return {"status": "skipped", "reason": skip}

    # "Send to everyone": after the per-tier sends to KNOWN fans, fire ONE
    # default-price broadcast to the house audience (fans + following, OF-resolved,
    # reaches uncached subs too), excluding every known fan so nobody is
    # double-sent. Off until enabled per account (a deploy alone never mass-blasts
    # a sub list).
    reach_all = bool(cfg.get("reach_all", False))
    # Broadcast audience knobs. Read here beside reach_all (they only ever apply
    # to that leg) and normalized ONCE, so the payload site below stays a plain
    # copy. `broadcast_lists` absent → None → the historical fans + following;
    # present-but-empty → an empty audience, which send_mass_run skips.
    bcast_lists, bcast_excl = broadcast_audience(cfg)
    # Pause = don't re-touch a fan messaged in the last N hours (the contact
    # guard). Default 0 = NO pause (send to everyone). Applies to both phases.
    try:
        pause_hours = max(0, int(cfg.get("pause_hours") or 0))
    except (TypeError, ValueError):
        pause_hours = 0
    # A live, unscoped run — the one condition BOTH optional legs below hang off.
    # A plan must not send or spend (dry_run), and force_ids/only_fan_ids mean
    # "these fans and nobody else": quietly widening a scoped run — to a second
    # PPV, or to a paid model call the last real send never made — is exactly
    # what a scope exists to prevent. Named once because it was written out twice
    # and the second copy is how the third one drifts.
    live_unscoped = not dry_run and not force_ids and not only_fan_ids

    # ── the owner leg. Default OFF, per account. ─────────────────────────
    # The ownership guard below removes the fans who already unlocked this PPV's
    # hero media and the run then sends them NOTHING — measured 2026-08-22, buyers
    # receive 12-52% fewer mass PPVs than non-buyers on all six live accounts,
    # because ownership only ever accumulates. With this on, those fans get a
    # DIFFERENT library PPV in the same tick instead of nothing.
    #
    # Per-account and not global on purpose: the all-lanes count (mass + 1:1)
    # flips three of the six — the 1:1 seller lane already targets payers
    # (`payers_only` defaults on), so on those accounts buyers ALREADY receive
    # more total priced offers than non-buyers and this leg would over-serve them.
    #
    # `live_unscoped` below is what skips it outright.
    owner_leg = bool(cfg.get("owner_second_leg", False)) and live_unscoped

    base_cents = int(ppv.get("base_price_cents") or 0)
    # Operator price limits — every COMPUTED price (per-cell, broadcast, feed)
    # is clamped into these; the authored base_price_cents is never rewritten.
    bounds = price_bounds(cfg)
    bcast_cents = max(bounds[0], min(base_cents, bounds[1]))
    media = _ppv_media(ppv)      # non-empty ids — _unsendable_reason gated it
    day_idx = now.toordinal()   # rotates the preview once per day → fresh on each resend
    # AI caption at send: ONE finished line about this media, written now and
    # shared by every cell below. Default OFF per account. Arrives already
    # word-filtered — see `describe_media.send_time_hook`.
    ai_hook = None
    if live_unscoped and cfg.get("ai_caption_at_send"):
        ai_hook = await describe_media.send_time_hook(
            account_id, media.ids, day_idx=day_idx)
    ctx = _SendCtx(account_id, bounds, account_lang, account_voice,
                   pause_hours, day_idx, run_id, ai_hook)

    # ── per-account cap: even-spread the day/week/month limit (one send every
    #    window/N, re-scheduling a too-soon send to its slot).
    # (force_ids = an explicit live-test scope, bypasses the cap. A rotated pick
    # re-asks a question its tick already answered — cheap, and it keeps this
    # path self-contained for the one-shot payloads that arrive here directly.)
    if not dry_run and not force_ids:
        capped, release_at, which = await _cap_gate(cfg, account_id, now)
        if capped:
            job_id = await _defer_capped(account_id, ppv_id, release_at, now,
                                         is_resend=is_resend)
            log.info("ppv_send capped account=%s ppv=%s cap=%s release=%s defer_job=%s",
                     account_id, ppv_id, which, release_at, job_id)
            return {"status": "skipped", "reason": f"capped_{which}",
                    "retry_at": release_at.isoformat() + "Z", "defer_job_id": job_id}

    # ── duplicate-fire gate: NEVER send the same ppv twice within the gap ─
    # Guards against the executor retrying a partially-failed job, a
    # double-enqueue, or a manual fire landing on the rule's — with the
    # default pause_hours=0 the contact guard is OFF, so this ledger check is
    # the real protection. Skipping is safe: a missed cycle self-heals at the
    # next cadence fire; a double-blast doesn't. (Runs AFTER the cap check so
    # a capped fire keeps its defer-to-slot semantics; a deferred job lands
    # past the gap, so the two never fight.)
    try:
        dup_gap_min = float(cfg.get("min_send_gap_minutes")
                            if cfg.get("min_send_gap_minutes") is not None
                            else _DUP_GAP_MIN_DEFAULT)
    except (TypeError, ValueError):
        dup_gap_min = _DUP_GAP_MIN_DEFAULT
    if not dry_run and not force_ids and dup_gap_min > 0:
        last = await _last_ppv_send(
            account_id, now - timedelta(minutes=dup_gap_min), str(ppv_id))
        if last is not None:
            log.warning("ppv_send duplicate-fire gate account=%s ppv=%s "
                        "last_sent=%s gap_min=%s — skipping",
                        account_id, ppv_id, last, dup_gap_min)
            return {"status": "skipped", "reason": "duplicate_recent_send",
                    "ppv_id": ppv_id, "last_sent_at": last.isoformat() + "Z",
                    "gap_minutes": dup_gap_min}

    # Whale gate. NOT applied under force_ids: force_ids is the human live-test
    # escape hatch (it already bypasses the cap and the dup gate), and a forced
    # send that silently reaches nobody because the test fan happens to be a payer
    # is the worst possible debugging experience — the operator sees "ok, 0
    # recipients" and has nothing to grep for. only_fan_ids is a MACHINE scope and
    # keeps every gate armed, per this module's header convention.
    spend_cap = spend_bound(cfg)
    # `spend_capped` comes back with the rows: a blast that quietly reaches fewer
    # people and says nothing about why is the failure mode `ghost_skipped` was
    # added for, and only _eligible_fans knows the real eligible set to count
    # against.
    fan_rows, last_purchase, spend_capped = await _eligible_fans(
        account_id, spend_cap=None if force_ids else spend_cap)
    if force_ids:
        fan_rows = [r for r in fan_rows if int(r[0]) in force_ids]
    if only_fan_ids:
        fan_rows = [r for r in fan_rows if int(r[0]) in only_fan_ids]

    # ── ghost cycle: she is dark on him today, so this lane is too ──────
    # Unlike the ownership guard below, this one DOES yield to `force_ids`: the
    # ghost is a gate (a schedule about when she talks), not a fact about the fan,
    # and an operator firing at named fans has overridden every other gate here.
    # `only_fan_ids` is a machine scope and does not — see the header.
    #
    # The broadcast leg below needs no filter: it excludes `_all_fan_ids`, and a
    # fan with an anchor is by definition one we know.
    #
    # IT RUNS ABOVE THE OWNERSHIP SPLIT, and that order is load-bearing. The
    # primary audience is the same set either way (all − owners − dark ==
    # all − dark − owners), but the OWNER group that falls out below is only
    # ghost-clean if the dark fans are already gone — and the owner leg sends to
    # that group. Filtered the old way round it would have been the one lane in
    # this module that blasts a fan she is deliberately silent on. One call, not
    # two: a second `_ghost_dark_ids` would be a second opinion about the same day.
    #
    # `ghost_skipped` therefore counts EVERY eligible fan the cycle took out,
    # including ones ownership would also have removed. Under the old order those
    # overlapping fans were dropped as owners first and never counted here; the
    # three counters now partition the eligible set instead of shadowing each other.
    ghost_skipped = 0
    if not force_ids:
        dark = await _ghost_dark_ids(account_id, [int(r[0]) for r in fan_rows], now)
        if dark:
            before = len(fan_rows)
            fan_rows = [r for r in fan_rows if int(r[0]) not in dark]
            ghost_skipped = before - len(fan_rows)
            log.info("ppv_send ghost-skip account=%s ppv=%s skipped=%d (dark today)",
                     account_id, ppv_id, ghost_skipped)

    # ── ownership guard — UNCONDITIONAL, and deliberately NOT under exclude_buyers ─
    # Re-selling a fan a clip he ALREADY UNLOCKED is a money bug in both directions:
    # he pays twice for the same media (refund + chargeback risk, and chargebacks are
    # the one thing that kills an OF account), or he sees it's the same file at a
    # different price and stops trusting every future price we quote. There is no
    # config value for which that is the desired outcome — so there is no config flag
    # in front of it. `exclude_buyers` survives as a no-op for old configs.
    #
    # It runs AFTER the scopes, never inside an elif on one of them:
    #   force_ids may scope WHO we send to; it may NEVER license re-selling media a
    #   fan already owns. force_ids bypasses GATES (cap, dup-fire) — it is not a
    #   whitelist, and ownership is not a gate, it is a fact about the fan.
    #
    # A SPLIT, not a drop: the fans on the right are kept as `owner_rows` for the
    # owner leg at the bottom of this run. With the leg off they are simply
    # discarded, as they always were — but `owner_skipped` now REPORTS them either
    # way. That number only ever reached a log line before, which is precisely why
    # the gap it measures went unnoticed for as long as it did.
    fan_rows, owner_rows = await _split_owners(account_id, media, fan_rows)
    owner_skipped = len(owner_rows)
    if owner_skipped:
        log.info("ppv_send owner-skip account=%s ppv=%s skipped=%d (already unlocked)",
                 account_id, ppv_id, owner_skipped)

    # No known fans is only a hard stop when we're NOT also broadcasting to the
    # house audience (reach_all): the broadcast can still reach the uncached list.
    # A fan-scoped run (force_ids/only_fan_ids) never broadcasts — the whole point of
    # a scope is that the audience is those fans and nobody else.
    broadcasting = reach_all and not force_ids and not only_fan_ids
    # Everyone owning the hero media is the live `the second account` shape — the whole primary
    # audience gone and nothing to send. That run is exactly the one the owner leg
    # exists for, so it may not stop here.
    primary_audience = bool(fan_rows) or broadcasting
    if not primary_audience and not (owner_leg and owner_rows):
        # Carry the counters even here: "no_fans" because everyone is mid-ghost is a
        # very different run from "no_fans" because the roster is empty or because
        # every last fan already owns this one, and the stats row is the only place
        # anyone can tell them apart.
        return {"status": "skipped", "reason": "no_fans",
                "ghost_skipped": ghost_skipped, "owner_skipped": owner_skipped}

    cells = _segments(fan_rows, last_purchase, now)

    # ── dry_run: the per-cell plan, no send, no enqueue ─────────────────
    if dry_run:
        plan = []
        for key, cell in sorted(cells.items()):
            price = round_to_99(base_cents * cell["spend_mult"] * cell["rec_mult"], bounds)
            plan.append({
                "cell": key, "recipients": len(cell["fan_ids"]),
                "price": price / 100,
                "caption": _pick_caption(ppv, price, account_lang, account_voice)[:80],
                "preview": _rotate_preview(media.previews, day_idx),
            })
        return {"dry_run": True, "ppv_id": ppv_id, "is_resend": is_resend,
                "cells": len(plan), "fans": len(fan_rows), "plan": plan, "sent": 0,
                "ghost_skipped": ghost_skipped, "owner_skipped": owner_skipped,
                "broadcast_all": broadcasting,
                "broadcast_price": (bcast_cents / 100) if broadcasting else None,
                "pause_hours": pause_hours}

    # ── send: one mass call per non-empty cell, matrix price + rotated preview
    from automations.send_mass_message import run as send_mass_run

    send_errors = 0
    results: list[dict] = []

    leg = await _send_cells(ctx, cells, ppv, media, str(ppv_id))
    sent_cells, total_recipients = leg.cells, leg.recipients
    send_errors += leg.errors
    results.extend(leg.rows)

    # ── broadcast: ONE default-price send to the house audience (OF-resolved:
    #    fans + following), with EVERY known fan excluded (the per-tier sends above
    #    + buyers/bots/blacklist) → only the uncached rest get it, at the base
    #    "default" price. This is how a PPV reaches her whole free-page list
    #    without scraping it. ─────────────────────────────────────────────────────
    broadcast = None
    # Operator decision O3: the house broadcast FIRES FENCED under the include
    # audience (send_mass_run attaches the AUTOFENCE — no revenue blackout).
    # This per-account/per-rule toggle is the optional skip for operators who
    # want enforce mode to silence the house blast entirely.
    if broadcasting and payload.get("audience_skip_broadcast"):
        import audience_include as _audiences
        pol = await _audiences.automation_audience(account_id)
        if pol.mode == "enforce":
            broadcasting = False
            results.append({"cell": "broadcast:all", "status": "skipped",
                            "reason": "audience_skip_broadcast"})
    if broadcasting:
        known_ids = await _all_fan_ids(account_id)
        broadcast_payload = {
            # default-price caption, same run-fixed hook as the cells
            "text": _pick_caption(ppv, bcast_cents, account_lang,
                                  account_voice, hook=ai_hook),
            "media_files": media.ids,
            "previews": _rotate_preview(media.previews, day_idx),
            "price": bcast_cents / 100,               # the DEFAULT price, clamped
            # Operator audience. DEFAULT (key absent) is the historical
            # fans + following — an account that never opens these controls
            # behaves byte-identically to before this feature existed.
            #
            # ⚠️ The `is None` test is load-bearing and must NOT become
            # `cfg.get(...) or BROADCAST_LISTS`. This module's house idiom for
            # optional lists IS `or []` (see preview_options above, online_blast,
            # mass_premade) — but here an EMPTY list is a real operator decision
            # ("I deselected everything"), and `or` treats it as falsy and
            # substitutes fans + following. That is the inversion this lane can
            # least afford: the operator asks for nobody and gets the entire
            # subscriber list at the base price.
            "user_lists": (list(audiences.BROADCAST_LISTS)
                           if bcast_lists is None else bcast_lists),
            # Fan lists to skip, server-side. `excluded_user_lists` is the ONLY
            # exclusion OF honors on a list audience, and send_mass_run APPENDS
            # the Auto_Exclude id to whatever we pass — it never replaces it, so
            # naming lists here cannot un-exclude the known fans below.
            "excluded_user_lists": bcast_excl,
            "excluded_users": known_ids,              # → Auto_Exclude (no double-send)
            "automation_kind": "ppv_send",
            "automation_ref": str(ppv_id),
            "exclude_replied_hours": pause_hours,
            "exclude_inbound_hours": pause_hours,
        }
        try:
            res = await send_mass_run(account_id, broadcast_payload, run_id=run_id)
        except Exception as e:  # noqa: BLE001 — same containment as the cells
            log.warning("ppv_send broadcast send failed account=%s ppv=%s: %r",
                        account_id, ppv_id, e)
            send_errors += 1
            broadcast = "error"
            results.append({"cell": "broadcast:all", "price": bcast_cents / 100,
                            "recipients": 0, "status": "error",
                            "error": repr(e)[:200],
                            "excluded_known": len(known_ids)})
        else:
            broadcast = res.get("status")
            results.append({"cell": "broadcast:all", "price": bcast_cents / 100,
                            "recipients": res.get("recipients", 0), "status": broadcast,
                            # See the cell append above — a bare "error" with no
                            # reason is unreadable in automation_runs.stats_json.
                            "reason": res.get("reason"),
                            "excluded_known": len(known_ids)})
            if broadcast not in ("skipped", "error"):
                sent_cells += 1   # counts as a send for the cap + 'ok' status

    # ── also post to feed: opt-in ("auto post to feed with mass"). Fire ONCE per
    #    run, only when a send actually went out (don't post to the feed on an
    #    all-empty/skipped cycle). Best-effort — a feed-post failure never fails the
    #    send. Same paid post + ⭐ preview + feed-voice caption as the manual button.
    feed_post = None
    if ppv.get("feed_enabled", True) and ppv.get("also_post_to_feed") and sent_cells:
        try:
            feed_post = await post_to_feed(account_id, ppv, bounds=bounds)
        except Exception:
            log.exception("ppv_send also_post_to_feed failed account=%s ppv=%s", account_id, ppv_id)
            feed_post = {"status": "error", "reason": "exception"}

    # ── monthly resend: one-shot +30d (a resend gets a fresh random preview) ─
    # `primary_audience` is what the old `no_fans` return used to guarantee: before
    # the owner leg existed, reaching this line at all meant the primary leg had
    # someone to send to. The leg can now carry a run whose primary audience was
    # empty, and such a run must not book a monthly repeat of a PPV it never sent.
    resend_job_id = None
    if primary_audience and ppv.get("resend_monthly") and not is_resend:
        import automation_executor as ax
        resend_job_id = await ax.enqueue_job(
            account_id, "ppv_send",
            payload={"account_id": account_id, "ppv_id": ppv_id, "is_resend": True},
            run_at=now + timedelta(days=30),
        )

    # ── the owner leg. Runs LAST, below every gate above, so none of them can
    #    read a counter it moved: `sent_cells` still gates the feed post,
    #    `primary_audience` still gates the resend, and the cap/dup ledger sees
    #    only what it saw before. ─────────────────────────────────────────────
    second_leg = None
    sub = _LegResult(0, 0, 0, [])
    if owner_leg and owner_rows:
        second_leg, sub = await _run_owner_leg(
            ctx, cfg, now, primary_id=str(ppv_id), owner_rows=owner_rows,
            last_purchase=last_purchase)
        send_errors += sub.errors
        results.extend(sub.rows)

    log.info("ppv_send account=%s ppv=%s cells=%d recipients=%d errors=%d broadcast=%s "
             "resend_job=%s feed=%s owner_skipped=%d sub_cells=%d",
             account_id, ppv_id, sent_cells, total_recipients, send_errors, broadcast,
             resend_job_id, (feed_post or {}).get("status"), owner_skipped, sub.cells)
    # NOTE: an all-failed run returns status 'error' in the STATS only — it must
    # not raise, or the executor's job retry would re-broadcast any cell that
    # did go out. The failed cells simply wait for the next cadence fire.
    return {
        # A run whose primary cells were all empty but whose owner leg delivered
        # DID send — reading it as 'skipped' would hide the one thing this feature
        # exists to do on a fully-owned-out account.
        "status": "ok" if (sent_cells or sub.cells) else
                  ("error" if send_errors else "skipped"),
        "reason": None if (sent_cells or sub.cells) else
                  ("all_sends_failed" if send_errors else "all_cells_empty"),
        "ppv_id": ppv_id, "is_resend": is_resend,
        # PRIMARY leg only (plus the broadcast, as always) — the owner leg keeps its
        # own counts under `second_leg` rather than inflating the number every
        # report and dashboard already reads as "the blast".
        "cells_sent": sent_cells, "recipients": total_recipients,
        # How many fans the ghost cycle took out of this blast. Without it the run
        # just quietly reaches fewer people and nothing says why.
        "ghost_skipped": ghost_skipped,
        # How many already owned this PPV's hero media. `ghost_skipped` and
        # `spend_capped` have always reported themselves; this one only ever
        # reached a log line, which is how a 12-52% shortfall in what buyers
        # receive stayed unmeasured.
        "owner_skipped": owner_skipped,
        # The owner leg's own outcome, None when it is off or had nobody.
        "second_leg": second_leg,
        # How many fans the whale gate took out (0 when it's off). Same reason
        # ghost_skipped exists: a shrinking audience must say why.
        "spend_capped": spend_capped,
        "spend_cap_cents": spend_cap,
        "send_errors": send_errors,
        "broadcast": broadcast, "pause_hours": pause_hours,
        "resend_job_id": resend_job_id, "feed_post": feed_post, "results": results,
    }
