"""service/automations/tip_request.py — nudge a quiet mass-buyer with a free
teaser image + an ask-for-a-tip caption (backlog item 42).

Trigger (SWEEP): a fan BOUGHT a mass PPV inside the window and has NOT replied
since — the money's warm but the conversation went cold, so we send ONE free
vault image picked AT RANDOM from the account's configured teaser pool, with a
caption that asks for a tip. No LLM, no per-fan generation: a configured image
pool + one caption. The purchase signal is `messages.is_paid` (flipped by the ledger's
`transaction_ingest._link_ppv_message` — the only reliable PPV-unlock signal);
"mass" = the buy rode a broadcast (`mass_run_id IS NOT NULL`).

Design constraints (lane L7):
  • Config lives NESTED under `account_ai_config.tip_reward_config_json`
    ['tip_request'], NOT its own column — item 42's lane must not touch the
    cross-lane `models.py` schema seam, and the tip_reward `image_reply` flags
    already precedent sharing that column. Persisted/validated via
    tip_reward_config_api._validate_tip_request.
  • Per-fan send dedup is a cooldown stamp in `fans.custom_fields['_tip_request']`
    — namespaced, migration-free, mirroring tip_reward's `_image_reply` stamp.

Ships DISABLED (enabled=false, no media). A creator enables it and picks the
tip-request image pool; a `tip_request` automation_rule with a cadence trigger
fires this sweep.
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
from datetime import datetime, timedelta

import automation_executor as ax        # _make_client seam
from attribution import write_outbound_attribution
from audiences import contact_guard_excludes
from automation_registry import register
from automations import _customs
from automations._common import (
    apply_word_restriction, load_hard_skip_ids, should_skip_muted_creator,
)
from automations.fan_state import fan_state, put_fan_state
from db.engine import get_session
from db.models import AccountAiConfig, Fan, Message
from sqlalchemy import func, select

log = logging.getLogger("of-relay.automation.tip_request")

_AUTOMATION_KIND = "tip_request"
_STATE_KEY = "_tip_request"    # fans.custom_fields per-fan cooldown stamp

# Built-in defaults for any key the config omits. DISABLED + no media → a fresh
# account never fires until a creator enables it and picks the teaser image(s).
_DEFAULTS = {
    "enabled": False,
    "media_ids": None,         # tip-request teaser POOL (vault media ids); each
                               # send picks one at random
    "media_id": None,          # legacy single-image key, folded into the pool
    "caption": "hope you loved that 🥺 wanna send me a lil tip so i keep going?",
    "min_wait_hours": 2,       # give the fan time to reply naturally first
    "max_age_hours": 48,       # don't chase a purchase older than this
    "cooldown_hours": 168,     # per-fan: at most one tip-request / week
    "guard_hours": 6,          # cross-automation contact-guard window
    "limit": 200,              # max fans nudged per sweep
}


async def _load_config(account_id: str) -> dict:
    """`tip_reward_config_json['tip_request']` shallow-merged over _DEFAULTS.
    A None value in the stored sub-config falls back to the default."""
    async with get_session() as s:
        cfg = await s.get(AccountAiConfig, str(account_id))
    raw = getattr(cfg, "tip_reward_config_json", None) if cfg else None
    sub: dict = {}
    if raw:
        try:
            sub = (json.loads(raw) or {}).get("tip_request") or {}
        except Exception:
            log.warning("bad tip_request config account=%s", account_id, exc_info=True)
    merged = dict(_DEFAULTS)
    if isinstance(sub, dict):
        merged.update({k: v for k, v in sub.items() if v is not None})
    return merged


def _teaser_pool(cfg: dict) -> list[int]:
    """The configured teaser images as a deduped positive-int list. The legacy
    single `media_id` rides along as one more candidate, so configs saved before
    the pool existed keep firing unchanged."""
    raw = cfg.get("media_ids")
    candidates = list(raw) if isinstance(raw, (list, tuple)) else []
    candidates.append(cfg.get("media_id"))   # legacy single-image key
    pool: list[int] = []
    for mid in candidates:
        try:
            mid = int(mid)                   # int(None) → TypeError → skipped
        except (TypeError, ValueError):
            continue
        if mid > 0 and mid not in pool:
            pool.append(mid)
    return pool


async def is_enabled(account_id: str) -> bool:
    """On AND at least one teaser image is set — both required to fire."""
    cfg = await _load_config(account_id)
    return bool(cfg.get("enabled") and _teaser_pool(cfg))


def _cooled_down(fan: Fan | None, cooldown_hours: int) -> bool:
    """True if a tip-request was sent to this fan within cooldown_hours (per-fan
    throttle so a repeat mass-buyer isn't nudged every sweep). 0 → never throttle."""
    if cooldown_hours <= 0:
        return False
    at = fan_state(fan, _STATE_KEY).get("at")
    if not at:
        return False
    try:
        last = datetime.fromisoformat(at)
    except Exception:
        return False
    return (datetime.utcnow() - last) < timedelta(hours=max(1, int(cooldown_hours)))


async def _mass_buyers_no_reply(
    account_id: str, *, ready_before: datetime, fresh_after: datetime,
) -> dict[int, datetime]:
    """{fan_id: last_mass_purchase_at} for fans who bought a MASS PPV in the
    window [fresh_after, ready_before] AND have sent NO inbound message since
    that purchase (they went quiet after buying)."""
    async with get_session() as s:
        bought_rows = (await s.execute(
            select(Message.fan_id, func.max(Message.purchased_at))
            .where(
                Message.account_id == str(account_id),
                Message.direction == "out",
                Message.mass_run_id.is_not(None),
                Message.is_paid.is_(True),
                Message.purchased_at.is_not(None),
                Message.purchased_at <= ready_before,
                Message.purchased_at >= fresh_after,
            )
            .group_by(Message.fan_id)
        )).all()
        cand = {int(fid): dt for fid, dt in bought_rows if fid is not None and dt is not None}
        if not cand:
            return {}
        # Last inbound per candidate — drop anyone who replied after buying.
        last_in = {
            int(fid): dt for fid, dt in (await s.execute(
                select(Message.fan_id, func.max(Message.created_at))
                .where(
                    Message.account_id == str(account_id),
                    Message.fan_id.in_(list(cand.keys())),
                    Message.direction == "in",
                )
                .group_by(Message.fan_id)
            )).all() if fid is not None
        }
    return {
        fid: bought_at for fid, bought_at in cand.items()
        if not (last_in.get(fid) and last_in[fid] > bought_at)
    }


@register("tip_request")
async def run(account_id: str, payload: dict, *, run_id: int) -> dict:
    """Sweep quiet mass-buyers and send each the global tip-request teaser.

    payload:
      • dry_run   — resolve candidates + eligibility, send nothing.
      • fan_id    — scope to ONE fan and bypass the window/reply gates (manual
                    test / operator "send now"); still honours dry_run.
      • force     — with fan_id, also bypass skip-list / guard / cooldown.
    """
    payload = payload or {}
    dry_run = bool(payload.get("dry_run"))
    force = bool(payload.get("force"))
    only_fan = payload.get("fan_id")

    cfg = await _load_config(account_id)
    pool = _teaser_pool(cfg)
    if not cfg.get("enabled") and not force:
        return {"status": "skipped", "reason": "disabled"}
    if not pool:
        return {"status": "skipped", "reason": "no_media_id"}

    caption = apply_word_restriction(str(cfg.get("caption") or ""))
    cooldown_h = int(cfg.get("cooldown_hours") or 0)
    limit = max(1, int(cfg.get("limit") or 200))
    now = datetime.utcnow()

    # ── Candidate set ────────────────────────────────────────────────
    if only_fan is not None:
        # Fan-scoped (manual / force): bypass the window + reply gates.
        candidates: dict[int, datetime] = {int(only_fan): now}
    else:
        min_wait_h = max(0, int(cfg.get("min_wait_hours") or 0))
        max_age_h = max(1, int(cfg.get("max_age_hours") or 48))
        candidates = await _mass_buyers_no_reply(
            account_id,
            ready_before=now - timedelta(hours=min_wait_h),
            fresh_after=now - timedelta(hours=max_age_h),
        )
    # Include-only audience: gate the sweep; the fan-scoped manual/force path
    # above is operator-explicit targeting and stays exempt (like force_ids).
    import audience_include as _audiences
    audience_stats: dict = {}
    if only_fan is None:
        _kept = set(await _audiences.filter_candidates(
            account_id, list(candidates), kind="tip_request",
            stats=audience_stats))
        candidates = {fid: t for fid, t in candidates.items() if fid in _kept}
    if not candidates:
        return {"status": "ok", "reason": "no_candidates", "sent": 0,
                **audience_stats}

    # ── Eligibility sets (skip-list + cross-automation contact guard) ─
    hard_skip: set[int] = set() if force else await load_hard_skip_ids(account_id)
    guard_ids: set[int] = set()
    if not force:
        guard_h = int(cfg.get("guard_hours") or 0)
        if guard_h > 0:
            guard_ids = await contact_guard_excludes(account_id, outbound_hours=guard_h)

    sent = skipped = errors = 0
    client = None

    for fid in candidates:
        if sent >= limit:
            break
        async with get_session() as s:
            fan = await s.get(Fan, (str(account_id), int(fid)))

        # ⚠️ DELIBERATELY OUTSIDE THE `force` BYPASS, AND THE ONLY CHECK HERE THAT IS.
        #
        # Everything below is a THROTTLE — a cooldown, a contact guard, an
        # operator stop — and `force` exists to let a human overrule a throttle.
        # This is not a throttle. He has paid for a voice note that has not been
        # recorded yet, and asking him for money again is the failure the customs
        # lane was built to prevent; a `force` that quietly re-enabled it would put
        # the one un-overridable rule behind the one flag that overrides
        # everything. The way to tip-ask this fan is to deliver his custom and
        # clear him on /customs, which takes one click.
        #
        # No query: the loop already holds his `Fan` row, so this is the same
        # `is_owed` the chat engines read, not the audience-set variant the blast
        # lanes need.
        if _customs.is_owed(fan):
            skipped += 1
            continue

        if not force:
            if fid in hard_skip or should_skip_muted_creator(fan):
                skipped += 1
                continue
            if fid in guard_ids:
                skipped += 1
                continue
            if _cooled_down(fan, cooldown_h):
                skipped += 1
                continue

        if dry_run:
            sent += 1
            continue

        if client is None:
            client = await asyncio.to_thread(ax._make_client, account_id)
        media_id = random.choice(pool)   # per-fan pick, so the pool rotates
        try:
            result = await asyncio.to_thread(
                lambda fid=int(fid), mid=media_id:
                    client.send_message(fid, caption, media_files=[mid], price=0)
            )
        except Exception:
            log.warning("tip_request send failed account=%s fan=%s",
                        account_id, fid, exc_info=True)
            errors += 1
            continue

        msg_id = result.get("id") if isinstance(result, dict) else None
        ts = datetime.utcnow()
        if msg_id:
            await write_outbound_attribution(
                account_id=account_id, fan_id=int(fid), message_id=int(msg_id),
                sent_by_employee_id=None, body=caption, price_cents=0,
                created_at=ts, automation_kind=_AUTOMATION_KIND, emit_live=True,
            )
        # Stamp the per-fan cooldown so the next sweep doesn't re-nudge. Own
        # session; best-effort (the send already happened).
        try:
            async with get_session() as s:
                fan = await s.get(Fan, (str(account_id), int(fid)))
                if fan is not None:
                    put_fan_state(fan, _STATE_KEY, {"at": ts.isoformat()})
        except Exception:
            log.debug("tip_request cooldown stamp failed account=%s fan=%s",
                      account_id, fid, exc_info=True)
        sent += 1
        log.info("tip_request sent account=%s fan=%s media=%s msg=%s",
                 account_id, fid, media_id, msg_id)

    return {"status": "ok", "sent": sent, "skipped": skipped, "errors": errors,
            "candidates": len(candidates), "dry_run": dry_run, **audience_stats}
