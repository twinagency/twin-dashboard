"""service/automations/autoreply.py — Automation: autoreply ("Auto Convo").

CONTINUE the chat when the team didn't reply fast enough. When a KNOWN, LOW-SPEND
fan MESSAGED and nobody (team or AI) answered within the window (default 5 min –
3 h), send ONE casual, **never-PPV** reply — tone-matched to the recent messages,
just keeping the conversation going. It does NOT gather info (we already know him)
and it does NOT sell. After the window it's too stale → send_followup's drip owns
it (26h+).

How it stays out of the other senders' way (timing, not trigger):
  • welcome_chatter_for_info / ai_chatter answer their fans within SECONDS (webhook) — so by
    silence_min those fans aren't waiting. Auto Convo only catches fans no one
    covered in time (graduated / team-owned / AI not enabled for them).
  • send_followup re-engages much later (26h+).

Eligibility (ALL must hold; every knob is per-account in autoreply_config_json):
  1. enabled + not in quiet hours
  2. the FAN spoke last (an unanswered inbound) and the wait (now − his last
     inbound) is in [silence_min, silence_max] — the team didn't reply in time.
     With an optional step-in RANGE (step_in_max_minutes > silence_min) the
     floor is instead drawn per (fan, message) in [silence_min, step_in_max],
     deterministically, so the reply lag stops looking like a fixed timer.
  3. info-complete (≥75% bio bar — a fan we actually know)
  4. lifetime spend < max_lifetime_spend_cents  AND  spend in the last
     recent_spend_days < max_recent_spend_cents   (low spenders only)
  5. days since last purchase ≥ min_days_since_purchase (never-bought = ∞ → pass)
  6. days since first chat/subscribe ≥ min_days_since_first_chat (established)
  7. not blacklisted, not on automation_paused_until (a human is in the chat)
  8. not already covered this wait (max_nudges per his message, min_gap apart) —
     and re-checked at send time that he's STILL waiting (AutoreplyState).

Like nudge_online, this NEVER sets fans.automation_paused_until (it gates on its
own AutoreplyState), so the chat engines are never frozen by it. Self-
registers via @register("autoreply"); schedule with an automation_rules row
(kind="autoreply", trigger_json={"every_seconds": N}).
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

import automation_executor as ax
import llm_client
from ._persona import compose_persona
from . import _language
# 🚫 no `_pins` import — pins unwired 2026-08-15, ruling in `_pins.py`'s docstring.
from . import _customs
from . import _voice  # whose voice this account writes in (NULL → 'her')
from . import _sell_signal  # the model's own "he asked to buy" line (ARMED, OR)
from . import sell_lane  # THE gate every priced send passes through
from attribution import write_outbound_attribution
from automation_registry import register
from db.engine import get_session
from db.models import (
    AccountAiConfig, AutoreplyState, Blacklist, Fan, Message, SkipList, Transaction,
)
from llm_client import LLMCapExceeded
from ._common import (
    BIO_CONSISTENCY_GUARDRAIL,
    # PAINFUL_TEXTING / LIVE_PROOF_GUARDRAIL are NOT imported here: both vary by
    # creator voice, so this engine reads them off `_voice.blocks(...)` instead.
    # `_common` still exports the female lane for the engines that don't.
    NO_NARRATION_RULE, ONPLATFORM_GUARDRAIL,
    STYLE_3LINE, STYLE_MAX_BUBBLES,
    NONNATIVE_OUTPUTS, NONNATIVE_REGISTER, apply_nonnative_spacing, apply_nonnative_style, apply_word_restriction,
    build_tip_ask_block, hold_with_typing, apply_typo_throttle, is_content_ask,
    load_nonnative_flags, load_spacing_flags, load_voice_blocks,
    load_painful_texting_flag,
    load_strip_emojis, load_style_flags, load_tip_ask_config,
    load_typing_indicator, load_typing_wpm, load_typo_flags, load_hard_skip_ids,
    load_promo_spam_ids,
    recent_payer_fans, resolve_fan_name, resolve_model, should_skip_muted_creator,
    skip_unreachable_fan, typing_delay_seconds,
)
from ._wordfilter import (  # compliance word filter
    banned_hit_summary, filter_banned, load_banned_words,
)
from ._clock import clock_block, clock_line, load_clock_tz
from automations._outbound import finalize_draft
from .welcome_chatter_for_info import (_is_info_complete, _strip_html,
                         split_for_bubbles, _dedupe_lead_reaction)

log = logging.getLogger("of-relay.automation.autoreply")

_PURPOSE = "autoreply"
_DEFAULT_LIMIT = 200          # candidate sweep ceiling
_DEFAULT_MAX_SENDS = 25       # per-run send cap
_TEMPERATURE = 0.95
_HISTORY_TAIL = 16            # last N messages handed to the model for tone
_MSG_CLIP = 300
_REPLY_MAX_CHARS = 600


def _defaults() -> dict:
    """Built-in OFF state + sensible knobs (the UI seeds from this)."""
    return {
        "enabled": False,
        "silence_min_minutes": 24,   # give the team this long before stepping in
        "silence_max_minutes": 1115,  # ~18.5h — past this the thread is too stale
        "step_in_max_minutes": 0,    # top of the step-in range; 0 = step in at exactly silence_min
        "max_nudges": 1,
        "min_gap_minutes": 5,        # ≥ this between replies to the same fan
        "max_lifetime_spend_cents": 2_000_000,  # < $20,000 lifetime (whales are the
                                                # closer's; the hot-lead skip owns them)
        "recent_spend_days": 1,
        "max_recent_spend_cents": 50_000,       # < $500 in the window
        "min_days_since_purchase": 0,           # a recent buyer still gets kept warm
        "min_days_since_first_chat": 0,         # brand-new fans included
        "last_n_messages": _HISTORY_TAIL,
        "quiet_hours_json": None,             # [start,end] creator-local; null=24/7
        # When True, don't require a complete profile — just respond from the last
        # few messages + whatever's already been gathered. Widens coverage to fans
        # we don't fully know yet.
        "info_not_required": True,
    }
    # NOTE: the vault-sell permission is deliberately NOT here. It lives in
    # `ai_chatter_config_json` as `autoreply_sell_on_ask`, next to the shelf flags,
    # the offer caps and the qualification gate it depends on — see `run()`.


def _step_in_minutes(cfg: dict, fan_id: int, inbound_at: datetime) -> int:
    """Minutes he must have been waiting before Auto Convo steps in. With a
    step-in RANGE set (step_in_max > silence_min), a per-(fan, message) draw
    in [silence_min, step_in_max] — capped one minute under silence_max so
    the top of the band is still a reachable window — and DETERMINISTIC
    (seeded by fan + his message's second), so every tick sees the same
    number and it re-rolls only when he writes again. step_in_max absent /
    0 / <= silence_min ⇒ exactly silence_min, no rng drawn."""
    lo = int(cfg["silence_min_minutes"])
    hi = min(int(cfg.get("step_in_max_minutes") or 0),
             int(cfg["silence_max_minutes"]) - 1)
    if hi <= lo:
        return lo
    key = inbound_at.replace(microsecond=0).isoformat()
    return random.Random(f"autoreply:{int(fan_id)}:{key}").randint(lo, hi)


async def _load_config(account_id: str) -> dict | None:
    """Per-account gate + knobs; returns the merged config when ENABLED, else None
    (absent/NULL/disabled/bad JSON → OFF, the safe default)."""
    async with get_session() as s:
        row = await s.get(AccountAiConfig, str(account_id))
    stored: dict = {}
    if row is not None and row.autoreply_config_json:
        try:
            stored = json.loads(row.autoreply_config_json) or {}
        except Exception:
            log.warning("bad_autoreply_config account=%s", account_id, exc_info=True)
            stored = {}
    cfg = {**_defaults(), **stored}
    if not cfg.get("enabled"):
        return None
    cfg["_utc_offset"] = int(getattr(row, "utc_offset", 0) or 0) if row else 0
    return cfg


def _sell_turn(last_in: str, at: datetime | None, lang: str, *,
               model_says_ask: bool = False,
               wide_ask: str | None = None) -> sell_lane.Turn:
    """His side of this turn, as the seller reads it.

    ONE place, because `run` now has TWO sale moments — the regex one before the
    generation and the model-only one after the reply lands — and two hand-built
    turns are two chances to judge different words, a different language, or a
    different inbound. Same reason `ai_chatter._sell_turn` exists.

    `fan_spoke_last` / `our_last_at` are left at their defaults on purpose, unlike
    the closer's: every autoreply candidate IS a fan waiting on an unanswered
    inbound (that is the trigger), so the default `True` is not an assumption here.
    (`our_last_at` staying unset is also why the widened readers key on the TEXT of
    our last message and never on its age — see `_sell_signal`.)"""
    return sell_lane.Turn(text=last_in, at=at, lang=lang,
                          model_says_ask=model_says_ask, wide_ask=wide_ask)


def _in_quiet_hours(cfg: dict, now: datetime) -> bool:
    """True if the creator-local hour is inside quiet_hours_json=[start,end].
    null / [0,0] → never quiet (24/7). Mirrors the executor's gate."""
    qh = cfg.get("quiet_hours_json")
    if not qh or not isinstance(qh, (list, tuple)) or len(qh) != 2:
        return False
    start, end = int(qh[0]), int(qh[1])
    if start == end:
        return False
    hour = int((now + timedelta(hours=cfg.get("_utc_offset", 0))).hour)
    return start <= hour < end if start < end else (hour >= start or hour < end)


# ── Re-engagement style variety (controls vibe + shape, never sells) ──
_STYLE_VARIANTS = (
    "answer him directly, then a light tease.",
    "short flirty reply, NO question.",
    "warm + playful, like you've been thinking of him.",
    "vibe sexual? keep it going — one suggestive line, still NO pics/PPV.",
    "two TINY texts on separate lines. 0-1 emoji.",
)


def _build_messages(persona: str, f: Fan, history: list[tuple[str, str]],
                    style: str, style_on: bool = False,
                    nonnative_on: bool = False,
                    content_ask: bool = False,
                    # 🔔 Ask the model to flag a buy-ask the regex may have missed.
                    # Defaults OFF so every other caller (and every test) builds
                    # today's prompt byte-for-byte. See `_sell_signal`.
                    sell_signal: bool = False,
                    tip_ask_block: str = "",
                    custom_owed: bool = False,
                    painful_on: bool = True,
                    lang: str = "en",
                    clock: str = "",
                    v: "_voice.VoiceBlocks" = _voice.HER) -> list[dict]:
    facts = []
    nm = resolve_fan_name(f)
    if nm:
        facts.append(f"name: {nm.split('/')[0][:40]}")
    # `likes` is boobs/ass and nothing else — it exists to route a straight man to
    # the right body content out of a WOMAN's vault, and `gen_info` fills it
    # fleet-wide. On a male account it asserts, inside a facts block the model is
    # told never to contradict, a preference for a body the creator does not have.
    # Dropped for the male lane rather than re-mapped: what a submissive man is
    # into is a different axis entirely and `fetishes` already carries it as free
    # text. Resolved BEFORE the tuple so the lane check is one named decision
    # rather than a branch buried in a literal.
    likes = "" if v.is_male else ("boobs" if f.likes_boobs
                                 else ("ass" if f.likes_ass else ""))
    for label, val in (("age", f.his_age), ("city", f.home_city),
                       ("country", f.home_country), ("job", f.occupation),
                       ("hobbies", f.hobbies), ("recent", f.recent_events),
                       ("likes", likes)):
        if val:
            facts.append(f"{label}: {str(val).strip()[:80]}")
    facts_block = "\n".join(f"- {x}" for x in facts) if facts else "- (not much on file)"
    convo = "\n".join(f"{'FAN' if d == 'in' else 'YOU'}: {b}" for d, b in history if b)

    # He asked to SEE content right now: this is the one case Auto Convo answers
    # with a SALES line instead of pure keep-warm banter — a natural "tip me $X"
    # ask (the tip_reward automation delivers once he tips), NEVER the bare word
    # "tip" (the bug this fixes). Otherwise the usual never-sell rules apply.
    # A paid-for custom that has not shipped outranks every selling surface —
    # the fan already gave us money for something he has not received, so the
    # tip-ask is suppressed in CODE and not merely discouraged in the prompt.
    selling = content_ask and bool(tip_ask_block) and not custom_owed
    directive = tip_ask_block if selling else f"THIS MESSAGE — {style}"
    if selling:
        hard_rules = (
            "HARD RULES:\n"
            "- You already KNOW him — do NOT re-ask his name, age, location, job or "
            "hobbies. Use what you know to make it personal.\n"
            "- Don't apologize for being slow or mention the delay — just reply "
            "naturally, warm and easy, never needy.\n"
            "- SHORT and human: lowercase, contractions, u/ur/ya, 0-1 emoji, vary "
            "your wording. No paragraphs.\n"
            f"{NO_NARRATION_RULE}"
        )
    else:
        # ⚠️ THE NEVER-SELL RULE AND THE CUSTOMS CARVE-OUT ARE THE SAME PROMPT.
        # `v.customs_offer` below says "ONE THING YOU DO OFFER: a paid CUSTOM";
        # this rule said "NEVER offer, mention, or hint at PPV, paid content,
        # pics, or videos". Both rendered, ~30 lines apart, and which one the
        # model obeyed was a coin flip per generation — so week one produced
        # either no customs at all (and the wrong conclusion that customs don't
        # sell) or a violation of the lane's defining rule, with no way to tell
        # from outside which.
        #
        # The ban stays absolute for everything Auto Convo has never sold; the
        # sell_customs branch names the single opted-into exception, so the two
        # rules describe one policy instead of contradicting each other.
        _never_sell = (
            "- NEVER offer or hint at PPV, pics, or anything paid — this is "
            "purely conversation.\n"
            if not v.sell_customs else
            "- NEVER offer or hint at PPV, pics, or anything paid. ONE exception: "
            "a custom voice note (see LIVE PROOF below) if it comes up naturally.\n"
        )
        hard_rules = (
            "HARD RULES:\n"
            f"{_never_sell}"
            "- quietly make him feel like the only one. you KNOW him: never "
            "re-ask name/age/job, use it.\n"
            "- never apologize for the delay, never needy.\n"
            "- match the recent vibe: sexual stays suggestive, casual stays casual.\n"
            "- SHORT: lowercase, u/ur, 0-1 emoji, never reuse a line or emoji from "
            "this chat, no paragraphs.\n"
            f"{NO_NARRATION_RULE}"
        )

    # The prompt clock (clock_block: "" when the account has no tz configured →
    # byte-equal prompt) — same block as welcome_chatter_for_info. A model with
    # no clock invents one.
    system = (
        f"{persona}\n"
        "A fan messaged you — reply to his last message like you just got back "
        "to your phone. 100% human, never a bot.\n\n"
        f"{v.painful_texting + chr(10) + chr(10) if painful_on else ''}"
        f"{clock_block(clock)}"
        f"{directive}\n\n"
        f"{hard_rules}\n"
        f"{ONPLATFORM_GUARDRAIL}\n\n"
        # See `_voice._CUSTOMS_CARVE_OUT`: the offer is its own block so that an
        # engine which renders only the refusal cannot sell. '' unless this
        # account sells customs and this fan clears the bar.
        f"{v.live_proof}{v.customs_offer}\n\n"
        f"{BIO_CONSISTENCY_GUARDRAIL}\n\n"
        # The emoji VOCABULARY is a fact about who the creator is, not a style
        # preference — but it ships inside the humanizer, which is opt-in per
        # automation. An account with `autoreply: false` in style_config therefore
        # had NO emoji guidance at all, and the prompt still asks for emoji, so the
        # model picked the female set. `v.emoji_vocab` is "" for her, so this is a
        # no-op on every female account whichever branch it takes.
        f"{v.humanizer + chr(10) + chr(10) if style_on else v.emoji_vocab}"
        f"{NONNATIVE_REGISTER + chr(10) + chr(10) if nonnative_on else ''}"
        "Your reply is ONLY the message text — no JSON, quotes, or metadata."
        f"{_language.output_language_directive(lang)}"
        f"{_customs.prompt_block(custom_owed, v.voice)}"
        # LAST, and after the output contract it is the sanctioned exception to —
        # same placement as the closer's, so a model that has read one prompt reads
        # the other the same way.
        f"{chr(10) + chr(10) + _sell_signal.BLOCK if sell_signal else ''}"
    )
    user = (
        f"What you know about him:\n{facts_block}\n\n"
        f"Recent conversation (oldest→newest):\n{convo}\n\n"
        "Reply to his last message now, in THIS MESSAGE's style."
    )
    return [{"role": "system", "content": system},
            {"role": "user", "content": user}]


async def _candidates(account_id: str, cfg: dict, now: datetime) -> list[tuple[Fan, datetime]]:
    """[(fan, his_last_inbound_at)] where the FAN spoke last and is STILL WAITING
    on a reply — nobody (team or AI) answered within [silence_min, silence_max].
    That's the "cover a slow team" trigger: give the team `silence_min` to reply,
    and stop after `silence_max` (too stale → send_followup's drip owns it).

    Read from the MESSAGES table (source of truth — Fan.last_message_* lag scrape).
    welcome_chatter_for_info/ai_chatter answer their fans within seconds, so by silence_min those
    aren't waiting; Auto Convo only catches fans no one covered in time. Also gated
    on info-complete + low spend + established + not blacklisted/human-handled."""
    sil_max = int(cfg["silence_max_minutes"])
    horizon = now - timedelta(minutes=sil_max)   # ignore chats quiet longer than max
    first_chat_cut = now - timedelta(days=int(cfg["min_days_since_first_chat"]))

    async with get_session() as s:
        bl = {int(r[0]) for r in (await s.execute(select(Blacklist.fan_id))).all()}
        # The LATEST message per fan within the silence-max horizon (most-recent
        # first; first row seen per fan_id is its latest).
        rows = (await s.execute(
            select(Message.fan_id, Message.direction, Message.created_at)
            .where(Message.account_id == str(account_id),
                   Message.is_unsent.is_(False),
                   Message.created_at >= horizon)
            .order_by(Message.fan_id, Message.created_at.desc(), Message.message_id.desc())
        )).all()
    last: dict[int, tuple[str, datetime]] = {}
    for fid, direction, ts in rows:
        fid = int(fid)
        if fid not in last:
            last[fid] = (direction, ts)
    # Fans where the FAN spoke last (an unanswered inbound) and the wait is in
    # [step-in, max] — i.e. the team hasn't replied fast enough. The step-in
    # floor is `silence_min`, or this fan's own draw when a range is set.
    waiting: dict[int, datetime] = {}
    for fid, (direction, ts) in last.items():
        if direction != "in" or ts is None or fid in bl:
            continue
        wait_min = (now - ts).total_seconds() / 60.0
        if _step_in_minutes(cfg, fid, ts) <= wait_min <= sil_max:
            waiting[fid] = ts
    if not waiting:
        return []

    async with get_session() as s:
        frows = (await s.execute(
            select(Fan).where(
                Fan.account_id == str(account_id),
                Fan.fan_id.in_(list(waiting.keys())),
                Fan.lifetime_spend_cents < int(cfg["max_lifetime_spend_cents"]),
            )
        )).scalars().all()
    out: list[tuple[Fan, datetime]] = []
    for f in frows:
        if f.automation_paused_until and f.automation_paused_until > now:
            continue  # a human is in the chat → stand down
        started = f.subscribed_at or f.created_at
        if started and started > first_chat_cut:
            continue  # established relationship only
        if not cfg.get("info_not_required") and not _is_info_complete(f):
            continue  # known fan only (unless "info not needed" mode is on)
        out.append((f, waiting[int(f.fan_id)]))
    return out


async def _spend_and_last_purchase(account_id: str, fan_ids: list[int],
                                   window_start: datetime) -> dict[int, tuple[int, datetime | None]]:
    """{fan_id: (recent_spend_cents, last_purchase_at)} for the candidate set."""
    out: dict[int, tuple[int, datetime | None]] = {fid: (0, None) for fid in fan_ids}
    if not fan_ids:
        return out
    async with get_session() as s:
        rows = (await s.execute(
            select(Transaction.fan_id, Transaction.amount_cents, Transaction.occurred_at)
            .where(Transaction.account_id == str(account_id),
                   Transaction.fan_id.in_([int(x) for x in fan_ids]))
        )).all()
    for fid, amt, when in rows:
        fid = int(fid)
        recent, last = out.get(fid, (0, None))
        if when is not None and (last is None or when > last):
            last = when
        if when is not None and when >= window_start:
            recent += int(amt or 0)
        out[fid] = (recent, last)
    return out


async def _load_state(account_id: str, fan_id: int) -> AutoreplyState | None:
    async with get_session() as s:
        return await s.get(AutoreplyState, (str(account_id), int(fan_id)))


async def _save_state(account_id: str, fan_id: int, *, spell_inbound_at,
                      nudges_sent: int, last_nudge_at) -> None:
    now = datetime.utcnow()
    vals = dict(account_id=str(account_id), fan_id=int(fan_id),
                spell_inbound_at=spell_inbound_at, nudges_sent=int(nudges_sent),
                last_nudge_at=last_nudge_at, updated_at=now)
    async with get_session() as s:
        await s.execute(
            sqlite_insert(AutoreplyState).values(**vals)
            .on_conflict_do_update(index_elements=["account_id", "fan_id"], set_={
                "spell_inbound_at": spell_inbound_at, "nudges_sent": int(nudges_sent),
                "last_nudge_at": last_nudge_at, "updated_at": now})
        )


async def _history(account_id: str, fan_id: int, tail: int) -> list[tuple[str, str]]:
    async with get_session() as s:
        rows = (await s.execute(
            select(Message.direction, Message.body)
            .where(Message.account_id == str(account_id), Message.fan_id == int(fan_id),
                   Message.is_unsent.is_(False))
            .order_by(Message.created_at.desc(), Message.message_id.desc())
            .limit(tail)
        )).all()
    return [(d, _strip_html(b)[:_MSG_CLIP]) for d, b in reversed(rows)]


async def _fan_still_waiting(account_id: str, fan_id: int, inbound_at) -> bool:
    """Re-validate just before sending: the fan must STILL be waiting — no reply
    (outbound) landed since his last inbound. If the team or welcome_chatter_for_info answered
    in the meantime, stand down (don't double-message). Reads the messages table
    (the truth), not Fan.last_message_sent_at (which lags scrape)."""
    async with get_session() as s:
        row = (await s.execute(
            select(Message.message_id).where(
                Message.account_id == str(account_id), Message.fan_id == int(fan_id),
                Message.direction == "out", Message.is_unsent.is_(False),
                Message.created_at > inbound_at).limit(1)
        )).first()
    return row is None


async def _load_unreachable_ids(account_id: str) -> set[int]:
    """Fans skip-listed 'unreachable' (deleted/blocked — every send 404s and burns
    an LLM call). autoreply otherwise ignores skip_list, but this one reason must
    be honored: the 7d undeliverable pause eventually expires and, without this,
    a widened autoreply would re-generate + re-fail on a dead fan."""
    async with get_session() as s:
        rows = (await s.execute(
            select(SkipList.fan_id).where(SkipList.account_id == str(account_id),
                                          SkipList.reason == "unreachable")
        )).all()
    return {int(r[0]) for r in rows}


@register("autoreply")
async def run(account_id: str, payload: dict, *, run_id: int) -> dict:
    payload = payload or {}
    cfg = await _load_config(account_id)
    if cfg is None:
        return {"enabled": False, "candidates": 0, "sent": 0}
    now = datetime.utcnow()
    if _in_quiet_hours(cfg, now):
        return {"enabled": True, "quiet_hours": True, "candidates": 0, "sent": 0}

    model = await resolve_model(account_id, _PURPOSE, payload.get("model"))
    typing_wpm = await load_typing_wpm(account_id)
    typing_indicator = await load_typing_indicator(account_id)  # live "...is typing"
    style_on = (await load_style_flags(account_id))[_PURPOSE]  # human-style opt-in
    account_lang = await _language.load_account_language(account_id)  # output language + guards
    # Whose voice this account writes in AND whether it may sell customs, as one
    # resolved bundle off ONE row read. Built once per run beside the language for
    # the same reason: both are account-constant and cannot change mid-sweep.
    # NULL → 'her' → every string below renders exactly as it always has.
    voice_blocks = await load_voice_blocks(account_id)
    typo_on = (await load_typo_flags(account_id))[_PURPOSE]    # thumb-typo opt-in
    nonnative_on = (await load_nonnative_flags(account_id))[_PURPOSE]  # non-native opt-in
    # Space-before-"?" — its own tri-state key, read independently but only
    # ever APPLIED inside the non-native block below, so it can narrow that
    # register and never widen it.
    spacing_on = (await load_spacing_flags(account_id))[_PURPOSE]
    painful_on = await load_painful_texting_flag(account_id)  # brevity/emotion framing (default ON)
    strip_emoji_on = await load_strip_emojis(account_id)  # account-wide emoji strip
    max_bubbles = STYLE_MAX_BUBBLES if style_on else 2
    style_pool = _STYLE_VARIANTS + ((STYLE_3LINE,) if style_on else ())
    dry_run = bool(payload.get("dry_run"))
    only = payload.get("only_fan_ids") or payload.get("test_fan")
    only_set = ({int(only)} if isinstance(only, int)
                else {int(x) for x in only} if only else None)
    limit = int(payload.get("limit") or _DEFAULT_LIMIT)
    max_sends = int(payload.get("max_sends") or _DEFAULT_MAX_SENDS)
    tail = int(cfg.get("last_n_messages") or _HISTORY_TAIL)
    max_nudges = int(cfg["max_nudges"])
    # Minimum time between Auto Convo replies to the SAME fan — never faster than
    # min_gap, and never faster than silence_min (so a fan who fires back can't
    # pull instant replies; he waits the same minimum again).
    reply_gap = timedelta(minutes=max(int(cfg["min_gap_minutes"]),
                                      int(cfg["silence_min_minutes"])))

    cands = await _candidates(account_id, cfg, now)  # [(fan, our_last_out_at)]
    if only_set is not None:
        cands = [(f, t) for (f, t) in cands if int(f.fan_id) in only_set]

    # Include-only audience (operator decision O1: autoreply IS gated) — before
    # the [:limit] slice so the fence can't eat the tick's budget, and before
    # any LLM spend.
    import audience_include as _audiences
    audience_stats: dict = {}
    _kept = set(await _audiences.filter_candidates(
        account_id, [int(f.fan_id) for (f, _) in cands], kind="autoreply",
        stats=audience_stats))
    cands = [(f, t) for (f, t) in cands if int(f.fan_id) in _kept][:limit]
    # Nobody waiting → done. Same shape as the disabled / quiet-hours returns,
    # and what makes a 60 s cadence cheap: an empty tick is one messages query
    # plus the audience filter, not ~20 loads and `sell_lane.for_run`.
    if not cands:
        return {"enabled": True, "candidates": 0, "sent": 0, **audience_stats}

    # autoreply gates on automation_paused_until, not skip_list — so load the
    # HARD skips (muted_creator / manual "restrict this fan") explicitly and skip
    # them here too, so a restricted fan is silenced on EVERY automation.
    hard_skip = await load_hard_skip_ids(account_id)
    promo_spam = await load_promo_spam_ids(account_id)
    # The info-complete gate used to ACCIDENTALLY shield no-info / promo /
    # unreachable fans from Auto Convo. With info_not_required widening coverage,
    # those exclusions must be explicit — mirror what every other chat sender does
    # so a widened autoreply never texts a dead fan or peer-creator promo spam.
    # (Mid-funnel fans are NOT excluded here by design — the funnel replies fast,
    # so a fan is never left waiting long enough mid-funnel for Auto Convo to step
    # in; if the funnel stalls, a keep-warm line is preferable to silence.)
    unreachable = await _load_unreachable_ids(account_id)
    cand_ids = [int(f.fan_id) for (f, _) in cands]
    # Hot leads (tip/PPV unlock within RECENT_PAYER_HOURS) belong to the CLOSER,
    # not never-sell Auto Convo — skip them here; ai_chatter owns/sells the moment.
    # Both sides call recent_payer_fans with the SAME (default) window, so the
    # skip-set and the closer's own-set can never diverge.
    hot_leads = await recent_payer_fans(account_id, cand_ids)

    # Spend-window + last-purchase gates (one transactions query for the set).
    win_start = now - timedelta(days=int(cfg["recent_spend_days"]))
    purchase_cut = now - timedelta(days=int(cfg["min_days_since_purchase"]))
    spend = await _spend_and_last_purchase(account_id, cand_ids, win_start)

    persona = await _load_persona(account_id)
    clock_tz = await load_clock_tz(account_id)  # None ⇒ no clock line in the prompt
    banned_words, banned_mode = await load_banned_words(account_id)  # compliance word filter
    # Content-ask tip-ask: when a fan asks to SEE content, Auto Convo answers with a
    # natural "tip me $X" line instead of pure keep-warm banter (tip_reward delivers
    # once he tips), NEVER the bare word "tip". Account-level → build once.
    tip_ask_enabled, tip_amount, tip_template = await load_tip_ask_config(account_id)
    # Off (per-account toggle) → empty block; the content-ask just gets keep-warm
    # banter, no tip-ask.
    # ⚠️ NOT HOISTED. The customs half of this block is a PER-FAN decision
    # (`_customs.may_offer`), so it is built in the loop off the narrowed bundle
    # — pure string assembly, on a path that is about to call an LLM.
    # Double-pitch guard: when ai_chatter (the closer) owns this account, IT handles
    # selling — Auto Convo stays purely keep-warm even on a content-ask.
    ai_chatter_owns = False
    try:
        from .ai_chatter import is_enabled as _ai_chatter_enabled
        ai_chatter_owns = await _ai_chatter_enabled(account_id)
    except Exception:
        log.debug("autoreply ai_chatter gate check failed", exc_info=True)
    # The vault sell lane: config, permission, counter snapshot, budget and tally,
    # all on one object. Its `cfg` is the CLOSER's, and so is the permission key —
    # the shelf switches, the offer caps and the gate it depends on all live there,
    # and two engines reading two copies of a cap is two caps.
    lane = await sell_lane.for_run(account_id, engine=_PURPOSE,
                                   permission_key="autoreply_sell_on_ask")
    # 🔔 The model's own read of "did he ask to buy" — ARMED, OR'd with the regex.
    # Off `lane.cfg` (the CLOSER's blob) for the same reason the shelf flags are:
    # one config owns the selling knobs, and two engines reading two copies of a
    # switch is two switches.
    #
    # ALL THREE CONDITIONS ARE "can this signal possibly act", not preferences —
    # every one of them makes the answer unusable, so asking for it would be a
    # prompt block and a protocol line bought on every reply for nothing:
    #   `ai_chatter_owns` — the closer owns the fan; `content_ask` carries the same
    #                       guard and autoreply's money surfaces both stand down
    #   `lane.on`         — no shelf, no ask-trigger, or no permission: every sale
    #                       refuses `R_DISABLED` before it reads a word he wrote
    signal_on = (not ai_chatter_owns and lane.on
                 and bool(lane.cfg.get("sell_signal_enabled")))

    client = None
    sent = skipped_spend = skipped_cap = skipped_raced = errors = 0
    skipped_restricted = 0   # muted creator / manual "restrict from automations"
    skipped_unreachable = 0  # skip_list 'unreachable' (dead/blocked → send 404s)
    skipped_banned = 0       # compliance word filter tripped in "block" mode
    skipped_spam = 0         # peer-creator promo: creator_we_follow + $0 + no exchange + blasted
    skipped_hot_lead = 0     # tipped/unlocked recently → closer's moment
    skipped_cooldown = 0     # a sibling sender paused him this tick
    skipped_locked = 0       # another sender holds the fan-lease

    for f, inbound_at in cands:
        if sent >= max_sends:
            break
        fid = int(f.fan_id)
        # Durably restricted (muted peer-creator, or hand-restricted) → never reply.
        if fid in hard_skip or should_skip_muted_creator(f):
            skipped_restricted += 1
            continue
        # Dead/blocked fan — sending 404s and burns an LLM call.
        if fid in unreachable:
            skipped_unreachable += 1
            continue
        # Peer-creator promo spam — the jaka problem. Needs real promo evidence,
        # not just OF's creator_we_follow flag (see load_promo_spam_ids).
        if fid in promo_spam:
            skipped_spam += 1
            continue
        # Just-paid hot lead → the closer (ai_chatter) owns the moment, not us.
        if fid in hot_leads:
            skipped_hot_lead += 1
            continue
        recent_spend, last_purchase = spend.get(fid, (0, None))
        # recent spend gate
        if recent_spend >= int(cfg["max_recent_spend_cents"]):
            skipped_spend += 1
            continue
        # days since last purchase ≥ min (never bought → passes)
        if last_purchase is not None and last_purchase > purchase_cut:
            skipped_spend += 1
            continue

        st = await _load_state(account_id, fid)
        # Min cadence: never reply to this fan again within `reply_gap`, even if
        # he re-messages fast (applies ACROSS messages, not just the same one).
        if st is not None and st.last_nudge_at and (now - st.last_nudge_at) < reply_gap:
            skipped_cap += 1
            continue
        # Per-message dedup: don't cover the SAME waiting message twice (a new fan
        # message → new anchor → fresh spell, so it can be covered after the gap).
        spell_anchor = inbound_at
        nudges = int(st.nudges_sent or 0) if (st is not None and st.spell_inbound_at == spell_anchor) else 0
        if nudges >= max_nudges:
            skipped_cap += 1
            continue

        # Re-validate right before sending: he must STILL be waiting (no reply
        # landed since his message — else the team/welcome_chatter_for_info got it first).
        if not await _fan_still_waiting(account_id, fid, inbound_at):
            skipped_raced += 1
            continue

        # Cooldown read + the DB-atomic fan-lease, BEFORE any generation. The lease
        # moved up here from below the LLM call for two reasons that point the same
        # way: it is the cross-engine mutex `sell_lane` requires, and a reply drawn
        # before we hold it is a reply we may throw away — on a selling turn we
        # would pay for a generation the sale replaces. welcome_chatter_for_info and ai_chatter
        # have always taken it in this order; autoreply was the odd one out.
        if await ax.fan_on_cooldown(account_id, fid):
            skipped_cooldown += 1
            continue
        if not await ax.acquire_fan_lease(account_id, fid, _PURPOSE):
            skipped_locked += 1
            continue

        # Everything from here holds the lease — a try/finally guarantees it's
        # released on every non-send path (like welcome_chatter_for_info/ai_chatter)
        # so a future raise can never leak it for the full TTL. autoreply NEVER
        # sets a cooldown (it must not freeze the other senders): on a confirmed
        # send it KEEPS the lease to expire by TTL (no sibling double-messages
        # right after us), on anything else it RELEASES for a faster retry.
        sent_ok = False
        try:
            history = await _history(account_id, fid, tail)
            # He spoke last (the trigger) → his ask is the latest inbound.
            last_in = next((b for d, b in reversed(history) if d == "in"), "")
            # Per-fan language: fans.language (manual pin or gen_info detection)
            # overrides the account default; unset → account default.
            fan_lang = _language.resolve_language(account_lang,
                                                  getattr(f, "language", None))
            # Tip-ask only when the closer doesn't own the account (the double-pitch
            # guard above) — and the same test arms the vault sale below, so the two
            # money surfaces can never both fire on one turn.
            content_ask = ((not ai_chatter_owns)
                           and _language.is_content_ask(last_in, fan_lang))
            # 🚨 THE VAULT TRIGGER IS ITS OWN VARIABLE, and `content_ask` must stay
            # narrow. `content_ask` also reaches `_build_messages`, where it swaps
            # the whole system prompt for the tip-ask sales one — so folding "how
            # much?" or a bare "yes" into it would make an agreement fire a TIP
            # pitch, which is the regression the widened readers exist to avoid.
            # Same split ai_chatter keeps between `content_ask` and `vault_ask`.
            _wide = (None if ai_chatter_owns else
                     lane.wide_ask(last_in, _sell_signal.last_outbound(history),
                                   lang=fan_lang, fan_id=fid))
            vault_ask = content_ask or bool(_wide)

            if client is None:
                try:
                    client = await asyncio.to_thread(ax._make_client, account_id)
                except Exception:
                    log.warning("autoreply client init failed account=%s", account_id,
                                exc_info=True)
                    break

            # ── He asked to SEE something. Sell him that, from the vault ──
            #
            # Auto Convo has been never-PPV since it shipped, and the reason was
            # sound: it is a keep-warm layer with no seller's brakes of its own, so
            # anything it sold would be sold blind. `sell_lane` IS those brakes, so
            # the rule is now "never sells UNGUARDED" instead of "never sells" —
            # which matters most on the accounts that run Auto Convo with no closer
            # at all, where a content ask has never had any path to a sale.
            #
            # A sale REPLACES this turn's banter (he gets the priced answer to what
            # he typed, not that plus "so what are u up to") and COUNTS as a send:
            # `sent` is what `max_sends` bounds, so a sale that skipped it would let
            # one run ship its whole reply budget plus unbounded priced PPVs.
            if vault_ask and await lane.sell(
                    client, fid, _sell_turn(last_in, inbound_at, fan_lang,
                                            wide_ask=_wide),
                    fan=f, dry_run=dry_run):
                sent += 1
                sent_ok = True   # a priced send IS a send: keep the lease to TTL
                await _save_state(account_id, fid, spell_inbound_at=spell_anchor,
                                  nudges_sent=nudges + 1,
                                  last_nudge_at=datetime.utcnow())
                continue

            style = random.choice(style_pool)
            # The bundle narrowed to THIS fan: a custom is only mentioned to a man
            # who has proven he pays. Below the bar the permission and its price
            # band come out of every block that carries them — `customs_offer`
            # and the tip-ask. (`live_proof` used to be one of them; the offer
            # now has its own block — see `_voice._CUSTOMS_CARVE_OUT`.)
            v = _voice.for_fan(voice_blocks, f)
            tip_ask_block = (build_tip_ask_block(tip_amount, tip_template,
                                                v.sell_customs)
                             if tip_ask_enabled else "")
            msgs = _build_messages(persona, f, history, style, style_on=style_on,
                                   nonnative_on=nonnative_on, lang=fan_lang,
                                   content_ask=content_ask,
                                   sell_signal=signal_on,
                                   tip_ask_block=tip_ask_block,
                                   painful_on=painful_on, clock=clock_line(clock_tz),
                                   v=v,
                                   custom_owed=_customs.is_owed(f))
            try:
                res = await llm_client.chat(model=model, messages=msgs, purpose=_PURPOSE,
                                            account_id=account_id, fan_id=fid,
                                            temperature=_TEMPERATURE)
            except LLMCapExceeded:
                log.warning("autoreply LLM cap reached account=%s — stopping", account_id)
                break
            except Exception:
                errors += 1
                log.warning("autoreply generate failed account=%s fan=%s", account_id, fid,
                            exc_info=True)
                continue

            raw = (res.content or "").strip()
            # 🔔 The model's "he asked to buy" line. ALWAYS stripped — even with the
            # block off — because a model that has seen the protocol once in a
            # prefix-cached conversation can emit it later unprompted, and a fan must
            # never read "SELL: yes". Same discipline as the closer's marker parse.
            raw, _model_ask = _sell_signal.parse(raw)
            # 🔔 FOR THE RECORD, on every reply the model wrote — the disagreement
            # rates between the two readers are the whole point of arming this, and
            # they are only comparable across engines if both log on the same event.
            # `record`, not `decide`: the OR is not what acts here (see below), and a
            # `decide` whose verdict is thrown away reads like a bug.
            if signal_on:
                _sell_signal.record(regex_says=vault_ask, model_says=_model_ask,
                                    account_id=account_id, fan_id=fid,
                                    engine=_PURPOSE, via=_wide)
            # …and what acts is the model-ONLY case, which is the recall this exists
            # for. `vault_ask` is not an OR here but a BAR: the deterministic path
            # already took its shot above and `continue`d on success, so reaching
            # this line with it True means that sale was REFUSED (caps, no matching
            # media) — and a refused ask must not be re-attempted on the same
            # inbound. `sell_lane` memoes and counts it exactly once. It reads
            # `vault_ask`, NOT `content_ask`: since the widened readers can take
            # that first shot too, barring on the narrow one would re-attempt every
            # refused "how much?" seconds later.
            model_added_ask = signal_on and _model_ask and not vault_ask
            # Deterministic floor under ONPLATFORM_GUARDRAIL: if the model still leaked
            # a number / off-platform handle / meetup arrangement, swap for a deflection.
            # The shared send chokepoint (_outbound): off-platform guard, then the
            # account-wide emoji strip, before the split. No PHASE 2 consistency check
            # — autoreply does not implement it, which is why there is no
            # `consistency_autoreply` flag to switch on (see _common.CONSISTENCY_AUTOMATIONS).
            raw, _leak = await finalize_draft(
                raw, account_id=account_id, fan_id=fid, purpose=_PURPOSE,
                strip_emoji=strip_emoji_on, v=v)
            parts = [apply_word_restriction(p)[:_REPLY_MAX_CHARS]
                     for p in split_for_bubbles(raw, max_bubbles,
                                                rng=random.Random(f"split:{f.fan_id}:{raw}"))
                     if p.strip()][:max_bubbles]
            # Don't open with the same reaction word we just used ('oof' every send).
            if style_on and parts:
                parts = _dedupe_lead_reaction(parts, [b for d, b in history if d == "out"])
            if not parts:
                errors += 1
                continue
            # Compliance word filter — before the nonnative/typo layers
            # (filter_banned's documented contract), so a typo can't smuggle a
            # flagged word past the scan.
            parts, _bw = filter_banned(parts, banned_words, banned_mode)
            if parts is None:
                skipped_banned += 1
                log.warning("autoreply BLOCKED reply — banned word(s) %r account=%s fan=%s",
                            banned_hit_summary(_bw), account_id, fid)
                continue
            if _bw:
                log.info("autoreply masked banned word(s) %r account=%s fan=%s",
                         banned_hit_summary(_bw), account_id, fid)
            name_protect = [n for n in (f.real_name, f.generated_nickname,
                                        f.of_display_name) if n]
            if nonnative_on:  # opt-in: deterministic non-native misspellings (always)
                # ONE rng for the whole reply — see apply_nonnative_spacing.
                _q_rng = random.Random(f"{f.fan_id}:{raw}:q")
                parts = [apply_nonnative_style(p, protect=name_protect)
                         for p in parts]
                if spacing_on:
                    parts = [apply_nonnative_spacing(p, _q_rng) for p in parts]
            if typo_on:  # opt-in: a realistic thumb-slip (+ a throttled "*fix" bubble)
                protect = name_protect + (list(NONNATIVE_OUTPUTS) if nonnative_on else [])
                parts = await apply_typo_throttle(
                    account_id, f.fan_id, parts, random.Random(f"{f.fan_id}:{raw}"),
                    protect=protect, max_bubbles=max_bubbles)
            if dry_run:
                sent += 1
                continue

            # Re-check after the generation: the LLM call can take longer than a
            # sibling's short (10-15s) cooldown, so someone may have answered him
            # while we drew the reply. If he's no longer waiting, stand down.
            if not await _fan_still_waiting(account_id, fid, inbound_at):
                skipped_raced += 1
                continue

            for idx, part in enumerate(parts):
                await hold_with_typing(account_id, fid,
                                       typing_delay_seconds(part, typing_wpm),
                                       typing_indicator=typing_indicator)  # "typing"
                try:
                    result = await asyncio.to_thread(client.send_message, fid, part)
                except Exception as e:
                    errors += 1
                    # Permanent (deleted/blocked) → quarantine, so the next tick's
                    # paused-gate drops the fan BEFORE the LLM call. Transients retry.
                    await skip_unreachable_fan(account_id, fid, e, log=log)
                    log.warning("autoreply send failed account=%s fan=%s", account_id, fid,
                                exc_info=True)
                    break
                mid = result.get("id") if isinstance(result, dict) else None
                if mid:
                    await write_outbound_attribution(
                        account_id=account_id, fan_id=fid, message_id=int(mid),
                        sent_by_employee_id=None, automation_kind=_PURPOSE,  # autoreply
                        body=str(result.get("text") or part),
                        price_cents=0,
                        created_at=ax._parse_iso(result.get("createdAt")) or datetime.utcnow(),
                        emit_live=True,
                    )
                    sent_ok = True
            if sent_ok:
                await _save_state(account_id, fid, spell_inbound_at=spell_anchor,
                                  nudges_sent=nudges + 1, last_nudge_at=datetime.utcnow())
                sent += 1
                # 🔔 THE MODEL CAUGHT AN ASK THE REGEX MISSED — sell it, AFTER the
                # answer. The other ordering in this loop, and deliberately so:
                #
                #   * regex ask → we knew before generating, so the pack REPLACES the
                #     banter (he gets the priced answer to what he typed, nothing else)
                #   * model ask → we only learned it FROM the draft, so the answer has
                #     already gone out and the pack follows it
                #
                # That second shape is the closer's ("the answer lands before the PPV
                # that answers it"), so a fan reads the same conversation either way:
                # she replies, then the thing he asked for arrives. Waiting for the
                # NEXT turn instead would need the ask to survive in the regex, which
                # is the gap this exists to close.
                #
                # ⚠️ KNOWN, AND NOT WORTH THE RESTRUCTURE: `dry_run` returns above
                # (before the wire) so this branch never runs under it, while the
                # regex sale — which happens before that return — does. A dry-run
                # report therefore UNDERSTATES model-only sales. Reaching it would
                # mean splitting the dry-run early-exit around the whole send block,
                # which buys a diagnostic number at the price of the live path's
                # shape. The live counters (`sold` / `sell_refused`) are unaffected.
                # No `wide_ask` here, and it is not an omission: this branch runs
                # only when `vault_ask` was False, which already means no widened
                # reader fired on this turn.
                if model_added_ask and await lane.sell(
                        client, fid,
                        _sell_turn(last_in, inbound_at, fan_lang,
                                   model_says_ask=True),
                        fan=f, dry_run=dry_run):
                    sent += 1
        finally:
            if not sent_ok:
                await ax.release_fan_lease(account_id, fid)

    return {"enabled": True, "candidates": len(cands), "sent": sent,
            **audience_stats,
            "skipped_spend": skipped_spend, "skipped_cap": skipped_cap,
            "skipped_raced": skipped_raced, "skipped_restricted": skipped_restricted,
            "skipped_unreachable": skipped_unreachable, "skipped_spam": skipped_spam,
            "skipped_hot_lead": skipped_hot_lead, "skipped_cooldown": skipped_cooldown,
            "skipped_locked": skipped_locked, "skipped_banned": skipped_banned,
            **lane.stats,
            "errors": errors, "dry_run": dry_run, "model": model}


async def _load_persona(account_id: str) -> str:
    async with get_session() as s:
        cfg = await s.get(AccountAiConfig, str(account_id))
    return compose_persona(cfg, fallback=(
        "You are a warm, flirty OnlyFans creator texting a fan you've been "
        "chatting with."))
