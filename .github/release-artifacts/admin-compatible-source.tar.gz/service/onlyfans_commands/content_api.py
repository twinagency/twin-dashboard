"""Explicit content-edit credential; no uploads or implicit provider actions."""
import asyncio
import hmac
import json
import os
import re

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from onlyfans_read.contract import ID_PATTERN
from onlyfans_runtime.content_management import get_content, update_content, item_reference, InvalidContent, VersionRequired
from onlyfans_runtime.store import Refused
from .api import unique_keys

SCHEMA = "of-content.v1"
HEADER = "X-OnlyFans-Content-Version"
PREFIX = "/onlyfans/content/v1"
router = APIRouter(prefix=PREFIX, tags=["onlyfans-content"])


def configured():
    token = (os.environ.get("ONLYFANS_CONTENT_TOKEN") or "").strip()
    tenant = (os.environ.get("ONLYFANS_CONTENT_TENANT") or "").strip()
    others = [(os.environ.get(name) or "").strip() for name in (
        "ONLYFANS_API_TOKEN", "ONLYFANS_CONTROL_TOKEN", "ONLYFANS_CONFIGURATION_TOKEN", "ONLYFANS_CAMPAIGN_TOKEN", "ONLYFANS_CONNECTION_TOKEN")]
    if (os.environ.get("ONLYFANS_PROCESS_ROLE") != "api" or not token or tenant == "deployment" or
        not re.fullmatch(r"[A-Za-z0-9._:-]{1,64}", tenant) or
        any(value and hmac.compare_digest(value.encode(), token.encode()) for value in others)):
        return None
    return token, tenant


def response(body, status=200):
    return JSONResponse({"schemaVersion": SCHEMA, **body}, status_code=status,
        headers={"Cache-Control": "private, no-store", HEADER: SCHEMA})


def refuse(code, status, message):
    return response({"ok": False, "code": code, "error": message}, status)


def authenticate_version(request, account_id, item_id, schema):
    """Version-neutral content-purpose credential check.

    Returns (store, tenant) or a (code, status, message) refusal for the
    caller's own contract envelope. item_id=None checks only the account.
    """
    config = configured()
    if config is None:
        return ("content_unavailable", 503, "Content editing is not configured.")
    token, tenant = config
    auth = request.headers.get("authorization", "").split()
    if len(auth) != 2 or auth[0].lower() != "bearer" or not hmac.compare_digest(auth[1].encode(), token.encode()):
        return ("unauthorized", 401, "The content credential was not accepted.")
    if request.headers.get(HEADER) != schema:
        return ("unsupported_schema", 400, "The content contract version is required.")
    try:
        if not ID_PATTERN.fullmatch(account_id):
            raise InvalidContent()
        if item_id is not None:
            item_reference(item_id)
    except InvalidContent:
        return ("invalid_request", 400, "That content reference is invalid.")
    store = getattr(request.app.state, "control_store", None)
    if store is None:
        return ("content_unavailable", 503, "Content editing is unavailable.")
    return store, tenant


def authenticate(request, account_id, item_id):
    context = authenticate_version(request, account_id, item_id, SCHEMA)
    if isinstance(context, tuple) and len(context) == 3:
        return refuse(*context)
    return context


@router.get("/accounts/{account_id}/items/{item_id}")
async def get(request: Request, account_id: str, item_id: str):
    context = authenticate(request, account_id, item_id)
    if isinstance(context, JSONResponse):
        return context
    store, tenant = context
    try:
        data = await asyncio.to_thread(get_content, store, tenant, account_id, item_id)
    except Refused:
        return refuse("not_available", 404, "That content item is not available.")
    except Exception:
        return refuse("content_unavailable", 503, "Content could not be read.")
    return response({"ok": True, "accountId": account_id, "itemId": item_id, "item": data})


@router.post("/accounts/{account_id}/items/{item_id}")
async def post(request: Request, account_id: str, item_id: str):
    context = authenticate(request, account_id, item_id)
    if isinstance(context, JSONResponse):
        return context
    store, tenant = context
    try:
        if request.headers.get("content-type", "").split(";")[0].strip().lower() != "application/json":
            raise ValueError()
        raw = bytearray()
        async for part in request.stream():
            if len(raw) + len(part) > 65536:
                return refuse("request_too_large", 413, "The content request is too large.")
            raw.extend(part)
        body = json.loads(raw, object_pairs_hook=unique_keys,
            parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite")))
        if type(body) is not dict or set(body) != {"patch", "expectedRevision", "expectedFingerprint", "commandKey", "actor"}:
            raise ValueError()
    except (ValueError, TypeError, UnicodeError, RecursionError):
        return refuse("invalid_request", 400, "That content request is invalid.")
    try:
        revision, fingerprint = await asyncio.to_thread(update_content, store, tenant, account_id, item_id,
            patch=body["patch"], expected_revision=body["expectedRevision"], expected_fingerprint=body["expectedFingerprint"],
            command_key=body["commandKey"], actor=body["actor"])
    except VersionRequired as exc:
        return refuse("version_required", 409, str(exc))
    except InvalidContent as exc:
        return refuse("invalid_content", 400, str(exc))
    except Refused as exc:
        if str(exc) in {"scope unavailable", "content unavailable"}:
            return refuse("not_available", 404, "That content item is not available.")
        return refuse("content_conflict", 409, "Content changed. Refresh before saving again.")
    except Exception:
        return refuse("outcome_unconfirmed", 500, "The save outcome is not confirmed. Refresh or retry the same request.")
    return response({"ok": True, "applied": True, "accountId": account_id, "itemId": item_id,
        "commandKey": body["commandKey"], "recordedRevision": revision, "recordedFingerprint": fingerprint})
